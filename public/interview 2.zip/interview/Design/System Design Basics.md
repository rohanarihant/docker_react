System Design Basics

    * IP Address is a unique identifier of a machine
      all  computer connected  to the internet and send the data in terms of bytes to this IP Addresses

    * Types of scaling
        Vertical :-  increasing the ROM and RAM
        Horizontal :- increasing the no of servers
    
    * Destributed System
        it is a system of several processors running on different computers that communicate and co-ordinates the actions by messaging throuth the n/w. sharing a state or working together to achive the goal

    * Process
        when  we compile a JAVA Application it becomes a class file. JAR file is a container of all the class files and this get stored into our file systm. when we launched our app our OS will ccreate a instance of our application into our memory.
        that instance is memory
        Processes running on the machine can communicate each other through the n/w, file sys or memeory.
                problems:-
                    they are not a distributed app
                    Single machine limitation
                    Single points of failure
        
        solution
            if we decouple the processes and put them into a diff machine then they can scale horizontaly and if one of them goes down then other can take the responsibility of our application
            since everything is on the diff machine then n/w in the only way for processes to comm to each other. once the comm is established then they will make sure that the state is shared b/w each other to achieve the common goal.
            if process  don't know about each other then it becomes collection of computers not a distributed system



        # Client Server Architecture


            when we type amazon.com  it will call the DNS server to check the ip address of the webapp
            DNS server will return the IP address 
            when we say our browser/client to send a req  to server  it will send a bytes or character(inn some special format packates)
            when server will get the req, it knows the source IP address and where it needs to send the response to


            server port will be decided by the protocol type
                e.g if HTTP -> 80 and HTTPs -> 8443
            
        
        # Monalithic vs Microservices
            Pros with Monalithic
                easier to design
                simple to deploy
                High performance because no n/w hopes
            
            Cons
                complex over time
                slow startup time
                small changes can effect the entire application
                if a specific service req more resources then entire application needs to be scaled
                monalithic apps will be extremely diff to talk to each other.

        # SOA (service oriented app) made apps talk to each other and sharing data easily
                it allowed app on diff platform to talk to each other easily
                SOA arch achieve this using SOAP protocol, a specification for exchanging structural info and abstraction layer (ESB enterprise service bus)
                ESB is the backbone of SOA
                    problems :-
                        complex
                        expensive
                        difficult to maintain

                
        # Microservices
                mic arch breakdown the app in isolate key func called service to meet a specific and unique business need
                in mic arch we build each component as a seperate loosely coupled service, which may collaborate with each other based on the business requirement


        # Latency vs Throughput
            Latency :- it basically is how long does it takes a data to go from one point of sys from other
            N/W Lat :- how long does it takes your n/w req to go from client to server and back to the client
            machine Lat :- when reading data from memory or disk
                e.g high latency :- video games
                    low latency :- Airline booking

        
        # throughput
            how much amount of work a computer can perform in a given amount of time
            how much mount of data we can transfer from one point to another point in system. can be measure in MBPS/GBPS
            internet download speed is 50mbps. ISP can transfer of content a sec to you over your n/w
            HTTP req per sec

            throughput = load / time taken 
            throughput = work done / time taken 

        # bandwidth
            it comes into play when we are dealing with when data is geting transfered over networks on multiple locations

            resources               bandwidth                   throughput
            low                     high                        low
            high                    low                         low
            high                    high                        high

        # Responce Time
            sometime used interchangebly with latency 

            the time taken betweenn the req sent and the response
                t1 ---> 1 sec
                t2 <---
            
            for good throughput 
            we need good respurces, bandwidth and reponse time


<!-- Performance Metrics of an Application -->

    API response Time
    Throughput of the APIs (in a given ammount of time how many APIs can one application support)
        depends upon the instance
        depends upon the logic written
    Error Occurences
        in some scenarios or edge  cases app is returning an errors
        logs are also showing lot of errors
    Bugs / Defects in the app
        some perticullar input make application to crash
        in that case app is not resilient enough

<!-- Performance Metrics of an Databases -->
    Time taken by various db queries
    
    Number of queries executed per unit of time (or throughput)
        it depends upon the queries and schema, if we have lot of join then it will take huge reponse time and low throughput
        memory, if we have lot of data and the insance on the db has to suppor tthat much memory
        tto protect the data, some snapshot has been taken, replica has to be created, so that DB remain safe and performed

<!-- Performance Metrics of an Cache -->
    Cache :- in memory key value store

    Latency of writing to cache
        if writing is taking so much of time then we can say cache is not performing well.
        reading to cache is content operation
    
    Number of Cache eviction and invalidation
        if the eviction is at good rate and write is happening at a good rate then cache is performing well

    Memory of cache instance
        if we have less memory and we have more keys to be accumulated, then we need to increase the memory size
        if eveiction is not happing at good rate, then we need to decrease he cache save time

    thoughtput
        how many queries happ3ning in a sec
        and how fast the eviction is happening

<!-- Performance Metrics of an Massage Queue -->
    Rate of production and consumption
        the speed at which we push messages to the queue
        the speed at which consumers can pull the messages from the queue.

    Fraction of stale or unprocessed messages
        bad mesages in the queue
        failed messages in the failed queue
        lot of retry happened
        consumers are not able to process the messages
    
    Number of consumers affects bandwidh and throughput

<!-- Performance Metrics of an Workers -->
    there are some workers running eaitther inside the application or outside the app

    some worker whos job is to pick the msg and execute
    some workers is schedule to pick some data from the db perform some operation and update

    Time taken for job completion
    Resources used in processing

<!-- Performance Metrics of an Server Instances -->
    every component(worker, app, db)
        every instance of server req 2 things
            memory/RAM
            cpu

            if the req is too high then we need to have to increase the resources
            if code is not optimal and memory leak issue then we need to review that


<!-- PM Tools -->
    nurelic
    datadog
    



      