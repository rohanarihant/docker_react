# Paradigm
    Programming paradigms are different ways or styles in which a given program or programming language can be organized
    Each paradigm consists of certain structures, features, and opinions about how common programming problems should be tackled.
    Certain paradigms are better suited for certain types of problems, so it makes sense to use different paradigms for different kinds of projects.

    # Imperative Programming
        Imperative programming consists of sets of detailed instructions that are given to the computer to execute in a given order.
        It's called "imperative" because as programmers we dictate exactly what the computer has to do, in a very specific way.
        Imperative programming focuses on describing how a program operates, step by step.
                const nums = [1,4,3,6,7,8,9,2]
                const result = []

                for (let i = 0; i < nums.length; i++) {
                    if (nums[i] > 5) result.push(nums[i])
                }

                console.log(result) // Output: [ 6, 7, 8, 9 ]
        We're being detailed and specific in our instructions, and that's what imperative programming stands for.


    # Procedural Programming
        Procedural programming is a derivation of imperative programming, adding to it the feature of functions (also known as "procedures" or "subroutines").
        In procedural programming, the user is encouraged to subdivide the program execution into functions, as a way of improving modularity and organization.
            e.g :- 
                function pourIngredients() {
                    - Pour flour in a bowl
                    - Pour a couple eggs in the same bowl
                    - Pour some milk in the same bowl
                }

                function mixAndTransferToMold() {
                    - Mix the ingredients
                    - Pour the mix in a mold
                }

                function cookAndLetChill() {
                    - Cook for 35 minutes
                    - Let chill
                }

                pourIngredients()
                mixAndTransferToMold()
                cookAndLetChill()

        That simplification and abstraction is one of the benefits of procedural programming.
        But within the functions, we still got same old imperative code.
    

    # Functional Programming
        In functional programming, functions are treated as first-class citizens,
        meaning that they can be assigned to variables, passed as arguments, and returned from other functions.

        Another key concept is the idea of pure functions. A pure function is one that relies only on its inputs to generate its result. And given the same input, it will always produce the same result. Besides, it produces no side effects (any change outside the function's environment).

            programs written mostly with functions
            idea of code modularity
            the absence of side effects
            identify and separate responsibilities within the codebase
            improves the code maintainability



            const nums = [1,4,3,6,7,8,9,2]                                                    function filterNums() {                              
            const result = [] // External variable                                             const result = [] // Internal variable
            for (let i = 0; i < nums.length; i++) {                                            for (let i = 0; i < nums.length; i++) {
                if (nums[i] > 5) result.push(nums[i])                                               if (nums[i] > 5) result.push(nums[i])
            }                                                                                       }
            console.log(result) // Output: [ 6, 7, 8, 9 ]                                       return result                                           
            const nums = [1,4,3,6,7,8,9,2]                                                     }
                                                                                        console.log(filterNums()) // Output: [ 6, 7, 8, 9 ]
        
    # Declarative Programming
        Declarative programming is all about hiding away complexity and bringing programming languages closer to human language and thinking.
        It's the direct opposite of imperative programming in the sense that the programmer doesn't give instructions about how the computer should execute the task, but rather on what result is needed.

        This will be much clearer with an example. Following the same array filtering story, a declarative approach might be:
            const nums = [1,4,3,6,7,8,9,2]
            console.log(nums.filter(num => num > 5)) // Output: [ 6, 7, 8, 9 ]
        JavaScript's filter, map, reduce and sort functions are good examples of declarative code.

        * the computer processes this information as imperative code anyway.
    
    # Object-Oriented Programming
        One of the most popular programming paradigms is object-oriented programming (OOP).
        
        The core concept of OOP is to separate concerns into entities which are coded as objects.
        Each entity will group a given set of information (properties) and actions (methods) that can be performed by the entity.
        OOP is very useful on large scale projects, as it facilitates code modularity and organization.


        OOP makes heavy usage of classes (which are a way of creating new objects starting out from a blueprint or boilerplate that the programmer sets)Objects that are created from a class are called instances.

                // Create the two classes corresponding to each entity
                    class Cook {
                        constructor constructor (name) {
                            this.name = name
                        }

                        mixAndBake() {
                            - Mix the ingredients
                            - Pour the mix in a mold
                            - Cook for 35 minutes
                        }
                    }

                    class AssistantCook {
                        constructor (name) {
                            this.name = name
                        }

                        pourIngredients() {
                            - Pour flour in a bowl
                            - Pour a couple eggs in the same bowl
                            - Pour some milk in the same bowl
                        }
                        
                        chillTheCake() {
                            - Let chill
                        }
                    }

                    // Instantiate an object from each class
                    const Frank = new Cook('Frank')
                    const Anthony = new AssistantCook('Anthony')

                    // Call the corresponding methods from each instance
                    Anthony.pourIngredients()
                    Frank.mixAndBake()
                    Anthony.chillTheCake()



**Benefits of OOPs**

Encapsulation :- Reduce complexity + increase reusability
Abstraction :- Reduce complexity + isolate imact of change
Inheritence :- Eliminate redundant code
Ploymorphism :- Refactor ugly switch/case statements


**For scalabel and error prone code we need to have Classes**
    Classes set a blueprint to create objects with predefined properties and methods.
    By creating a class, you can later on instantiate (create) objects from that class, that will inherit all the properties and methods that class has.


**Benefit of using Class :- we can use those blueprint to create new objects quicker and more securely then if we did it manually**

# Inheritance
    ability to create classes based on other classes
    we can define a parent class (with certain properties and methods), and then children classes that will inherit from the parent class all the properties and methods that it has

        Some things to keep in mind about inheritance:
            A class can only have one parent class to inherit from. You can't extend multiple classes, though there're are hacks and ways around this.
            You can extend the inheritance chain as much as you want, setting parent, grandparent, great grandparent classes and so on.
            If a child class inherits any properties from a parent class, it must first assign the parent properties calling the super()
                function before assigning its own properties.
            When inheriting, all parent methods and properties will be inherited by the children. We can't decide what to inherit from a parent class
            Children classes can override the parent's properties and methods.


                    class Enemy extends Character {
                        constructor(name, phrase, power, speed) {
                            super(speed)
                            this.name = name
                            this.phrase = phrase
                            this.power = power
                        }
                        sayPhrase = () => console.log(this.phrase)
                        attack = () => console.log(`I'm attacking with a power of ${this.power}!`)
                    }


                    class Alien extends Enemy {
                        constructor (name, phrase, power, speed) {
                            super(name, phrase, power, speed)
                            this.species = "alien"
                        }
                        fly = () => console.log("Zzzzzziiiiiinnnnnggggg!!")
                    }

                    const alien1 = new Alien("Ali", "I'm Ali the alien!", 10, 50)
                    alien1.attack() // output: I'm attacking with a power of 10!


# Encapsulation
     it stands for an object's capacity to "decide" which information it exposes to "the outside" and which it doesn't.
     Encapsulation is implemented through public and private properties and methods.

                class Something {
                    #property;

                    constructor(){
                        this.#property = "test";
                    }

                    #privateMethod() {
                        return 'hello world';
                    }

                    getPrivateMessage() {
                        return this.#property;
                    }
                }

                    const instance = new Something();
                    console.log(instance.property); //=> undefined
                    console.log(instance.privateMethod); //=> undefined
                    console.log(instance.getPrivateMessage()); //=> test
                    console.log(instance.#property); //=> Syntax error


        Encapsulation is useful in cases where we need certain properties or methods for the inner working of the object,
        but we don't want to expose that to the exterior.
        Having private properties/methods ensures we don't "accidentally" expose information we don't want.


# Abstraction
    Abstraction is a principle that says that a class should only represent information that is relevant to the problem's context.
    In plain English, only expose to the outside the properties and methods that you're going to use. If it's not needed, don't expose it.

# Polymorphism
    Polymorphism means "many forms"
    It's the ability of one method to return different values according to certain conditions


    parameter-based. 👌

        const alien2 = new Alien("Lien", "Run for your lives!", 15, 60)
        const bug1 = new Bug("Buggy", "Your debugger doesn't work with me!", 25, 100)

        alien2.sayPhrase() // output: "Run for your lives!"
        bug1.sayPhrase() // output: "Your debugger doesn't work with me!"

        But we can see that when we call the method on different species, we get different results:
        And that's because we passed each class a different parameter at instantiation. That's one kind of polymorphism, 


    Inheritance-based
        class Enemy extends Character {
            constructor(name, phrase, power, speed) {
                super(speed)
                this.name = name
                this.phrase = phrase
                this.power = power
            }
            sayPhrase = () => console.log(this.phrase)
            attack = () => console.log(`I'm attacking with a power of ${this.power}!`)
        }


        class Alien extends Enemy {
            constructor (name, phrase, power, speed) {
                super(name, phrase, power, speed)
                this.species = "alien"
            }
            fly = () => console.log("Zzzzzziiiiiinnnnnggggg!!")
            attack = () => console.log("Now I'm doing a different thing, HA!") // Override the parent method.
        }

        const alien1 = new Alien("Ali", "I'm Ali the alien!", 10, 50)
        alien1.attack() // output: "Now I'm doing a different thing, HA!"

        This implementation is polymorphic because if we commented out the attack method in the Alien class, we would still be able to call it on the object:

        alien1.attack() // output: "I'm attacking with a power of 10!"



# Object Composition
    Object composition is a technique that works as an alternative to inheritance.

        class Enemy extends Character {
            constructor(name, phrase, power, speed) {
                super(speed)
                this.name = name
                this.phrase = phrase
                this.power = power
            }
            sayPhrase = () => console.log(this.phrase)
            attack = () => console.log(`I'm attacking with a power of ${this.power}!`)
            fly = () => console.log("Zzzzzziiiiiinnnnnggggg!!")
        }


        class Alien extends Enemy {
            constructor (name, phrase, power, speed) {
                super(name, phrase, power, speed)
                this.species = "alien"
            }
        }

        class Bug extends Enemy {
            constructor (name, phrase, power, speed) {
                super(name, phrase, power, speed)
                this.species = "bug"
            }
            hide = () => console.log("You can't catch me now!")
        }

        class Robot extends Enemy {
            constructor (name, phrase, power, speed) {
                super(name, phrase, power, speed)
                this.species = "robot"
            }
            transform = () => console.log("Optimus prime!")
            // I don't need the fly method =(
        }

        As you can see, inheritance causes problems when the starting plan we had for our classes changes (which in the real world is pretty much always)Object composition proposes an approach in which objects get properties and methods assigned only as they need them.

            const bug1 = new Bug("Buggy", "Your debugger doesn't work with me!", 25, 100)

            const addFlyingAbility = obj => {
                obj.fly = () => console.log(`Now ${obj.name} can fly!`)
            }

            addFlyingAbility(bug1)
            bug1.fly() // output: "Now Buggy can fly!"