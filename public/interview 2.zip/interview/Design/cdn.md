**CDN**
    A content delivery network (CDN) is a geographically distributed group of servers that caches content close to end users.
    A CDN allows for the quick transfer of assets needed for loading Internet content, including HTML pages, JavaScript files, stylesheets, images, and videos.

    The popularity of CDN services continues to grow, and today the majority of web traffic is served through CDNs

    Problem/Solution  :-
        A properly configured CDN may also help protect websites against some common malicious attacks, such as Distributed Denial of Service (DDOS) attacks.


        <!-- What is a DDoS attack? -->
            A distributed denial-of-service (DDoS) attack is a malicious attempt to disrupt the normal traffic of a targeted server,
            service or network by overwhelming the target or its surrounding infrastructure with a flood of Internet traffic.

            From a high level, a DDoS attack is like an unexpected traffic jam clogging up the highway, preventing regular traffic from arriving at its destination.

            How does a DDoS attack work?

            DDoS attacks are carried out with networks of Internet-connected machines.
            These networks consist of computers and other devices (such as IoT devices)which have been infected with malware,
            allowing them to be controlled remotely by an attacker. These individual devices are referred to as bots (or zombies), and a group of bots is called a botnet.
            Once a botnet has been established, the attacker is able to direct an attack by sending remote instructions to each bot.
            When a victim’s server or network is targeted by the botnet, each bot sends requests to the target’s IP address,
            potentially causing the server or network to become overwhelmed, resulting in a denial-of-service to normal traffic.
            Because each bot is a legitimate Internet device, separating the attack traffic from normal traffic can be difficult.

            What is the process for mitigating a DDoS attack?

                Blackhole routing :- One solution available to virtually all network admins is to create a blackhole route and funnel traffic into that route. In its simplest form, when blackhole filtering is implemented without specific restriction criteria, both legitimate and malicious network traffic is routed to a null route, or blackhole, and dropped from the network.

                Rate limiting :- Limiting the number of requests a server will accept over a certain time window is also a way of mitigating denial-of-service attacks.

                Web application firewall :-  


    What are the benefits of using a CDN?

    1. Improving website load times - 
                By distributing content closer to website visitors by using a nearby CDN server (among other optimizations), visitors experience faster page loading times.
                As visitors are more inclined to click away from a slow-loading site, a CDN can reduce bounce rates and increase the amount of time that people spend on the site.
                In other words, a faster a website means more visitors will stay and stick around longer.

    2. Reducing bandwidth costs - Bandwidth consumption costs for website hosting is a primary expense for websites.
                Through caching and other optimizations, CDNs are able to reduce the amount of data an origin server must provide, thus reducing hosting costs for website owners.
    
    3. Increasing content availability and redundancy - 
                Large amounts of traffic or hardware failures can interrupt normal website function. Thanks to their distributed nature, a CDN can handle more traffic and withstand hardware failure better than many origin servers.
    4. Improving website security - 
                A CDN may improve security by providing DDoS mitigation, improvements to security certificates, and other optimizations.


    How does a CDN work?
            
            A CDN is a network of servers linked together with the goal of delivering content as quickly, cheaply, reliably, and securely as possible.


