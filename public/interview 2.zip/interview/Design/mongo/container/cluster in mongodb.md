# MongoDB cluster inside containers (like Docker)
    This is a standard practice for creating portable, scalable, and manageable database environments

# What is a MongoDB Cluster
    means a replica set or a sharded cluster.
    
    Replica Set: A group of MongoDB servers (nodes) that hold the same data copy.
        This provides high availability; if one node fails, another takes over

    Sharded Cluster: Used for horizontal scaling with large datasets.
        It distributes data across multiple shards (each a replica set)
        It also includes config servers for metadata and mongos routers for directing client requests

# Running a MongoDB Cluster with Docker
    Docker lets you run each MongoDB instance (node) in its own container.
    This is excellent for local development and testing.

    A common approach is using Docker Compose:
        You define all the services (containers) in a docker-compose.yml file

    Create a Docker Network: This allows the containers to communicate with each other by name
    Start MongoDB Instances: Run multiple containers, each with mongod --replSet <setName> to designate them as part of a replica set
    Initiate the Replica Set: Connect to one of the containers and use rs.initiate() in the MongoDB shell. This command links all the nodes together to form the cluster 

    Here are the key Kubernetes concepts used for deploying MongoDB clusters:

        StatefulSet: This is the ideal workload controller for databases. It provides stable, unique network identifiers and stable persistent storage, which is crucial for stateful applications like MongoDB .

        Persistent Volumes (PV) and Persistent Volume Claims (PVC): These decouple storage from the pod's lifecycle. If a pod restarts, the data remains intact on the persistent volume and reattaches to the new pod .

        Headless Service: This service provides DNS entries for each pod in the StatefulSet. This allows MongoDB nodes to discover each other to form the replica set




