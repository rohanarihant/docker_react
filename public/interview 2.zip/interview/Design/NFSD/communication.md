# Poolinng Machanism

    <!-- Short Pooling -->

        do the req and res jobs in a iterative basis, in a interval
        if we wanted something to happen in a realtime

            - short live connection
            - no persistent data
            - less resource utility
            - problem with scale (huge number of req, max of them could be no data response)

        Example of Use Case
            - Real Time system
            - Notifications
            - CricInfo
            - Analysis
            - Version Update
        working
            will req the server apis in intervals for the new data 
            when get the data it will update
            
        things to care
            always handle the error case
            close the interval when done with the pooling otherwise keep on using the resources
            

# Long Pooling
    in long pooling we have to send the req from the client to server
    first req will be triggered and whenn received the data will be returned
    then again req will be sent to server for new response
    it will wait unntil the new data received at server and get updated and return by server
    
# Web Socket
        full duplex communication
        will work on long live TCP connectiton
        Conntinues bi-directional comm
            we dont have to wait, any new data on server or new req on client will send on real time


        <!-- how web socket works -->
            Client -> send handshake req (HTTP upgrade) -> Server 
            it will open the connetion, http will be upgraded using method (101 (changing the n/w status or protocol))  
            once  n/w is opened, then single long live TCP connection is opened
            Bi-directional comm channel will be opened
            when close  the conection, it wiill end the comm channel

            liberaries like  socket.io  and ws (npm  package)
            
            const {server} = require('socket.io');
            const app = express();
            const server = createServer(app);
            const io = new Server(server);

            io.on("connection", (socket) => { // here 'connection is a event'
                console.log('connection established') // will  established a message with  clients
                socket.io('chat message', (msg) => { // 'chat message' is a custom message
                    io.emit('chat message', msg); // will broadcast the message to everyone whoever made a connection
                })
            })
            socket.on('chat message', (msg) => { // connetionn receiving the message from server
                console.log(msg);
            })
            socket.on('disconnect', () => {
                console.log('User disconnected');
            })

            * WSS :- for web coscket twe have a protocol called WS and secure one for tthat is WSS (web socket secure)
            * Framing ;- small msg can go directly, long msg can go in chunks
            * 101 switching protocol


            User Case
                Analyttics
                Fiancial Trading
                Online Gaming
                Collab (google sheet)

            Challenges
                Resource usage (going to use lot of resources)
                each conn is ttcp conn the no of user increases the conn increases
                there  are some conn limits
                Sticky sessions
                    if we have load balancer then we should make sure that req always go to the same server where connn has established
                Authentication
                Firewalls :- thing about the proxy to get allowed the web socket
                Cache layers :- 
                Scaling
                Testing/debugging
                Backward Compatability
                        if ws will nottt work thenn we will have to downgrade our connections to htttp/https for short or long pooling 
                Resource Cleanup :- cleannup our servers
                Connection drops
