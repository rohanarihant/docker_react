# XSS (Cross site scripting)

    if any hacker want to inject any malicious script to our system and executing it. 
    through  url, from  forms, attacker can get my ccredentials or secret information

    Vulnerability :- 
        User session hijacking :- 
            if we are appending a html script into our code using innerHTMl then it will be appended and run some script will be
            which will steel the token etc.
        Unauthorized activity :- send vulnerable content, send wrog, spam message
            using renderingn the scripts it will render and call a method and steel our title and description
        Capturing Keystrocks :- inject script and person can see each keystrock
            script or code can be injected using queryParam and which will run an event on keypress and it  will spy my activties and track the data
        Stealing Critical Info :- capture entire webpage where the payment is happening
            some script can  be passed  and will   replace the important form with some spam form which will steel the info and stell t he critical info 
        Phishing Attack :- using the script inject the form, does something for attacker
            script will took to the other fake url which will steal important information of our data

        Example :- 
            const params = new UrlSearchParams(window.location.search);
            const name = document.get('name');
            document.getElementById('username').innerHTML = `${name}`;

                here script can be passed as a param and get executed. it can steel the token from our cookie.
                or call an enndpoint to steel our data.


    Mitigation :-
        List all possible way to take input
        replace innerHTML with innerText | textContent (will be displayed as a normal string not as a js script)
        Escaping the content using removing the script tags and  replacing it with just a text
        use lib like React which will print the  conetnt as a string not script using {}
        use lib DomPurify which will sanitize the data
            const sanitizedName = DOMPurify.sanitize(name);

        Avoid using eval (to run js code get from form input)
        CSP Headers :- (Content Security Policy)

            Allowed sources :- where you want to load your content like script, image, iframe, css etc
            Script Noncess :- we can have some scripts which will tell which are our script and which are 3rd party
            Report-only mode :- 

            we can uuse a header in content security policy
                res.setHeader(
                    "Content-Security-Policy",
                    "default-src 'self';"            // for all imports
                    "script-src 'self' http://unsecure.com;" // will allow script from own domain and unsecure.com
                    "script-src  'unsafe-inline'" // to run our local  script in  <script> tag
                    "script-src  'self' 'nonce-randomKey'" // to run script only with this randomKey nonce, it can be anything <script nonce="randomKey">
                    "img-src" 'self'
                )




# Iframe Protection
    Vulnerbilities
        Click Hijacking :- we cannn endup in clicking some other event which is getting rendered by iframe and thing ould be dne which you 
        are not supposing
                            not be able to identtify which button or event we are clicking weather iframe or main app
        Data theft :- we can pass data from child(iframe) to parent and parent to child, that can be done very carefully
                      in old browsers the child iframe can access the window obj and throw that the innerHTML or data, cookie can steal
                      butt in modern browser they are not allowed, will get failed to read a named property 'document' from 'window'
        Session & Cookie theft :- iif some data is stolen from storage that can be taken carefully


    Mitigation :- 
        we can use the CSR policy
            frame-ancestors and 
                res.setHeader('Content-Securiity-Policy', "frame-ancestors 'none'") we will not allow our app to append in other app under a iframe

        from parent window to set restriction for child iframe
            sandbox attribute inn the iframe 
            <iframe sandbox="allow-same-origin allow-scripts">
                    allow-same-origin - w/o this resource will be trated as special origin and always fail same-origin-policy
                                        preventing access to data storage/cookies and some js apis
                    allow-scripts - allow scripts to get executed
                    allow-downloads - allow downloading the files with a or aria element
                    allow-modals - allow modals to get executed
                    allow-forms - allow page to submit forms, without this attribute, no validation, no sendinng data to server
                    allow-payment-request - 

            Cookie :- can have secure, httpOnly, sameSite: 'strict'
                    httpOnly
                        Cookies created via JavaScript can't include the HttpOnly flag.
                        You can access existing cookies from JavaScript as well if the HttpOnly flag isn't set.
                        Use the HttpOnly attribute to prevent access to cookie values via JavaScript.
                    
                    secure
                        cookie is going to send if its https
                        cookie with no HttpOnly attribute will not set, can be accessed and modified
                    sameSite
                        if app is navigating from one to another and api are called with another endpoint
                        then cookies will not going to passed


    
# Security Headers
        X-Powered-By :- will tell which server we are using, if we dont want to show that in our response headers
        Referrer-Policy :- when redirecting from onne page to another then it will tell where we got redirected
                    no-referrer - we dont want to tell from where we got redirected
                    no-referrer-when-downgrade - when coming from https to http
                    origin - when want to send only origin
                    origin-when-cross-origin - when moving from linkedin to whatsapp to facebook etc
                    same-origin - send origin path, query-string for same-origin req. donnt send the referrer header for cross-origin req
                    strict-origin - send only the origin when the protocol security level stays the same 
                    strict-origin-when-cross-origin (default) - Send the origin, path, and querystring when performing a same-origin request.
                                For cross-origin requests send the origin (only) when the protocol security level stays same (HTTPS→HTTPS)
                                Don't send the Referer header to less secure destinations (HTTPS→HTTP).
                    unsafe-url - Send the origin, path, and query string when performing any request, regardless of security.

                    <a href="http://example.com" referrerpolicy="origin">…</a>

        X-Content-Type-Options :- res http header used by the server to indicate the response type
                                  this header will allow you to avoid mime (media type) sniffing

                    nosniff :- Blocks a request if the request destination is of type style and the MIME type is not text/css,
                               or of type script and the MIME type is not a JavaScript MIME type.


        X-XSS-Protection :- is a feature that stopped pages from loading when they detected reflected cross-site scripting (XSS) attacks
                    X-XSS-Protection - 0 (dont want)
                    X-XSS-Protection - 1 (want)
                    X-XSS-Protection - 0 (want mode=block) will block the req
                    X-XSS-Protection - 0 (want report=<reporting_uri>) will report the req

        HSTS - HTTP Strict Transport Security
                    if we have https and http req both
                    but with this we can serve our http reqs to https

                    1st req
                        http req from browser to server 
                            server will check and redirect to https
                            and append Strict Transport Security header in the res header

                    next time browser will send the same insecure req http
                    it will checck the header and automaticaly redirect it to https
                    and pass it to server



