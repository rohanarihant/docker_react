throughput
    the number of operation we can do in a perticular time


Kafka is having high throughput

    