**Host web app on sub-route with reverse proxy**
    There are two ways in which we can host the website on the sub-route

        1. If the web application is client-side rendered, we can serve it directly through CDN (content-delivery-network).
        2. If the web application is placed on any server, we can create a reverse proxy through Nginx and serve the application.

    In both cases, we will have to first change the base route in the application so that it can match the sub-route.

        function App() {
            return (
                <BrowserRouter basename="/app">
                    <Routes>
                        <Route path="/" /> {/* 👈 Renders at /app/ */}
                    </Routes>
                </BrowserRouter>
            );
        }
    Basename tells the react application that the base URL of the application is /app and it will render on that.
    Once this is in place, we can create a build of the web application and host it as per our requirements.

**Hosting web application on the CloudFront on sub-route**
    In the S3 bucket, create a sub-folder with the same name as the sub-route i.e. /app, and dump our build files in this folder.

    Then configure the CloudFront to access the files from the origin path /app which notifies the CDN that files from the given folder have to be served.

    Once the configuration at the cloudfront is done, we can configure the domain to point to this CDN URL.

**Host web app on sub-route with reverse proxy using Nginx**
    The second way is to serve the same CDN URL or the static files through the reverse proxy.

    We can configure the Nginx and set that if a sub-route is encountered, then proxy the request to the CDN or the file path.
