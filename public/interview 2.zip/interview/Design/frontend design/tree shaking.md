**What is Tree shaking in JavaScript?**
    also known as unused exports 
    is a proccess of removing unused code from js bundles.

**Why do we need to do the Tree shaking?**   
    it is imp to keep the prod build light as  possible,  so  that it can be downloaded, processed and executed faster.
    in the Comp arch each comp is having unused code that the other comp may not require.
    it may not be used in the whole app, but when included it will increase the bundle size.
    ultilately affecting the performance.
    e.g :- if we have utility file which has utility funcs.

    Even though we are not using the bar function it is included in the final build and it is annotated by the comment /* unused harmony export bar */ stating this is an unused function.

**How does Tree shaking works?**
    This is true since “static” modules are required for tree shaking to function
    Before ES6, The dynamic import of CommonJs module was used which allowed importing files conditionally.
        
        var module;
        if (condition) {
            module = require("foo");
        } else {
            module = require("bar");
        }
    
        but this was a problem for the tree shaking and hurdle to decide which module is getting imported bcz the module is getting imported onrunn time.
        in ES6 modules are getting imported staically at the top of the file.
            import foo from "foo";
                it will really helped to detect the unused code to determine which code is being used just like modern IDEs and linters does the highlighting the unused code in your files.

            the bundler like webpack are so efficient in Tree shaking that they are removing almost all the used imports or codes even properties that are exported but not imported anywhere.
    
        Side effects :-
            There are two types of function pure and impure. Pure functions are predictable as they provide the same output for the same input, thus they can be safely removed as unused code.
            But the impure functions that have side effects, whose outcome is not predictable cannot be removed.
            In the same way, Tree shaking can have side effects and it will have to be mitigated properly.

                    let numbers = [1, 2, 3];
                    console.log(numbers); // (3) [1, 2, 3]
                    const addNumber = function(num) {
                        numbers.push(num);
                    };
                    addNumber(4);
                    console.log(numbers); // (4) [1, 2, 3, 4]
            
            The ES6 modules are also prone to side effects, for example, the use of polyfills, we are not sure when and where the polyfills will be used, thus do we have to remove them or keep them?

                One way to solve this is by hinting to the Webpack that our code is side effects free. To do this add the following property in your package.json
                    // package.json
                    {
                    "sideEffects": false
                    }


            Alternatively, we can alert Webpack about which files have side effects.

                    // package.json
                        {
                        "sideEffects": [
                            "./polyfills.js"
                        ]
                        }