**Optimization**

    Assets :- JS, css and html, node_module how to optimize that.
    build :- 



**Network**

    1. Load JS asynchronously
        using keyword  async in script tag
        using keyword  defer in script tag

    2. Lazy Loading

        <!-- First  technique -->
            to do the job in the parallel of other stuff.
            
            * lazy loading for images, iframe and scripts
            <img loading="lazy">
            <iframe loading="lazy">
                it will going to load these images in an async fashion
            
            
            * eager loading for images, iframe, scripts
            <img loading="eager" />
            <iframe loading="eager" />
                prompt an early download of an asset

        
            * when the browser  assign "High" priority to an image but we dont actually want that
            <img src="" fetchpriority="low" />

            we want to initialize a early fetch of a resource but also depriorities it

        
        <!-- Second  technique -->       

            Intersaction Observer

            web api provided by browser

            this is a machanism we can call the some set of action at  some point in our DOM event

        <!-- Content-visibility -->
            it will set the priority for the thing which are on the visible area it will load those content and rest of the thing not in visible area are loaded in the async/lazy loading way 

            .story {
                content-visibility : auto;
                content-intrinsic-size: 1000px;
            }

        <!-- Serving Critical CSS -->
            <link rel="stylesheet"  href="style.css">
                it will block the rendering until and unless it will load the css
            <link rel="stylesheet" href="full.css" media="print" onClick="this.media='all'"  />
                this is a media type of styles, only used for the printing purpose
                means not critical
                can be downloaded make it available for next rendering
                shouldn't be used for the next rendering or next fold.


**Resource Hinting**
        a way for the developer to tell the browser about what’s likely to happen in the future so that the browser can factor that into its choices for how it loads resources.

        <link rel="preload" href="https://api-my-app.com" />

        Preload :-
            its a technique where we want some perticular file need to be executed in future, so we will pre load them and rennder them whenever needed
            before preload network requests will start after the action to move to nnext step
            after preload the file will get loaded in background and execute it

        prefetch :- 
            in this case files will be loaded behind the scene but not executed in future whenever needed.

        preconnect :-
            it will first do the handshake and whenever in future the need to  execute the code needed then it  will  do
            no need of the handshake to be done here.

        dns-prefetch :-
            it will also do the handshake before same like preconnect but works in the old browsers
        pre-render :- 
            it will pre render the content which is going to  rennder in future  or next page
                e.g: like dashboard  page after the signup
            
            <link rel="pre-render" /> ---> create hidden tabcontents --->  load page including JS execution  ---> throw hidden tab away
                                                                                        |
                                                                                        |
                                                                                        |
                                                                                swap in hidden tab
            
            
    
            




