**Things to consider for innterview**
    Requirement :-
        Functional 
            - Demand/Supply
            - Module Level thinking
                - user mngmt
                - help & support
                - payment gateway
                - pricing & subscription
                - prod listing
                - cart page
                - acc mngmt
            - feature level thinking
        
        Non-Functional Requirement
            - Mobile/Desktop
            - Responsive/Adaptive
            - Internet/Location/Devices
            - Accessibility
            -  Performance (FCP, LCP, TTI, web Vitals)
            - CSR/SSR
            - Authentication/Authorization
            - Security
            - Cahing
            - offline support
            - Logging & Monitoring
            - A/B Testting
            - Internationalization
            Localization
            -verioning
            - pwa
            - CI/CD

    Scoping (Perioritization)
        Functional
            - Demand
            - Module
                - Product Listing
                - cart page
            - Feature
                - search
                - lsiting
                - 
