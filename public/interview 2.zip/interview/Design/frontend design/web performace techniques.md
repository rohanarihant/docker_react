web performace techniques


    LCP (Loading Contentful paint) (Loading)
        it will load the static content like js, css, images etc
        it should range b/w 2 - 2.5 sec 
        beyong 4 sec is poor and need to improve
        Bad LCP = Bad SEO
    
            to improve this we need to do
                1. Reduce Resource Load Time
                    make sure that images are compressed and preffer to use the modern format like webp and avif etc.
                    use bear minnimum number of fonts to render the  page
                
                2. CDN
                    prefer to store that content in diff region CDN
                3. Blocking JS
                    render blocking JS
                    if we want run any js code before render anything to browser it delay our CP.
                    prefer SSR in that case
                    because in SPA it will run buncch of code to render the content 
                4. Preload
                    we can optimize resource priority by using preload links to make sure that assets are discovered first
                    also can add fetchpriority in the images to set the priority as high or low

    FID (First Input Delay) (Ineractivity)
        web app should have 100ms or less FID 
        and if it has more than 300ms then it will be worse.
        getting calculated when user interact with the button and time taken by event handlers to procecss them
            improve by reducing the JS execution time
            cann add workers in the JS code
            or use lazy loading of react to lazy load the code

    CLS (cumalative layout shift) (Visual Stability)
        it measure visual stability
        element on the page shouldnt be jumping around in unexpected ways
            checkc and improve this my lighhouse web dev tool or web vital extension 
                if we are havong images w/o extensions, but they should have width and height
                or use css aspect-ratio property, aspect-ratio: 69/420;
                or you can use (srcset) to use diff images unnder diff conditions
                    srcset="img-480w.jpg 480w, img-800w.jpg 800w"
                    sizes="(max-width: 600px) 480px, 800px"


    Tools to improve the web performance
        web Vitals (JS extension)
            will share the web performace in diff metriccs and for diiff view of the page

        Unnlighthouse
            open source tool that runs the google lighthouse tools for every page of your app.
        GTMetrix

            Performace Metrix
                1. First Conentful Page
                    how quickly content like text annd images are painted onto our page.
                    good to be loaded less then 900ms
                2. Time to Interactive
                    how long it takes for your page to become fully interactive
                    a good user exp is 2.5 or less
                3. Speed Index
                    how quickly the content of you page is visibly populated
                    good UE is 1.3 or less
                4. Total Blocking Time
                    time blocked by scripts during your page loading process.
                    good UE is 150ms or less
                5. Largest Contentful Paint
                    ttime talken for the largest element of content(e.g - Banner Image) to be painted on page
                    should be 1.2 sec or less
                6. cumalative layout shift
                    How much your page layout shift as it loads
                        score should be less then 0.1
                    

