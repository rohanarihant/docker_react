<!-- MOST COMMON HEADERS  -->

Accept: application/json
User-agent: req origin (postman, browser type)
Authorization
Content-Type: Images, pdf
Cookie
Cache-Control



<!-- CORS -->
Access-Control-Allow-Origin
Access-Control-Allow-Credentials
Access-Control-Allow-Method

<!-- Security -->
Cross-Origin-Embedder-Policy
Cross-Origin-Opener-Policy
Cross-Security-Policy
X-XSS-Protection
