**HTTP Methods**

Basics of operations that can be used to protect with server.

GET :-  retrive a resource
HEAD :- no msg body (res headers only)
OPTIONS:- what operations are available (what are the permitted comm option for given resource or serve, for server will have to send *)
TRACE :- loopback test 
DELETE :-
PUT :-
POST :-
PATCH :-


HEAD :-
    req a header w/o body, it is same as GET but w/o res body
    itt will return only headers same as GET req.

    Need :- reason behind this is again performance.
    e.g :- if we want to decide before downloading large file. if file is too large, we won't want it.
            in this case we need to check size of res or file. only headers can give you that info.
            content-length : 122234 (values in bytes)
        Attempt to save bandwidth


OPTIONS :-
    a method to req comm options for the res identified by URI.
    doesnt invoke any action or an operation on resource, but it provide necessary info for comm with the resource.
    res of this method doesn't content res body, but we can add body to make more informative, only if server support
    for server info we need to add *, it will return options about server.
        info about resource :- https://www.abc.com/users/123 
        info about server :- https://www.abc.com/* 


<!-- -------------------------------------------------------------------------------------------------------------------------------->
Safe Methods:- 
    Method is Safe, if req doesn't alter the state of server.
    Read is operations consider to be safe.
    client doesn't req  any change, but just ask for info so, req shoudln't introduce any side effect or load on server, also it should not trigger any external calls.
    there is no any restriction imposed by server for get method for creation of load.
    Developers shouldn't allow to do any operation that is not safe with SAFE methods

    e.g :-
        GET and HEAD is considered to be safe.
        developer need  to make sure that GET and HEAD methods 
            dont alter a state of server
            intro any side effect
            Dont call external sys

Idempotent Methods :-

    are methods, that doesn't matter how many times you call with identical req, it will generate same results.

    it means if you are calling the same methods repitedly then you resource should not be changeable.
    e.g GET, DELETE, PUT
        if you delete or update a resource once then again retry will not make any impact on resource
    
    *Idempotent vs Safe
        can be called multiple times w/o changing the responses
        but safe methods doesn't change the resource, meaning it may read but not write.

Cacheable Methods :-
    Response of req can be cacheable (it can be stored and used later)
    nnot all method res can be cacheable
    some methods such as GET, HEAD are cacheable, and some res codes are cacheable
    Ideally, a req that has both Cacheable req and Cacheable res code is eligible for caching.


