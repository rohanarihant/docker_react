Fault :-
    is something which is sort of beyond our control and result of this fault, failure occur where customer can't be served.

    failure handling in the whole system will be handled in the multiple ways

    Tolerating the fault :-

    Types of Faults in distributed systems :-
    1. network faults :- 
        n/w timeout, h/w issue, system running out of memory, sys is running out of CPU, human errors

    understand the type of fault
    tolerate the fault
    making system fault safe


    for H/W faults
        we cann have multiple instances of app servers

    for code Bug faults
        we can write the unit test cases
        peoper testing
        we can handle the fault in UI in a graceful manner

    for DB faults
        we can have muliple nodes of DBs
        have multiple replicas of dbs

    Types of faults
        Transit faults :- occurs for a small duration
                          Hard to locate

        Permanent Fault :- 
                          Continues until fixed
                          Easily Indentifiable

    Types of Failures in a system
        req get 500
        whole system get into a eratic state
        work flow start responding wrong data
        one component stopped responding 