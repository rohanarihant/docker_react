import {mount as ProductsMount} from 'products/ProductsIndex';
import{mount as cartMount} from 'cart/CartShow';

console.log("container");

ProductsMount(doument.querySelector('#my-products'));
cartMount(doument.querySelector('#my-products'));