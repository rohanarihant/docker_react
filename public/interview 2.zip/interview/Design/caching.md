
**Cache**
    A cache is like short-term memory which has a limited amount of space. It is typically faster than the original data source.

    Caching consists of :- 
        1. precalculating results (e.g. the number of visits from each referring domain for the previous day)
        2. pre-generating expensive indexes (e.g. suggested stories based on a user’s click history)
        3. storing copies of frequently accessed data in a faster backend (e.g. Memcache instead of PostgreSQL.

    Caching Pattern
        app code invalidate the cache
        happens through expiry
        every object will have a time which we menttioned using TTL (Time to live)

    cache can be kept in multiple levels
        browser level
        proxy level
        app level
        outside app 


    <!-- Invalidation -->

    <!-- Eviction -->
        Cache Eviction :- when a new key is coming in cache and the cache is already fixed then it will go and invalidate the existing key so that new key will be stored in  the cache.

        Stretegies  :- 
        
            FIFO :- the first time writen key will be removed from the cache.
            LRU (least recently used) :- the key which is used vary recently or longer period of time
                                            k1 : 2 days 
                                            k2 : 1 day
                                            k3 : 5 days (will be removed)
                                            k4 : 10 hours 
            LFU (least frequently used) :-  k1 : 100 (accessed 100 times)
                                            k2 : 200 (accessed 200 times)
                                            k3 : 5 (accessed 5 times) removed from the cache
                                            k4 : 10 (accessed 10 times)


    <!-- Cache Patterns -->
        1. cache aside pattern
            client --- server --- db
                        |
                      cache
            cache will talk to server not to DB
            new req will talk to db and fetch the reccords and store it in cache
            then it will check the same record in the cache for the next time

            if a new value is updated to the dbs then it should be updated in the cache or the cache will be invalidated
            pros :- if db went down then app will talk to cache the whole system will not crash
            cons :- have to use the udpating logic in the app to update the cache when new write happens
        
        2. Read through stretegy /  patternn
            client -- server -- cache -- DB
                used in where we are having read heavy work load like newsfeed
                data modeling b/w cache and db has to be similar
        3. Write through stretegy /  patternn
            client -- server -- cache -- DB
                same like RTS but here the cache will be having the responsibility to update the db if the new data arises
                there will be a extra layer of latency
        4. Write around stretegy /  patternn
            client -- server -R- cache -R- DB
                        |                 |
                        -------------------
                used in write heavy systems
                app directly write to DB
                and read directly from the cache
        5. write back stretegy /  patternn
            client -- server -- cache -- DB

                used where write heavy reqs
                here writes are saved in cache and ack to server
                then all writes are saved in DB after some span of time in batches


