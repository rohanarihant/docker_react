**What is the use of Capped Collection?**

    capped collections are fixed-size collections that support high-throughput operations that inserts, retrieve and delete documents based on insertion order.

    fixed size collections
    max size in bytes and max no of docs.
    auto removal of old documents.
    high thoughput and performance
    it create the new document by overriding the old documents in the collections.


**How can you store images, videos and large files (>16mb)**

    GridFS is driver app for uploading and retrival of mongoDB files larger than 16mb.
    GridFS divides large files ino equals chunks and stores them as a seperate documents.
    each audio a nd video files are sreamed as a chuncks. one chunk file size can be 256kb.


**Explain Aggregation in MonngoDB?**
    MDB aggregation operation act on groups of values from multiple documennts, perform operations on the grouped values and return a single computed result.

    Aggregation Pipeline :- multiple docs entered the pipeline then these docs are being transformed to the aggregated results.
    Map Reduce Operations :- mappinng and reducing the operations. it will map each doc and process along one or more doc in each doc andn in reduce phase the o/p of map operations are being combined together 
    Single pupose agg operation :- this operation aggreate all the docs from a single collection in mongoDB

    Aggregattion pipeline methods :- 

        Match :- $sum, $avg, $min, $max, $push
        Group :-


**What are the some utilities for Backup and Restoring inn MongoDB?**

    the MongoDBshell does not include export, import, duplicate or retrival operation.
    However MongoDB provides all  the utilities to take backup and perform the restore operations.

    4 options
        MongoImport
        MongoExport
        MongoDump
        MongoRestore


**Explain about Map Reduce Process in MongoDB?**

    Map Reduce is a data processing paradigm for condensing large volumes of data into useful aggregated results.

    Mapping :- each doc is processed and emits common and redunttant part of the docs to pass a unnique record for the next phase.

    Reducing :- in this phase all the unique parts get together and aggregated to produce a single result and finally we have a query
                here we will pass the query to filter the resultant set so with the help of map-reduce
                user can perform sorting, filtering and doc modifications as per their need.

**How MDB ennsure high availability of Data**
    MDB automaically stores copy sets, and multiple  copies of data distributed across servers and data centers.
    Replica sets help prevent website using native duplication and automatic failures.

    

    