**Message Queue**
    MQ are a middleware used by diff parts of sys (says producers and consumers) to comm or process operations async.
    e.g :- AWS SQS, rabbitMQ, kafka etc.
<!-- Sync vs Async comm -->
    Sync :- info/data is shared bettween services in real time. e.g phone, video calls
    Async :- info/data is shared independent of time. (immediate res is not necessary)
    e.g :- customer raise req to get the previous 6 months order invoices
    it will processed to the message queue and then will be processed async
    user will be notified you will get the invoices in sometime
    and then email will be sent with the invoices


<!-- Producer & consumer -->
    queue could be a process which has data structure and memory to store the msgs
    it could be running on the same/different machine components have to interact with it

    e.g
        SQS
        Kafka
        RabbitMQ


    Messages :- short data which tells what has to be done
    Peoducers :- tell what has to be done
    Consumers :- carry out the pertticular operations

    if load or msgs got increase then we have to increase the no of consumers

<!-- Ordering and Consumptions -->
    comsumptions :- it will consume the message 1 by 1. c1 will pick the msg and process it and ack MQ. then queue will remove M1.
    One to One (Producer consumer model)
    One to Many (Publisher subscriber model)

    Order :- ordering of the messages
    it will depend a lot in some apps like chatt
    it doesn't matter in the applications like order invoice generator

    Ordered MQ (eg :- text messages)
    Unordered MQ (eg :- invoice generation reqs)



**Publisher Subscriber**

<!-- Real world analogy of Pub/Sub Model -->
    Publisher :- create and send messages to a topic.
    Subscriber :- create a subscription to a topic to receive messages from it.

    Need of Publisher subscriber Model
        when we need to de-couple out componnents
        they dont depend upon each other
    

        PUBLISHER----> Broker -----> o/p --> sub1(sms), sub2(email), sub3(logging), sub4(order processing)
                        (event bus)

        Messages Ordering :- order is not define or gerentied, (with the help of peiority queue pattern we can use that)
        consumptions :- its not one to one consumption 

<!-- Pub/Sub Use cases -->

    1. Async workflow

        order placed --->   send order confirmation
                            process item of packaging
                            Generate the invoice
                            initiating seller workflow

    2. decoupling
    3. load balancing
                inncreased load can be balanced either by increasing the no of subscribers.
                and even if subsccribers are limite. thenn too messages would be retained in the queue.
    4. deffered processing
            we can put a msg into a queue and schedule it on time then can be processed later
    5. data streaming





