JWT

user will be authorized and authenticated with username and password
then it will return the JWT token, will contain the user role, expiry and clientID
token will be passed in each request
private key is used to siigned the JWT token
public key is used to verify the JWT token
it is very imp because it is very diff to forged a JWT signed with private key

These base 64 encoded strings are header, payload, and signature. It would look like xxxxxx.yyyyyy.zzzzzz
    Header :- 
        contain meta info
        data of the token or JWT
            2 parts :- (base 64 encoded)
                token type
                singning algo

                    {
                    "alg":"SHA256",
                    "typ":"JWT"
                    }

    Payload :-
        has claims.
        contain the entity and extra data related to the user.
            We can add different claims in our token, here are the three types:

                Registered claims :- are predefined but notmendatory.
                    e.g :- audience, expiration time
                public claims :- 
                    we need to eliminate collision
                    define public claims via URI (Containing namespace that is collision-resistant)
                private claims :- 
                    we share data between two parties that have agreed to utilize these claims
                    These are nor public neither registered claims

        we should not put any sensitive and secret information in the payload.


JWT will be having 3 thing
    Return address :- it tells the recepient who send the JWT and where it comes from
        Header :- contain the metadat info of the token, algo is used to signed the token
    message :- actual content and payload of the JWT  
        Payload: - contains the claim which are statements about the subject of the JWT like user identity, their permissions and time at which the token was issed
    VAC seal :- 
        is a special signature only the sender knows how to create, created using a secret code like a password.
        it will ensure nobody will tempre the content of the JWT w/o sender knowing about it.
        signature is create with the encoded header, payload and a seccret (private key) and a cryptographic algo
        all these 4 components allow the creation of the signature

2 types  of  JWT claims
    Registered claims are the claims that are defined by the jwt specification
        e.g :- issuer, subject, audience and expiration and issuer time of JWT
    Custom Claim :- are not defined by JWT specification, but youcan store any innfo if you want to store

    Claims are encoded and seperated by dots







Service Account

    is a special account used by our VM not user
    use case of SA
        1. if an app sitting inside a VM want to talk to other services like CF and Cloud bucket
        2. if from other cloud services if we want to talk to any gcp services



    when in GCP we open app or compute engine then default service account will have permission to talk to VM or other services.
    we can create our own SA and can define roles.

    3 types of roles can SA have
        1. primitive 
            include the ownder(can delete the project)
            editor (one level below)
            viewer (can view the project)

        2. predefined role
            created for specific services and managed by GCP
        3. Custom Role
            to combine diff roles. you might not find in predefined roles
            which provide granular access according to a user specified list of permission
            e.g if an app want to execute a CF from app and read objs from bucket





OAuth 2.0
    is an authorizattion framework that can be used to authenticate users grant them access to protected resources



    Delegation Authority
        benefits of sharing our credentials with a 3rd party app
        you can verify or change the level of access granted another app
        easily change the pass w/o breaking any integrations
        revoke access by deleting the access token
        donnt need to share the pass with anyone


    4 parties
        Resourse Owner (who own's the data)
        Client  (to whom delegate the authority)
        Authorization Server (generating the access token)
        Resourse Server (User data resides)


    Authorization and Resourse Server can resides seperate or inside the same server

    Client will reach to RS but since no valid access token it will redirect to the AS there we need to do authentication
    auth can be  handle outside OAuth, could be handled by SAML. after validating the  credential will return the access and refresh token
    AT will have 1hr expire time
    if AT expire then client will use the refresh token to get the new access token from AS


    the flow start with the user's web browser getting redirected with the msg containing the 
        client id
        redirect uri
        response type
        scope (level of access)


    
    User        -----------------------------   User Agent      -----------------------------  Authorization server
    (resource owner)                            (browser)       -----------------------------  


                                                Client App      -----------------------------   Google Calender
                                                (3rd Party)     -----------------------------

    OAuth 2.0 and JWT are 2 diff protocols
    they will work together to provide an  secore and efficient way for 3rd party apps  to access ptotected res
    JWT is self contained and easily verified by the resource server

    3rd party app first need to obtain the access token
    it does this with OAuth 2.0 to authenticate you with google
    once authenticated google will issue you a access token to the 3rd party apps
    3rd app takes the access token and encoode a JWT token 
    JWT will be sent to the resource server like G calender(resource server)
    then resource server then verify it grant the access to calender

    JWT benefits
        is self contained and easily verify by the server
        Secure :- it makes it more seccure then other access token (OPEC token)
        Efficient :- are compact and URL safe, make them easy transmit over the n/w, this willimprove perf
                    jwt can be used to represent a variety of claims such as identity auth or other data.

        they dont provide any authentication and authorization service by themselfs.

        Google authorization server is also an identity provider, means authenticate the user and grant permission

        they both are the 2 diff roles in OAuth 2.0 auth framework
        identity provider - authentication
        authorization - authorization is responsible for issuing access token

        there might be a case where they both are seperate identity


        Diff Flows
        1. Authorization code flow
            app needs to access proteccted resources on behalf of user
                1. auth with the IDP (identity provider)
                2. idp redirecct back to the app with auth code
                3. app sends the auth code to auth server which validate the code and validate the token and refresh token
                4. app then make the AT to make req to the resource server 

        2.client credentials flows
             is used whenn the app doest access the protected resource on behalf of the user
            the app needs to access its own protected resources 
            the app authenticates with the AS using its client id(username/email) or cltient secret(password)
            AS returns the AT to the app
            App then use the AT to make req to the Resource Server(RS)
            user is direccctly entering the username andd pass to the app itself no idp


    


        






            