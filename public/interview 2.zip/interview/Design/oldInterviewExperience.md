cimpress (codility)
    product $10 of mobile
    coupon $2 discount on next mobile product
    coupon 25%  discount on all the  products in the cart
    coupon 10% disccount on next order
    product $10 of mobile


capillary
    // react app 
        function App {
            const [countt, setCount] = useState(0)
            const handleOnClick = () => {
                setCount(prevCount => prevCount+1);
            }
            useEffect(() => {
                console.log("useEffect 1 of 1");
                return () => {
                console.log("useEffect 1 of 2");
                }
            },[]);
            useEffect(() => {
                console.log("useEffect 2 of 1");
                return () => {
                console.log("useEffect 2 of 2");
                }
            },[count]);
            console.log("render")
            return(
                <button onClick={handleOnClick} />
            )
        }

        file explorer app in react

        keys should be unique
        if index will be the key then will it effect performance

        secure in cookie and all other attribues
        ttl in  cookie and localSorage
        diff b/w local and session sessionStorage
        how node.js work
        how many queue in  node.js
        thread pools
        how jwt work in app
        how to validate the token in backennd


        factory and prottotype pattern

        console.log("1");
        Promise.resolve().then((){ console.log("2")})
        setTimeout(() => { connsole.log("3")})
        Promise.resolve().then((){ setTimeout(() => {console.log("4")})})
        setTimeout(() => { connsole.log("5")})
        Promise.resolve().then((){ console.log("6")})
        console.log("7");

        

// Ikea



Given a file with the following contents/lines, find each number which does not have any adjacent symbols, including diagonally. Periods (.) do not count as a symbol.
 
```
467..114.
...*.....
..35..633
......#..
617*5....
.....+.58
..592....
......755
...$.*...
.664.598.
```
 
In this sample number `114` and `58` does not have any adjacent symbols, while `467` has an diagonally adjacent symbol `*` on the 2nd line. That same symbol is also adjacent to `35` on the 3rd line.
 
Feel free to skip writing a reader/parser for the file/data and assume you're able to represent the data in any data structure you see fit.



<!-- final = [114, ];
temp = []
const symbol = "*"
const data = [
[4,6,7,0,0,1,1,4,0],
[0,0,0,"*",0,0,0,0,0],
[0,0,3,5,0,0,6,3,3],
[0,0,0,0,0,0,"#",0,0]
]
function checkIsNumber(number){
	return number > 0 && number < 10; 
}
function checkSiblings(left, right){
		return left !== symbol && right !== symbol;
}
function validateAdjusent(adj, ind){
		return ind > 0 && ind < adj.length;
}
function checkAdjusentSibling(adj, ind, parentLength){
		
    	return adj[ind] !== symbol && adj[ind-1] !== symbol && adj[ind+1] !== symbol
}
function findAdjucentSymbol(newData){
	let finalOutput = [];
  let tempOutput = [];
	newData.map((arr, pi) => {
  arr.map((ele, ci) => {
    if(checkIsNumber(ele)){
          if(validateAdjusent(newData[pi-1],ci)){
          	if(checkSiblings(arr[ci-1], arr[ci+1]) && checkAdjusentSibling(newData[pi-1],ci) && checkAdjusentSibling(newData[pi+1],ci)){
            
            }
          }
	     
	    }
  })
  }) 
}

findAdjucentSymbol(data); -->



<!-- d4insigts

preprocesser and postprocessor //
relative vs fixed //
default position //
doctype
iframe events //
webpack plugins and loader //
react vs angular
react.lazy
throttle in js
debounce vs throttle
webpack chunking process
memo vs lazy
api methods (options) //
diff b/w for, map and forEacch
functional vs class based comp -->


<!-- web workers
grid/flexbox
positions
specificity


chekc the nested obj to have that key or not

const arr = [0,1,2,3]
console.log(arr.map((a) => a*2));
console.log(arr.forEach((a) => a*2));
console.log(arr.filter((a) => a));
console.log(arr); -->

<!-- Havells -->
one dimenttional car movinng in a directions
10m forward
20m backward
how far from starting posititon
total how many meters driven
should not  go in minus

followup  questions were  need  to be asked

<!-- BT  Group -->

react questions
wcag
sql prevent hacker to access millions of reccords
Open Web Application Security Project (OWASP)
OWASP vulnerbilities

// 1st round
flex, basis, shrink
event loop
return the length of integers in nested array
polyfill of bind
preload vs prefetch
improve the image load performance
rendering content 
web performance improvement
prototype chain


// system design
scalabilities/availablity
assumption
real time
create sttories


<!-- Altimatick -->

how to improve performance in react app
lazy.load will help in performance improvement
how react app will render on browser
lighthouse improvement
react design pattern
redux principle
things to take care before starting a project in react
keys in react list
what is diff bttwen display: grid/flex;


curried js question -> https://codedamn.com/problem/d6ur5r5Lj6fFQ3ULTs8P-
jump function in js -> https://www.geeksforgeeks.org/check-if-last-index-can-be-reached-by-jumping-atmost-jumpi-in-each-position/

<!-- EPAM -->
deployment stretegies
  canery
  blue billing

container/cluster in mongodb
spyOn
sqs
call ec2 from pubsub
docker layers
docker stages
diff bw lambda and ec2
how to download huge list of files from s3

<!-- common wealth bank -->
  special DB
  how node will handle multiple asysnc calls
  how virtual dom algo will do the comparison, how efficient it is?
  which lib node use to increase threads?
  where do you want to see yourself after 2-3 years ?
  what is concurrency
  what is jwt 
  how services will comm to each other
