# CF
    fully managed serverless execution ennv
    scalable func-as-a-service platform
    can be used to connect cloud services
    no need to provision iinfra or manage servers
    integrated wtih cloud operations for logging and monitoring
    2 prod versions
        1 gen
        2 gen
    
# Cloud Run
    managed compute platform
    runs containers on google's infra
    supports source-based dep that builds containers for you
    build full-featured apps with other G cld serv

# a CF
    simple piece of code, impl a single purpose func
    can be invoked directly from HTTP req
    can be triggered in res to an evnt generated from child infra and services
    execute in a fully managed env
    can be written in many supported languages


# using CF
    connective layer to conn and extend CS.
    e.g :- 
        respond to a file upload to CS
        repond to a msg published to pub/sub topic


# features
    can be locally developed and tested
    seamless auth
    http and event-driven
    integrates with cloud dbs
    portable using open source frameworks

# benefits
    augments existing CS
    serverless (dont need a server)
    auto scaling (can scale few invocation a day to many Mn invocation)
    observable (tool for observabiility and error diagnostic)
    pay as syou go

# types of CF
    HTTP func
        uses http triggers
        provide url endpoint
        used to handle reqs
        ideal for webhooks or single use endpoints
        support auth annd unauth

    Event Drivenn
        cloudEvent func
        background func

        uses event triggerss for
            pub/sub
            cloud storage
            firestore
            firebase
            eventarc sources
        
    2nd gen CF
        larger instances (can have upto 16gb of ram)
        increased concurrency (can handle thousands of concurrent reqs)
        runtme limit (60 mins for http and 10 mins for event driven)
