**Containers**

    A way of package app with all the nececssary dependencies and configs.
    Portable artifacts :- easily shared and moved around 
    that portability of containers plus everything packaged in one isolated env gives it some of adv that makes development and deployment process more efficient.

    where do containers live? 
    Container Repository
        containers live in a container repo 
        this is a special storage for containers
        private containers
        public (Docker Hub)



    Before vs After Containers 
        before :-
            installation process is diff in each OS env
            Many steps where something could go wrong

        After :-
            actually do not have to install any of the services direcctly on OS because the container is its own isolated OS layer
            with Linux based images.
            everything packaged in one isolated env
                like node.js, postgress.sql etc
            packaged with all needed configurations
            so as developer you dont need to 
            for  developer you  have to go and check the binaries to download 
            rather  you have to  go and check the container repository and download on local machine
            download  cmd is one  to fetch the container and starts at the same  time

            you can run diff env of the same app locally with any conflicts

    What is Container?
        Layers of images.
        mostly Linux based Images, because  small in size.
        base image should need to be small so it would be alpine, that states cotainer stay small in size.
        on top of the base image we will have Application Image.


        Docker run postgres
            will try to find locally then move to the docker hub
            will fetch all the hashes
            docker containers are made up of layers
                linux image layer
                app layer

                if we are changing the version then newyer version then only diff layers will be downloaded

            it fetches the image and starts it

    Image vs Container
        the actual package
        the app package with the config and the dependencies
        artifact that can move around is the Image

        Container:-
            when we pull the image locally and started on the app inside
            starts the app
            cont env is creatd
            is the running env for the Image

            it contains :- 
            file system
            app image
            env config
            binded a port to it. so that talk to app running inside of container
            file system is virtual in the container, it has its own avsraction of OS, diff then the file system of host env

    Docker vs Virtual Machine
        OS:- run on 2  layers
            Kernel          Applications
            Kernal is the part of the comm with the h/w components like CPU and Memory
            App will run on the kernal layer
            

            e.g :- Linux OS will use diff apps but same kernals. so that their UI is diff.

            Docker virtualize the App layer
                when download a docker image, it contains the app layer of the OS and some other apps installed on top of it.
                it uses the kernal of its host, they doesn't have there own host.
            
            Virtual Machine
                will have the App and own kernel layer
                it virtualize the complete OS

                it means if you download a VM Image on host it doesn't use your host Image.

            Diff
                DI will have less image size because containing one layer. can be in MBs
                VM will have large image size because containing 2 layers, can be in GBs.
            
            DI are faster

    Problem with Docker
        some of the older versions of Windows and Macs are not suppoting docker Images
        Linux based docker images will not be supportable on window sys kernel

        docker  toolbox is used in  that case
        which abstract away the kernel to make it possible for your hosts, to run diff docker images.
        will react like a bridge b/w docker and the OS. 

    Container PORT vs HOST Port

        multiple containers can run on thr host machine
        laptop has certain ports available
        conflict when same port on host machine

        host            5000            3000            3001


        container       5000            3000            3000

        can work fine if 2 same connttainer's port bind with diff host ports


Docker hub -- pull images
commit the code -- git
jenkins  --- ci/cd build js apps / ccreates docker apps push to docker repo
dev servers pull those images and run 

# What Docker Actually Does
    Docker allows developers to package an application along with everything it needs to run
    code, runtime environments, system tools, libraries, and settings—into a single,
    lightweight blueprint called a Docker Image.

    When you run this image, it launches a Container
    This container acts as an isolated sandbox that runs exactly the same way on a laptop,
    a test server, or an enterprise cloud platform


