# Jenkins
    is conntinuous Integration tool that allows continous development, test annd deployment of newly created codes.

    # Nightly build and integration
        commit changes to the source code
        all code will be pulled onnnly at night
        all changes made to the code are build together

    # C build & I
        commit changes to the source code
        code is pulled whenever there is a commit made to SC
        all changes made to sc is build cont
    