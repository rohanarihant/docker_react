Helm
    its a package manager for kubernetes
    convinient way to packaging, collectitons of k8s yaml files and distributes them in public and private repo.

    e.g
    if we want to add a Elastic Stack for logging
        we nneed tto add satteful Set, ConnfigMap, Secret, Services, k8s user witth permissions
        it will be hectic, we need to create yaml config for all services.
        lets think someonne already created those yaml file once and packaged them and made it available somewhere
        so that other people use same kind of deployment in k8s cluster. 

        HELM CHART :- that bunnlde of yaml file called HELM CHART
            you can also create your own helm chrt with helm
            push them tto helm repo
            we cann resuse the existing yaml config

        Template Engine
            deploymennt and services config almost the same
            docker image name and version tags are diff

            if same sort of code is repeaed innn tthe yaml configs
            then we will 
                define a common blueprint
                dynnamic values are replaced by placeholders
                that would be a template file

                sepc: 
                    containers:
                    - name: {{.Values.container.name}}
                      image: {{.Values.container.image}}
                      port: {{.Values.container.port}}
