docker ps
    // list running containers
docker run image (postgres:9.6)
    will find in locally and thenn go to docker hub and run it on container

docker pull image
    // pull the image
docker run -d redis
    // runn docker image in detach mode
    give the container id
docker stop id-of-container
    // stop the perticular conntainer
docker start id-of-conttainer
    // start the perticular conntainer
docker ps -a
    list all stopeed and running containers

docker run -d -p6000:1234(container port)
            (host port)

docker images
    show all docker images

docker logs container-id/container-name
    show the log of the container

docker run -d -p:6000:6347 --name redis-older(container-name) redis:4.4.0(image-version)

docker exec -it(Interactive Terminal) container-id /bin/bash
    it will move the terminal to tthe directory
    you can check the files and folder inside it
    you can also check the env vars

docker run / docker start
    run will pick the image with specofic version and create a new container  from the image
    start working with containers