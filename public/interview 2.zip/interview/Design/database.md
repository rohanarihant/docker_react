Database
    SQL :- structure query language (table based) (verticaly scalable)
        relational db, slow easy quering on relationships b/w data among multiple tables. data is well-structured and error will be less
        are ACID compliannce
            Atomicity :- all or nothing transections
            Consistency :- data is valid before and after
            isolated :- multiple transections at a same time
            Durability :- Committed data is never lost
        weekness:- columnn and tables have to be created ahead of time
                    take more time in setup as compared to nosql
                    they are not effective in storing unstructured data for the format is unknown
                    diff to scale horiozontly
            

    No-SQL :- document, key-value, graph, wide column store. (horizontally scalable)
            simple to setup, there is no able relationships, data is stored in key-value, documents
            better choice of storing unstructured data
            they cann shard the data across diff data stores
            horizontal scaling easier
            lott of data can be stored

            weekness:-
            typically designed for distributed use cases
            write heavy can be supported by muliple right shards for the same data partitions is called peer-peer app
            trade-off is loss of strong consistency
            in distributed shard in no-sql cluster there is some delay before the update is propagatted to otther replicas
            during this time reading from data will be stale of data
            this is called eventual consistency
                a sinle shard np-sql db can be strongly consistent, fully take adv of the scalability benefits of the no-sql
                db should really be set up as a distributed cluster
**Database Replication**
    means to have a copy 
    we can have a db with data and have a exact copy of the data.

        Primary(master)   ->>>>  Secondary(Slave)
    
    benefits
        if a db replication is kept in diff geographical locations
        then it will be accessed easily and reducces lattency a lot.

        if multiple services are having dependency over a single db then we can create a replica of it and then
        other services can read from the replica db.

    understanding replication lag
        it will  be a diff betwenn the data update between master and slave db

            Primary DB     ->    Secondary DB
            new value x:2         x:1 
            the time to updae new value in secondary DB
            it will be worse if rep lag is huge

        solution :- synchrounously replicating
                    these are solved by 
                            consistency models
                                read after write consistency :- 
                                        the user will not see write is completed until and unless the the same value is added/updated to the replica db
                                        in this case replication lag is 0
                                        this is known as synchronous replication

                                        downside :- performance might take a hit.
                            consistency algorithms

                    Asynchrounously replicating
                        after writing to the master db, it will say ok
                        slave db updation will be happen asynchronously behind the scene

                        pros: less letency
                                fast write
                                realtime data is not imp
                            
                        cons: inconsistency in replicas
                                banking, fligh app its not usefull

                    Semi-Synchrounously replicating
                        when new write is issued primary db will wait 1 replica to ack and say ok
                        other will be update in background

    Replication vs snapshot
        snapshot is diff from replica
        snapshot is taking a state of db at a certain time. so that we can recover the data on the event of failure

            t1 = 6 tables 10k rows
            t2 = 11 ttables 12k rows


    ways to do the replication
        after a certain time eg 1 min the data will be copied and updated in replica

        change data capture :- 
            a slightest channge is captured by the running process and updated to the replica