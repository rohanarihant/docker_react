**Builder Design Pattern**
    part of creationn designn patternn family
    in OOPs programming, when new obj is created from constructor.
    you can either pass all the args and no args to the constructor

        class Payment{
            constructor(currency, amount) {
                this.currency = currency;
                this.amount = amount;
            }
        }

        const a = new Payment();
        const b = new Payment('₹', 1000);

        <!-- While this suffices for many cases,
        oftentimes we want to build the object once it is created.
        In that case, we can make use of the builder design pattern. -->


       * Builder design pattern helps to create the objects with only required values,for this,
         we can create a no-args constructor and then build the object step-by-step and
         then get the final result from it.


        class Payment {
            constructor(currency = '₹', amount = 0) {
                this.currency = currency;
                this.amount = amount;
            }

            addAmount = function(val){
                this.amount += val;
                // returning the reference of the same object
                return this;
            }

            pay = function(){
                console.log(`${this.currency} ${this.amount}`);
            }
        }

        const p1 = new Payment();

        p1.addAmount(100).addAmount(200).addAmount(200).pay();
        // "₹ 500"


        For example, let’s say you have a payment object, before making the final payment, we want to continuously add the amount. In that case, we can do the method chaining (alternative name for Builder design pattern) where we return the reference of the current object from the methods so that the methods of the same object can be used as required

        * In JavaScript, we don’t have to define Class to create objects, we can create them directly and use the builder pattern on it.

        const p1 = {
            currency: '₹',
            amount: 0,
            addAmount: function(val){
                this.amount += val;
                return this;
            },
            addCurrency: function(currency){
                this.currency = currency;
                return this;
            },
            pay: function(){
                console.log(`${this.currency} ${this.amount}`);
            }
        };

        p1.addAmount(100).addAmount(200).addAmount(200).pay();
        // "₹ 500"

        p1.addAmount(200).addCurrency('$').pay();
        // "$ 700"

        *Builder design pattern is best suited when you have to create a complex object on the run-time or have to create a composite tree like the DOM.



    