
Services that does one thing very well and interacts with other services.

**Key Concepts**

    High Coheshion & Low coupling :- 
        Coheshion :- every functionality related to order or every feature or data or business logic
                    should be sitting very close to the order service or inside the order service.
        Coupling :- if services are too dependent on each other or they know too much about each other
                    share a common data source or a database that means services are coupled with each other.


                    order               Contract                Product
                        id                  order_id                id
                        user                product_id              name
                        data: {}            user_id                 price

                here less coupling is made, becuase if some changes occured in order or product or if field
                name changes then no need to change the contract.

    Business Domain Modeling
        in mcs services are devided into the business domain or the features
        like :- Orders, Payment, Authentication, Products, Invoices, Notifications, Carts


    Independent deployment
        should be able to deploy mcs independent of each other
        and also we can have diff mcs in diff languages
        also we can scale each of them independently
    
    Observability
        we can observe each service independently, is it healthy
        we can have a pattern to check one service might be causing degeradation to other service,
        if not implemented balances and check properly.

    Resilience
        if one of the service is degraded or db is down, the other service should not affected
        we can have fault tolerent into the system and resilience in the system, so that the 
        failure should not travell across the system
        we can fix the broken part then rest part can continuesly working
    Team Organization





**Types of Coupling**
the more mss talk or dependent upon each otther the slow the systtem would be
itt would increate letency, complexity of arch, diff o find the issues

        
        4 Types of coupling

            * Domain :-     

                    Courses        Payments
                       |           /
                       |         /
                       |       /
                       |     /
                    Users ------------ Notifications

                User ms will talk to each one of them seperately
        
            
            *   Pass through coupling

                it meanns when we pass a data to a service which doesn't need it

                e.g User ms will send user dettails and email, phone fields to payments
                but payments ms  doesn't need it, then paymentt will pass that to notifications ms
                
                problems :- 
                    payment doesn't need that  data but  have to  take and process it
                    if any changes in notification data then payments has to do that change also


            * Common Coupling
                if 2 or more services are reading/writing to  the same db tthat will be the common coupling

                it  will be good to have 2  diff dbs for 2 diff mss with diff domains
                for read only will be ok

            * content coupling
                
                if one service A will have connection to its db under a boundry
                but if service B(diff domain) will come and have connection to db of service A
                then it will be a problem and it sould not happen
                
                in that case service B should call the service A and then do the changes inn DB through it



**Functional and Non-Functional Requirement**


    Functional Requirement :- 
        system level or tthe component level needs of features that users are suppose to have
        they will come from product or user perspective
        business need certain features to be developed
        tech team requirement

        e.g for Twitter
            post tweet
            delete tweet
            favourite a tweet
            follow people
        
    Non Functional Requirement :-
        latency of posting a tweet
        system is available to handle certain number of Daily Active Users(DAU)
        engineering driven teams requirements for performance
        SLA (service level Agreement)
        SLO (Service level Objective)

        Traffic
        Users
        Availability
        Throughput
        Latency

        through capacity estimation will help to get the choice of resources, nno of resources

