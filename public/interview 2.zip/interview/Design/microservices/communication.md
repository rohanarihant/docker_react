
2 types of comm
    1. synchronous blocking
    2. asynchronous non-blocking

1. synchronous blocking
    a mcs makes a call to another mcs and block operation, while waiting for the response

    Req/Res via REST/RPC over http

2. asynchronous non-blocking
    mcs emmitting a call is able to carry on processing wheather or not the call is received.
    it will not wait for the response to come and continue processing, it will process the res over a time.

    Event driven -> 
                topic based messaging sys (pub/sub) and kafka
                Queue based broker RPC

        here the event publisher doesn't know who has subscribe to the topic
        and what they are going  to do with that
        they are comoletely decoupled and there is no problem while scaling it.

        disadvantages :- will be more complexities

    Shared DB -> 
                one side we are writing the data (like uploading a file to s3)
                the other mcs can reading the data

            problem with this:-
                if both the mcs started reading/writing.
            this approach is not recommended.
        the flow should pass in one way



<!-- ------------------------------------------------------------------------------------------------------------------------------------------------------------------>
**Event Based Communication**

    * Message :- medium of comm or transfer of data. it will be a data which cann be passed between 2 services tthrough msg broker.
    * Event :- event is a payload that is send over that msg. through message broker.


    Message Brokers

    Queue based message broker :- message will be added to the quque annd then it will  be picked by the consumer one by one.  
    topic based message broker :- we can have mulitple topics where diff subscribers can subscribe  to  one or more topics.

    Dead-letter queue :- if anny msg couldn't be consumed then it will be picked from the  queue and added to the  dead-letter queue. afer that as per the  writen logic
    the msg will  be consumed and processed.



    problems :- 
        lost messages (retry)
        order of messages 
        consumer at fault (reply method solved)
<!-- ------------------------------------------------------------------------------------------------------------------------------------------------------------------>