**Cloud FUnction**

    will let us automatically run backend code in reponse to 
    event trigger or
    http request
    Schedule a Cloud Function to run at specific times or intervals.

    with CF we ca run server code w/o server

    when this trigger CF spins up server instance for fun in cloud that activates annd run fun in response to these triggers

