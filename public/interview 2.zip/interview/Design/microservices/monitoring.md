Monitorinng



Observability :-

    you have to implement a system to observe the systetm as a whole to see if it is working as expected or not.
    some of the tools to have observabilities into a system are like :- 
        METRIX
            how cpu, memory, read/write transections are happening in diff machines
            how the matrixs of certain instances are behavinng and reporting.
        
        LOGGING
            can have logging into our system
        TRACING
            implement tracing into our system
            track diff flow  of the systems, to see what flow certain points the system is executing and at what point its failing

        
        Observability can be done through
            Log Aggregation
            Metrix Aggregation
            Alerts
            Tracing


            Tracing :- when anny business flow in ms, it will produce  some traces. there are some common tool used to aggregate those traces
            to track the series of evennts that took place in diff systems to figure out where actually the problem happens
            to check how diff services are interacting with each other.



**Service Discovery**

    <!-- Servie Registry -->                                                       ip address
                                                            ---------   Server 1 (192.111.10)
    client    --------------------    Load Balancer    --------------   Server 2 (192.111.11)
                                                            ---------   Server 3 (192.111.12)


    client is making a req to server through load balancer and then load balancer will have to deccide where tto route this req to which server
    there can be multiple servers on backend and each one is having diff IP address
    some time some servers got restarted and new servers adds up.
    
    Servie Registry is used to route a req from load balancer to servers

    itt will tell what are the new insances and what's their IPs.
    new deployment will tell the service reg the details of new instances 

    this is called server side discovery
        server side the discovery is happening
        ss is responsible to figure out the registery
        where are my mappings and what are the hosts name for those instances.



**Side Car Pattern**
    sidecars are supporting processes or services that are deployed with the primary application

    it can be develop along with app and can share the same pysical memory, memory

    e.g :-
    our app is supporting http and we need to upgrade it to support https
    we can have a sidecar which will get the https reqs and send the http req innternally
    sidecar act as a proxy annd forward the trafic tto lagacy apps


    whennever we need proxy we can use sidecar

    e.g 2
    if we have to take care of some conditions using file system we can have side car and take care under it
    to server the static contennt

    Application                                                 Side Car
                    |                                         |
                        |                                  |
                            |                          |
                                |                  |
                                     Config File

    
    logging app where app instances will write the logs to local file system
    and log aggregator will read the logs periodically and sennd it to loggin tools over a time.

