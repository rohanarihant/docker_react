**Transactions in Monalithic**

    if monalitthic if we need to update 2 database tables or rows at the same time then we can just lock the ddb and update

    but in  microservice arch we are  having 2 services and 2 dbs those we have to update then in that case
    if we have to make sure that both of thtem should be updated. if one got failed then  other should either revert or retry to update. 

    *Two Phase Commit*
        is a standardized protocol that ensures that a db commit is implementing in the solution.
        where commit operaion is broken into  2 diff parts.

        order                                           Notifications
          |                                                 |
        worker A                                        worker B
        
                            Cordinaor
                it will check witth both of the workers                 step 1 & 2 -> Vote Phase
                are they ready to updatte the state                     step 3 & 4 -> Commit Phase
                if workers says Yes
                then it will lock the dbs and update the state

        Long living trannsecttions problem
            if we are going to lock the db with milions of data for a lonng time 
            it will be risky for the whole system

    *Microservices Saga*
        is a sequence of transections that update each service and publishes a message or event to trigger the next transection steps


        this  is a process using event to updae the multiple db state at once

        for example
            Backward recovery Approach :- is a way of undoing changes made tot resources such as files or dbs.
                enrollment of a sttudent  ttot course
                check for dubplicate
                process the payment
                course assignment
                send nottifications

                here in that case if payment got failed then itt will revert the enrollment of the student and send the failed nottification

            Forward Recovery
                lets suppose if the 3 step got failed
                then we will retry that step again

                Saga can be implemented in 2 ways

                    * Orchesttration Approach :- command and control is the architecture where it will approach

                    Notifications <--- Users -----> Courses
                                         |
                                         |
                                         |
                                       payment
                    Users MS will command to other MSs for all the steps

                    * Choreography Approach :- it will train the transection to be performed

                    here user service will trigger event after registeration of event
                    User Created
                    then courses service will trigger the event to payment service
                    Process the Payment
                    then payment service will trigger the event to Notifications services
                    Payment Done
                    Notofication service will send the email
                    Email sent

                    no one is commander and not havong control


                    we need to have very good monitoring and obserbilities in our system


                In both the service for debugging we are having co-relation Ids
                like we can attach UUid to eacch transaction  and sub-sequennt ransections 
                it will be easy to debug.





**Event Sourcing**

    how would you handle state changes and transactions in distributed systems?
        when try to capture the events happening into your systems then try to make use of those events in order to update the overal state of the system.


        e.g
        if user wannt to place an order
        he added some items to cart and order state is pending
        he added moore items and order state is pending
        he initialted the payment and order state is pending
        got paymennt confirmed and order state is pending

        warehouse find some products outofstock and cancel the order
        user cancel the order
        or payment confirmation failed and order cancel

        but we want to see in which scenario the order got cancelled?

        here Event sourcing and Event Store comes into the picture
        every time an update happens to a perticular entity like event happens that will be stored to the event store
        can be any persistant store as per choice
        eveny event will be stored into the event store

        we can reply the events to check the state
        