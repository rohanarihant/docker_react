# Why does my JavaScript code receive a "No 'Access-Control-Allow-Origin' header is present on the requested resource" error, while Postman does not?
    If I understood it right you are doing an XMLHttpRequest to a different domain than your page is on.
    So the browser is blocking it as it usually allows a request in the same origin for security reasons.
    You need to do something different when you want to do a cross-domain request.

            Regular web pages can use the XMLHttpRequest object to send and receive data from remote servers, but they're limited by the same origin policy

            Extensions aren't so limited. An extension can talk to remote servers outside of its origin, as long as it first requests cross-origin permissions.