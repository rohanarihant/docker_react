# Level A
    Level A is the minimum level
        providing the alternative text of Non-text Content
        Captions (Prerecorded) :- Captions are provided for all prerecorded audio content in synchronized media,
                                except when the media is a media alternative for text and is clearly labeled as such.
        




# Level AA
    include Level A and AA requireemnt.
    provide higher level of accessability
    provide caption for videos
    allowing users to navigate through keybaord conrol

    Captions (Live) :- Captions are provided for all live audio content in synchronized media.
    Audio Description (Prerecorded) :- During existing pauses in dialogue, audio description provides information about actions, characters, scene changes, and on-screen text that are important and are not described or spoken in the main sound track
    Identify Input Purpose :- The purpose of each input field collecting information about the user can be programmatically determined when: 
    Contrast (Minimum) :- The visual presentation of text and images of text has a contrast ratio of at least 4.5:1, except for the following: 
        1. Large Text: Large-scale text and images of large-scale text have a contrast ratio of at least 3:1;
        2. Incidental: Text or images of text that are part of an inactive user interface component, that are pure decoration, that are not visible to anyone, or that are part of a picture that contains significant other visual content, have no contrast requirement.
        3. Logotypes: Text that is part of a logo or brand name has no contrast requirement.
    including text-based controls, or by providing direct support for resizing text or changing the layout. An example of direct support might be via server-side Resize Text :- script that can be used to assign different style sheets.
# Level AAA
    website/web content meets higher level of accessibility

    providing sign language interpretation for audio and video content
    allowing users to adjust the text size and spacing

    Sign Language (Prerecorded) :- Sign language interpretation is provided for all prerecorded audio content in synchronized media.
    Extended Audio Description (Prerecorded) :- Where pauses in foreground audio are insufficient to allow audio descriptions to convey 
                    the sense of the video, extended audio description is provided for all prerecorded video content in synchronized media.


