# overview of WCAG

it is a guidelines created by world wide web consortium (W3C) to help to make web content more assesible for people with disabilities. 
WCAG is the global standard in digital accessibility guidelines.
It enables all organizations to measure the accessibility of content, sites, and apps against documented requirements for all people, including those with disabilities

# WCAG currently has three levels of success criteria: A, AA, and AAA
    
    Level A — deals with the most basic web accessibility features (must have)
    Level AA — signifies the biggest and most common barriers for disabled users (should have)
    Level AAA — addresses the highest (and most complex) level of web accessibility

# There are 4 web content accessibility principles that will help you know web accessibility better
    1. Perceivable
        UI components must be presented to users in way to  perceive.
        Content should be perceivable through sight, sound (hearing) and touch.
        conntent should be transformable from one fromat to another easily.
        example:- Text should be transformable into audio by using a text-to-speech screen reader 
                  Maximize compatibility with current and future user agents, including assistive technologies.

        How to ensure content is perceivable?
            Provide text alternatives for any non-text content so that it can be changed into other forms for people who need it,
                such as large print, braille, speech, symbols or simpler language.
            Give alternatives for time-based media.
            Make it easier for users to see and hear content including separating foreground from background.
    
        1.2: The content should be structured in an adaptable way: The HTML files should be written in such a way that the structure and
            intended information should not be lost if the page styling were to be removed.

        1.2. Operable: The user will not get disrupted by using those websites that are operable. Every part of the site’s
            functionality from playing and pausing video and audio to selecting a link from a menu to navigating a page can be utilized by visitors.

    2. Operable
        UI components and navigation must be operable.
            by using keyboard, onscreen keyboard and voice input etc.
            every part of the site funtionality from playing and  pausing video and audio to selecting 
                a link from menu to nevigating a page  can be utilize by visior.
            How to ensure content is Operable?
                Make all functionality available from a keyboard.
                Provide users enough time to read and use the content.
                Do not design content in a way that is known to cause seizures.
                Provide ways to help users navigate, find content, and determine where they are.

            2.1: The entire functionality should be used via a keyboard: There are some users who will not use a touchpad or mouse while the site is being navigated. The website functionality should be accessible with the keyboard.

            2.2: Flashing/blinking content should be avoided: Specific issues can be triggered when content flashes or blinks take place more than three times in a second. This needs to be avoided.

    3. Understandable
        Info and operation of UI must be understandable.
        websites  must use  clear tterms, simple instrutions and explain complex issues 
        It should function in a way that users understand, by avoiding unusual, unexpected or inconsistent functions

        How to ensure content is understandable?
            Make text content readable and understandable.
            Ensure web pages appear and operate in predictable ways.
            Help users avoid and correct mistakes.

        3.1: The text content should be easy to read: The full scope of the potential audience should be considered when the content is being drafted. The readers should be able to comprehend the web content that has been written, including those who are interested to learn the site’s native language.

        3.2: The pages should be logically structured: When the site’s navigation and structure are being planned, the pages and navigational links should be placed in a way that feels intuitive to visitors.


    4. Robust
        A website must meet recognized standards, such as using clean HTML and CSS.
        Robust content works across operating systems, different browsers, and even on mobile devices.
        The site visitors should be able to choose their own technologies to access, read and interact on the site.

        How to ensure content is robust?
            Maximize compatibility with current and future user agents, including assistive technologies.

        4.1: HTML should be written in a way that it can be parsed: The web page’s HTML file is used by assistive technologies so that its contents can be translated into a different format. For this purpose, the HTML code of the web page should be well-written.


    Operable, Understandable and Robust.
