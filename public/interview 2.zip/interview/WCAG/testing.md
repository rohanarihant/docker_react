# WCAG testing
    basically falls under the purview of Accessibility Conformance Testing (ACT).
    ACT strives to document and establish rules so that the conformance of web content to accessibility standards can be effectively tested.
    These test rules address manual, automated and semi-automated testing.