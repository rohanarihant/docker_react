# 4 types of disability

    visual: color blindness, having a vision loss
    auditory: nnot just hearing, autoritory
    motor: people who dont have the motor skills, someone only uses the keyboard, they can't use the mouse,  no  hand
    cognitive: vestibular issues, like people having headache with animation

    visual: 
        should  have alternative text over the images.
        should try to avoid having text over the images, 
        if you have then put some dark or opaque backgroud behind the text, so that people  can read the text.
        making  sure that something info isn't just based on color, if someone doont  see the diff b/w  2 colors they dont see what they are choosing. 

        use semanticc elements because  they are build to work  with these things.
            e.g if you use div instead of button if its clickable and have some actions the screen reader dosn't gonna know how to present that.


    auditory:
        make sure have closed captions or subtitles on videos
            closed caption :- they are more contextual, like someone  knock the door. subtitles sometime dont  have these
            make sure that you speak  clearly and enunciate
            deafness is the spectrum, we cant hear the voice

    motors:
        keyboard  navigation, could be easier to click and navigate
        should have the content which require less energy to see the things
        should have bigger touch  target so that it would be easier for them  to click
        touch  target  shouldn't overlap, adding paddinng to a button to make it bigger
        should not have timed actions, like to type something in a time limit, sometime people shouldn't have 10 fingers.

    congnitive: 
        text density :- like amazon is havong dense content.
            person comes first face difficulty to understand the things,
            link should have a underline always
            buttons hould always have outline they should look different then the links
            easily differenciatte the is  this a action or a navigation link

            should not play any audio and video automatically on the landing of the webapp
            sometime some  people couldn't understand and leave the page
            or should ahve the control bec it can be irritating
            should not have animation, like motion in css,  would be difficult for perople with headache or migrane
            only turn on for the people like explicitly  want it.

    ARIA: accessible rich internet applications
            set of rule states of properties that you can apply to like non-native or non-semantic elements to make tthem work a bit more
            e.g sometime we need a div instead of button but it is clickable and have action but its a container having content into it
