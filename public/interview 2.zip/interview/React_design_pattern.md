# container/ Presentational Pattern

    we can use the container/presentaion pattern to seperate the view from the logic.
        Presentational Component :- that cares about how data is shown to the user.
        Container Component :- that cares about what data is shown to the user.


    Trade Offs :-

    