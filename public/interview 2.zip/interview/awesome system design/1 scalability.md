# Scalability
    Scalability is the property of a system to handle a growing amount of load by adding resources to the system.

    How system grows?
        1. Growth in User Base
            more users started using the system, leading to increased number of reqs.
        2. Growth in Features
            introducing new func to expand the sys's capabilities
            e.g adding new payment methods
        3. Growth in Data Volume
            Growth in amount of data the system stores and manages due to user activity or logging
            e.g youtube is storing more data daily.
        4. Growth in complexity
            system's arch evolves to accomodate new features, scale or integrates and resulting in adiitional components and dependecies
            e.g A sys that started as a simple app is broken into smaller, independent systems.
        5. Growth in geographic reach
            sys is expanded to serve users in new regions and countries
            e.g an e-commerce company is launching new webapp and expanding into new countries


# How to scale a system?
    Vertical Scaling
        adding more power to your existing machines, by upgrading system with more RAM, faster CPUs or additional storage.
        good for simple arch but has limitations in how far you can go.

    Horizontal Scaling
        this means adding more machines to system to spread the workload across multiple servers
    
    Load Balancing
        is the process of distributing traffic across multiple servers to ensure no single server will be overwhelmed
    
    Caching
        store frequently accessed data in-memory to reduce the load on the server or db
        implement caching can drametically reduce the res time
    CDN (content delivery n/w)
        distribute the static assets closer to users. this can reduce latency and result in faster load times
        e.g cloudflare provides CDN services, speeding up web upon users worldwide
    Partitioning
        split data and functionality across multiple nodes/servers to disctribute workload and avoid bottleneck
        e.g Amazon DynamoDB uses partitioning to distribute data and traffic for its NoSQL database service across many servers, ensuring fast performance and scalability.
    Asynchronous comm
        Defer long running or non-critical tasks to background queues or message brokers
        this ensures your main app responsive to users
        e.g Slack uses async comm for messaging. when a msg is sent, the sender's interface doesn't freeze, it continues to responsive
        while msg is processed and delivered in the background
    Microservice Arch
        break down app into the smaller, inndependent services that can scales independently.
        this improve resilience and allow teams to work on specific comp in parallel.
    Auto Scaling
        automatically adjust the number of active servers based on the current load.
        ensures that system can handle spikes in treffic w/o mannual intervention 

        e.g AWS auto scalling monitors apps and automatically adjusts capacity to maintain steady.
            predictable performance at the lowest possible cost.
    Mutli region deployment
        deploy the app in multiple data centers and cloud regions to reduce latency and improve redundancy
        e.g spotify uses muti regions deployments to ennsure their music streaming service remains highly available and respondive
        to users all over the world, regardless of where they are located.
    
    
