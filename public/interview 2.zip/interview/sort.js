// bubble sort

function bubbleSort(arr){
    let swapped;
    do{
        swapped = false;
        for(let i=0;i<arr.length;i++){
            if(arr[i] > arr[i+1]){
                let temp = arr[i];
                arr[i] = arr[i+1];
                arr[i+1] = temp;
                swapped = true;
            }
        }
    }while(swapped);
    console.log(arr);
}
bubbleSort([0,4,2,9,0,2,3,1]);