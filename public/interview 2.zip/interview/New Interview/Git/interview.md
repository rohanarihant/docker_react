# git merge vs rebase
    The Core Difference
    Merge	                                                    Rebase
    Creates a merge commit that combines two branches	        Rewrites history by moving your branch to the tip of another
    Preserves complete history(including branching structure)	Creates a linear history (no merge commits)
    Non-destructive operation	                                Rewrites commit history (destructive to commit SHAs)
    Safer for shared branches	                                Riskier for shared branches

# Visual Example
           A---B---C  (feature)
         /
    D---E---F---G  (main)

Git Merge
    git checkout main
    git merge feature

              A---B---C  (feature)
         /         \
    D---E---F---G---H  (main)
                    ^
                  Merge commit

    History shows exactly when the branch was merged
    Branch structure is preserved

    Before either operation, this is what the repository looks like.
    main has progressed with commits M1 and M2. Your Feature branch has progressed separately
    with commits F1 and F2. Both branches have diverged.


Git Rebase
    git checkout feature
    git rebase main

            A'---B'---C'  (feature)
                     /
    D---E---F---G  (main)

    New commits A', B', C' are created with new SHAs
    Feature branch now starts from G (tip of main)
    History is linear (no merge commit)
    Original commits A, B, C are discarded (rewritten)

    The Feature branch no longer forks from the common ancestor.
    Instead, it now stems directly from M2 (the current tip of main).
    The original commits F1 and F2 are replaced by brand-new commits, F1' and F2'
    This creates a perfectly linear history that looks as though
    the feature was developed sequentially after main was completed.



# git merge →
    Preserves history.
    It takes two branches and joins them, creating a new "merge commit" that has two parents.
    It records exactly when and where branches diverged and came back together.

# git rebase →
    Rewrites history.
    It takes the commits from your feature branch and moves them to the tip of the target branch (e.g., main),
    creating a perfectly straight, linear line of commits.

# What is the HEAD in Git, and what does a "Detached HEAD" state mean?
    HEAD is simply a pointer that references the current commit or active branch you are currently working on.

# Q3: What is the difference between git fetch and git pull?    
    git fetch :- 
        safely communicates with your remote repository (like GitHub).
        It downloads new commits, branches, and tags from the remote but does not alter your local working files.
        It lets you see what others have done before deciding to integrate it.
    git pull :-
        is a combination command. It automatically runs git fetch first,
        and then immediately runs a git merge to force those remote changes into your current local branch.

# Explain the difference between git merge and git rebase. When would you use each?
    git merge takes the contents of a source branch and integrates them with the target branch via a unique "merge commit." It preserves the exact chronological history of when things happened, even if the commit history looks like a messy web.

    git rebase lifts your current branch's commits and replays them one-by-one on top of the target branch's latest commit. It rewrites history to create a perfectly flat, linear line

    The Rule:
        Use merge for public or shared branches (like main or develop) to avoid confusing teammates by altering history. Use rebase locally on your private feature branch to clean up your commit history before creating a pull request.

# Q5: You accidentally committed a file containing an API key or password to your local branch. How do you fix it before pushing?  
    You use git commit --amend
    First, fix the file on your local machine to remove the password.
    Run git add <file> to stage the corrected file.
    Run git commit --amend --no-edit.
        This tells Git to take your staged correction and override the previous bad commit directly,
        leaving no trace of the password in your local branch's history.

# Q6: What is the difference between git reset --soft, --mixed, and --hard?
    This dictates how aggressively you want to roll back your repository to a previous commit:
        --soft:
            Moves the HEAD pointer back to a target commit,
            but leaves your staged files and working directory untouched.
            Great for rewriting commit messages or squashing.
        --mixed (Default): Moves the HEAD pointer and un-stages your files.
            Your files remain on your computer, but they are marked as modified/unstaged.
        --hard:
            Destructive.
            It resets the HEAD,
            un-stages your files
            completely wipes out any uncommitted modifications in your working directory to match the target commit exactly.

# Q7: A developer deleted a local feature branch by mistake before pushing it to remote. Is that code lost forever? How do you recover it?
    No, it's rarely lost immediately thanks to git reflog
    Git maintains a hidden diary called the reference log (reflog)
    that tracks every single movement of the HEAD pointer—even across deleted branches or broken rebases.

    Git maintains a hidden diary called the reference log (reflog) that tracks every single movement of the HEAD pointer—even across deleted branches or broken rebases.
    