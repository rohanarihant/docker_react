# Improve performance in a React application

    reducing bundle size,
    preventing unnecessary re-renders,
    and optimizing asset delivery

#   Code Splitting & Bundle Size
    Lazy Loading:
        Use React.lazy() and Suspense to split code by route.
        This loads JavaScript only when a user visits that page.
    Tree Shaking:
        Import specific functions instead of entire libraries to exclude unused code from the final bundle.
    Bundle Analysis:
        Use webpack-bundle-analyzer or Vite's visualizer to find and remove heavy dependencies.

#   Rendering Optimization
    Component Memoization:
        Wrap functional components in React.memo() to skip re-rendering
        if their props have not changed.
    Hook Optimization:
        Use useMemo for expensive calculations and useCallback to cache function references between renders.
    Virtual Lists:
        Implement react-window or react-virtualized to render only the visible items in long lists.
    Stable Keys:
        Use unique, permanent IDs for list item key props instead of array indexes to help React match elements efficiently.

#   State Management
    State Colocation:
        Keep state as close to where it is used as possible instead of lifting it globally to prevent widespread re-renders
    Atomic State:
        Use libraries like Zustand or Recoil for fine-grained state updates that bypass parent component rendering
    Debouncing Inputs:
        Delay state updates for text inputs or search fields to prevent a render on every single keystroke.

#   Asset & Resource Management
    Data Caching:
        Use React Query (TanStack Query) or RTK Query to cache server data, eliminate duplicate requests, and update UI
    Instantly.Image Handling:
        Serve images in WebP format, use modern srcset attributes,
        and apply lazy loading (loading="lazy") for off-screen images.