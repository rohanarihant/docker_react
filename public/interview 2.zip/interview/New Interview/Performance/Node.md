# Improve Node.js & Express App Performance

# 1. Clustering & Process Management
    # Using Node.js Cluster Module
# 2. Caching Strategies
#   In-Memory Caching with Node-Cache
#   Redis Caching
# 3. Database Optimization
#   Connection Pooling
    // MySQL Connection Pool
        const mysql = require('mysql2');

        const pool = mysql.createPool({
        host: 'localhost',
        user: 'user',
        password: 'password',
        database: 'mydb',
        waitForConnections: true,
        connectionLimit: 10, // Maximum connections
        queueLimit: 0,
        enableKeepAlive: true,
        keepAliveInitialDelay: 0
        });

        // Promisify pool
        const poolPromise = pool.promise();

        // Use pool for queries
        async function getUsers() {
        const [rows] = await poolPromise.query('SELECT * FROM users');
        return rows;
        }

        // MongoDB Connection Pooling
        const mongoose = require('mongoose');

        mongoose.connect(process.env.MONGODB_URI, {
        useNewUrlParser: true,
        useUnifiedTopology: true,
        maxPoolSize: 10,
        minPoolSize: 2,
        maxIdleTimeMS: 30000,
        connectTimeoutMS: 30000
        });

        // PostgreSQL Pool
        const { Pool } = require('pg');
        const pgPool = new Pool({
        host: 'localhost',
        port: 5432,
        database: 'mydb',
        user: 'user',
        password: 'password',
        max: 20,
        idleTimeoutMillis: 30000,
        connectionTimeoutMillis: 2000
        });

# 4. Compression & Response Optimization
#   Enable Compression
#   Response Streaming
# 5. Middleware Optimization
# 6. Rate Limiting
#   Basic Rate Limiting
#   Advanced Rate Limiting with Redis
# 7. Logging & Monitoring
#   Structured Logging
    const winston = require('winston');

    const logger = winston.createLogger({
    level: 'info',
    format: winston.format.combine(
        winston.format.timestamp(),
        winston.format.errors({ stack: true }),
        winston.format.json()
    )})
# Monitoring with Prometheus
# 8. Security Headers (Helmet)
# 9. Database Query Optimization

