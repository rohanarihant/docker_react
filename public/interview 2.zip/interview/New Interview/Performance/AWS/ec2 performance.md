# if EC2 instances are failing then, what are the steps to follow to check them ?

#      🔍 Step 1: Check the Status Checks (Diagnose the Problem)
        select your instance and go to the Status checks tab

            System Status Check Failed 
                problem with the AWS physical host that your instance runs on
                This could be due to hardware degradation, network issues, or other infrastructure problems
            Instance Status Check Failed
                This indicates a problem within your instance's operating system or configuration
                such as a kernel panic, file system error, or full disk

#       🛠️ Step 2: Take Action Based on the Check
            solution is to force your instance to move to a new, healthy physical host
            Action :- choose Instance state > Stop instance, and then Start instance
#       B. If the Instance Status Check Failed (OS/Configuration Issue)
            Check System Logs:
                In the EC2 console, go to Actions > Monitor and troubleshoot > Get system log
                Look for errors like:
                    Kernel panics or out-of-memory (OOM) errors.
                    Filesystem errors (e.g., "fsck" errors).
                    Disk full errors. You can also check logs like /var/log/messages or /var/log/syslog if you have access
                Try a Reboot:
                    Start with a simple reboot by selecting Instance state > Reboot instance.
                    This can resolve transient software issues
                Try a Stop and Start:
                    If a reboot doesn't work, perform a stop and start to move the instance to new hardware,
                    which can also fix OS-level problems
                Advanced Troubleshooting (If Stop/Start fails):
                    If the instance won't start at all, you may need to detach its root volume,
                    attach it to a healthy "rescue" instance, and inspect the logs (/var/log/)
                    to fix the underlying configuration error
#       🚀 Step 3: When to Use Alternative Access Methods
            EC2 Serial Console:
                This is a powerful tool that gives you direct console access to your instance (if supported),
                allowing you to troubleshoot boot issues without a network connection
            AWS Systems Manager Session Manager:
                This provides a browser-based,
                secure shell connection that doesn't require opening inbound ports like SSH,
                making it a great alternative when networking is the problem
#       🧑‍💻 Step 4: If the Problem Persists
            Check the AWS Health Dashboard:
                There might be a broader issue with the EC2 service in your region.
            Contact AWS Support:
                If you've tried these steps and the issue remains, raise a support ticket 
