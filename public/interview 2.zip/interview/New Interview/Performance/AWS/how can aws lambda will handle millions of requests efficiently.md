#   1. How Lambda Scales Mechanically
    one Lambda execution environment handles exactly one request at a time
    
    Horizontal Scaling:
        if all current execution environments are busy for a new request then
        AWS instantly spins up a new instance (container) of your function to handle the new request
    Rapid Concurrency Scaling:
        AWS Lambda can scale independently across functions by 1,000 concurrent executions every 10 seconds until
        it hits your account's concurrency limit.
    Reuse:
        As soon as an environment finishes a request,
        it remains "warm" for a period to instantly pick up subsequent requests,
        avoiding the overhead of creating a new container

#   2. Design Patterns for High-Volume Efficiency
    Pattern A: Asynchronous / Event-Driven Buffering (Recommended)
        never hit Lambda directly with millions of raw requests.
            Buffer them using Amazon SQS or Amazon Kinesis.
        
        Why it works:
            If 500,000 requests hit your system simultaneously,
            SQS will absorb the spike instantly.
            Lambda then reads from the queue in controlled batches.
            This prevents your Lambda account from getting throttled and,
            more importantly, protects your downstream databases from crashing
    
    Pattern B: Synchronous API Traffic
        If the requests are coming from an API (via API Gateway or an Application Load Balancer):
            Enable Edge Caching:
                Utilize CloudFront or API Gateway caching.
                If 50% of your millions of requests are repetitive data fetches,
                caching them at the edge means they never invoke Lambda at all—saving you massive compute costs.  

#   3. Optimizing Your Lambda Code and Configuration
    When you execute millions of times, 
    even a 50-millisecond inefficiency adds up to massive delays and high AWS bills.

    Eliminate "Cold Starts"
        When Lambda spins up a new instance, it has to download your code and initialize your runtime.

        Provisioned Concurrency:
            For hyper-critical endpoints, you can allocate "Provisioned Concurrency."
            This keeps a specific number of environments perpetually hyper-warm and ready to respond
            instantly with zero initialization lag
        Minimize Bundle Size:
            Keep your deployment zip or container image as lean as possible.
            Only import the specific SDK modules you need rather than an entire heavy library
    4. Reuse Database Connections (Global Scope)
        Declare your database clients, configuration, and HTTP clients outside the handler function (in the global scope)
        This way, when Lambda reuses an execution environment, it reuses that exact connection

