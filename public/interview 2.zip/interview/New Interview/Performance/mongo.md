# Improve MongoDB Performance in Node.js

# 1. Indexing Strategies
#   Create Proper Indexes
#   Indexing in Mongoose
    const userSchema = new mongoose.Schema({
        email: { type: String, index: true, unique: true },
        username: { type: String, index: true },
        age: { type: Number, index: true },
        status: { type: String, index: true },
        createdAt: { type: Date, index: -1 },
        lastLogin: { type: Date, index: true }
    });

    // Compound indexes in Mongoose
    userSchema.index({ status: 1, createdAt: -1 });
    userSchema.index({ email: 1, username: 1 }, { unique: true });
#   Analyze Queries with Explain
    // Analyze query performance
    const result = await db.collection('users')
        .find({ status: 'active', age: { $gt: 18 } })
        .sort({ createdAt: -1 })
    .explain('executionStats');

    console.log('Query performance:', {
        executionTimeMs: result.executionStats.executionTimeMillis,
        totalDocsExamined: result.executionStats.totalDocsExamined,
        totalKeysExamined: result.executionStats.totalKeysExamined,
        stage: result.executionStats.executionStages.stage,
        indexUsed: result.executionStats.executionStages.inputStage?.indexName
    });

# 2. Query Optimization
#   Use Projection to Limit Fields (Only return needed fields)
    // ❌ Bad - Returns all fields
    const users = await db.collection('users')
    .find({ status: 'active' })
    .toArray();

    // ✅ Good - Only return needed fields
    const users = await db.collection('users')
    .find({ status: 'active' })
    .project({ 
        name: 1, 
        email: 1, 
        role: 1, 
        _id: 0 
    })
    .toArray();

    // In Mongoose
    const users = await User.find(
    { status: 'active' },
    'name email role -_id'
    ).lean();

# Use Lean Queries (Mongoose)   (Returns plain JavaScript objects)
    // ❌ Bad - Returns Mongoose documents (heavy)
    const users = await User.find({ status: 'active' });

    // ✅ Good - Returns plain JavaScript objects
    const users = await User.find({ status: 'active' }).lean();

    // With virtuals
    const users = await User.find()
    .lean({ virtuals: true });

    // For large datasets
    const users = await User.find()
    .select('name email')
    .lean()
    .exec();

# Prefer Aggregation pipeline
# Batch Operations
    // ❌ Bad - Multiple individual operations
        for (const user of users) {
        await db.collection('users').updateOne(
            { _id: user._id },
            { $set: { lastLogin: new Date() } }
        );
        }

        // ✅ Good - Bulk write
        const bulkOps = users.map(user => ({
        updateOne: {
            filter: { _id: user._id },
            update: { $set: { lastLogin: new Date() } },
            upsert: false
        }
        }));

        await db.collection('users').bulkWrite(bulkOps, {
        ordered: false // Continue on error
        });

        // ✅ Even better - Bulk update with pipeline
        await db.collection('users').updateMany(
        { status: 'inactive' },
        [
            { $set: { status: 'archived' } },
            { $set: { archivedAt: new Date() } }
        ]
        );
# 3. Aggregation Pipeline Optimization
#    Use Pipeline Stages Efficiently
#    Use $lookup with Sub-pipeline
# 5. Caching Strategies
# 6. Read Preference & Write Concern
      // readPreference: 'secondary',     // Only read from secondaries
     // readPreference: 'secondaryPreferred', // Prefer secondaries
    // readPreference: 'nearest',       // Read from nearest node
# Optimize Write Concern
    // Default write concern (acknowledged)
        await db.collection('users').insertOne({ name: 'John' });
    // For non-critical data (faster)
        await db.collection('logs').insertOne(
            { message: 'Log message' },
            { writeConcern: { w: 0 } } // Unacknowledged
        );
    // For critical data (slower but more durable)
        await db.collection('payments').insertOne(
        { amount: 100, status: 'completed' },
        { 
            writeConcern: { 
            w: 'majority', 
            wtimeout: 5000,
            j: true // Journal
            }
        }
        );

# 7. Data Modeling & Schema Design
#   Use Embedded Documents vs References
    // ✅ Good for one-to-few relationships (Embedded)
const userSchema = new mongoose.Schema({
  name: String,
  email: String,
  addresses: [{
    street: String,
    city: String,
    country: String,
    isDefault: Boolean
  }]
});

// ✅ Good for one-to-many (References)
const orderSchema = new mongoose.Schema({
  userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  items: [{
    productId: { type: mongoose.Schema.Types.ObjectId, ref: 'Product' },
    quantity: Number,
    price: Number
  }],
  total: Number,
  status: String
});

// ✅ Hybrid approach (Embed frequent data, reference infrequent)
const productSchema = new mongoose.Schema({
  name: String,
  price: Number,
  // Embed frequently accessed data
  reviewsSummary: {
    averageRating: Number,
    totalReviews: Number
  },
  // Reference full reviews
  reviews: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Review' }]
});