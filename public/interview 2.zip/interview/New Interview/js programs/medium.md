1. Remove duplicates from an array

function removeDuplicateFromArray(arr){
    const uniqueArray = [];
    for(let i=0;i<arr.length;i++){
        if(uniqueArray.indexOf(arr[i]) === -1){
            uniqueArray.push(arr[i]);
        }
    }
    return uniqueArray;
}

2. Remove duplicates from array of objects by id
const users = [
  { id: 1, name: "A" },
  { id: 2, name: "B" },
  { id: 1, name: "A" }
];

function removeDuplicatesFromArrayOfObjects(arrayOfObjects){
    return [...new Map(arrayOfObjects.map((obj) => [...obj.id, obj])).values()]
}

3. Flatten a nested array
function flatten(arr){
    let result = [];
    for(let ele of arr){
        if(Array.isArray(ele)){
            result = [...result, ...flatten(ele)]
            <!-- result = result.concat(flatten(ele)) -->
        }else{
            result.push(ele)
        }
    }
    return result;
}

console.log(flatten([1, [2, [3, 4]], 5]));

4. Count frequency of elements
const arr = ["a", "b", "a", "c", "b", "a"];

function countFrequencyOfElements(list){
    let freqOfElements = {};
    for(let element of list){
        if(!freqOfElements[element]){
            freqOfElements[element] = 1
        }else{
            freqOfElements[element] += 1
        }
    }
    return freqOfElements
}
console.log(countFrequencyOfElements(arr))

5. 5. Find the first non-repeating character
function firstUniqueChar(str){
    let obj = {};
    for(let char of str){
        if(str.indexOf(char) === str.lastIndexOf(char)){
            return char;
        }
    }
}
console.log(firstUniqueChar("javascript"));

function firstUniqueChar(str){
    let chars = {};
    for(let char of str){
        chars[char] = (chars[char] || 0) + 1;
    }
    for(let char of str){
        if(chars[char] === 1) return char
    }
}
console.log(firstUniqueChar("javascript"));

6. Check if two strings are anagrams
function isAnagram(str1, str2){
    if(str1.length !== str2.length){
        return false;
    }
    const normalize = (str) => str.split("").sort().join("")

    return normalize(str1) === normalize(str2)
}
console.log(isAnagram("listen", "silent"));
function normalizeString(str){
    let chars = {};
    for(let char in str){
        chars[char] = (chars[char] || 0) + 1;
    }
    return chars;
}
function isAnagram(str1, str2){
    if(str1.length !== str2.length){
        return false;
    }
    let chars = {};
    for(let char in str1){
        chars[char] = (chars[char] || 0) + 1;
    }
    for(let char in str2){
        if(!chars[char]){
            return false;
        }
        chars[char]--;
    }
    return true
}

7. Implement debounce

function debounce(fn, delay){
    let timer
    return function(...args){
        clearTimeout(timer);
        timer = setTimeout(() => {
            fn(...args)
        },delay)
    }
}

const search = debounce(() => {
    console.log('...searching')
},2000)
search();

8. Implement throttle

function throttle(fn, delay){
    let lastCall = 0
    return function(...args){
        const now = Date.now()
        if(now - lastCall >= delay){
            fn(...args)
            lastCall = now
        }
    }
}

const search = throttle(() => {
    console.log('...searching')
}, 2000)
search()

9. curry a func
function curry(a){
    return function(b){
        return b ? curry(a+b) : a
    }
}

console.log(curry(1)(2)(3)())

function curry(fn){
    return function curried(...args){
        if(args.length >= fn.length){
            return fn(...args);
        }

        return function(...nextArgs){
            return curried(...args, ...nextArgs);
        }
    }
}
function sum(a,b,c){
    return a+b+c;
}
const newCurry = curry(sum);
console.log(newCurry(1)(2)(4))

10. Implement memoization

function memoize(fn){
    let cache = new Map();
    return function(...args){
        let key = JSON.stringify(args);

        if(cache.has(key)){
            return cache.get(key);
        }
        const result = fn(...args);
        cache.set(key, result)
        return result;
    }
}

const slowSquare = n => n*n;
const flatSquare = memoize(slowSquare)
console.log(flatSquare(25))

# 11. Implement deep clone
    function deepClone(obj, map = new Map()){
        if(obj === null || typeof obj === 'object') return obj;

        if(map.has(obj)) return map.get(obj);

        const clone = Array.isArray(obj) ? [] : {};
        map.set(obj, data);

        for(let key in obj){
            clone[key] = deepClone(obj[key], map);
        }
        return clone;
    }
    console.log(deepClone({
        a:"hello",
        data: {
            power: "power"
        },
        name: null,
        uname: ['name','prithiv']
    }))

# 12. Implement Promise.all
const promise1 = new Promise((resolve, reject) => {
        setTimeout(() => {
            resolve('resolved promise 1')
        },1000);
    })
    const promise2 = new Promise((resolve, reject) => {
        setTimeout(() => {
            resolve('resolved promise 2')
        },1000);
    })
    const promise3 = new Promise((resolve, reject) => {
        setTimeout(() => {
            reject('reject promise 3')
        },1000);
    })
    function promiseAll(promises){
        let result = {};
        let taskCounter = 0;
        return new Promise((resolve, reject) => {
            promises.forEach((promise) => {
                promise.then(res => {
                    result[res] = res;
                    taskCounter++;

                    if(taskCounter === promises.length){
                        resolve(result)
                    }
                }).catch(error => {
                    reject(error);
                })
            })
        })
    }

console.log(promiseAll([promise1, promise2, promise3]).then(res => console.log(res)))

# 13. Implement retry logic for async function
    async function retry(fn, attempts=3, delay=1000){
        try{
            return await fn();
        }catch(err){
            if(attempts <= 1) return err;

            await new Promise((resolve) => setTimeout(resolve, delay));
            return retry(fn, attempts-1, delay)
        }
    }

# 14. Implement an EventEmitter
    class EventEmitter(){
        constructor(){
            this.events = {}
        }

        on(event, listener){
            if(!this.events[event]) this.events[event] = [];
            this.events[event].push(listener);
        }

        emit(event, ...args){
            if(!this.events[event]) return;
            this.events[event].forEach((fn) => fn(...args));
        }
        off(event, listener){
            if(!this.events[event]) return;
            this.events[event] = this.events[event].filter((ent) => ent !== listener);
        }
    }

