# 1. Top 4xx Client Error Codes
    Code                     Name                           When to Use It
    400	                     Bad Request	                Generic client error.
                                                            Use when payload syntax is invalid,
                                                            required parameters are missing,
                                                            or malformed JSON is sent.
    
    401	                    Unauthorized	                Missing or invalid authentication credentials
                                                            (e.g., missing JWT token, expired session, or bad API key). Actually means "Unauthenticated".
    
    403	                    Forbidden	                    The client is authenticated,
                                                            but does not have permission to access the resource
                                                            (e.g., a regular user attempting to call an Admin endpoint).

    404	                    Not Found	                    The requested URI path does not exist,
                                                            or the specific database record
                                                            (e.g., /users/999) was not found.

    409	                    Conflict	                    Request conflicts with current server state.
                                                            Frequently used when creating a resource that already exists
                                                            (e.g., duplicate email on registration).

    422                     Unprocessable Entity            The JSON syntax is valid,
                                                            but the payload fails schema validation rules
                                                            (e.g., email format invalid, age is a negative number). Extremely popular in modern APIs (Express, FastAPI, Rails).
    
    429                     Too Many Requests               The client has exceeded rate limits within a given time window.


#   2. Top 5xx Server Error Codes
    Server errors indicate that the client sent a valid request, but the server failed internally to process it.

    500                     Internal Server Error           Generic catch-all for unhandled exceptions,
                                                            runtime bugs, or unexpected server crashes.
    
    502                     Bad Gateway                     The server acting as a gateway/proxy
                                                            (e.g., NGINX, API Gateway)
                                                            received an invalid response from an
                                                            upstream server or microservice.
    
    503                     Service Unavailable             The server is temporarily unable to handle the request
                                                            due to maintenance, deployment, or heavy traffic overload.
    
    504                     Gateway Timeout                 An upstream service or database took too
                                                            long to respond,                                                causing the proxy/gateway to time out.