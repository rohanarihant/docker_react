# GroupBy
const employees = [
 { name: "Asha", dept: "Eng" },
 { name: "Ravi", dept: "Sales" },
 { name: "Meena", dept: "Eng" }
];

function groupBy(arr, key){
    let obj = {};
    for(let ele of arr){
        if(!obj[ele[key]]) obj[ele[key]] = [];
        obj[ele[key]].push(ele);
    }
    return obj;
}

function groupBy(arr, kay){
    return arr.reduce((prev, curr) => {
        if(!prev[curr[key]]) prev[curr[key]] = [];
        prev[curr[key]].push(curr);
        return prev;
    },{})
}
console.log(groupBy(employees, 'dept'))

# Q2 Group and count occurrences
const products = [
 { name: "Pen", category: "Stationery" },
 { name: "Notebook", category: "Stationery" },
 { name: "Laptop", category: "Electronics" }
];

function groupCountBy(arr, key){
    let obj = {};
    for(let ele of arr){
        if(!obj[ele[key]]) obj[ele[key]] = 0;
        obj[ele[key]] += 1;
    }
    return obj;
}
console.log(groupCountBy(products, 'category'))

# Q3 Group by multiple keys (composite key)
const staff = [
 { name: "Asha", dept: "Eng", role: "Dev" },
 { name: "Ravi", dept: "Eng", role: "QA" },
 { name: "Meena", dept: "Eng", role: "Dev" }
];

function groupByMulti(arr, keys){
    let obj = {};
    for(let ele of arr){
        const compositionKeys = keys.map((key) => ele[key]).join("|");
        (obj[compositionKeys] = obj[compositionKeys] || []).push(obj[compositionKeys].push(ele))
    }
    return obj;
}
console.log(groupByMulti(staff, ["dept", "role"]))

# Q4 Convert array of objects to a map keyed by ID
const users = [
 { id: "u1", name: "Asha" },
 { id: "u2", name: "Ravi" }
];

# Q7 Flatten a deeply nested object

const nested = {
 user: {
    name: "Asha",
    address: { city: "Bengaluru", zip: "560001" }
 },
 active: true
};

<!-- {a:{b:1}} -> {"a.b":1}. -->

function flattenObject(obj, prefix=""){
    let newObj = {};
    for(let key in obj){
        let value = obj[key];
        let newKey = prefix ? `${prefix}.${key}` : prefix;
        if(typeof value === 'object' && !Array.isArray(value)){
            Object.assign(newObj, flattenObject(value, newKey))
        }else{
            newObj[newKey] = value;
        }
    }
    return newObj;
}
console.log(flattenObject(nested))

# Q8 Unflatten a dot-notation object
const flat = {
 "user.name": "Asha",
 "user.address.city": "Bengaluru",
 "active": true
};

function unflattenObject(obj){
    let newObj = {};
    for(let keys in obj){
        let allKeys = keys.split(".");
        let current = newObj;
        for(let ele of allKeys){
            if(ele === allKeys[allKeys.length-1]){
                currrent[ele] = obj[allKeys];
            }else{
                currrent[ele] = currrent[ele] || {};
                currrent = currrent[ele];
            }
        }
    }
    return newObj;
}
console.log(unflattenObject(flat))

# Q10 Deep clone an object
const original = {
 name: "Asha",
 address: { city: "Bengaluru" },
 tags: ["dev", "lead"],
 createdAt: new Date()
};
    function deepClone(obj, map= new Map()){
        if(obj === null || typeof obj !== 'object') return obj;
        if(obj instanceOf Date) return new Date(obj.getTime());
        if(map.has(obj)) return map.get(obj);
        
        const clone = Array.isArray(obj) ? [] : {};
        map.set(obj, clone);
        for(let key of Object.keys(obj)){
           clone[key] = deepClone(obj[key], map)
        }
        return clone;
    }

    const copy = deepClone(original);
    copy.address.city = "Mumbai";
    console.log(copy);

# Q11 Deep merge two or more objects

const defaults = {
 theme: { color: "blue", size: "md" },
 features: { beta: false }
};
const overrides = {
 theme: { color: "red" },
 features: { beta: true, gamma: true }
};

function isSimpleObject(obj){
    return obj !== null && typeof obj === 'object' && !Array.isArray(obj);
}
function deepMerge(target, source){
    let result = {...target};

    for(let key of Object.keys(source)){
        if(isSimpleObject(result[key]) && isSimpleObject(source[key])){
            result[key] = deepMerge(result[key], source[key]);
        }else{
            result[key] = source[key];
        }
    }
    return result;
}

console.log(deepMerge(defaults, overrides))

# Q12 Build a tree from a flat parent-child list
const flatCategories = [
 { id: 1, name: "Electronics", parentId: null },
 { id: 2, name: "Phones", parentId: 1 },
 { id: 3, name: "Laptops", parentId: 1 },
 { id: 4, name: "Android", parentId: 2 }
];

function buildTree(obj){
    let mapTree = new Map(obj.map(ob => [ob.id, {...ob, children: []}]));
    const root = [];

    for(let key of mapTree.values()){
        console.log(key)
    }

}

# Q13 Invert an object (swap keys and values)
const roleIds = { admin: 1, editor: 2, viewer: 3 };

function invertObj(obj){
    let newObj = {}
    for(let [key, value] of Object.entries(obj)){
        newObj[value] = key
    }
    return newObj;
}

console.log(invertObj(roleIds))

# Q14 Rename keys in an object based on a mapping
const apiUser = { usr_name: "Asha", usr_email: "asha@example.com", age: 30 };
const keyMap = { usr_name: "name", usr_email: "email" };

function renameObj(apiUser, keyMap){
    let newObj = {};
    for(let key in apiUser){
        const newKey = keyMap[key];
        console.log(newObj[newKey])
        if(newObj[newKey]){
            newObj[newKey] = apiUser[key];
        }       
    }
    return newObj;
}

console.log(renameObj(apiUser,keyMap))

