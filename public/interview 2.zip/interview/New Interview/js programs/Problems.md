# Reverse a String
function reverseString(str){
    let reverse = '';
    for(let i=str.length-1;i>=0;i--){
        reverse += str[i];
    }
    return reverse;
}

console.log(reverseString('Rohan'))

function reverseString(str){
    let reverse = '';
    for(let char of str){
        reverse = char+reverse;
    }
    return reverse;
}

console.log(reverseString('Rohan'))

# Check Palindrome
    const isPalindrome = (str) => {
        let reverse = ''
        for(let char of str){
            reverse = char + reverse;
        }
        return reverse === str;
    }
    console.log(isPalindrome('rohan'))

# Find second Largest Number in Array
    function findSecondLargestNumber(arr){
        let first = arr[0];
        let second = null;

        for(let i=1;i<arr.length;i++){
            if(arr[i] > first){
                second = first;
                first = arr[i];
            }else if(arr[i] > second && arr[i] !== first){
                second = arr[i];
            }
        }
        return second;
    }

    console.log(findSecondLargestNumber([10, 5, 8, 20, 15])); // 15
    console.log(findSecondLargestNumber([5, 5, 5, 5])); // null (all equal)
    console.log(findSecondLargestNumber([1, 2])); // 1

# Remove Duplicates from Array
    function removeDuplicate(arr){
        let uniqueArray = [];
        for(let i=0;i<arr.length;i++){
            if(uniqueArray.indexOf(arr[i]) === -1){
                uniqueArray.push(arr[i])
            }
        }
        return uniqueArray
    }
    console.log(removeDuplicate([1,2,1,3,4,5,6]));

# count vowels in string
    function countVowelsInString(stringWithVowels){
        let count = 0;
        const vowels = ['a','e','i','o','u'];
        for(let char of stringWithVowels){
            if(vowels.indexOf(char.toLowerCase()) !== -1){
                count++
            }
        }
        return count;
    }
    console.log(countVowelsInString('rOhan'))

# factorial of a number
    const factorial = (n) => n <= 1 ? 1 : n * factorial(n-1);
    console.log(factorial(5))

# Check if number is Prime
    const checkPrimeNumber = (n) => {
        if(n<2) return n;
        for(let i=2;i<Math.sqrt(n);i++){
            if(n % i === 0) return false;
        }
        return true
    }
    checkPrimeNumber(7)
    checkPrimeNumber(10)

# Flatten a Nested Array

function flatternArray(arr){
    let result = [];
    for(let i=0;i<arr.length;i++){
        if(Array.isArray(arr[i])){
            result.push(...flattenArray(arr[i]))
        }else{
            result.push(arr[i])
        }
    }
    return result;
}


# group by 
const people = [
{ name: 'John', age: 25 },
{ name: 'Jane', age: 30 },
{ name: 'Bob', age: 25 },
];
function groupBy(arr, key){
    let obj = {};
    for(let i=0;i<arr.length;i++){
        let item = arr[i];
        let groupedValue = item[key]
        if(!obj[groupedValue]){
            obj[groupedValue] = [];
        }
        obj[groupedValue].push(item);
    }
    return obj;
}

const groupedBy = groupBy(people, 'age');

# Debounce func
function debounce(fn, delay){
    let timer;
    return function(...args){
        clearTimeout(timer);
        timer = setTimeout(() => {
            fn(...args);
        }, delay)
    }
}

const query = debounce((query) => console.log(query), 300)


# Throttle function
    const throttle = (fn, delay) => {
        let lastCall = 0;
        return function(...args){
            let now = Date.now();
            if(now - lastcall >= delay){
                lastCall = now;
                fn(...args)
            }
        }
    }

# Deep clone an object
    const deepClone = (obj) => {
        if(obj === null || typeOf obj !== 'object') return obj;
        let copy = Array.isArray(obj) ? [] : {};
        for(let key in obj){
            copy[key] = deepClone(obj[key])
        }
        return copy;
    }

# Analgram of 2 strings
    function isAnagram(str1, str2) {
  // 1. If lengths are different, they cannot be anagrams
  if (str1.length !== str2.length) {
    return false;
  }

  const charMap = {};

  // 2. Count frequencies in the first string manually
  for (let i = 0; i < str1.length; i++) {
    const char = str1[i];
    if (charMap[char]) {
      charMap[char]++;
    } else {
      charMap[char] = 1;
    }
  }

  // 3. Compare and subtract frequencies using the second string
  for (let i = 0; i < str2.length; i++) {
    const char = str2[i];

    // If the character doesn't exist in our map or its count is already 0
    if (!charMap[char]) {
      return false;
    }

    charMap[char]--;
  }

  return true;
}

// --- Test Cases ---
console.log(isAnagram("listen", "silent")); // Output: true
console.log(isAnagram("hello", "billion")); // Output: false
console.log(isAnagram("rat", "car"));       // Output: false

# Chunk an array
const chunk = (arr, target) => {
    let chunkedArray = [];
    for(let i=0;i<arr.length;i++){
        chunkedArray.push(arr.slice(i,i+target))
    }
    return chunkedArray;
}

# 2 pointer
function twoSum(nums, target) {
    // Initialize the HashMap
    const numMap = new Map();

    // Single loop traversal
    for (let i = 0; i < nums.length; i++) {
        const currentNum = nums[i];
        const complement = target - currentNum;

        // Check if the complement is already in the map
        if (numMap.has(complement)) {
            // Return the stored index and the current index
            return [numMap.get(complement), i];
        }

        // If not found, save current number and index to the map
        numMap.set(currentNum, i);
    }

    return []; // Return empty array if no solution exists
}

// Example Execution:
const nums =;
const target = 9;
console.log(twoSum(nums, target)); 

# 2 Pointer problem solution
function twoSumTwoPointer(nums, target) {
    // Initialize pointers at the start and end of the sorted array
    let left = 0;
    let right = nums.length - 1;

    // Loop continues until the pointers meet
    while (left < right) {
        const currentSum = nums[left] + nums[right];

        if (currentSum === target) {
            return [left, right]; // Found the pair
        } else if (currentSum < target) {
            left++; // Sum is too small, move left pointer right to increase sum
        } else {
            right--; // Sum is too large, move right pointer left to decrease sum
        }
    }

    return []; // Return empty array if no solution exists
}

// Example Execution (Array MUST be sorted):
const sortedNums =;
const target = 9;
console.log(twoSumTwoPointer(sortedNums, target)); // Output: [0, 1]

# bubble sort
    function bubbleSort(arr) {
    let n = arr.length;
    
    // Outer loop moves the boundary of the unsorted part
    for (let i = 0; i < n; i++) {
        // Inner loop compares adjacent elements
        for (let j = 0; j < n - 1 - i; j++) {
            // Swap if the current element is greater than the next
            if (arr[j] > arr[j + 1]) {
                let temp = arr[j];
                arr[j] = arr[j + 1];
                arr[j + 1] = temp;
            }
        }
    }
    return arr;
}

// Example Execution:
const numbers = [9,4,6,2,5,1,5,6];
console.log(bubbleSort(numbers)); 

# objs deep comparison
    
function isDeepEqual(obj1, obj2) {
  // 1. If both point to the exact same memory reference, they are equal
  if (obj1 === obj2) return true;

  // 2. If either is not an object, or is null, handle primitive comparison
  if (typeof obj1 !== 'object' || obj1 === null || typeof obj2 !== 'object' || obj2 === null) {
    return false;
  }

  // 3. Get the keys of both objects
  const keys1 = Object.keys(obj1);
  const keys2 = Object.keys(obj2);

  // 4. If they don't have the same number of properties, they aren't equal
  if (keys1.length !== keys2.length) return false;

  // 5. Recursively check every key and value
  for (let key of keys1) {
    // Check if the key exists in obj2 and evaluates to the same deep structure
    if (!keys2.includes(key) || !isDeepEqual(obj1[key], obj2[key])) {
      return false;
    }
  }

  return true;
}

// --- Test Case ---
const complex1 = { name: "Alice", details: { id: 101, roles: ["admin"] } };
const complex2 = { details: { id: 101, roles: ["admin"] }, name: "Alice" }; // Reordered fields

console.log(isDeepEqual(complex1, complex2)); // Output: true



function deepObjComparison(obj1, obj2){
    if(obj1 === obj2){
        return true
    }
    if(typeof obj1 !== 'object' || obj1 === null || typeof obj2 !== 'object' || obj2 === null){
        return false;
    }
    let keys1 = Object.keys(obj1);
    let keys2 = Object.keys(obj2);

    if(keys1.length !== keys2.length){
        return false
    }
    for(let key of keys1){
        if(!keys2.includes(key) || !deepObjComparison(obj1[key], obj2[key])){
            return false;
        }
    }
    return true;
}

const complex1 = { name: "Alice", details: { id: 101, roles: ["admin"] } };
const complex2 = { details: { id: 101, roles: ["admin"] }, name: "Alice" }; // Reordered fields

console.log(deepObjComparison(complex1, complex2));

# filtering the object
const students = [
    {id: 1, name: "Amit", grade: "A"},
    {id: 2, name: "Priya", grade: "B"},
    {id: 3, name: "Rahul", grade: "A"},
    {id: 4, name: "Sneha", grade: "C"},
    {id: 5, name: "Vikram", grade: "B"},
    {id: 6, name: "Neha", grade: "A"},
    {id: 7, name: "Karam", grade: "C"}
]

const formatStudents = (students) => {
    let map = {};
    for(let student of students){
        if(!map[student.name]){
            map[student.grade] = []
        }
        map[student.grade].push(student.name)
    }
    return map;
}
console.log(formatStudents(students))