1. Two Sum

function twoSum(nums, target){
    let map = new Map();
    for(let i=0;i<=nums.length;i++){
        let complement = target - nums[i];
        if(map.has(complement)){
            return [nums[i], complement]   
        }
        map.set(nums[i], i)
    }
    return []
}
console.log(twoSum([1,2,3,4,5,7], 9))

2. Two Sum with pair of indexes

function twoSumAllPairs(nums, target){
    let result = [];
    let map = {};

    for(let i=0;i<nums.length;i++){
        let currElement = nums[i];
        let complement = target-nums[i];

        if(map[complement] !== undefined){
            for(let objIndex of map[complement]){
                result.push([i, objIndex]);
            }
        }
        if(map[currElement] === undefined){
            map[currElement] = []
        }
        map[currElement].push(i)
    }
    return result;
}
console.log(twoSumAllPairs([1,2,3,4,5,7], 9))

3. Maximum SubArray 
function maximumSubArray(nums){
    let maxSubArray=nums[0]; let maxEndingHere = nums[0];
    for(let i=1; i<nums.length;i++){
        maxEndingHere = Math.max(nums[i], maxEndingHere + nums[i]);
        maxSoFar = Math.max(maxSoFar, maxEndingHere)
    }
    return maxSoFar;
}
console.log(maximumSubArray([-2,1,-3,4,-1,2,1,-5,4],6))

4. Rotate array by K positions
function rotate(nums, k){
    const chunk = nums.slice(0,k)
    return [...nums.slice(k,nums.length),...chunk]
}

rotate([1,2,3,4,5,6,7], 3)

function rotate(nums, k){
    let start = 0;
    let end = k;
    while(start < end){
        [nums[start], nums[end]] = [nums[start], nums[end]]
    }
}
console.log(rotate([1,2,3,4,5,6,7], 3));

5. welcome to @Geeks#for#Geeks@@@, print character counts to string

function countCharacters(str){
    let chars = {};
    let result = '';
    for(let char of str){
        if(chars[char] === undefined){
            chars[char] = 1
        }else{
            chars[char] += 1
        }
    }
    for(let [key, value] of Object.entries(chars)){
        result += `${key}${value},`
    }
    return result;
}

console.log(countCharacters('@Geeks#for#Geeks@@@'))

6. const input = [{name: 'personX', list:[1,2,3,4,5,6,7]}, {name: 'personY', list:[8,9,10,11,12,13]}]
<!-- output : {personX: [2,3,5,7], personY: [11, 13]} -->
<!-- program to take input and resturn exact output -->


function isPrime(num){
    if(num <= 1) return false;
    for(let i=2; i<=Math.sqrt(num); i++){
        if(num % i === 0) return false;
    }
    return true;
}

function formatObj(input){
    let result = {};
    for(let obj of input){
        result[obj.name] = obj.list.filter(isPrime)
    }
    return result;
}

console.log(formatObj(input))

7. reverse a string without changing the position of special character
input = "R@*IG#H!T" output= "T@*HG#I!R"

const input = "R@*IG#H!T";
// output= "T@*HG#I!R"

function reverseStringWithoutSpecialCharacter(str){
    const alphabets = ['a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z']

    const isAlphabet = (char) => alphabets.indexOf(char) !== -1;
    let newStr = str.split("");
    let start = 0;
    let end = newStr.length-1;
    let tempChar = null;
    while(start <= end){
        
        if(!isAlphabet(newStr[start].toLowerCase())){
            start++;
        }
        if(!isAlphabet(newStr[end].toLowerCase())){
            end--;
        }else{
            tempChar = newStr[start];
            newStr[start] = newStr[end];
            newStr[end] = tempChar;
            start++;
            end--;
        }
        
    }
    return newStr.join("");
}

console.log(reverseStringWithoutSpecialCharacter("R@*IG#H!T"))

# solve this cal(10)(20)(30)('add')

function cal(...args){
    next = function(...nextArgs){
        const lastArgs = nextArgs[nextArgs.length-1]
        if(typeof lastArgs === 'string'){
            return execute([...args, ...nextArgs.slice(0,nextArgs.length-1)], lastArgs)
        }
        return cal(...args, ...nextArgs)
    }
    return next;
};

function execute(nums,diff){
    if(diff === "add") return nums.reduce((prev, curr) => prev+curr,0);
    if(diff === "sub") return nums.reduce((prev, curr) => prev-curr);
    if(diff === "mul") return nums.reduce((prev, curr) => prev*curr,1);
    return 'Invalid Option';
}
console.log(cal(10)(20)(30)('sub'))

# call apis with delays
const delays = [1000,500,200];

const fakeApi = (ms) => new Promise(res => setTimeout(() => res(`Done ${ms}`),ms));

console.log("start")
delays.forEach(async(ms) => {
    const result = await fakeApi(ms);
    console.log(result);
});

console.log("End")
# write a function to match all open brackets have a closed one in js
<!-- input ()({})[()] -> true -->

function isBalanced(str){
    const stack = [];
    const pairs = {')':'(', '}':'{', ']':'['}
    const opneners = new Set(['(','{','[']);

    for(let char of str){
        if(opneners.has(char)){
            stack.push(char);
        }else if(char in pairs){
            if(stack.pop() !== pairs[char]) return false;
        }
    }
    return stack.length === 0;
}
console.log(isBalanced("()({})[()]"))