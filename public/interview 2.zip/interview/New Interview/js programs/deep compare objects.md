function validateNestedObjects(obj1, obj2){
    if(obj1 === obj2){
        return true
    }
    if(!obj1 || !obj2) return false
    if(typeof obj1 !== typeof obj2) return false
    if(typeof obj1 !== 'object'){
        return obj1 === obj2
    }
      // Handle arrays
  if (Array.isArray(obj1) && Array.isArray(obj2)) {
    if (obj1.length !== obj2.length) return false;
    for (let i = 0; i < obj1.length; i++) {
      if (!deepValidateObjects(obj1[i], obj2[i])) return false;
    }
    return true;
  }
  
  // If one is array and other isn't
  if (Array.isArray(obj1) || Array.isArray(obj2)) return false;
    const key1 = Object.keys(obj1)
    const key2 = Object.keys(obj2)
    if(key1.length !== key2.length) return false
    for(let key of key1){
        if(!key2.includes(key)) return false

        const val1 = obj1[key]
        const val2 = obj2[key]

        if(!validateNestedObjects(val1, val2)) return false
    }
    return true
}
const objA = { name: "John", age: 25, address: { city: "NYC", zip: 10001 } };
const objB = { name: "John", age: 25, address: { city: "NYC", zip: 10001 } };
const objC = { name: "John", age: 30, address: { city: "NYC", zip: 10001 } };

console.log(validateNestedObjects(objA, objB)); // true
console.log(validateNestedObjects(objA, objC)); // false