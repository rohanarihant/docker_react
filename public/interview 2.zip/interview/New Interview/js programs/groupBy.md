function groupBy(itemList, fn){
    return itemList.reduce((prev, curr) => {
        const key = fn(curr);

        if(!prev[key]){
            prev[key] = []
        }
        prev[key].push(curr);
        return prev;
    },{})
}

const fruits = ['apple', 'banana', 'apple', 'orange', 'banana'];
const grouped = groupBy(fruits, fruit => fruit);
console.log(grouped);