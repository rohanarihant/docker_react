# Prototypal Inheritance vs ES6 Classes

    Core Concept: They're the Same Under the Hood
        ES6 classes are syntactic sugar over JavaScript's prototypal inheritance.
        Understanding both is crucial for JavaScript mastery.

    // Both achieve the same result
    // Prototypal inheritance (pre-ES6)
    function Animal(name) { this.name = name; }
    Animal.prototype.speak = function() { console.log(`${this.name} makes sound`); };

    // ES6 Class
    class AnimalClass {
        constructor(name) { this.name = name; }
        speak() { console.log(`${this.name} makes sound`); }
    }

