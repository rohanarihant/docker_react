# Unidirectional Streaming: Server-to-Client Updates

    1. Server-Sent Events (SSE) ⭐ Most Recommended
        Perfect for financial data feeds - unidirectional, auto-reconnecting, built on HTTP/1.1+.

            app.get('/stock-prices', (req, res) => {
            res.writeHead(200, {
                'Content-Type': 'text/event-stream',
                'Cache-Control': 'no-cache',
                'Connection': 'keep-alive',
                'Access-Control-Allow-Origin': '*'
            });
            
            const interval = setInterval(() => {
                const price = {
                symbol: 'AAPL',
                price: getRandomPrice(),
                timestamp: Date.now()
                };
                res.write(`data: ${JSON.stringify(price)}\n\n`);
            }, 100);
            
            req.on('close', () => clearInterval(interval));
            });

        Performance Metrics (Real-world)
            Metric	            WebSocket	       SSE      Difference
            Messages/sec	    65,000	           52,000   20% slower
            Memory/connection	35KB	           18KB	    48% less
            CPU for 10K clients	45%	               28%	    38% less