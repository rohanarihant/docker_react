# Web Vitals in React
    Web Vitals are a set of metrics that measure user experience and performance in web applications.
    Here's a comprehensive guide to implementing and optimizing Web Vitals in React.

#   What are Core Web Vitals?
Core Web Vitals are three specific metrics that measure different aspects of user experience:

1. LCP (Largest Contentful Paint) - Loading Performance
    Measures loading speed of the largest content element
    Good: ≤ 2.5 seconds
    Needs Improvement: 2.5-4.0 seconds
    Poor: > 4.0 seconds

     Loading (LCP)
        □ Optimize images (WebP format, lazy loading)
        □ Use CDN for static assets
        □ Implement server-side rendering or static generation
        □ Minify CSS/JS
        □ Use preconnect/dns-prefetch for third-party domains
        □ Implement critical CSS inline

2. FID (First Input Delay) - Interactivity
    Measures responsiveness to user input
    Good: ≤ 100 milliseconds
    Needs Improvement: 100-300ms
    Poor: > 300ms

    ✋ Interactivity (FID)
        □ Minimize main thread work
        □ Use Web Workers for heavy computations
        □ Defer non-critical scripts
        □ Implement code splitting
        □ Use requestIdleCallback for non-urgent tasks
        □ Optimize event handlers

3. CLS (Cumulative Layout Shift) - Visual Stability
    Measures unexpected layout shifts
    Good: ≤ 0.1
    Needs Improvement: 0.1-0.25
    Poor: > 0.25

    📐 Visual Stability (CLS)
        □ Set dimensions for all media
        □ Use aspect-ratio CSS property
        □ Reserve space for dynamic content
        □ Avoid inserting content above existing content
        □ Use font-display: optional or swap
        □ Animate transforms instead of layout properties


