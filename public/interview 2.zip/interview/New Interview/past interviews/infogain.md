# we have to create a CRUD application in react for user management to handle the errors and input validations
#   what will be your approach?
# how do you handle jwt tokens and enable and disable routes for login and protected routes in React.js
# if your EC2 instance is failing then how will you approach to this problem?
# how to handle millions of requests in lambda function?