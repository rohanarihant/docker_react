# how js works
# how eventloop works
# copy by memory and copy by value
# class TaskRunner {
  constructor() {
    this.queue = [],
    this.isExecuting = false
  }


  push(task) {
    this.queue.push(task);
  }

  run(){
    if(this.isExecuting) return false;
    this.isExecuting = true;
    this.runNext();
  }

  runNext(){
    if(this.queue.length === 0){
      this.isExecuting = false;
      return;
    }

    const currentTask = this.queue.shift();
    currentTask(() => {
      this.runNext()
    })
  }
}


// Each task is an asynchronous function with the following signature:
const createTask = (i) => (onDone) => {
  setTimeout(() => {
    console.log(i);
    onDone();
  }, 3000);
};

const r = new TaskRunner();

r.push(createTask(1), 1);
r.push(createTask(2), 3);
r.push(createTask(3), 2);
r.run()

# how to run if task 2 is pushed before task 1 and if same task1 is added twice
# how you are using AI in your code
