# diff b/w map and filter with example
# output question on this 
    one object having 2 methods one is normal and another is arrow method
# SOLID principle with example
# generics in typescript
# how to handle the types and nested types with a generic type 
# diff partial and emit
# git rebase vs merge
# react HOC component 
    <Can access={"admin"}>
        <DeleteButton />
    </Can>
# js problme solving on throttle
