# unwind
# aggregation pipelines
# find 2nd largest in the array of unsorted 
# find 2nd largest in the mongodb
# sharding and replicaiton in mongo
# imprve performance of react app, which is not redeployed from last 1 year
# performance optimization techniques
# code review
# ci/cd
# [1,2,3,4,5], k=3 o/p= [3,4,5,1,2]
# pagination with $offset and other technique
# multiple write operartions at once in mongodb
#   acid operations in mongo
# dependency injection
# design patterns
# docker container and kubernetes
# dead letter queue
# event streaming used
# microservices design patterns
# no of queues used
# o/p based questions on event loop
# what is event loop
# 3 sub repo and you want to run one on dev and 2 on stage and all on prod (scripts in package.json)
# unit test libraries
# normal vs error middlewares
# jwt security
# how to secure banking frontend app
# cors
# event bubbling and how to prevent them