# CORS
    To fix a CORS (Cross-Origin Resource Sharing) error,
    it is important to understand a fundamental rule: CORS is a security feature enforced by the browser,
    and its configuration happens entirely on the backend server, not inside React.

    When your React app (running on http://localhost:3000) tries to fetch data from an API running on a different domain
    or port (like http://localhost:8080), the browser blocks the response unless the server explicitly grants permission.

    🛠️ 1. The Development Solution: Vite / Create React App Proxy
        During local development, you can trick the browser by configuring a local development proxy.
        Instead of sending requests directly to the backend server, React sends requests to its own development server, which forwards them to the backend server-side (where CORS rules do not apply).

        Add a server.proxy block to route your API traffic:
        import { defineConfig } from 'vite';
        import react from '@vitejs/react-refresh';

        export default defineConfig({
        plugins: [react()],
        server: {
            proxy: {
            // When React fetches '/api/users', Vite redirects it to 'http://localhost:8080/api/users'
            '/api': {
                target: 'http://localhost:8080',
                changeOrigin: true,
                secure: false,
            },
            },
        },
        });

    If you use older Create React App (package.json)
        Simply add a single line at the root level of your configuration file:
        "proxy": "http://localhost:8080"

    // ❌ Avoid this during dev: triggers CORS
        fetch('http://localhost:8080/api/users') 

    // ✅ Do this: Vite/CRA proxy handles it seamlessly
        fetch('/api/users')

    🌐 2. The Production Solution: Backend Configuration
        A proxy configuration only works during local development.
        Once your React app is compiled and deployed to production,
        the backend server must be configured to allow requests from your frontend domain.

        The backend must include specific HTTP response headers:
            Access-Control-Allow-Origin: Explicitly set this to your frontend domain (e.g., https://myapp.com). Avoid using * (allow all) in production if your API handles private user sessions.
            Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS
            Access-Control-Allow-Headers: Content-Type, Authorization
    
    🕒 3. Understanding the "Preflight" Request (OPTIONS)
        When React triggers a non-simple request—such as a POST request containing a JSON payload or a request containing a custom Authorization token header—the browser automatically transmits a hidden HTTP request using the OPTIONS method first.

        This is known as a Preflight Request.
        The browser asks the server, "Am I allowed to send this data?"
        If your server is not configured to respond to OPTIONS requests with a standard status code 200,
        the browser blocks the subsequent main request from running.

        

