# In GCP everything belongs to a project
    whenever we delete a project in GCP
    all resources inside the project are deleted along with it

    Gcp env can be accessed from CLI, console, SDKs, APIs, cloud shell and mobile app

# IAM
    3 simple ideas
        Members :- users, service accounts or groups
        Roles :- bundles of permissions
        Permissions :- individual actions

    3 Roles
        Basic :- like Order or Editor
                 avoid in Prod
                    Viewer : view only
                    Editor : can create, modify and delete resource
                    Owner : full access
        Predefined Roles :-
            like Storage Viewer
            Example: 
                roles/compute.instanceAdmin.v1 for managing Compute Engine instances,
                or roles/ml.admin for full access to AI Platform Training resources
        Custom Roles :-
            advanced, only when needed

# Service Accounts
    an identity that an instance or an application can use to run API req on your behalf
        a VM needs access to cloud storage
        CF talk to DB
        an app calls Google APIs
        service to service communications

# Secret Manager
    most common security practice is never hard code secrets
        API Keys
        Database Password
        Certificates
            code or app fetches the secrets at run time

# CONTAINERS
# GCE
    Compute Engine
        virtual machine in the cloud
        GCP's version of EC2

        we need a server that's always running traditional applications, dbs, anything that doesn't fit serverless

    how it works
        pick your machine types, choose OS, launch
        you get VM running in minutes
    
# Cloud Run Functions (CF)
    run code without managing servers
    GCP's version of Lambda

    why this is huge?
        No Servers, auto scales
        pay only for execution time
        same benefits as Lambda

# Google Kubernetes Engine
    managed kubernetes service
    it gives 2 modes over operating with Kubernetes
        1, Autopilot cluster
            Google will manage most of the part for you
            you just need to mention the cpu and memory
            it will orchestrate rest for you
        2, Standard Cluster
            you will have more control of your clusters

    How it works ?
        Create a cluster
        deploy your containerization apps
        GKE handles the control plane
        auto scaling, auto repair, all stuffs

# Cloud Runs
    serverless containers
    unique to GCP

        take any containerized app
        deploy to cloud run
        it scales to zero, scale up automatically
        only pay what we use
        no k8s complexity
    
    How it works
        package your app in container
        push to container registery
        deploy to cloud run

    Cloud RUn is easier then k8s but more flexible than CF

# APP Engines
    its a Platform as a service
    fully managed app platform

    zero infra management, just deploy your code
    google handles everything

    How it works?
        write app
        deploy with one command
        google handle scalling, load balancing, everything

    when to use app engine?
        when to focus only on code
        dont want to think about the infra at all


# SOTRAGE AND DATABASES
# Storage Types
    1. Object Storage
        media files like Images, videos, text files
        file with metadata, unlimited scale
        static content, archives, data lakes

        // Implemented as
        Cloud Storage :- 
            GCP's version of AWS S3
            unlimited object storage

            Storage Classes :-
                Standard :- Frequent access
                Nearline :- Once a month access
                Coldline :- Once a quater
                Archive :- Once a year

        How it works :
            create a bucket
            upload objects
            set permissions using IAM
            we can version files
                if there is any change in the previous and newer version of files
                we can track that
            set lifecycle rules
                to transfer storage from HOT to COLD storage
            trigger events

    2. Block Storage
        direct attached storage like hard drives
        OS Drives, database storage

        // Implemented as
            Persistent Disk :-
                block storage for compute engine VMs

                why we needs :- 
                    Every VMs needs storage
                    your OS boots from persistent disk
                    your app data lives here

                How it works :- 
                    create a disk
                    attach to a VM
                    act like a hard drive
                    can snapshot, resize, change types
                
                Persistent Disk Types :-
                    Standard (HDD) :- cheap, slower
                    Balanced (SSD) :- good balance of performance and cost
                    SSD :- High performance
                    Extreme :- highest performance for DBs

        * Snapshot :- during outrages, snapshots are very important to bring the data back again
            Persistent DIsk A
                    |
            snapshot 1 (full snapshot)
                    |
            snapshot 2 (only contains blocks that are diff since snaphot 1)
                    |
            snapshot 3 (only contains blocks that are diff since snaphot 2)
    3. Files Storage
        share n/w files systems
        multiple servers accessing same files

            What is it?
                managed NFS file storage
                that multiple VMs can access

            How it works
                create a filestore instance
                mount it on VMs
                they all see the same files
                all server can see the same file

    4. Database Storage:
        Structured Data
            SQl for complex queries
        NoSQL
            for speed and scale

        what is it ?
            managed MySQL, postgreSQL, and SQL Server
        why use this ?
            you need a db without managing servers, backup and patches
        Features :- 
            High Availability :- Automatic failovers
            Read Replicas :- scale read traffic
            Automatic Backups :- Point in time recovery
            Reliability scenarios
        
        // Another DB
            Cloud Spanner
                Globally distributed relational db
            
            why it's special ?
                unique to google
                is a relational DB that scales horizontally globally
                ACID transections across the world
        
        // Another No SQL DB
            Firestore
                serverless document db
                    store documents in collections
                    Query them
                    data sync in real-time to clients
            when to use ?
                mobile app
                serverless arch
                real-time apps

        // Another DB
            BigQuery
                data warehouse for analytics

            why it's special
                google's crown jewel for data
                analyze petabytes of data with sql
                pay only for queries
        // Another DB
            BigTables
                NoSQL wide-column db for massive scale
                use for IOT, time series, analytical data
        
        // Memory store
            managed Redis
            memcached for caching


# NETWORKING AND CONTENT DELIVERY
# Virtual Private Cloud
    you own a private n/w in google cloud

    for security, isolation, control over n/w traffic

    VPCs are global in GCP
    you create subnets in specific regions
    simpler then AWS

    Need to know:
        subnet creation
        Firewall rules (these are like security groups)
            how to set them
            they are like security groups, where you are controling incoming and outgoing traffic
            how to setup routes

# CLoud Load Balancing
    disctributes traffic across your instances
    its global, one anycast IP, traffic routes to the nearest healthy backend

    

