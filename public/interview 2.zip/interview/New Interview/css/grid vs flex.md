# grid vs flexbox
    
    Property                Grid                                Flexbox
    Dimension        Two – Dimensional                      One – Dimensional
    Features         Can flex combination of items          Can push content element to extreme alignment
                     through space-occupying Features
    Support Type     Layout First                           Content First



# Grid
    2-dimensional grid layout sys with rows and  columns
    easier to design web pages w/o having to use floats and positioning.
    allow us to align ele into rows and columns.

    you have to define a container element as a grid with display: grid,
    set column and row sizes with grid-template-columns and grid-template-rows,
    then place its child elements into the grid with grid-column and grid-row.



# FlexBox
    css flexbox offer a one dimentional layout
    helpful in allocating and aligning the space among items in container (made if grid)
    works with all kind of devices and screen sizes.

