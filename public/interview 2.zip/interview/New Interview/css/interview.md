# diff browsers have diff default styles, how do you avoid that?
    1. Use Normalize.css (Recommended Baseline)
        Normalize.css fixes common cross-browser bugs while preserving useful default browser styles
            (like keeping headings bold and lists bulleted).
        It ensures elements render consistently across all platforms
    
    How to add it:
        Import it at the absolute top of your main CSS or JavaScript entry file before any of your custom styles.

    CDN Example:
        <link rel="stylesheet" href="https://cloudflare.com" />

    2. Use a CSS Reset (Aggressive Clear)
        A CSS Reset takes a clean-slate approach by aggressively stripping
        all margins, paddings, borders, and default formatting from every element.

        *, *::before, *::after {
            box-sizing: border-box; /* Fixes layout sizing bugs */
            margin: 0;
            padding: 0;
        }

    3. Modern Built-In Framework Resets
        If you use modern CSS frameworks or design systems, you do not need to add a reset manually.
        They include pre-configured resets right out of the box:

        Tailwind CSS: Automatically applies its own aggressive reset called Preflight.
        Bootstrap: Automatically includes a built-in cross-browser normalization stylesheet called Reboot.MUI /
        Chakra UI: Feature built-in components like <CssBaseline /> or baseline theme configs that handle resets globally.


# center a div
    Method 1: Flexbox (Recommended for most layouts)
        .parent {
            display: flex;
            justify-content: center; /* Centers horizontally */
            align-items: center;     /* Centers vertically */
            height: 100vh;           /* Gives the parent height (e.g., full screen viewport) */
        }
    
    Method 2: CSS Grid (The Shortest Code)
        If you only have one child element inside the parent,
        CSS Grid can center it perfectly using just two lines of layout code.

        .parent {
            display: grid;
            place-items: center;     /* Centers both horizontally and vertically at once */
            height: 100vh;           /* Ensures the parent has height to center within */
        }

    Method 3: Absolute Positioning (Best for Overlays/Modals)
        Use this approach if the child div needs to sit on top of other content (like a pop-up modal or a dropdown box).
        .parent {
            position: relative;      /* Establishes the boundary box */
            height: 100vh;
        }

        .child {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%); /* Shifts the element back by half its own width/height */
        }
