#   z-index

The z-index property in CSS controls the overlapping order of elements along the z-axis (depth)
Elements with a higher z-index value sit on top of elements with lower values.

# The Most Common Mistake
    By default, z-index does not work on static HTML elements.
    If an element has its default layout position (position: static),
    changing the z-index will have zero effect.

    To make z-index work
        change the position to relative, absolute, fixed, sticky

# The Three Value Types
    auto (Default):
        The element inherits its stacking order matching its parent or position in the HTML source code.
    Positive/Negative Numbers: Integers like 1, 100, or -5.
        Negative numbers position the element behind normal text and default blocks.
    inherit:
        Takes the exact z-index value assigned to its parent element.
