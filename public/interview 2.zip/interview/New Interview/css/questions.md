# What is the difference between CSS and SCSS ?

    CSS: Cascading Style Sheet is a stylesheet language used to define the presentation and layout of a webpage written in HTML or XML. CSS follows a cascading hierarchy, where styles defined at a higher level in the stylesheet cascade down to affect the lower-level elements. CSS is now an essential part of web development in conjunction with HTML and Javascript. CSS has a file extension of .css.

    SCSS: Syntactically Awesome Style Sheet SCSS (Sassy CSS) is a preprocessor scripting language that is a superset of CSS. It provides additional features and functionalities that are not available in regular CSS. SCSS syntax is very similar to CSS, but it allows for the use of variables, nesting, mixins, and other programming constructs. SCSS has a file extension of .scss.

    Differences:

    Syntax: CSS follows a plain-text syntax, whereas SCSS follows a more structured syntax with additional features such as variables, nesting, and mixins.
    Variables: SCSS allows you to define variables to store commonly used values such as colors, font sizes, and spacing, whereas CSS does not.
    Nesting: SCSS allows you to nest selectors within other selectors, making it easier to write and read complex stylesheets, whereas CSS requires you to write each selector separately.
    Mixins: SCSS allows you to create reusable code snippets using mixins, which are like functions in programming languages. CSS does not provide this functionality.
    File Extension: CSS files use the .css file extension, while SCSS files use the .scss file extension.
    Compilation: CSS files are interpreted by web browsers directly, whereas SCSS files must be preprocessed into standard CSS files using a preprocessor such as Sass.
    SCSS contains all the features of CSS and contains more features that are not present in CSS which makes it a good choice for developers to use it.
    SCSS offers variables, you can shorten your code by using variables. It is a great advantage over conventional CSS.

    scss variables
        $white: #ffffff;
        $ubuntu-font: 'Ubuntu', 'Arial', 'Helvetica', sans-serif;

        body{
            color: $white;
            font: $ubuntu-font;
            font-size: xx-large;
            padding: 2rem;
        }

    file import and nesting
        @import "my theme";
        @import "framework/bootstrap";

        footer {
            div {
                p {
                    margin: 2rem;
                    color: #2f2f2f;
                }
            }
        }
    The @mixin directive lets you create CSS code that is to be reused throughout the website.
    @mixin important-text {
        color: red;
        font-size: 25px;
        font-weight: bold;
        border: 1px solid blue;
    }
    The @include directive is created to let you use (include) the mixin.
    .danger {
        @include important-text;
        background-color: green;
    }

# What is the difference between SASS and SCSS ?
    SASS is used when we need an original syntax, code syntax is not required for SCSS.
    SASS follows strict indentation, SCSS has no strict indentation.
    SASS has a loose syntax with white space and no semicolons, the SCSS resembles more to CSS style and use of semicolons and braces are mandatory.
    SASS file extension is .sass and SCSS file extension is .scss.
    SASS has more developer community and support than SCSS.

# what is the diff b/w preProccessor and PostProcessor
preProcessor
    a css preProcessor is like a helper script for css
    it adds extra powers to css, letting you use things like variables and nested rules
    make things easier and better when your styling web pages.

    e.g :- Sass/LESS

PostProcessor
    Post-processing happens after you already produced the plain CSS,
    and want to extend it further through automation
    This can include extending class selectors, or auto-appending prefixes for certain CSS properties.
    Generally speaking, pre-processing has its own stylesheet languages, such as Sass and LESS, that convert into pure CSS. Post-processing takes that basic CSS, and applies automation/repetition.

    NOT   _________>  CSS ____________> Super CSS
    CSS

# !important

    !important is a special keyword used to override the normal cascading rules of CSS.
    When added to the end of a style property declaration,
    it forces that specific rule to take precedence over any other selector, regardless of its specificity

    Why !important is Considered Bad Practice
        Breaks the Cascade:
            It disrupts the natural hierarchical flow of CSS, making stylesheets chaotic and hard to track.
        Debugging Nightmare:
            If a component isn't styling correctly later, you have to hunt down hidden !important flags across your code base.
        Forces More !important:
            The only way to override a property styled with !important is to write another rule with
            !important that has an even higher structural specificity. This creates a messy code spiral.

# Specificity Rules
    CSS evaluates styles based on the following hierarchy (from lowest to highest priority):

    1. Tag Selectors: (e.g., p, div)
    2. Class Selectors: (e.g., .highlight, .btn)
    3. ID Selectors: (e.g., #main-header)
    4. Inline Styles: (e.g., style="color: blue;")
    5. !important Keyword: Overrides all the layers above.

# Psudo class and Psudo elements in css
    pseudo-classes and pseudo-elements are keywords added to selectors that
    let you style elements based on their state or target specific parts of their content without adding extra HTML tags

    pseudo-classes use one colon (:)
        :hover: Styles an element when a user places their mouse pointer over it.
        :focus: Styles form inputs or links when they are actively selected via keyboard or mouse.
        :nth-child(n): Targets an element based on its exact numerical position inside a parent container.

    pseudo-elements use two colons (::)
        ::before: Inserts extra styling content right before the content of an element.
        ::after: Inserts extra styling content right after the content of an element.
        ::placeholder: Styles the placeholder text inside form inputs.
        ::first-line: Styles the very first line of text inside a paragraph container.

# diff between em, rem, vh, vw etc.
    In CSS, these units are used to create flexible, responsive layouts.
    They are divided into two main categories: Relative to Font Size and Relative to Viewport

    1. Font-Relative Units (rem and em)
        rem (Root EM)
            Relative to: The font size of the root element (<html>).
            Default Behavior: By default, most browsers have a root font size of 16px. Therefore, 1rem = 16px.
            Why use it: It provides perfect accessibility.
                If a user changes their default browser font size for readability,
                everything styled in rem scales up or down beautifully.
            Example: padding: 2rem; will always equal 32px (2 × 16px), regardless of how deep the element is nested
        
        em
            Relative to: The font size of its immediate parent element.
                (If used directly on the font-size property, it is relative to the element's own inherited font size).
            The Risk:
                It multiplies down through nested elements, which can cause layout scaling bugs if you aren't careful.
            Why use it:
                Great for margins, padding, or border-radii that need to scale proportionally with an isolated component's text size (like a button text scaling alongside its internal padding).
            Example: If a parent div has font-size: 20px, then 1em inside that div equals 20px.
    
    2. Viewport-Relative Units (vw, vh, vmin, vmax)
        These units are calculated as a percentage of the user's active browser window (viewport) size.
        1 unit = 1% of that axis.

        vw (Viewport Width)
            Relative to: 1% of the total width of the browser window.
            Example: If a screen is 1920px wide, 50vw equals 960px.
        vh (Viewport Height)
            Relative to: 1% of the total height of the browser window.
            Example: height: 100vh; forces a section to take up the exact full height of the user's screen.
        vmin (Viewport Minimum)
            Relative to: 1% of whichever viewport dimension is smaller (Width or Height).
            Why use it:
            Perfect for mobile apps or games that need to fit nicely on both
            landscape and portrait screens without clipping text.
        vmax (Viewport Maximum)
            Relative to: 1% of whichever viewport dimension is larger (Width or Height).