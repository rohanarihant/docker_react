# Specificity

    If there are two or more CSS rules that point to the same element, the selector with the highest specificity value will "win", and its style declaration will be applied to that HTML element.

    Think of specificity as a score/rank that determines which style declaration is ultimately applied to an element.

    Selector	Specificity Value	Calculation
      p	            1	                  1
      p.test	      11	                1 + 10
      p#demo	      101	                1 + 100
      <p style="color: pink;">1000	    1000
      #demo	        100	                100
      .test	        10	                10
      p.test1.test2	21	                1 + 10 + 10
      #navbar p#demo 201	            100 + 1 + 100
      *	             0	                0 (the universal selector is ignored)

      