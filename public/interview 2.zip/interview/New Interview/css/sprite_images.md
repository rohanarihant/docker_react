# 📚 What are CSS Sprites?

    CSS Sprites is a technique where you combine multiple images into a single image file (called a sprite sheet). You then use CSS to display only specific portions of that image by defining the position and size of the "crop box" (viewport) for each element.

    Instead of loading 10 separate images (10 HTTP requests), you load 1 sprite sheet (1 HTTP request), which significantly improves page load times.

    🎯 Why Use CSS Sprites?
    Benefit	                            Explanation
    Reduced HTTP Requests	            One image request instead of many
    Faster Page Load	                Fewer round trips to the server
    Better Performance	                Especially beneficial for mobile users
    Easier Management	                All icons in one file
    Caching Efficiency	                One file to cache instead of many

    🏗️ How CSS Sprites Work
        Sprite Sheet (100px × 100px)
┌─────────────────────┐
│  ┌──────┐ ┌──────┐  │
│  │Icon 1│ │Icon 2│  │
│  │(0,0) │ │(20,0)│  │
│  └──────┘ └──────┘  │
│  ┌──────┐ ┌──────┐  │
│  │Icon 3│ │Icon 4│  │
│  │(0,20)│ │(20,20│  │
│  └──────┘ └──────┘  │
└─────────────────────┘

    🛠️ Creating a Simple Sprite
        1. The Sprite Sheet

        sprite.png (80px × 80px)
        Contains 4 icons (20px × 20px each)

        /* ===== SPRITE BASE CLASS ===== */
.sprite {
  background-image: url('sprite.png');
  background-repeat: no-repeat;
  display: inline-block;
  
  /* Each icon is 20x20 */
  width: 20px;
  height: 20px;
}

/* ===== INDIVIDUAL ICONS ===== */
.sprite-home {
  background-position: 0 0;        /* Top-left corner */
}

.sprite-user {
  background-position: -20px 0;    /* 20px right, 0 down */
}

.sprite-settings {
  background-position: 0 -20px;    /* 0 right, 20 down */
}

.sprite-logout {
  background-position: -20px -20px; /* 20px right, 20 down */
}