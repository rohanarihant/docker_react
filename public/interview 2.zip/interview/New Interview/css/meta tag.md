# meta tag
    is a snippet of HTML code placed in the <head> section of a webpage that provides metadata—information
    about the page rather than content displayed on the page itself.

    Meta tags are invisible to users visiting the site but are crucial for search engines (like Google),
    web browsers, and social media platforms to understand and display your webpage correctly.

    <head>
        <meta charset="UTF-8">
            Tells the browser which character set to use to display text.
            UTF-8 is the global standard because it correctly renders almost all languages,
            symbols, and emojis without turning them into broken question mark symbols.
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
            Controls how your site scales on mobile screens. Without this tag,
            mobile browsers will render your desktop website at full width and zoom out,
            making the text microscopic and unreadable
        <meta name="description" content="Learn all about meta tags and how they improve website SEO.">
            Provides a brief summary of your webpage. Search engines frequently display this exact text
            as the snippet snippet below your website title in search results. Keep this under 160 characters
        <meta name="robots" content="index, follow">
             Directs web crawlers on how to treat your page. index,
             follow tells them to list the page in search results and follow its links.
             Using noindex, nofollow completely hides a private page from Google search results
    </head>


# Social Media Meta Tags (Open Graph & Twitter Cards)
    When you share a link on WhatsApp, X (Twitter), Slack, or LinkedIn,
    these tags control the preview card (image, title, and description) that appears:
        
        <!-- Open Graph for Facebook, LinkedIn, WhatsApp -->
        <meta property="og:title" content="My Awesome Website" />
        <meta property="og:description" content="A cool place to learn coding." />
        <meta property="og:image" content="https://example.com" />

        <!-- Twitter Cards -->
        <meta name="twitter:card" content="summary_large_image" />

# Why Are They Important?
    SEO (Search Engine Optimization):
        High-quality meta descriptions encourage users to click your link in search results, increasing organic traffic
        
    User Experience (UX):
        Proper viewport configs ensure mobile users do not face broken layouts.
    
    Click-Through Rates (CTR):
        Rich social media preview cards make shared links look professional and clickable.

