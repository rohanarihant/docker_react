console.log("script")

// const items = document.querySelectorAll("div");
// const newItems = items.sort(() => Math.random() - 0.5)
// console.log(items,'itemsss', newItems)

const items = [1,2,3,4,5,6,7,8,9]

function shuffle(){
    clearNode();
    const shuffledList =  items.sort(() => Math.random() - 0.5);
    renderList(shuffledList);
}

function sort(){
    clearNode();
    const sortedList = items.sort((a,b) => a-b);
    renderList(sortedList);
}
function clearNode(){
    const container = document.querySelector(".container");
    container.innerHTML = ""
}
function renderList(itemList){
    const container = document.querySelector(".container");
    for(let i=0;i<itemList.length;i++){
        let tempDiv = document.createElement("div");
        tempDiv.className = `item item-${itemList[i]}`;
        tempDiv.innerHTML = itemList[i];
        container.appendChild(tempDiv)
    }
}
renderList(items);