# Position
    Elements are then positioned using the top, bottom, left, and right properties. However, these properties will not work unless the position property is set first. They also work differently depending on the position value.


# Static
    HTML elements are positioned static by default.

    Static positioned elements are not affected by the top, bottom, left, and right properties.
    An element with position: static; is not positioned in any special way; it is always positioned according to the normal flow of the page:

# Relative
    An element with position: relative; is positioned relative to its normal position.
    Setting the top, right, bottom, and left properties of a relatively-positioned element will cause it to be adjusted away from its normal position.
    Other content will not be adjusted to fit into any gap left by the element.

# fixed
    An element with position: fixed; is positioned relative to the viewport,
    which means it always stays in the same place even if the page is scrolled.
    The top, right, bottom, and left properties are used to position the element.

    A fixed element does not leave a gap in the page where it would normally have been located.
    it would be fixed to the part of the page eventhough if we scroll it

# Absolute  
    An element with position: absolute; is positioned relative to the nearest positioned ancestor
    (instead of positioned relative to the viewport, like fixed).
    Note: Absolute positioned elements are removed from the normal flow, and can overlap elements.

# sticky
    An element with position: sticky; is positioned based on the user's scroll position.
    A sticky element toggles between relative and fixed, depending on the scroll position.
    It is positioned relative until a given offset position is met in the viewport - then it "sticks" in place (like position:fixed).
