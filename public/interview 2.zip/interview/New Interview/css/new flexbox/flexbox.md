align-items: baseline // will align the all elements with respect to the text inside it.

flex-direction: row, row-reverse, column, column-reverse 

align-self: flex-start // will align a perticular element.

order: -1, 1 // all of the elemnts are having default 0 
            if we pass -1 to any element then it will come first
            if we pass 1 to any element then it will come last

flex-grow: 1; // will take the available space

flex-basis: 1 // will assign some space to a element (20%, 100px)

flex:   1       0       
     (grow) (shrink) (basis)

flex-wrap: wrap // will wrap all the elements within the div's width
           wrap-reverse // reverse the elements 

align-content: stretch // will stretch the elements height to fit across the height 
                center  to  center the elements with in the available height

The two properties flex-direction and flex-wrap are used so often together that the shorthand property flex-flow was created to combine them. This shorthand property accepts the value of the two properties separated by a space.

flex-flow: row wrap to set rows and wrap them.

Tflex-shrink :- he flex-shrink CSS property sets the flex shrink factor of a flex item. If the size of all flex items is larger than the flex container, items shrink to fit according to flex-shrink.



