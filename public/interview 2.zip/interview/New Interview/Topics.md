Topics

Next.js (SSR, CSR, SSR) etc
build generation process, with multiple options
caching
performace (profile and other)
web security
web vitals, GLHS
performance optaizations
WCAG complaince and best practices
testing framework
awareness of mobile tesing and device specific testing

OWSAP security principals
secure frontend development practices
benchmarking, performance tunning and continous front-end optamizations
modern build pipelines, toolchains and criss-functional collaboration 

deployment strategies
scalabilities
other libraries used

HTML, CSS3, responsive web design
css preprocessors (sass, less) and framework like tailwind css
strong in BEN methodology
es6+, including dom manupulation, js object model and modern design patterns
advance in React.js with practicle expousore to design systems and automatic design methodology



source-map-explorer
Next.js design pattern with diff design app senarios
networking/ comm patterns


ci/cd stages
sneak. (security stage)
react query
toolkit
memory leak
mono caching


react query

hooks
poll data in interval
api calls
cache

