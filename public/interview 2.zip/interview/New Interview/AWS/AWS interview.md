# Q1: How would you deploy a production-ready React application on AWS?
    The ideal modern approach is using AWS Amplify
    (for built-in CI/CD, preview branches, and hosting)
    or a combination of Amazon S3 and Amazon CloudFront.

        Key Points to Mention: * Build the React app into static files (npm run build).
            Upload the build folder to an S3 bucket configured for static website hosting.
            Put a CloudFront CDN distribution in front of S3 for SSL/TLS,
                custom domain routing, and caching assets globally to reduce latency.
            Configure CloudFront error responses to handle Client-Side Routing (React Router)
                by redirecting 404 errors back to /index.html.

# Why is CloudFront necessary when hosting a React app on S3? Why not just use S3's static website endpoint?    
    What they are looking for:
        Understanding of security, performance, and HTTPS.
    Key Points to Mention:
        S3 static website hosting does not support custom SSL certificates natively (you can't use https://yourdomain.com). CloudFront provides the SSL layer via AWS Certificate Manager (ACM).
        Additionally, CloudFront caches the React assets at Edge Locations globally,
        making the app load significantly faster for users far from the S3 bucket's region.
            
# Q3: What are the different ways to deploy a Node.js/Express API on AWS, and how do you choose between them?
    What they are looking for: Awareness of IaaS vs. PaaS vs. Containers.

        EC2 (Virtual Machines):
            Full control over the OS, but high maintenance
            (you manage patching, scaling, and reverse proxies like Nginx manually).
        AWS Elastic Beanstalk (PaaS):
            Easiest for traditional Express apps. You upload your code, and Beanstalk handles provisioning EC2,
            Load Balancers, and Auto Scaling automatically.
        Amazon ECS / EKS (Containers):
            Best for microservices. Dockerize the Express app and run it using ECS with AWS Fargate
            (serverless containers) for seamless scaling and isolation.
        AWS Lambda (Serverless):
            Wrapping the Express app using tools like @vendia/serverless-express to run as functions.

# Q4: If your Express API on an EC2 instance suddenly experiences a massive spike in traffic, how do you ensure it doesn't crash?
    What they are looking for:
        Understanding of high availability and horizontal scaling.
    Key Points to Mention:
        Put the EC2 instance inside an Auto Scaling Group (ASG) behind an Application Load Balancer (ALB).
        Set scaling policies based on CPU utilization or Request Count.
        When traffic spikes, the ALB distributes the load, and the ASG automatically provisions new EC2 instances
        to share the burden.

# Q5: In a MERN stack application, how do you handle the "M" (MongoDB) when moving to AWS?
    What they are looking for:
        Knowledge of database hosting options on AWS.
    Key Points to Mention: * Option 1:
        Use MongoDB Atlas (fully managed) and connect it to AWS via VPC Peering (connects two separate private cloud networks, allowing resources like virtual machines to communicate directly using private IP addresses) or private endpoints for security.

        Option 2:
            Use Amazon DocumentDB, which is AWS's fully managed, MongoDB-compatible NoSQL database.
        Option 3:
            Self-host MongoDB on EC2 instances
            (not recommended for production due to high operational overhead for clustering and backups)
        Option 4:
            Migrate from MongoDB to Amazon DynamoDB if a pure AWS-native,
            serverless key-value database fits the access patterns.

# Q6: How do you secure database credentials in a Node.js application running on AWS?
    What they are looking for:
        Security best practices (avoiding hardcoded .env files in production).
    Key Points to Mention:
        Use AWS Secrets Manager or AWS Systems Manager Parameter Store.
        The Node.js application can fetch the database URI securely at runtime using the AWS SDK.
        Combine this with IAM Roles assigned to the EC2 instance or
        Lambda function so that no hardcoded AWS credentials or keys are stored in the git repository.

# Q7: How would you convert a traditional Express.js REST API into a serverless architecture on AWS?
    What they are looking for:
        Understanding of the API Gateway + Lambda pattern.
    Key Points to Mention: 
        Replace the traditional listening server with Amazon API Gateway to handle routing and HTTP requests.

        Point API Gateway routes to AWS Lambda functions.
        You can either deploy the entire Express app into a single "monolith" Lambda function using a wrapper or
        split your Express routes into individual, independent Lambda functions (microservices approach)
        using framework tools like Serverless Framework or AWS SAM.

# Q8: What is a "Cold Start" in AWS Lambda, and how would you mitigate it in a Node.js backend?
    What they are looking for:
        Advanced optimization skills for serverless Node.js.
    Key Points to Mention:
        A cold start happens when a Lambda function is invoked after being idle,
        forcing AWS to spin up a new container and initialize the Node.js runtime.

    What Happens During a Cold Start :-
        Init Phase (The Cold Start):
            AWS spins up a secure container, downloads your deployment package,
            and runs your function's initialization code (code outside the main handler function).
        Invoke Phase: AWS executes your actual handler code to process the specific incoming event.
        Shutdown Phase: If the function receives no new traffic for some time, AWS tears down the container
        

# Q9: Describe a typical CI/CD pipeline for a MERN application using AWS services.
    What they are looking for:
        DevOps familiarity.
        Key Points to Mention:
            * AWS CodePipeline orchestrates the workflow.
        Code push to GitHub triggers AWS CodeBuild, which runs npm install,
            executes Jest tests, and runs the production build scripts.
        AWS CodeDeploy pushes the frontend build to S3/CloudFront and updates the backend code on Elastic Beanstalk,
            ECS, or Lambda.

# How do you manage database pooling or connections in serverless environments versus containerized (ECS) environments?
#    Lambda functions are ephemeral and scale instantly
     ECS containers are long-running and scale predictably

    1. Serverless Environments (AWS Lambda)
        The Problem: Connection Explosion
        every concurrent execution environment is an isolated container that handles exactly one request at a time
        If you have 1,000 concurrent requests, AWS spins up 1,000 Lambda instances

        If your application uses a traditional connection pool size of 10 inside the code, Lambda will attempt to open $1,000 \times 10 = 10,000$ connections simultaneously.
        This will immediately exhaust your database’s max_connections limit and crash it.

    Use an External Connection Proxy (The Best Practice):
        Lambda cannot maintain a centralized pool across different instances
        you must move the pooler outside of the compute layer.

        AWS RDS Proxy:
            Sits between Lambda and your Amazon RDS database
        PgBouncer:
            for postgress DB
    2. Declare Pools in the Global Scope:
        Always initialize your database client outside of the Lambda handler function.
        This takes advantage of Lambda's container reuse
    3. Strictly Limit the Local Pool Size:
        Set your ORM/driver config (maxPoolSize or max) to 1
        Since a single Lambda environment only processes one request at a time, it never needs a local pool larger than 1.

#    Containerized Environments (Amazon ECS)
    The Problem: Connection Leaks & Thrashing
        ECS tasks (Docker containers) are long-running and multi-threaded/event-looped (e.g., an Express.js app).
        A single container can handle thousands of HTTP requests over its lifespan
        The risk here is connection leaks (forgetting to release a connection back to the local pool) or
        improper mathematical scaling when ECS tasks autoscale.

        1. Application-Level Connection Pooling:
            ECS containers excel at local pooling
            You configure your database driver (like Mongoose, Sequelize, or Prisma)
            to open a set number of permanent connections when the container boots up
        2 Handle Container Lifecycle Signals (SIGTERM):
            When ECS decides to scale down or deploy a new version, it sends a SIGTERM signal to your container.
            gracefully close the connection pool

            // Good Container Pattern (ECS)
                const mongoose = require('mongoose');

                // Establish a permanent pool for this long-running container
                mongoose.connect(process.env.DB_URI, {
                maxPoolSize: 15, // Shared across hundreds of requests hitting this one container
                minPoolSize: 5
                });

                // Capture ECS shutdown event to prevent orphan database connections
                process.on('SIGTERM', async () => {
                console.log('ECS stopping task. Closing DB pool...');
                await mongoose.connection.close();
                process.exit(0);
                });

# How do you handle file downloads or massive payloads in Node.js securely without overloading the server's RAM?
    Never read the entire file into memory (RAM) at once
    process data in small, sequential chunks using Streams, Buffer management, and Pipeline architectures

    1. Handling Large File Downloads (Server to Client)
        you should stream the file directly from the disk to the HTTP response object (res)
        In Node.js, the res object is a writable stream.

        The Modern Way: stream.pipeline
            Using fs.createReadStream combined with pipeline ensures that chunks of the file are read
            and immediately sent over the network, keeping memory consumption down to a few kilobytes.

        const express = require('express');
        const fs = require('fs');
        const { pipeline } = require('stream/promises');
        const path = require('path');

        const app = express();

        app.get('/download', async (req, res) => {
        const filePath = path.join(__dirname, 'huge-video.mp4');

        // 1. Set headers so the browser knows it's a file download
        res.setHeader('Content-Disposition', 'attachment; filename="video.mp4"');
        res.setHeader('Content-Type', 'video/mp4');

        try {
            // 2. Create a readable stream from disk
            const readStream = fs.createReadStream(filePath);

            // 3. Pipeline handles data flow and automatically cleans up on errors
            await pipeline(readStream, res);
            console.log('Download complete successfully.');
        } catch (err) {
            console.error('Download failed:', err);
            if (!res.headersSent) {
            res.status(500).send('Error downloading file');
            }
        }
        });

#       Understanding Backpressure
        When streaming a file
        a common bottleneck occurs if the server reads data from the disk
        faster than the client's internet connection can receive it
        This build-up of unconsumed data in the queue is called Backpressure.

        Using stream.pipeline or .pipe() automatically manages backpressure.
        It tells the readable stream to pause reading from the disk
        until the writable stream (the client network) catches up.
