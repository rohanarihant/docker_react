# AWS Amplify
    Full-stack development and hosting for React, Angular, Vue, Next.js, and mobile apps
    All-in-one service:
        Provides a Git-based CI/CD pipeline for continuous deployment,
        global CDN hosting (powered by CloudFront),
        and a set of client libraries to easily add backend features like authentication,
        APIs, and storage
    
    Common Use:
        Deploying a React app connected to a backend with real-time data and user authentication

# Amazon S3 & CloudFront
    Hosting static websites (HTML, CSS, JS) with high performance and security

    S3 stores your static files.
    CloudFront is a global CDN that caches your content at edge locations for low latency.
    You can keep your S3 bucket completely private,
    allowing access only through CloudFront for a highly secure setup

    Common Use: A secure and fast way to host a purely static React application.

# AWS AppSync
    Building real-time, data-driven applications that use GraphQL

    A fully managed GraphQL service that syncs data in real-time and works offline.
    It natively integrates with databases like DynamoDB and Aurora

    Common Use:
        Apps that require live updates, like a chat app or a live dashboard.

# Amazon API Gateway
    Creating, managing, and securing RESTful APIs and WebSocket APIs for your frontend to connect to backend services

    Handles tasks like request throttling,
    caching, and authentication,
    making it easier for frontend developers to work with backend logic (often hosted on AWS Lambda)

    Common Use:
        The backend for a single-page application (SPA) that needs a robust REST API.

#   The "Maximum Control" Path (API Gateway):
    If you need to build a custom, serverless backend from scratch,
    API Gateway provides a controlled, scalable interface for your frontend to interact with business logic,
    without the added abstraction of a framework like Amplify

