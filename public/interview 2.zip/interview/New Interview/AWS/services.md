# IAM (Identity and access management)
    Manage access to AWS resource
    user role management
    you can create user for you 
    we can assign the created users to group and assign them permission and roles

    also managing API keys
    which used to intercct our applications with AWS account

# EC2 (elastic and compute management)
    create, manage and monitor virtual servers
        can create multiple ec2 instances
    
    Security Groups
        it will define what traffic will in and what out

        inbound rules :- which port to open for others
        outbound rules :- our app will call which apis

# Elastic IP
    create fix ip for running machine
    otherwise running maching ip will change

# Kay pairs
    ssh management for login

# Load balancer
    it will handle the coming traffic and divert it into different machines

# Target group
    put your machine into the target group and load balancer will point to this

# EC2 Auto scalling group
    help to maintain availability of application
        if no of req increases upto certain limit then spin up the servers
        if my CPU utilization goes above 80% then increase no of servers

# S3 bucket
    create a new bucket to store, retrieve data

# Elastic container registery (like Docker HUb)
    FUlly managed docker container registry
        easy to store, manage, share and deploy container images and artifacts anywhere

    we can create respository here and inside them we can push our images
    
    Role :-
        Store and manage container images
        Acts like a secure, centralized library for your application's code and dependencies
        Image scanning, lifecycle policies, encryption, replication
        A warehouse where your packaged application code is stored securely.

# Elastic Container Service
    fully managed container
        if we provide the url of ECR and asked him to create 5 instance of it
        then it will create and maintain their logs

        it will scale up and scale down the services

    Role :-
        Deploy, run, and scale containers
        Acts like a manager that decides how and where to run the containers.
        Service auto-scaling, load balancing, support for multiple deployment strategies (rolling, blue/green)
        The execution team that takes the code from the warehouse and runs it efficiently on the production floor.

# Elastic Kubernetes service
    it will provide services to run kubernetes 
    pod management, cluster management, cloud resources like load balancer

    Standard, open-source Kubernetes API 
    $0.10 per hour (~$73/month) per cluster 
    You manage node groups, cluster updates, add-ons, and VPC CNI 
    Offers full Kubernetes ecosystem, API compatibility, and multi-cloud options
    Teams with Kubernetes experience, complex microservices, or multi-cloud strategy 
    

# CloudWatch
    its a centeral logging system
         contain the logs of all services
         like logs, console, print, std in and out, all collect here
        also setup the alarm on logs

# Cloud Trail
    event logs
    in aws account which user is doing what is stored here

# RDS
    managed relational db services

# Amazon DocumentDB
    like mongodb

# Elastic Cache
    in memory cache
    like Redis

# Amazon SQS
    provides queues for high throughput, sys to sys messaging
    use queue to decouple heavyweight processes and to buffer and batch work
    SQS stores messages until microservices and services application process them
    it works on FIFO and once we push messages to queue and then other side will pull
    then we are done after pulling them

# Amazon Simple Notification Service
    Pub/Sub messaging for microservices and serverless applications
    we publish it once and it goes to multiple people

    will work with event driven arch

# Simple Email Service
    give SMTP access
    is cloud based email service, that provides cost effective
    flexible and scalable way for businesses of all sized to keep in contact with their customers through email

# CloudFormation (Terraform)
    it is like Terraform but only for AWS
    we will have to write the configuration in yaml and json file
    to create cloud infra like 
        create EC2 instance
            which server
            which configuration
            which security group
            which load balancer
            etc
        when we upload yaml/json file, it will create EC2

# CloudFront (CDN)
    Securely deliver content with low latency
    and high transfer speeds

    its a fast CDN service that securely deliver data, videos and applications
    APIs to customer globally with low latency and high transfer speeds

# API Gateway (NGINX)
    is fully managed service that makes it easy for developers to create, publish, maintain and monitor and secure APIs
    based on some rules
    can be Host or Path
    based on those rules we can transfer or routes to here and there

# Amazon Route 53
    reliable way to routes users to internet applications

# Aws Lambda
    is a Function as a service
        can be called on event trigger
        through API, cron, if there is a message in SQS, if there is a notification in SNS, event bridge being triggered
        