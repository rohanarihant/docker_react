# Map polyfill

myMap = function(cb){
    if(this === null){ // check if called on null or undefined
        throw new TypeError('Cannot read property "map" of null or undefined')
    }
    if(typeof cb !== 'function'){ // check if cb is not a function
        throw new TypeError('is not a function')
    }
    let finalArray = [];
    for(let i=0;i<this.length;i++){
        finalArray.push(cb(this[i], i, this))
    }
    return finalArray
}

# Filter polyfills
Array.prototype.myFilter = function(cb){
    if(this === null){
        return new TypeError('cannot read property "filter" null or undefined')
    }
    if(typeof cb !== 'function'){
        return new TypeError('is not a function')
    }
    let finalArray = []
    for(let i=0;i<this.length;i++){
      if(cb(this[i], i, this)){
        finalArray.push(this[i])
      }
    }
    return finalArray
}

# Reduce polyfill
let arr = [1,3,4,5,6,7,8]

Array.prototype.myReduce = function(cb, init){
    let acc = init;
    for(let i=0;i<this.length;i++){
      if(!!acc){
        acc = cb(acc, this[i], i, this)
      }else{
        acc = this[i]
      }
    }
    return acc
}

console.log(arr.myReduce((e) => e > 4))
