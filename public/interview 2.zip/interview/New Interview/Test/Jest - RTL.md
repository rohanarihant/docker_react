#   Jest alongside React Testing Library (RTL)

#   Jest
    is the Test Runner & Assertion Library.
    It finds your test files, runs them, provides utilities for mocking,
    and checks if values match expectations (expect().toBe()).

#   React Testing Library
    is the DOM Utility.
    It provides a virtual DOM environment to render your React components,
    query elements on the screen, and simulate user interactions (clicks, typing).

🏛️ The RTL Philosophy: Test Behavior, Not Implementation
    Test your software the way real users interact with it.

#   Enzyme vs RTL
    Enzyme focused on implementation details—testing internal state,
    checking component method names, or inspecting prop values.
    
    RTL explicitly discourages this. Users do not care what your variable names are;
    they care that when they click a button, text appears on the screen.

    import { render, screen, waitFor } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import Counter from './Counter';

// 1. Jest Mocking: Intercept the global fetch API call
beforeEach(() => {
  global.fetch = jest.fn(() =>
    Promise.resolve({
      json: () => Promise.resolve({ name: 'Rahul' }),
    })
  );
});

afterEach(() => {
  jest.clearAllMocks();
});

describe('Counter Component', () => {
  
  // Test Case 1: Verifying Initial Render
    test('renders initial layout with default guest name', () => {
        render(<Counter userId="123" />);
        
        // Querying elements by their visible text or roles
        const headingElement = screen.getByRole('heading', { name: /welcome, guest/i });
        expect(headingElement).toBeInTheDocument();
        
        const countElement = screen.getByTestId('count-val');
        expect(countElement).toHaveTextContent('Current Count: 0');
    });

    // Test Case 2: Verifying Asynchronous API Updates
    test('fetches and displays the username asynchronously', async () => {
        render(<Counter userId="123" />);
        
        // Use findBy queries for elements that appear AFTER an async action/API resolves
        const updatedHeading = await screen.findByRole('heading', { name: /welcome, rahul/i });
        expect(updatedHeading).toBeInTheDocument();
        expect(global.fetch).toHaveBeenCalledTimes(1);
    });

    // Test Case 3: Verifying User Interaction (Clicks)
    test('increments count value when button is clicked', async () => {
        render(<Counter userId="123" />);
        const user = userEvent.setup();
        
        const buttonElement = screen.getByRole('button', { name: /increment/i });
        const countElement = screen.getByTestId('count-val');
        
        // Simulate a real user clicking the button
        await user.click(buttonElement);
        
        expect(countElement).toHaveTextContent('Current Count: 1');
    });
    });


#   🎛️ Understanding RTL Query Methods
    1. getBy...:
        Looks for an element immediately.
        Throws an error instantly if the element is not found or if it finds multiple matches.
        (Best for items you expect to be on the screen right away)
    2. queryBy...:
        Looks for an element immediately.
        Returns null if the element isn't found instead of throwing an error.
        (Crucial when verifying an element is not on the screen, like expect(screen.queryByText(/error/i)).toBeNull()).
    3. findBy...:
        Returns a Promise. It automatically polls the DOM and waits (up to 5 seconds by default)
        for the element to appear.
        (Essential for testing asynchronous behavior or text that changes after an API resolves).

#   ⚖️ Priority Order for Selecting Elements
    Priority 1: getByRole (e.g., button, heading, textbox) — enforces accessible semantic HTML.
    Priority 2: getByLabelText (for form fields) or getByPlaceholderText.
    Priority 3: getByText (for paragraphs and divs).
    Priority 4: getByTestId — Use this strictly as a last resort if you cannot select
                an element by its text or role (adds a data-testid attribute to your HTML code).

                