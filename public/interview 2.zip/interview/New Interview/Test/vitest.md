# ViTest
    1. Blazing Fast Speed
        Jest was created before modern tools like ESBuild and Vite existed
        and heavily dependend upon babel config
        but vitest reuses Vite's on-demand compilation and internal dependency graphs
        its watch-mode re-runs only the specific files you modify
        behaving much like browser Hot Module Replacement (HMR).

    2. Zero-Config TypeScript & JSX
        If you have ever tried to set up Jest for a TypeScript project,
        you know the headache of configuring ts-jest or Babel

        Vitest handles TypeScript, JSX, and TSX natively out of the box.
        If you already use Vite, Vitest reads your existing vite.config.ts directly.
        There is no separate test configuration required.
    
    3. Native ESM Support
        Modern JavaScript relies heavily on native ES Modules (import/export).
        Because Jest was built during the older CommonJS (require) era
        mocking or testing native ESM packages in Jest often requires complex experimental flags

        Vitest is ESM-first, making it entirely seamless.
    
    4. Drop-in Jest Compatibility
        use Jest globals like describe, test, expect, and beforeEach work exactly the same way
        The only major difference is that instead of the jest global object for mocking,
        Vitest uses vi (e.g., vi.fn() or vi.spyOn()).