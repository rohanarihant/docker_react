/** @type {import('jest').Config} */
const config = {
  // 1. Define the testing environment (simulates a browser DOM)
  testEnvironment: 'jest-environment-jsdom',

  // 2. Setup files to run before tests execute (e.g., adding custom DOM matchers)
  setupFilesAfterEnv: ['<rootDir>/jest.setup.js'],

  // 3. Map imports using path aliases (e.g., resolving '@components/Button' to actual files)
  moduleNameMapper: {
    '^@/(.*)$': '<rootDir>/src/$1',
    
    // Handle CSS/Style imports by mocking them out (prevents syntax crashes)
    '\\.(css|less|scss|sass)$': 'identity-obj-proxy',
    
    // Handle asset imports (like images or SVG files)
    '\\.(jpg|jpeg|png|gif|eot|otf|webp|svg|ttf|woff|woff2)$': '<rootDir>/__mocks__/fileMock.js',
  },

  // 4. File compilation/transformation configurations
  transform: {
    // Compiles TypeScript/modern JS using ts-jest (or change to babel-jest/@swc/jest if needed)
    '^.+\\.(t|j)sx?$': 'ts-jest',
  },

  // 5. Code Coverage collection configurations
  collectCoverage: true,
  coverageDirectory: 'coverage',
  collectCoverageFrom: [
    'src/**/*.{js,jsx,ts,tsx}',
    '!src/**/*.d.ts',
    '!src/main.tsx',
    '!src/vite-env.d.ts',
  ],
  
  // Enforce coverage performance thresholds for your CI/CD pipeline
  coverageThreshold: {
    global: {
      branches: 80,
      functions: 80,
      lines: 80,
      statements: -10,
    },
  },

  // 6. General configuration options
  verbose: true, // Detailed reports for individual test results
  clearMocks: true, // Automatically clear mock calls/instances between tests
};

module.exports = config;
