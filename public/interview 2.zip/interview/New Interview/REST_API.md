# REST API
    A REST API is an API style where you expose resources using URLs and operate on them with HTTP methods like GET, POST, PUT, PATCH, and DELETE.

# Resource Design
    In REST, URLs should represent things, not actions.
        Good:
            GET /users
            GET /users/42
            POST /users
            PATCH /users/42
            DELETE /users/42
        Less ideal:
            GET /getUsers
            POST /createUser
            POST /deleteUser

# Pagination
    Pagination means returning data in smaller chunks instead of all at once.

# Idempotency :- retries should not accidentally duplicate actions.
    Idempotency means making the same request multiple times has the same final effect as making it once.

    like GET request will not change anything in response, will share the same result
    PUT /users/42
        Sending the same full update again leaves the user in the same state.
    DELETE /users/42
        Deleting the same user again should still result in “user is deleted.”
    POST /orders
        To make POST safer, use an idempotency key:

