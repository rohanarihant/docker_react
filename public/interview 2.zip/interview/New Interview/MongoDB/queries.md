# find users earning more then average salary in mongodb with explanation
db.users.aggregate([
    {
        $group: {
            averageSalary: {
                _id: null,
                $avg: "$salary"
            }
        }
    },
    {
        $lookup: {
            from: 'users',
            pipeline: [],
            as: "allUsers"
        }
    },
    {
        $unwind: "$allUsers"
    },
    {
        $match: {
            $expr: {
                $gt: ["$allUsers.salary", "$averageSalary"]
            }
        }
    },
    {
        $project: {
            _id: "$allUsers.id",
            name: "$allUsers.name",
            salary: "$allUsers.salary",
            averageSalary: 1
            
        }
    }
])

# find duplicate names
db.users.aggregate([
    {
        $project: {
            _id: "$name",
            count: {
                $sum: 1
            },
            duplicateIds: {
                $push: "$_id"
            }
        },
        {
            $match: {
                count: { $gt: 1 }
            }
        },
        {
            $project: {
                _id: 0,
                duplicateName: "$_id",
                count: 1,
                documentIds: 1
            }
        }
    }
])

# find second highest salary
db.users.aggregate([
    {
        $group: {
            _id: "$salary",
        }
    },
    {
        $sort: {
            _id: -1
        }
    },
    {
        $skip: {
            _id: 1
        }
    },
    {
        $limit: {
            _id: 1
        }
    },
    {
        $project: {
            _id: 0,
            secondHighestSalary: "$_id"
        }
    }
])

# query for find a employee who joined in last 30 days
    db.users.find({
        joinDate: {
            $gte: new Date(new Date().setDate(new Date().getDate() - 30))
        }
    })

# find users with no orders using $lookup
