# Sharding vs Indexing
    MongoDB Sharding vs Indexing for Financial Logs
        When to Choose Sharding
            Sharding wins when ALL of these are true:
            Single server can't handle write throughput (>10K writes/sec)
            Data exceeds single node storage (>2TB)
            Working set exceeds RAM (>64GB)
            Time-series data with natural partition key
            
        Financial Transaction Log Example :-
            // SCENARIO: 1M transactions/hour, 100GB/day, 30TB/year
            // CHOOSE SHARDING for:
            {
            volume: '>50,000 writes/second',
            retention: '7+ years online',
            query_pattern: 'Range queries by account_id + date',
            hardware: '5+ commodity servers'
            }

            // CHOOSE INDEXING for:
            {
            volume: '<5,000 writes/second',
            retention: '90 days online then archive',
            query_pattern: 'Point lookups by transaction_id',
            hardware: 'Single powerful server'
            }
        
        Sharding Configuration for Financial Logs
            // MongoDB Sharding Setup
            sh.enableSharding("financial_db");

            // Choose shard key (CRITICAL for performance)
            sh.shardCollection("financial_db.transactions", {
                account_id: "hashed",  // Even distribution
                timestamp: 1            // Range-based for time queries
            });

            // Zone-based sharding (hot/cold data)
            sh.addShardTag("shard1", "hot");
            sh.addShardTag("shard2", "warm");
            sh.addShardTag("shard3", "cold");

            // Recent data on fast NVMe, old data on HDD
            sh.updateZoneKeyRange("financial_db.transactions",
            { timestamp: MinKey },
            { timestamp: new Date("2025-01-01") },
            "cold"
            );

        Decision Matrix
        Requirement	            Indexing Only	        Sharding
        Write volume < 5K/sec	    ✅	                ❌ Overkill
        Write volume > 20K/sec	    ❌	                ✅ Required
        Data size < 1TB	            ✅	                ❌
        Data size > 5TB	            ❌	                ✅
        Complex aggregations	    ✅ Simpler	        ❌ MapReduce needed
        Time-series queries	        ⚠️ Slows with size	 ✅ Parallelized
        Budget < $10K	            ✅	                ❌
        Team expertise	            ✅ Universal	        ❌ Specialized
        

