# Replication
    is the mechanism for creating and maintaining multiple copies of your data across different servers
    Its primary purposes are to ensure high availability, provide data redundancy against hardware failures,
    and enable disaster recovery

    The foundation of replication in MongoDB is the Replica Set.

    1. The Replica Set
        group of mongod instances (nodes) that all maintain the same data set
    
        consists of :-
            Primary Node: 
                sole node that accepts write operations
                It records all data changes in its operation log (the oplog)
                all read operations also go to the primary
            
            Secondary Nodes:
                replicate the primary's oplog and apply those operations to their own data sets
                "playing back" the changes to stay in sync with the primary.
            
            Arbiter Node (Optional): 
                participates in elections (voting) but holds no data

    2. The Heartbeat & Automatic Failover
        Replication is not passive; it's actively monitored.
            Heartbeats: Every 2 seconds, nodes in the replica set ping each other (via heartbeats).
            Elections: If a secondary does not hear from the primary for more than 10 seconds,
                it declares the primary dead and calls for an election to choose a new primary.
                The election is decided by a majority vote.
    
    3. The Oplog (The Engine of Replication) (operation logs)
        is a capped collection stored in the local database
        It records a rolling history of all write operations performed on the primary.

        Replication:
            Secondaries pull data from the primary's oplog in batches and
            apply the changes to their own data sets asynchronously.
        Replication Lag:
            If a secondary cannot keep up with the pace of writes on the primary,
            it falls behind. This is called "replication lag"
    
    4. Read Preferences (Offloading Reads)
        by default, all reads and writes go to the Primary
            primary (Default): Only read from the primary.
            secondary: Read exclusively from secondaries (useful for reporting/analytics).
            primaryPreferred: Read from the primary, but if unavailable, read from a secondary.
            secondaryPreferred: Read from a secondary, but if none are available, read from the primary.
            nearest: Read from the node with the lowest network latency, regardless of its role.
    
    5. Write Concern (Durability vs. Speed)
        introduces a trade-off between write speed and data safety
            w: 1: (The primary acknowledges a write)
                The primary acknowledges a write as soon as it writes to its own memory.
                Fast, but if the primary crashes before the write replicates, you can lose data.
            w: "majority": (mejority of replica set members acknowledge the write)
                The primary waits until the write has been committed to the majority of voting nodes in the replica set. Slower, but guarantees that if the primary fails, the data survives on another node.
            j: true - wait until write is commited to the journal.
    6. Read Concern
        Read concern controls the consistency and isolation of data returned by read operations
        Read Concerns
            like "majority" allow you to read data that has been confirmed across the majority of nodes,
            ensuring you don't read data that might be rolled back during a failover.

            common levels:
                * local
                * majority
                * linearizable
                * snapshot

    7. Chained Replication
        To reduce load on the primary,
        secondaries can replicate from another secondary instead of directly from the primary.
        While this reduces network strain on the primary,
        it can increase overall replication lag if the "chain" gets too long.



# WiredTiger storage engine
    default storage engine for MongoDB
    responsible for managing how data is stored, both in memory and on disk
    the core "plumbing" that handles the actual reading, writing, and organization of your data on the physical storage

    Key Features
        1. Document-Level Concurrency
            uses document-level concurrency control for write operations
            means multiple clients can modify different documents within the same collection simultaneously,
            without blocking each other
            with intent locks at the global, database, and collection levels
            If a conflict is detected between two operations
                transparently retries the operation
                fine-grained locking significantly improves performance for concurrent workloads
        2. Compression
            Collection Data:
                WiredTiger uses Snappy block compression
                configure it to use zlib or zstd compression
            Indexes:
                uses prefix compression for all indexes by default

    features:
        compression
        document-level locking
        better concurrency
        improve performance

# Explain Plan
    explain() method shows how mongoDB executes a query and whether it uses an index
    shows exactly how the database executes a query
    primary tool for understanding and improving query performance

        db.users.find({ age: 25}).explain("executionStats")

    explain() method accepts a verbosity parameter :-
        "queryPlanner" (default):
                Shows the plan the query optimizer selected, but does not execute it.
        "executionStats":
                Runs the winning plan and returns statistics about its actual performance.
                This is the most useful mode for optimization.
        **"allPlansExecution":
                Most detailed; includes statistics for all plans considered by the optimizer
    
    key metrics:
        Collscan (collection scan)
            reads every document in the collection. This is inefficient for large collections.
        IXSCAN   (Index scan)
            reads index keys. This is efficient and what you generally want to see.
        FETCH
            Retrieves the full document from disk after an index scan.
        SHARD_MERGE
            Merges results from multiple shards in a sharded cluster
        EOF
            End-of-stream; indicates the stage is done
    
    Key Metrics to Check :-
        executionTimeMillis :- Total time the query took
        nReturned :- Number of documents the query returned
        totalDOcsExamined :- Number of documents scanned
        totalKeysExamined :- Number of index entries scanned

# how to optimize queries
    educing the amount of data the database must scan, transfer, and process
    goal is to get the database to use an index to find your data instantly,

    1. Create the Right Index (The Golden Rule)
        Use .explain("executionStats")  
            check if your query uses an IXSCAN (index scan) or a COLLSCAN (collection scan)
        Support your query pattern
            Create indexes on the fields you use most frequently in $match, $sort, and $lookup conditions
        Use Compound Indexes:
            If you query on multiple fields then create a compound index
        Sorting Rule:
            if using sort() then include the sorted field in your compound index
            a query with sort({ "name": 1 }), your index should end with name: 1
    2. Write Selective Queries (Filter Early)
        Filter aggressively: 
            Put your most restrictive $match filters as early in the pipeline
        Equality before Range:
            ensure exact match comes first then range will come
    3. Use Projection to Limit Returned Data
        projection ({ "name": 1, "age": 1 }), you reduce the amount of data MongoDB must transfer
    4. Optimize Aggregation Pipelines (Order Matters)
        $match and $sort first:
        $project early: Strip away unused fields early
        $limit before $skip: If you are paginating, apply $limit before $skip if possible
    5. Avoid Expensive Anti-Patterns
        Case-Insensitive Regex: { "name": /^john/i } cannot use an index efficiently
        $where and $function: These execute JavaScript on the server and are incredibly slow.
            use operators ($expr, $cond, etc.).
        Large $or Clauses: A large $or can force multiple index scans
        avoid Unnecessary $lookup
    6. Monitor and Tune Write Concerns (for mixed workloads)
        Use writeConcern: "majority" only for critical data
        otherwise, use w: 1 for faster acknowledgment.

# Capped collection 
    is a fixed-size collection in MongoDB that operates like a circular buffer or a ring buffer.
    Once it reaches its maximum size, it automatically overwrites the oldest documents to make room for new ones.

    db.createCollection("logs", {
        capped: true,
        size: 10485760,    // Maximum size in bytes (10 MB)
        max: 5000          // Optional: maximum number of documents
    })

    Key Characteristics :-
        Fixed Size:
            You define the maximum size (in bytes) when you create it.
            Optionally, you can also set a maximum number of documents (max).
        Insertion Order Preservation:
            Documents are stored on disk in the order they were inserted.
            Consequently, queries that use the $natural order return documents in insertion order (oldest to newest).
        Automatic Eviction (FIFO):
            When the collection reaches its allocated size,
            MongoDB automatically deletes the oldest documents to make space for new inserts.
            This happens in a FIFO (First-In, First-Out) manner.
        No Explicit Deletions:
            You cannot manually delete documents from a capped collection using deleteOne() or remove().
            You can only drop the entire collection
        Update Restrictions:
            You cannot update a document in a capped collection if the update causes the document to increase in size.
            If your update keeps the document the same size or makes it smaller, it is allowed.

    Use Cases :- 
        Application Logging
        Caching
        Message Queues
        High-Throughput Data Ingestion

# DIff b/w updateOne and replaceOne
    updateOne :- modifies specific fields using update operators such as $set and $inc
    replaceOne :- replace the entire document (except _id)

# find 2nd highest element inside the array
    db.collection.aggregate([
        {
            $project: {
                topTwo: { $maxN: { n: 2, input: "$scores" } }
            }
        },
        {
            $project: {
                secondHighest: { $arrayElemAt: ["$topTwo", 1] }
            }
        }
    ])

# Deployment in MongoDB cluster
    Deployment is the process of creating and configuring your MongoDB database cluster
        1. Cluster Tiers (The Options)
            Flex Clusters :- 
                best features of the older shared and serverless tiers
                offering an easier choice for developers with the ability to scale
            Dedicated Clusters :-
                These are for production workloads
                M10 tier and offer dedicated resources

        2. The Deployment Process
            Choose a Cluster Type:
                You can deploy either a replica set (for high availability) or a sharded cluster (for large-scale data)
            Select a Cloud Provider and Region:
                best performance, choose the same cloud provider (AWS, Azure, GCP)
                and region where your application is hosted
                minimizes latency, data transfer costs, and improves stability
            Configure Cluster Specifications: Select the cluster tier (e.g., Flex, M10) and storage options.
            Set Up Security: Configure IP access lists and database users to control who can connect.

# Mongo over SQL
    about which is better suited for your specific application needs
    MongoDB excels in situations where you need
        flexibility,
        speed of development,
        horizontal scalability

                                        SQL                               MongoDB
        Schema                      Strict                                 flexible schema (each doc can have diff fields) 
        Document Model              split a complex object                  can have all fields in one collection
                                    like a User with Orders and Addresses across multiple tables
                                    and use joins
        Scaling                     Scaling a SQL database typically means vertical scaling
                                                                            native Horizontal Scaling
        Handling of High-Velocity Data
                                    If your application handles rapid, high-volume writes
                                                                            capped collections (auto-rolling FIFO queues) and document-level locking, MongoDB can ingest massive streams of data with very low latency
        Rich and Expressive Querying
                                                                            MongoDB offers a highly expressive query language the Aggregation Framework

# when not to choose MongoDB
    Your Data is Highly Relational: 
            If your data naturally fits into strict, tabular formats
            e.g., accounting ledgers, invoicing systems
    You Need Strict, Multi-Table ACID Transactions:
            While MongoDB supports multi-document transactions, SQL databases have decades of optimization for complex
            long-running transactions where absolute atomicity across many tables is required.
    You Have Reporting/BI Needs:
        generating complex business intelligence reports with unpredictable ad-hoc queries

    



