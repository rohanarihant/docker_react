# Sharding
    Sharding is MongoDB's method for horizontal scaling (scaling out).
        It is the process of splitting a single, large dataset across multiple physical machines (called shards),
        with each machine holding only a subset of the total data.
            Vertical Scaling (Scaling Up): Buying a bigger, more expensive server with 1TB of RAM and 64 CPU cores.
                (There is a physical limit).
            Horizontal Scaling (Scaling Out / Sharding): Buying 10 cheaper servers with 64GB of RAM each,
                and splitting your 1TB database so each server holds 100GB. (Virtually unlimited).

    The Architecture (The 3 Core Components)
        The Shards (The Data): These are the actual MongoDB instances that hold the data. Each shard is a replica set (primary + secondaries for redundancy) to ensure high availability.

        The Mongos (The Query Router): This is the "traffic cop." Your application never talks to the shards directly. It sends all queries to the mongos router. The router knows which shard holds which data, routes the query to the correct shard, gathers the results, and sends them back to your app.

        The Config Servers (The Brain): These hold the cluster's metadata—the mapping of which data lives on which shard. If the mongos router doesn't know where "Smith" is, it asks the Config Servers. (Config Servers are also a replica set, usually 3 servers).
    
    Two Sharding Strategies (Ranged vs. Hashed)
        Ranged Sharding (Best for Range Queries) :-
            How it works: MongoDB splits data based on the natural order of the shard key values.
            Key < 10 goes to Shard A, 10 < Key < 20 goes to Shard B

        Hashed Sharding (Best for Random Writes) :-
            How it works: MongoDB takes the shard key, runs it through a hash function,
            and distributes data based on the hash value. This ensures a random distribution of data.
    
    When to Shard (Decision Matrix)
        // SHARD if ANY of these are true:
            const shouldShard = {
                dataSize_gb: currentSize > 2000,           // >2TB
                writeOps_per_second: writesPerSec > 5000,   // >5K writes/sec
                activeWorkingSet_gb: ramAvailable < workingSetSize * 1.5,
                indexSize_gb: indexSize > 500,              // Indexes don't fit in RAM
                queryLatency_ms: p95Latency > 500           // Queries slowing down
            }

            // DON'T SHARD if:
            const avoidSharding = {
            dataSize_gb: currentSize < 200,             // <200GB can scale vertically
            writeOps_per_second: writesPerSec < 1000,   // Low throughput
            complexity_budget: teamShardingExperience === 'none'
            }
