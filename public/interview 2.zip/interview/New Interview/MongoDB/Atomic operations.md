# Atomic Operation in mongodb
    At its core, an atomic operation in MongoDB guarantees that a write operation either completes fully
    or does not happen at all, with no in-between states.
    This is the foundation for maintaining data integrity, especially in applications with concurrent users 

    🎯 Single-Document Atomicity
        all write operations are atomic at the single-document level 
        This holds true even if the operation modifies multiple fields within that document

        How it works:
            When you update a single document using methods like updateOne()
            or operators like $set, $inc, $push, the entire operation is atomic .
            For example, the following update to a user's balance and city is atomic;
            both fields are updated together, or not at all 

            db.users.updateOne(
                { _id: ObjectId("123") },
                { 
                    $set: { age: 31, "address.city": "Boston" },
                    $inc: { balance: 100 }
                }
            )

        Compound Operations:
            Methods like findOneAndUpdate(), findAndModify(), findOneAndReplace(), and findOneAndDelete()
            are atomic operations that let you find a document and modify it in one go.
            This prevents race conditions that could occur if you performed a read and then a separate write 

    🧩 Multi-Document Atomicity: Transactions
        While updates to a single document are atomic, modifying multiple documents
        (even in a single updateMany() call) is not atomic as a whole, and other operations can interleave 

        For true atomicity across multiple documents, you must use multi-document transactions (available from MongoDB 4.0) 
        . This allows a sequence of read and write operations on one or more collections to be executed atomically 

        When to use:
            Multi-document transactions are best reserved for scenarios like financial transfers,
            inventory deduction with order creation, or any workflow where partial updates would cause data inconsistency 
        
        How to use:
            Transactions are managed using a session and typically the withTransaction() callback,
            which automatically handles retries for transient errors .
        
            const session = db.getMongo().startSession();
            try {
            await session.withTransaction(async () => {
                // All operations inside this block are part of the transaction
                await db.inventory.updateOne({ _id: "item123" }, { $inc: { quantity: -1 } }, { session });
                await db.transactions.insertOne({ item: "item123", quantity: 1, description: "Order" }, { session });
            });
            } finally {
            await session.endSession();
            }

    💡 Avoiding Race Conditions
        The "lost update" problem is a classic race condition:
        User A and B read the same document, User A updates field X, and User B saves their version,
        overwriting User A's change 

        MongoDB offers several ways to avoid this:

            Use Atomic Operators:
                Use $inc instead of reading a value and then setting a new one.
                The following concurrent updates are safe because they atomically increment the value, rather than setting it to a fixed number 

                // Update A and B run concurrently
                // Update A
                db.movies.updateOne({ _id: 1 }, { $inc: { num_mflix_comments: 10 } })
                // Update B
                db.movies.updateOne({ _id: 1 }, { $inc: { num_mflix_comments: 20 } })
                // The final value is correctly 110 (80 + 10 + 20)

            Conditional Updates with Filters:
                Include the expected current value of the field in your query filter. This ensures your update only applies if the document hasn't changed since you last read it 

                // Only update if the current stock is exactly 10
                db.products.updateOne(
                    { _id: productId, stock: 10 },
                    { $set: { status: "low_stock" } }
                )
                If the stock is no longer 10, the update fails.

            Compound Operations: Methods like findOneAndUpdate() atomically find and update a document, eliminating the need for a separate read operation 

            Transactions: For complex operations that involve multiple documents, a transaction is the right tool for the job 