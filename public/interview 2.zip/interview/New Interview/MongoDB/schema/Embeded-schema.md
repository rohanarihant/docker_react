📦 Basic Embedded Schema Structure

    Mongoose allows you to define sub-documents (embedded schemas) that are nested inside parent documents.
    This is perfect for one-to-many relationships where the child data always belongs to the parent.



    const mongoose = require('mongoose');

        // 1. Define the embedded (sub) schema
        const addressSchema = new mongoose.Schema({
        street: {
            type: String,
            required: true
        },
        city: {
            type: String,
            required: true
        },
        state: {
            type: String,
            required: true,
            uppercase: true,
            maxlength: 2
        },
        zipCode: {
            type: String,
            required: true,
            match: /^\d{5}$/
        },
        country: {
            type: String,
            default: 'USA'
        },
        isPrimary: {
            type: Boolean,
            default: false
        }
        }, { 
        _id: false // Prevents creating separate _id for sub-documents
        });

        // 2. Define the parent schema with embedded documents
        const userSchema = new mongoose.Schema({
        name: {
            type: String,
            required: true
        },
        email: {
            type: String,
            required: true,
            unique: true
        },
        // Single embedded document
        primaryAddress: addressSchema,
        
        // Array of embedded documents
        addresses: [addressSchema],
        
        // Or using a more verbose syntax for arrays
        phoneNumbers: [{
            type: {
            type: String,
            enum: ['home', 'work', 'mobile'],
            default: 'mobile'
            },
            number: {
            type: String,
            required: true
            }
        }]
        }, {
        timestamps: true
        });

        const User = mongoose.model('User', userSchema);


#   Querying Embedded Documents

    // Find users who have a primary address in NY
    const usersInNY = await User.find({
    'primaryAddress.state': 'NY'
    });

    // Find users with at least one address in CA
    const usersWithCAAddress = await User.find({
    'addresses.state': 'CA'
    });

    // Find user with specific email and project embedded fields
    const user = await User.findOne(
    { email: 'john@example.com' },
    { 'name': 1, 'addresses.city': 1, 'phoneNumbers': 1 }
    );

    // Find users with mobile phone numbers
    const usersWithMobile = await User.find({
    'phoneNumbers.type': 'mobile'
    });


#   Updating Embedded Documents
    // Update a specific address in the array
    await User.updateOne(
    { 
        email: 'john@example.com',
        'addresses.street': '456 Side Ave'
    },
    { 
        $set: { 
        'addresses.$.city': 'San Francisco',
        'addresses.$.state': 'CA'
        }
    }
    );

    // Add a new address
    await User.updateOne(
    { email: 'john@example.com' },
    { 
        $push: { 
        addresses: {
            street: '321 Pine St',
            city: 'Austin',
            state: 'TX',
            zipCode: '78701'
        }
        }
    }
    );

    // Remove an address from the array
    await User.updateOne(
    { email: 'john@example.com' },
    { $pull: { addresses: { state: 'CA' } } }
    );

#   🎯 Best Practices
    Use _id: false on embedded schemas if you don't need individual IDs for sub-documents to save storage space.
    Limit array size - MongoDB has a 16MB document limit. Large embedded arrays can cause performance issues.
    Consider normalization -
        If embedded data changes frequently (like product prices), consider referencing instead of embedding.
    Use validation - Add validation rules to embedded schemas to ensure data integrity.
    Index embedded fields - For faster queries on embedded fields:

    userSchema.index({ 'addresses.city': 1 });
    userSchema.index({ 'phoneNumbers.number': 1 });

    Use dot notation for updating specific fields without overwriting the entire sub-document.

