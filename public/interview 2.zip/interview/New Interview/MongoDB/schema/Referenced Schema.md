#   Referenced schemas
    Here's a comprehensive example of referenced schemas (normalized relationships) in Express with Mongoose,
    showing how to connect collections using ref and populate().

📦 Basic Referenced Schema Structure
    // models/User.js
        const mongoose = require('mongoose');

        const userSchema = new mongoose.Schema({
        name: {
            type: String,
            required: true
        },
        email: {
            type: String,
            required: true,
            unique: true
        },
        password: {
            type: String,
            required: true
        },
        role: {
            type: String,
            enum: ['user', 'admin', 'moderator'],
            default: 'user'
        },
        createdAt: {
            type: Date,
            default: Date.now
        }
        });

        module.exports = mongoose.model('User', userSchema);

----------------------------------------------------------------------------------------------------------------

    // models/Product.js
        const mongoose = require('mongoose');

        const productSchema = new mongoose.Schema({
        name: {
            type: String,
            required: true
        },
        description: String,
        price: {
            type: Number,
            required: true,
            min: 0
        },
        sku: {
            type: String,
            unique: true,
            required: true
        },
        stock: {
            type: Number,
            default: 0,
            min: 0
        },
        category: {
            type: String,
            enum: ['electronics', 'clothing', 'books', 'food']
        },
        createdAt: {
            type: Date,
            default: Date.now
        }
        });

        module.exports = mongoose.model('Product', productSchema);

----------------------------------------------------------------------------------------------------------------
    // models/Order.js
const mongoose = require('mongoose');

const orderSchema = new mongoose.Schema({
  // Reference to User
  user: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',  // This creates the relationship
    required: true
  },
  
  // Array of references to Products with additional info
  items: [{
    product: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Product',
      required: true
    },
    quantity: {
      type: Number,
      required: true,
      min: 1
    },
    priceAtTime: {
      type: Number,
      required: true
    }
  }],
  
  totalAmount: {
    type: Number,
    required: true,
    min: 0
  },
  
  status: {
    type: String,
    enum: ['pending', 'processing', 'shipped', 'delivered', 'cancelled'],
    default: 'pending'
  },
  
  shippingAddress: {
    street: String,
    city: String,
    state: String,
    zipCode: String,
    country: String
  },
  
  paymentMethod: {
    type: String,
    enum: ['credit_card', 'paypal', 'bank_transfer'],
    required: true
  },
  
  createdAt: {
    type: Date,
    default: Date.now
  }
});

// Index for faster queries
orderSchema.index({ user: 1, createdAt: -1 });

module.exports = mongoose.model('Order', orderSchema);

🏗️ More Complex Reference Example
    // models/Review.js
const mongoose = require('mongoose');

const reviewSchema = new mongoose.Schema({
  product: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Product',
    required: true
  },
  user: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  rating: {
    type: Number,
    required: true,
    min: 1,
    max: 5
  },
  comment: {
    type: String,
    maxlength: 1000
  },
  images: [String],
  helpful: {
    type: Number,
    default: 0
  },
  createdAt: {
    type: Date,
    default: Date.now
  }
});

// Ensure a user can only review a product once
reviewSchema.index({ product: 1, user: 1 }, { unique: true });

module.exports = mongoose.model('Review', reviewSchema);

* Querying with Populate (The Magic of References) *
    // 1. Get orders with user and product details
        app.get('/api/orders', async (req, res) => {
        try {
            const orders = await Order.find()
            .populate('user', 'name email')  // Only get name and email
            .populate('items.product', 'name price sku') // Product details
            .sort({ createdAt: -1 })
            .limit(20);
            
            res.json(orders);
        } catch (error) {
            res.status(500).json({ error: error.message });
        }
        });

        // 2. Get a specific order with nested population
        app.get('/api/orders/:id', async (req, res) => {
        try {
            const order = await Order.findById(req.params.id)
            .populate({
                path: 'user',
                select: 'name email role'
            })
            .populate({
                path: 'items.product',
                select: 'name description price category'
            });
            
            if (!order) {
            return res.status(404).json({ error: 'Order not found' });
            }
            
            res.json(order);
        } catch (error) {
            res.status(500).json({ error: error.message });
        }
        });

        // 3. Get all orders for a specific user
        app.get('/api/users/:userId/orders', async (req, res) => {
        try {
            const orders = await Order.find({ user: req.params.userId })
            .populate('items.product', 'name price')
            .sort({ createdAt: -1 });
            
            res.json(orders);
        } catch (error) {
            res.status(500).json({ error: error.message });
        }
        });

# * 📊 Performance Optimization
    // 1. Use lean() for read-only queries (faster, returns plain JSON)
        app.get('/api/orders/lean', async (req, res) => {
        const orders = await Order.find()
            .populate('user', 'name')
            .lean();  // Better performance for read-only data
        res.json(orders);
        });

        // 2. Select specific fields to reduce data transfer
        app.get('/api/orders/summary', async (req, res) => {
        const orders = await Order.find()
            .select('totalAmount status createdAt')
            .populate('user', 'name')
            .lean();
        res.json(orders);
        });

        // 3. Use virtual populate for computed fields
        orderSchema.virtual('itemCount').get(function() {
        return this.items.reduce((sum, item) => sum + item.quantity, 0);
        });

        // Enable virtuals when converting to JSON
        orderSchema.set('toJSON', { virtuals: true });
        orderSchema.set('toObject', { virtuals: true });