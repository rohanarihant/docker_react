# How does MongoDB handle relationships? Embedded vs Referenced documents?
    MongoDB supports two patterns for relationships:

    # Embedded Documents (Denormalization)
            // Blog post with embedded comments
                {
                    _id: ObjectId("..."),
                    title: "MongoDB Best Practices",
                    content: "...",
                    author: {
                        name: "John",
                        email: "john@example.com"
                    },
                    comments: [
                        { text: "Great article!", user: "Alice", date: ISODate("...") },
                        { text: "Very helpful", user: "Bob", date: ISODate("...") }
                    ]
                }

                // Query: Single read for entire post + comments
                db.posts.findOne({ _id: postId });
                
    When to embed:
        ✅ One-to-one relationships
        ✅ One-to-many where "many" is small (< 100 items)
        ✅ Data that is always accessed together
        ✅ Data that doesn't change frequently

        faster read
        no joins

    # Referenced Documents (Normalization)
        // Post collection
            {
                _id: ObjectId("..."),
                title: "MongoDB Best Practices",
                content: "...",
                authorId: ObjectId("author123"),
                commentIds: [ObjectId("comment1"), ObjectId("comment2")]
            }

            // Author collection
            {
                _id: ObjectId("author123"),
                name: "John",
                email: "john@example.com"
            }

            // Comments collection
            {
                _id: ObjectId("comment1"),
                postId: ObjectId("..."),
                text: "Great article!",
                userId: ObjectId("user456")
            }

            // Query: Multiple reads (or use $lookup)
            db.posts.aggregate([
                { $match: { _id: postId } },
                { $lookup: {
                    from: "comments",
                    localField: "commentIds",
                    foreignField: "_id",
                    as: "comments"
                }}
            ]);

    When to reference:
        ✅ Many-to-many relationships
        ✅ One-to-many where "many" is large
        ✅ Data that changes frequently
        ✅ Data that is accessed independently

# Explain MongoDB's Aggregation Pipeline with practical examples
    The aggregation pipeline is a powerful framework for data processing and transformation

    // Example: E-commerce order analytics
        db.orders.aggregate([
            // Stage 1: Filter
            { $match: { 
                status: "completed",
                orderDate: { $gte: ISODate("2024-01-01") }
            }},
            
            // Stage 2: Unwind (flatten arrays)
            { $unwind: "$items" },

            // Stage 3: Lookup (join with products)
            { $lookup: {
                from: "products",
                localField: "items.productId",
                foreignField: "_id",
                as: "productInfo"
            }},
            
            // Stage 4: Add fields
            { $addFields: {
                productPrice: { $arrayElemAt: ["$productInfo.price", 0] },
                itemTotal: { $multiply: ["$items.quantity", "$productPrice"] }
            }},
            
            // Stage 5: Group
            { $group: {
                _id: "$customerId",
                totalSpent: { $sum: "$itemTotal" },
                averageOrderValue: { $avg: "$total" },
                orderCount: { $sum: 1 },
                firstOrder: { $min: "$orderDate" },
                lastOrder: { $max: "$orderDate" }
            }},
            
            // Stage 6: Project (reshape output)
            { $project: {
                customerId: "$_id",
                totalSpent: 1,
                averageOrderValue: { $round: ["$averageOrderValue", 2] },
                orderCount: 1,
                customerTier: {
                    $switch: {
                        branches: [
                            { case: { $gte: ["$totalSpent", 10000] }, then: "Platinum" },
                            { case: { $gte: ["$totalSpent", 5000] }, then: "Gold" },
                            { case: { $gte: ["$totalSpent", 1000] }, then: "Silver" }
                        ],
                        default: "Bronze"
                    }
                }
            }},
            
            // Stage 7: Sort
            { $sort: { totalSpent: -1 } },
            
            // Stage 8: Limit
            { $limit: 10 }
        ]);

        // Common aggregation operators
        db.orders.aggregate([
            // Conditional logic
            { $addFields: {
                orderType: {
                    $cond: [
                        { $gt: ["$total", 1000] },
                        "High Value",
                        "Standard"
                    ]
                }
            }},
            
            // Date operations
            { $project: {
                year: { $year: "$orderDate" },
                month: { $month: "$orderDate" },
                quarter: { $ceil: { $divide: [{ $month: "$orderDate" }, 3] } }
            }},
            
            // String operations
            { $project: {
                emailDomain: { $substr: ["$email", { $indexOfBytes: ["$email", "@"] }, -1] }
            }},
            
            // Set operations
            { $project: {
                uniqueCategories: { $setUnion: ["$categories", "$preferences"] }
            }}
        ]);


    Filter :- $match
    Unwind :- (flatten arrays) $unwind
    Lookup :- (join with products) $lookup
    Add fields :- $addFields
    Group :- $group
    Project :- (reshape output) $project
    Multiple conditions :- $switch
    Sort :- $sort
    Limit :- $limit

# How do you handle large data migrations in production?
    Data migrations require careful planning to avoid downtime

    Background indexing :- 
        db.orders.createIndex(
            { orderDate: 1, status: 1 },
            { background: true } // Non-blocking
        );

    Bulk write with batches :-
        // Strategy 2: Bulk write with batches
        async function migrateLargeCollection() {
            const batchSize = 1000;
            let processed = 0;
            let cursor = db.sourceCollection.find({});
            
            while (await cursor.hasNext()) {
                const batch = [];
                for (let i = 0; i < batchSize && await cursor.hasNext(); i++) {
                    const doc = await cursor.next();
                    // Transform document
                    doc.newField = doc.oldField * 2;
                    delete doc.oldField;
                    batch.push(doc);
                }
                
                // Bulk write with error handling
                try {
                    await db.targetCollection.bulkWrite(
                        batch.map(doc => ({
                            updateOne: { 
                                filter: { _id: doc._id },
                                update: { $set: doc }
                            }
                        })),
                        { ordered: false }
                    );
                } catch (error) {
                    console.error(`Batch failed at ${processed}:`, error);
                    // Log failed batches for retry
                }
                
                processed += batch.length;
                console.log(`Processed ${processed} documents`);
            }
        }

        // Strategy 3: Two-phase migration with versioning
        db.orders.updateMany(
            { schemaVersion: { $exists: false } },
            { $set: { schemaVersion: 1 } }
        );

        // Business logic checks schemaVersion
        function getOrder(order) {
            if (order.schemaVersion === 1) {
                // Use new schema
            } else {
                // Use old schema
            }
        }

        // Strategy 4: Use change streams for incremental sync
        const changeStream = db.collection.watch();
        changeStream.on('change', (change) => {
            // Synchronize changes to target
            syncChange(change);
        });   


# How would you optimize a slow query?
    Systematic approach to query optimization:
        // Step 1: Analyze with explain()
                db.users.find({ 
                    age: { $gt: 30 },
                    city: "Bengaluru",
                    status: "active"
                }).explain("executionStats");

                // Step 2: Check indexing
                // Create appropriate compound index
                db.users.createIndex({ 
                    city: 1,      // Most selective first
                    status: 1,
                    age: 1
                });

                // Step 3: Use covered queries (all fields in index)
                db.users.find(
                    { city: "Bengaluru", status: "active" },
                    { _id: 0, name: 1, email: 1 } // Only indexed fields
                );

                // Step 4: Avoid $where (slow) and use aggregation instead
                // ❌ Bad
                db.users.find({ $where: "this.age > 30 && this.city === 'Bengaluru'" });

                // ✅ Good
                db.users.find({ age: { $gt: 30 }, city: "Bengaluru" });

                // Step 5: Use projection to limit returned fields
                db.users.find(
                    { city: "Bengaluru" },
                    { name: 1, email: 1, _id: 0 }
                );

                // Step 6: Use limit() and skip() for pagination
                db.users.find({ city: "Bengaluru" })
                    .limit(50)
                    .skip(100);

                // Step 7: For heavy queries, use aggregation with $match first
                db.users.aggregate([
                    { $match: { city: "Bengaluru" } }, // Filter early
                    { $group: { 
                        _id: "$age",
                        count: { $sum: 1 }
                    }},
                    { $sort: { _id: -1 } }
                ]);

                // Step 8: Use hint() to force specific index
                db.users.find({ city: "Bengaluru" })
                    .hint({ city: 1, status: 1 });

                // Step 9: For large data, use pagination with cursor
                const cursor = db.users.find({ city: "Bengaluru" })
                    .batchSize(1000);

    Optimization Checklist:
        ✅ Proper indexes for common queries
        ✅ Query selectivity (filtering early)
        ✅ Limit result set size
        ✅ Project only needed fields
        ✅ Avoid expensive operations (regexwithoutindex,regexwithoutindex,where)
        ✅ Use aggregation pipeline for complex queries
        ✅ Consider sharding for large collections
        ✅ Analyze with explain()

# Explain MongoDB's replication and sharding
    Replication (Replica Sets)
        // A replica set typically has:
        // - 1 Primary (writes)
        // - Multiple Secondaries (reads, failover)
        // - 1 Arbiter (for voting, no data)

        // Configuration
        {
            _id: "rs0",
            members: [
                { _id: 0, host: "mongodb1:27017", priority: 2 },
                { _id: 1, host: "mongodb2:27017", priority: 1 },
                { _id: 2, host: "mongodb3:27017", priority: 0.5, votes: 0 }
            ],
            settings: {
                getLastErrorDefaults: { w: "majority", wtimeout: 5000 }
            }
        }

        // Read preferences
        db.users.find({}).readPref("secondary");      // Read from secondary
        db.users.find({}).readPref("primary");        // Read from primary (default)
        db.users.find({}).readPref("nearest");        // Lowest latency
    
    Sharding (Horizontal Scaling)
        // Enable sharding
            sh.enableSharding("myDB");

            // Choose shard key (critical decision!)
            sh.shardCollection("myDB.users", { userId: "hashed" });
            // OR range-based
            sh.shardCollection("myDB.orders", { orderDate: 1 });

            // Shard key selection principles:
            // 1. High cardinality (many unique values)
            // 2. Distribution (even data spread)
            // 3. Query pattern (queries should hit single shard)

            // Types of shard keys:
            // - Hashed: Even distribution for random access
            // - Range: Good for time-series data
            // - Compound: For complex query patterns

            // Additional sharding operations
            sh.addShard("rs1/mongodb1:27017,mongodb2:27017");
            sh.addShard("rs2/mongodb3:27017,mongodb4:27017");

            // Check sharding status
            sh.status();
            db.collection.getShardDistribution();

# How do you handle transactions in MongoDB
    MongoDB supports multi-document ACID transactions (v4.0+)
        Transaction Limitations:
            Only for replica sets (v4.0+) and sharded clusters (v4.2+)
            Timeout after transactionLifetimeLimitSeconds (60s default)
            Operations limited to 16MB document size
            Performance overhead (use only when needed)

# Connection Pooling in MongoDB
    Connection pooling is a technique where a cache of database connections is maintained and reused for future requests, rather than creating a new connection each time an application needs to interact with the database.
        • Reuse existing connections (no overhead)
        • Manage connections efficiently
        • Limit total connections
        • Handle connection lifecycle

        // ✅ GOOD: Using connection pooling (default behavior)
                const { MongoClient } = require('mongodb');

                // Connection pool is automatically managed
                const client = new MongoClient('mongodb://localhost:27017', {
                    // Pool size configuration
                    maxPoolSize: 100,          // Maximum connections in pool (default: 100)
                    minPoolSize: 10,           // Minimum connections to keep alive (default: 0)
                    maxIdleTimeMS: 30000,      // Close idle connections after 30s (default: 0 = no timeout)
                    waitQueueTimeoutMS: 5000,  // Max wait time for connection (default: 0 = infinite)
                    waitQueueSize: 500,        // Max queue size (default: 500)
                });

# Transactions
    MongoDB 4.0 used multi document ACID transactions

    operation on a single document is already atomic
    many applications can get by without transactions by using an embedded data model

    Multi-document transactions are specifically for situations where you need to update data across multiple documents or collections atomically. e.g like Bank transfer

    The Two APIs: Core vs. Convenient
        Convenient Transaction API :- 
            use the withTransaction() method
            which automatically handles starting, committing, and aborting the transaction

            return await session.withTransaction(async () =>

        Core API :-
            manually manage all steps
            including starting, committing, and aborting the transaction,
            as well as implementing complex error handling and retry logic

            readConcern:- isolation level for read operations
                'snapshot' being the default for multi-document transactions, ensuring a consistent point-in-time view
            writeConcern :- acknowledgment requested from the replica set
                { w: 'majority' } ensures that data is written to the majority of nodes


# Replication and Sharding


# why should we choose mongodb over sql ?
    a fundamental architectural choice:
            flexibility,
            scale,
            modern development speed versus rigid structural relationships.

            1. Flexible, Schema-less Architecture
                stores data as flexible, JSON-like structures called Documents.
                    Dynamic Fields: Documents within the same collection do not need to have the exact same set of fields.
                                One user profile document can have 5 fields, while another can have 10 fields seamlessly.
                    Rapid Iteration: If your application changes during a sprint, you just start writing the new data fields directly into the database.
                    There is no need to run complex ALTER TABLE schema migrations.
            2. Document Nesting vs. Complex Joins
                In SQL, to avoid duplicating data, you normalize your database across dozens of separate tables and combine them at runtime using intensive INNER JOIN operations.

                MongoDB encourages Denormalization through Embedded Documents and arrays. You can store related data together inside a single document.
            
                SQL Approach: To fetch a user profile along with their shipping addresses and order history, SQL has to perform a multi-table join across a Users table, an Addresses table, and an Orders table.

                MongoDB Approach: You can store addresses and orders as an embedded array directly inside the single User document. A single read query pulls the entire profile data package instantly, eliminating join overhead.

            3. Horizontal Scalability (Sharding)
                SQL Scaling (Vertical): SQL databases are traditionally built to scale vertically—meaning you have to buy a bigger, more expensive server with more RAM and CPU capacity. There is a hard physical ceiling to how large a single server can get.
                MongoDB Scaling (Horizontal): MongoDB was designed from day one to scale horizontally via Sharding. Sharding automatically distributes your data across clusters of multiple small, cheap, interconnected servers. If your data grows, you don't buy a bigger server; you just add another cheap server to the cluster.

            4. Native JavaScript/JSON Alignment (The MERN Match)
                For JavaScript developers, MongoDB provides an effortless mental model.
                Data goes into MongoDB as BSON (Binary JSON).
                It comes out of MongoDB as standard JavaScript Objects.