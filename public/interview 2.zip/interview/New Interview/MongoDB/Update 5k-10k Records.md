# Strategies to Update 5k-10k Records in MongoDB

    Updating 5,000–10,000 records is a moderate-sized operation. While it's not "big data," doing it inefficiently can still cause performance issues, lock contention, and application slowdowns. Here's a complete guide to choosing and implementing the right strategy.

    🎯 Quick    Decision Guide
    Strategy	                Speed	                Safety	Best For
    updateMany()	            ⚡ Fastest	            ⚠️ Single operation, can lock	Simple updates, non-critical
    Bulk Write (Ordered)	    ⚡ Fast	                ⚠️ Sequential, can block	When order matters
    Bulk Write (Unordered)	    ⚡⚡ Very Fast	        ✅ Parallel, minimal blocking	Best for 5k-10k updates
    Batch with for loop	🐌      Slow	                ✅ Safe, no lock	When you need per-document logic
    Stream + Bulk	            ⚡ Fast	                ✅ Safe	Very large datasets


    🚀 Strategy 1: updateMany() (Simplest)
        Use this when you need to apply the same update to all matching documents.

        Example: Set status for all inactive users
            // ✅ GOOD: Simple, fast, single operation
            const result = await User.updateMany(
            { status: 'inactive' },                           // Filter
            { $set: { status: 'archived', archivedAt: new Date() } } // Update
            );

            console.log(`Updated ${result.modifiedCount} records`);

    🚀 Strategy 2: Bulk Write (Recommended for 5k-10k)
        bulkWrite() is the best choice for 5k-10k updates.
        It sends all operations in a single request and can run them in parallel.

        Basic Bulk Write (Unordered - Fastest)
            // ✅ BEST: Unordered bulk write
            const bulkOps = users.map((user) => ({
            updateOne: {
                filter: { _id: user._id },
                update: { 
                $set: { 
                    status: user.newStatus,
                    updatedAt: new Date(),
                    score: user.score + 10
                }
                }
            }
            }));

            const result = await User.bulkWrite(bulkOps, { ordered: false });

            console.log(`✅ Matched: ${result.matchedCount}`);
            console.log(`✅ Modified: ${result.modifiedCount}`);
            console.log(`⚠️ Upserted: ${result.upsertedCount}`);

    🚀 Strategy 3: Batch Processing with for Loop
        Use when you need per-document logic or want to avoid a massive single operation.

        Simple Batch Processing
            // Process in batches of 100
            async function updateInBatches(users, batchSize = 100) {
            const results = [];
            
            for (let i = 0; i < users.length; i += batchSize) {
                const batch = users.slice(i, i + batchSize);
                console.log(`Processing batch ${Math.floor(i / batchSize) + 1}...`);
                
                const bulkOps = batch.map((user) => ({
                updateOne: {
                    filter: { _id: user._id },
                    update: { 
                    $set: { 
                        status: user.newStatus,
                        updatedAt: new Date()
                    } 
                    }
                }
                }));
                
                const result = await User.bulkWrite(bulkOps, { ordered: false });
                results.push(result);
                
                // Optional: Add delay between batches to reduce load
                // await delay(100);
            }
            
            return results;
            }

            // Usage
            const usersToUpdate = await User.find({ status: 'pending' }).limit(10000);
            const results = await updateInBatches(usersToUpdate, 100);