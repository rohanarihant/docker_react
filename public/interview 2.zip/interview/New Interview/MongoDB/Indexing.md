# Indexing
    Purpose :- 
        Fast queries on single node
        Within one server
        None (local to node)
        Direct collection access
        Limited to single node

    Use Cases :-

        // 1. Single Field Index
        db.transactions.createIndex({ timestamp: -1 })
        // Best for: Time-range queries, sorting

        // 2. Compound Index (CRITICAL for financial logs)
        db.transactions.createIndex({ 
        account_id: 1,    // Equality first
        timestamp: -1      // Range/ sort second
        })
        // Best for: WHERE account_id = X ORDER BY timestamp DESC

        // 3. Multikey Index (Arrays)
        db.transactions.createIndex({ tags: 1 })
        // Best for: Array field queries

        // 4. Text Index
        db.transactions.createIndex({ description: "text" })
        // Best for: Search within text fields

        // 5. Hashed Index (for sharding)
        db.transactions.createIndex({ account_id: "hashed" })
        // Best for: Even distribution in sharded clusters

        // 6. Partial Index (save space)
        db.transactions.createIndex(
        { timestamp: -1 },
        { partialFilterExpression: { amount: { $gt: 1000 } } }
        )
        // Best for: Large transactions only

        // 7. TTL Index (auto-delete)
        db.transactions.createIndex(
        { timestamp: 1 },
        { expireAfterSeconds: 7776000 } // 90 days
        )
        // Best for: Time-series data retention
