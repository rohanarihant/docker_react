Explain MVC architecture.
 2️⃣ Difference between REST & GraphQL.
 3️⃣ What are closures in JavaScript?
 4️⃣ Explain promises vs async/await.
 5️⃣ How do you optimize React performance?
 6️⃣ What is the Virtual DOM?
 7️⃣ Explain event bubbling & capturing.
 8️⃣ Difference between localStorage, sessionStorage & cookies.
 9️⃣ What is CORS & how to handle it?
 🔟 How do you secure APIs in Node.js?
 1️⃣1️⃣ Difference between SQL & NoSQL databases.
 1️⃣2️⃣ Explain database normalization.
 1️⃣3️⃣ How do you optimize database queries?
 1️⃣4️⃣ Difference between monolithic & microservices architecture.
 1️⃣5️⃣ How do you manage environment variables securely?
 1️⃣6️⃣ Explain JWT authentication.
 1️⃣7️⃣ What is Docker & why is it used?
 1️⃣8️⃣ Difference between Git merge & Git rebase.
 1️⃣9️⃣ How do you handle error logging in production apps?
 2️⃣0️⃣ Explain CI/CD pipelines.
 2️⃣1️⃣ Difference between scalability & performance.
 2️⃣2️⃣ How do you prevent XSS & CSRF attacks?
 2️⃣3️⃣ What’s the difference between HTTPS & HTTP/2?
 2️⃣4️⃣ Explain caching strategies in web apps.
 2️⃣5️⃣ How do you handle load balancing in cloud apps?

 # how do mongodb indexes improve performances ?
    without indexes, MongoDB must perform a collection scan
    meaning it reads every single document in a collection to find the ones that match your query

    Indexes solve this by acting like a book's index
    Instead of flipping through every page, you go straight to the right page.

    1. Drastically Reduce the Number of Documents Examined
        Without an index: A query for { "age": 30 } scans 1 million documents.
        With an index: MongoDB traverses the B-tree index directly to the value 30,
        finds the handful of pointers, and retrieves only those documents.
        The query time drops from seconds (or minutes) to milliseconds.

    2. Return Sorted Results Without Blocking (Sorting)
        If you query { "age": 30 } and want results sorted by "last_name", MongoDB has two options:

        Without an index:
            retrieve all matching documents, load them into memory
            perform a blocking sort (which fails if the dataset exceeds 32MB of memory).
        With a compound index:
            on { "age": 1, "last_name": 1 }
            MongoDB can walk the index and return the documents already sorted
            no more cpu/memory
        
    3. Answer Queries Entirely from the Index (Covered Queries)
        This is the ultimate performance hack.
        If all the fields you are querying and returning exist inside the index,
        MongoDB never has to fetch the actual documents from disk (RAM/SSD) at all.
    
# $unwind
    stage in MongoDB's aggregation pipeline is used to deconstruct an array field from an input document
    "flattening" an array

    The primary purpose of $unwind is to transform a document with an array into several documents,
    one for each array element

    { "_id": 1, "item": "ABC1", "sizes": [ "S", "M", "L" ] }
        to ({ $unwind : "$sizes" })
    { "_id": 1, "item": "ABC1", "sizes": "S" }
    { "_id": 1, "item": "ABC1", "sizes": "M" }
    { "_id": 1, "item": "ABC1", "sizes": "L" }

    Why and When to Use It ?
        operations that require treating array elements as individual values
    Grouping and Counting :-
        to count how many movies each director has made
        $unwind the directors array
        $group by the director's name
    Data Normalization :-
        It allows you to perform calculations,filtering, or reshaping on each element of an array independently

# $match
    filters the stream of documents passing through the aggregation pipeline
    allowing only those that meet the specified criteria to proceed to the next stage
    { $match: { status: "active", age: { $gt: 18 } } }

    You can use all the familiar operators like $eq, $gt, $lt, $in, $and, $or, $regex, $exists, etc.

# $group
    takes all documents that share the same value for a specific field
    consolidates them into a single output document per group,
    with the ability to calculate aggregates like sums, averages, counts, etc

        { "product": "Laptop", "category": "Electronics", "amount": 1200 }
        { "product": "Mouse", "category": "Electronics", "amount": 25 }
        { "product": "Desk", "category": "Furniture", "amount": 450 }

        {
            $group: {
                _id: "$category",
                totalSales: { $sum: "$amount" },
                count: { $sum: 1 }
            }
        }

        { "_id": "Electronics", "totalSales": 1225, "count": 2 }
        { "_id": "Furniture", "totalSales": 450, "count": 1 }
    
    The _id Field (Critical)
        Grouping Key: The _id field is required and defines what you're grouping by.
        Single Field: _id: "$category" groups by the category field.

# $project
    reshapes each document by including, excluding, or computing new fields
    specifying which fields to keep, which to remove, or which to create from expressions.

    { $project: { name: 1, price: 1, _id: 0 } }

    {
        $project: {
            fullName: { $concat: ["$firstName", " ", "$lastName"] },
            totalPrice: { $multiply: ["$price", "$quantity"] },
            isExpensive: { $gt: ["$price", 1000] },
            year: { $year: "$orderDate" }
        }
    }

# $sort
    $sort rearranges the document stream according to the sort criteria you define,
    passing the sorted results to the next stage.

    { $sort: { price: 1, name: -1 } }

# $lookup
    left outer join between documents in the current pipeline and documents in another collection
    If no matches are found, the array is empty.

        {
            $lookup: {
                from: "<foreign collection>",
                localField: "<field from input documents>",
                foreignField: "<field from foreign collection>",
                as: "<output array field name>"
            }
        }

    example :
        orders:- { "_id": 1, "customerId": "C001", "total": 250 }
                 { "_id": 2, "customerId": "C002", "total": 150 }

        customers :-
                 { "_id": "C001", "name": "Alice", "email": "alice@email.com" }
                 { "_id": "C002", "name": "Bob", "email": "bob@email.com" }
        
            {
                $lookup: {
                    from: "customers",
                    localField: "customerId",
                    foreignField: "_id",
                    as: "customerInfo"
                }
            }

        { "_id": 1, "customerId": "C001", "total": 250, "customerInfo": [{ "_id": "C001", "name": "Alice", "email": "alice@email.com" }] }
        { "_id": 2, "customerId": "C002", "total": 150, "customerInfo": [{ "_id": "C002", "name": "Bob", "email": "bob@email.com" }] }

        MongoDB 5.0 introduced a more powerful syntax where $lookup accepts a full pipeline for the foreign collection:
            This allows:
                Multiple join conditions
                Computed join fields (using $let variables)
                Additional filtering, sorting, and projection on the foreign documents before they're returned
                Uncorrelated sub-queries

        {
            $lookup: {
                from: "orderItems",
                let: { orderId: "$_id" },
                pipeline: [
                    { $match: { $expr: { $eq: ["$orderId", "$$orderId"] } } },
                    { $project: { product: 1, quantity: 1, price: 1 } },
                    { $sort: { price: -1 } },
                    { $limit: 5 }
                ],
                as: "topItems"
            }
        }

# $addFields
    $addFields appends new fields to each input document.
    The new fields can be static values, computed expressions, or derived from existing fields.
    All original fields remain unchanged.

    {
        $addFields: {
            fullName: { $concat: ["$firstName", " ", "$lastName"] },
            totalPrice: { $multiply: ["$price", "$quantity"] },
            status: "active"  // Static value
        }
    }

    // input document
    { "_id": 1, "firstName": "John", "lastName": "Doe", "price": 10, "quantity": 5 }

    // output document
    { "_id": 1, "firstName": "John", "lastName": "Doe", "price": 10, "quantity": 5, "fullName": "John Doe", "totalPrice": 50, "status": "active" }

# $expr
    is a MongoDB operator
    use aggregation expressions inside query
    find(), update(), delete(), and the $match stage of aggregation

    Regular query syntax
        { "price": { $gt: 100 } }

    $expr syntax
        allows you to compare fields to other fields
    
    db.sales.find({ $expr: { $gt: ["$revenue", "$cost"] } })
    // revenue is greater than cost

# $facet
    $facet aggregation stage executes multiple independent pipelines in a single query

    Example: E-Commerce Product CatalogImagine a dataset of products. We want to find all electronics under $1,000 and simultaneously get two things: a count of products grouped by manufacturer, and a list of the 5 most expensive items in that selection

        db.products.aggregate([
            { 
                $match: { 
                category: "Electronics", 
                price: { $lt: 1000 } 
                } 
            },
            {
                $facet: {
                // Facet 1: Group by Manufacturer
                "productsByManufacturer": [
                    { $group: { _id: "$manufacturer", totalProducts: { $sum: 1 } } },
                    { $sort: { totalProducts: -1 } }
                ],
                // Facet 2: Top 5 most expensive products
                "topExpensiveProducts": [
                    { $sort: { price: -1 } },
                    { $limit: 5 },
                    { $project: { name: 1, price: 1 } }
                ]
                }
            }
        ])
# Failover
    automatic process where a replica set elects a new Primary node to take over read/write operations
    when the current Primary becomes unavailable due to a crash, network partition, or manual shutdown

        1. Detection (Heartbeat & Timeout)
            Heartbeats: Every 2 seconds, all members of the replica set send a "ping" (heartbeat) to every other member.
            Timeout: If a Secondary node does not receive a heartbeat from the Primary for 10 seconds (the default electionTimeoutMillis), it marks the Primary as "dead" and initiates an election.

        2. The Election (Choosing a New Primary)
            eligible Secondary nodes trigger an election to decide who takes over
                
                Eligibility Criteria: A Secondary must meet two conditions to be eligible to become Primary:
                    Priority: It must have the highest priority setting among the available nodes.
                    Up-to-Date Data (Optime): 
                        It cannot be behind the other secondaries in replication.
                        It must have an optime that is at least as recent as the other voting members
                Voting: The candidate sends an election request to all other voting members.
                Majority: To win, the candidate must receive a majority (more than 50%) of the votes
                        from all voting members in the replica set.

# capped operation
    fixed-size collections that insert and retrieve documents based on insertion order
    a circular buffer
    once the allocated space or document limit is full,
    the oldest documents are automatically overwritten by new entries

    // Create a capped collection of 5 Megabytes with a max of 1,000 documents
        db.createCollection("log_events", { 
            capped: true, 
            size: 5242880, 
            max: 1000 
        })

    Key Use Cases
        Application Logging
        Cache Mechanisms
        Event Streaming

# SQL vs. NoSQL: Quick Reference
    Feature	                    SQL Databases	                        NoSQL Databases
    Data Structure	            Rigid tables, rows, and columns	        Flexible documents, key-values, or graphs
    Schema	Predefined          static schema required	Dynamic,        schema-less (add fields on the fly)
    Scaling	                    Vertical (Scale up the server size)	    Horizontal (Scale out by adding servers)
    Joins / Queries	            Highly efficient for complex,           Poor at joins; optimized for 
                                multi-table joins	                    rapid single-record lookups
    Data Integrity	            Strict ACID compliance (Ultra-reliable)	BASE model (Favors availability and speed)

# 4. When to Choose What?
Choose a SQL Database if:
    Your data structure is predictable and unchanging:
        You are building a system where the rules of the data are strictly defined
        (e.g., an ERP, accounting system, or HR platform).

    Data integrity and accuracy are non-negotiable:
        Applications involving financial transactions, healthcare data,
        or checkout systems where a single corrupted record is a critical failure.

    You rely heavily on complex relationships:
        Your app needs to run deeply analytical queries that join 5 or 6 different tables together to
        find a specific insight.

    Choose a NoSQL Database if:
        Your data structures are dynamic or rapidly changing:
            You are building a Content Management System (CMS),
            an e-commerce catalog with thousands of diverse product types,
            or a user profile system where fields change constantly.

    You have massive scaling and high-throughput needs:
        You are dealing with hundreds of thousands of read/write requests per second
        (e.g., real-time IoT sensor logging, chat apps, mobile gaming leaderboards).

    You want to store unstructured or semi-structured data:
        Perfect for logging data, user behavior tracking, caching web sessions,
        or handling rich JSON payloads directly from frontend applications (like the MERN stack).