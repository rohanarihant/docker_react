New WCAG 2.2 Criterion	            Level	Requirement
Focus Not Obscured (Minimum)	    AA	    When a component receives keyboard focus,
                                            it is not entirely hidden by other content (like a sticky header).
Dragging Movements	                AA	    Any function that requires dragging must also have a single-pointer
                                            alternative (like a click or double-click).
Target Size (Minimum)	            AA	    Touch targets (buttons, links) should be at least 24×24
                                            CSS pixels (on mobile, aim for 44×44px to be safe).
Consistent Help	                    A	    Help mechanisms (like contact info) should appear in the
                                            same relative order on every page.
Redundant Entry	                    A	    Don't require users to re-enter information they've already provided
                                            in the same process (e.g., auto-populate known fields).