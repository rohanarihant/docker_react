#   screen readers
assistive software programs that allow people who are blind,
visually impaired, or have learning disabilities to interact with digital content

They do this by turning the text and structural elements on a screen into synthesised speech or refreshable Braille displays

To make a website accessible, a screen reader relies heavily on the following semantic elements:
    1. Headings (<h1> to <h6>)
        Screen reader users rarely read an entire page to find information.
        Instead, they press a shortcut key (usually H) to jump from heading to heading to skim the page layout.
        Missing or out-of-order headings break this navigation.

    2. Alternative Text (alt attributes)
        When a screen reader encounters an image, it reads the alt text out loud.
        If the alt tag is missing, the screen reader might read the messy filename (e.g., IMG_48291.jpg),
        creating a jarring user experience.
            <img src="logo.png" alt="Company Logo"
    3. Semantic Form Labels
        Every input field must be explicitly paired with a <label>.
        Without this link, a screen reader user tabbing into a form field will only hear "Edit text, blank,"
        without knowing if they are supposed to type their name, email, or password.
            <label for="email-field">Email Address</label>
            <input type="email" id="email-field" name="email" />
    4. Descriptive Links
        Screen readers can generate a separate list of all hyperlinks on a page for fast navigation.
        Links that say "Click here" or "Read more" lose all meaning when extracted out of context.
        Links should always describe their destination.

        <!-- ❌ Bad: <a href="/details">Click here</a> to read about our services. -->
        <!-- ✅ Good: Read more about our <a href="/details">accessible web design services</a>. -->


🛠️ ARIA (Accessible Rich Internet Applications)
    Developers use ARIA attributes to communicate states and roles directly to the screen reader
        aria-live:
            Tells the screen reader to automatically announce dynamic changes on the screen
            (like a real-time chat notification or an error alert) without forcing the user to move focus.
        aria-expanded="true/false":
            Informs the user whether a menu or accordion drawer is currently open or closed.
        role="dialog":
            Signals to the screen reader that a modal window has opened and that interaction
            is now constrained to that popup box.

