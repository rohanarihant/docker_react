# Accessibility Standards
    Accessibility standards are the foundation for building web applications that are usable by everyone,
    including people with disabilities.
    The primary global standard for web accessibility is the Web Content Accessibility Guidelines (WCAG)

# The Core Standards

# WCAG (Web Content Accessibility Guidelines)
    This is the main international standard developed by the W3C
    It provides a comprehensive set of recommendations for making web content more accessible
    Following WCAG is essential for legal compliance and creating an inclusive user experience

# WAI-ARIA (Web Accessibility Initiative - Accessible Rich Internet Applications)
    This specification is crucial for building complex, interactive UI components
    It provides roles, states, and properties (like role="dialog" or aria-expanded) that you can add to HTML elements
    WAI-ARIA bridges the gap for assistive technologies when native HTML semantics are insufficient
    However, a core principle is "No ARIA is better than bad ARIA"; you should always prefer using semantic HTML first

# 💻 Applying Standards in React
Semantic HTML:
    This is the most important first step. Using native HTML elements like <button>, <nav>, <header>, and <input>
    gives you built-in accessibility, keyboard support, and screen reader announcements for free.
    For example, a <button> element is automatically focusable and responds to the Enter and
    Space keys without any extra code
ARIA Attributes in JSX:
    When you need to build custom components, you can use ARIA attributes.
    In React's JSX, all aria-* attributes are written with the standard kebab-case (e.g., aria-label, aria-labelledby), unlike many other React DOM properties that use camelCase
Focus Management:
    In single-page applications, you must manage focus programmatically to ensure a logical navigation flow.
    For example, when a modal opens, focus should move into it, and when it closes,
    focus should return to the element that triggered it.
    React's useRef and useEffect hooks are commonly used for this purpose
ARIA State Binding:
    Bind ARIA properties to React state to keep the UI and assistive technologies synchronized.
    For instance, a button that controls a dropdown menu should use aria-expanded={isOpen}
    so screen readers are notified when the menu opens or closes

# Common Implementation Patterns & Pitfalls
    Form Labels
        Use <label htmlFor="email"> linked to an <input id="email">
        Relying only on placeholder text for an input field
    Interactive Elements
        Use a <button> for clickable actions
        Using a <div onClick={...}> without keyboard support or proper roles
    Error Messages
        Link error messages to inputs with aria-describedby and use aria-invalid="true"
        Displaying error text visually without linking it to the input in the code
    Portals (Modals)
        Use aria-owns on the trigger to link it to the portaled content, and set role="dialog" on the modal itself
        Rendering a modal via createPortal to <body>, breaking the semantic connection for screen readers
    Dynamic Content
        Use an aria-live region to announce updates (e.g., aria-live="polite") without moving focus
        Updating content on the page without providing any notification to screen reader users

        aria-invalid="true"
        aria-expanded={isOpen}
        aria-owns on the trigger to link
        aria-live="polite" to announce update
        aria-label,
        aria-labelledby
