# React dev tool profiler

    is a performance diagnostics tool built directly into the React Developer Tools browser extension.
    how often a React application renders and what the "cost" (time spent) of each render is.
    it will help identify :- 
        performance bottlenecks
        specifically unnecessary re-renders
        and slow components

    you can optimize rendering behavior using tools like React.memo, useMemo, and useCallback

#    What It Measures :- 
        Commit Phase:
            Every time React updates the DOM tree, it produces a "commit."
            The Profiler captures each commit along the timeline
        Render Duration:
            How long a component spent in its render function during a commit.
        Base Duration:
            An estimate of how long it would take to render a component subtree
            from scratch without any memoization/caching.
        Render Reason:
            Why a specific component re-rendered (e.g., props changed, parent re-rendered, state changed, context changed).

#    Key Views in the Profiler
        1. Flamegraph Chart
            Horizontal Bars: Represent components.
            The width of a bar indicates how long that component took to render during that commit
        Color Coding:
            Yellow/Orange: Components that took a long time to render.
            Blue/Green: Components that rendered quickly.
            Grey: Components that did not re-render during this commit

        2. Ranked Chart
        Sorts every component rendered during a single commit by render duration,
        putting the slowest component at the top. This provides an instant,
        prioritized view of performance bottlenecks.