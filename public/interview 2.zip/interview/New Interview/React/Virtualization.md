# 
a performance optimization technique where you render only the items that are currently visible inside the user's screen viewport

Instead of rendering a massive list of 10,000 items all at once
which crashes browser memory and slows down the page
virtualization creates a small, reusable window of HTML elements that dynamically swaps out data as the user scrolls

# Popular Tools to Implement It
    react-window (lightweight, highly recommended)
        import React from 'react';
        import { FixedSizeList as List } from 'react-window';

        // 1. Create a component for your individual row
        const Row = ({ index, style }) => (
        // CRITICAL: You must pass the 'style' prop down to position the row correctly
        <div style={{ ...style, borderBottom: '1px solid #eee', padding: '10px' }}>
            Item number {index}
        </div>
        );

        export default function ReactWindowExample() {
        return (
            <List
            height={400}         // The pixel height of the visible scroll window
            itemCount={10000}    // Total number of items in your list
            itemSize={50}        // The pixel height of each individual row
            width={300}          // The pixel width of the scroll window
            >
            {Row}
            </List>
        );
        }

    react-virtualized (feature-rich but heavier)
        import React from 'react';
        import { List } from 'react-virtualized';
        import 'react-virtualized/styles.css'; // CRITICAL: You must import the global styles

        // 1. Create your row renderer function
        function rowRenderer({ key, index, style }) {
        return (
            // CRITICAL: You must use the provided 'key' and 'style' props
            <div key={key} style={{ ...style, borderBottom: '1px solid #eee', padding: '10px' }}>
            Item number {index}
            </div>
        );
        }

        export default function ReactVirtualizedExample() {
        return (
            <List
            width={300}          // Width of the visible box
            height={400}         // Height of the visible box
            rowCount={10000}     // Total items
            rowHeight={50}       // Height of each row
            rowRenderer={rowRenderer} // The rendering function
            />
        );
        }

    @tanstack/react-virtual.
        import React, { useRef } from 'react';
        import { useVirtualizer } from '@tanstack/react-virtual';

        export default function TanStackVirtualExample() {
        // 1. Create a reference to your scrollable parent element
        const parentRef = useRef(null);

        // 2. Initialize the virtualizer hook
        const rowVirtualizer = useVirtualizer({
            count: 10000,                  // Total items
            getScrollElement: () => parentRef.current, // Target scroll element
            estimateSize: () => 50,         // Default row height estimate
        });

        return (
            // Outer scrollable frame
            <div
            ref={parentRef}
            style={{ height: '400px', width: '300px', overflow: 'auto', border: '1px solid #ccc' }}
            >
            {/* Inner faked container that holds the scrollbar height track */}
            <div
                style={{
                height: `${rowVirtualizer.getTotalSize()}px`,
                width: '100%',
                position: 'relative',
                }}
            >
                {/* Render only the visible elements sliced by the hook */}
                {rowVirtualizer.getVirtualItems().map((virtualItem) => (
                <div
                    key={virtualItem.key}
                    style={{
                    position: 'absolute',
                    top: 0,
                    left: 0,
                    width: '100%',
                    height: `${virtualItem.size}px`,
                    transform: `translateY(${virtualItem.start}px)`, // Places the element correctly
                    borderBottom: '1px solid #eee',
                    padding: '10px',
                    boxSizing: 'border-box',
                    }}
                >
                    Item number {virtualItem.index}
                </div>
                ))}
            </div>
            </div>
        );
        }
