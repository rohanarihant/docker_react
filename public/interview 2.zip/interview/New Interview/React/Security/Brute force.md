#   Brute force attack

    A brute force attack is a trial-and-error method where an attacker uses automated software to systematically
    guess every possible combination of passwords, encryption keys, or hidden URLs until the correct one is found.

    Because computers can calculate millions of combinations per second,
    simple or recycled credentials can be cracked in minutes or even seconds.

# 🛡️ Core Solutions to Prevent Brute Force Attacks
    requires a multi-layered defense strategy spanning authentication rules,
    network configurations, and application-level code

    1. Implement Account Lockout Policies
        Temporarily freeze or lock an account after a set number of failed login attempts
        (e.g., 5 failed attempts locks the account for 15 minutes)
    2. Enforce Multi-Factor Authentication (MFA)
        Require a secondary verification step, such as a time-based token (TOTP) from an authenticator app,
        a push notification, or a hardware key
    3. Use Rate Limiting on Authentication Endpoints
        Restrict the number of HTTP requests a single IP address can make to your login endpoint
        within a specific timeframe.
    4. Mandate Strong Password Policies
        Force users to create long passwords (minimum 12–16 characters) combining uppercase, lowercase, numbers, and symbols
    5. Implement CAPTCHAs
        Display a challenge (like identifying objects in images or solving a puzzle) after 2 or 3 failed login attempts
    6. Deploy a Web Application Firewall (WAF)
        Use a cloud firewall service (like Cloudflare or AWS WAF) to detect high-velocity credential stuffing
        or brute-force patterns at the edge network.
