# Security Vulnerabilities
    face security vulnerabilities from three main sources :-
        server-side components,
        common coding mistakes,
        npm dependency ecosystem

    server-side components :-
        CVE-2025-55182 (React2Shell) - CVSS 10.0
            This is a critical Remote Code Execution (RCE) vulnerability caused by insecure deserialization of HTTP payloads 
            An attacker can send a single crafted HTTP request to a Server Function endpoint,
            executing arbitrary code on your server with the same privileges as your application.
            It affects React versions 19.0.0 through 19.2.0 and frameworks built on them like Next.js
    

    🛡️ Common Code-Level Vulnerabilities :-
        XSS via dangerouslySetInnerHTML
            React's JSX automatically escapes text content, preventing basic XSS 
            However, dangerouslySetInnerHTML intentionally bypasses this protection to render raw HTML 
            If you pass unsanitized user input to this prop, attackers can inject malicious scripts.

            Fix:
                Never pass unsanitized input to dangerouslySetInnerHTML. Use a sanitization library like DOMPurify before rendering 

        XSS in URL Attributes (href, src)
            React's escaping does not protect URL schemes in attributes like href 
            An input like javascript:alert(1) will be rendered as a valid, executable link 
        
            Fix:
            Validate and sanitize URLs, allowing only safe schemes like https:, mailto:, and relative paths 
        
    📦 Dependency & Supply Chain Risks
        Compromised npm Packages
            Attackers have hijacked maintainer accounts and injected malicious code into popular packages.
            For example, in 2021, the ua-parser-js package was compromised to install cryptominers and password stealers via its postinstall script 
            . A similar attack in 2025 compromised packages like chalk and debug 
