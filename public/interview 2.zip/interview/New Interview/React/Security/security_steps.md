#   🔐 1. Authentication & Authorization
        Secure JWT Token Management
        Protected Routes with Role-Based Access

#   Preventing XSS (Cross-Site Scripting)
        XSS :- 
            XSS occurs when an attacker injects malicious scripts into web pages viewed by other users.
            The script executes in the victim's browser, potentially stealing data, hijacking sessions,
            or defacing websites.
        
        ✅ Fixing XSS
            1. React Escapes Content by Default
            2. Sanitize HTML with DOMPurify
            3. Validate and Sanitize Input
            4. Content Security Policy (CSP)
                


        Purify / Sanitize the inputs

            import DOMPurify from 'dompurify';

            const SafeHTML = ({ content }) => {
            const sanitized = DOMPurify.sanitize(content, {
                ALLOWED_TAGS: ['b', 'i', 'em', 'p', 'br', 'a'],
                ALLOWED_ATTR: ['href', 'target', 'rel'],
                ALLOWED_URI_REGEXP: /^(https?:\/\/|mailto:|tel:)/i
            });
            
            return <div dangerouslySetInnerHTML={{ __html: sanitized }} />;
            };
        
        // NEVER do this with unsanitized user input
            const DangerousComponent = ({ htmlContent }) => {
                // NEVER do this with unsanitized user input
                return <div dangerouslySetInnerHTML={{ __html: htmlContent }} />;
            };
        
        // Secure URL Handling
            // ✅ GOOD: Validate URLs
                const SafeLink = ({ url, children }) => {
                const safeUrl = useMemo(() => {
                    try {
                    const parsed = new URL(url);
                    // Only allow http/https protocols
                    if (!['http:', 'https:'].includes(parsed.protocol)) {
                        return '#';
                    }
                    return url;
                    } catch {
                    return '#';
                    }
                }, [url]);

                return <a href={safeUrl} target="_blank" rel="noopener noreferrer">
                    {children}
                </a>;
                };
        
#       🔒 4. Environment Variables & Secrets
        never push secrets
        and .env to git


#       5. Security Headers (Server-Side)
        // server/securityHeaders.js (Express/Node.js)
            const helmet = require('helmet');

            // Content Security Policy (CSP)
            const securityHeaders = [
            {
                key: 'Content-Security-Policy',
                value: [
                "default-src 'self'",
                // Scripts from trusted sources only
                "script-src 'self' 'unsafe-inline' https://cdnjs.cloudflare.com",
                "script-src-elem 'self' https://cdnjs.cloudflare.com",
                // Styles
                "style-src 'self' 'unsafe-inline' https://fonts.googleapis.com",
                "style-src-elem 'self' https://fonts.googleapis.com",
                // Images
                "img-src 'self' data: https://*.cloudinary.com https://*.amazonaws.com",
                // Fonts
                "font-src 'self' https://fonts.gstatic.com data:",
                // API connections
                "connect-src 'self' https://api.example.com wss://api.example.com",
                // Frame ancestors
                "frame-ancestors 'none'",
                // Base URI
                "base-uri 'self'",
                // Form actions
                "form-action 'self'",
                ].join('; ')
            },
            {
                key: 'X-Frame-Options',
                value: 'DENY' // Prevent clickjacking
            },
            {
                key: 'X-Content-Type-Options',
                value: 'nosniff' // Prevent MIME sniffing
            },
            {
                key: 'X-XSS-Protection',
                value: '1; mode=block' // Legacy XSS protection
            },
            {
                key: 'Referrer-Policy',
                value: 'strict-origin-when-cross-origin'
            },
            {
                key: 'Strict-Transport-Security',
                value: 'max-age=31536000; includeSubDomains; preload'
            },
            {
                key: 'Permissions-Policy',
                value: 'geolocation=(), microphone=(), camera=()'
            }
            ];

            // React app - Add meta tags
            // public/index.html
            /*
            <meta http-equiv="Content-Security-Policy" content="default-src 'self'; script-src 'self' 'unsafe-inline'">
            <meta http-equiv="X-Content-Type-Options" content="nosniff">
            <meta http-equiv="X-Frame-Options" content="DENY">
            <meta name="referrer" content="strict-origin-when-cross-origin">
            */

#   🍪 6. Secure Cookies & Sessions
    
    Set-Cookie: userId=12345; Max-Age=86400; Expires=Wed, 21 Oct 2026 07:28:00 GMT
    Set-Cookie: user_preferences=dark_mode; Domain=myapp.com
    Set-Cookie: ad_tracking=xyz789; Domain=ads.thirdparty.com

    🛡️ Security Cookie Types
        Set-Cookie: session=abc123; Secure
            Transmitted over: HTTPS only
            Use: All sensitive data

        HttpOnly Cookies
            Prevents client-side JavaScript from reading the cookie
            Attribute: HttpOnly
            Accessible by: HTTPS requests
            Protects against: XSS attacks

            // ❌ This returns undefined
                document.cookie // auth_token is hidden
    
        5. SameSite Cookies
            Purpose: Controls cross-site request behavior
            Attribute: SameSite=Strict|Lax|None
            Protects against: CSRF attacks

            SameSite=Strict
                Behavior: Never sent for cross-site requests
                Security: Highest
                Use: Highly sensitive operations
                    Set-Cookie: admin_session=abc123; SameSite=Strict

            SameSite=Lax (Default in modern browsers)
                Behavior: Sent for top-level cross-site navigation (e.g., clicking a link)
                Security: Good balance
                Use: Most applications

            SameSite=None
                Behavior: Sent for all cross-site requests
                Requires: Secure attribute
                Use: Third-party integrations, embedded apps

