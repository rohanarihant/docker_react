# if multiple inputs are there in the form what technique will you use for validations and rendering those ?

If you bind every input to a standard React useState variable
every single keystroke triggers a component re-render

// ❌ Naive approach: Re-renders the entire form on every character typed
const [formData, setFormData] = useState({ firstName: '', lastName: '', email: '' });

The Solution: React Hook Form (Uncontrolled Strategy)
    The most efficient pattern for multi-field forms is using uncontrolled inputs powered by React Hook Form (RHF).
    
    It uses refs to read values directly from the DOM without causing top-level state updates on every keystroke
    Components only re-render when validation errors actually occur or when specific fields are explicitly watched

2. Validation Strategy: Schema-Based Validation
    Instead of writing imperative if/else checks inside event handlers,
    use a Schema-based validation library like Zod or Yup combined with a resolver.
        Decoupled Logic: Keeps validation rules separate from component JSX.
        Type Safety: Automatically generates TypeScript types from the schema.
        Declarative Rules: Easy handling of field dependencies (e.g., "Confirm Password must match Password").

Step 1: Define the Validation Schema

    import { z } from 'zod';

    export const formSchema = z.object({
    fullName: z.string().min(2, 'Name must be at least 2 characters'),
    email: z.string().email('Invalid email address'),
    age: z.coerce.number().min(18, 'You must be at least 18'),
    password: z.string().min(8, 'Password must be at least 8 characters'),
    confirmPassword: z.string()
    }).refine((data) => data.password === data.confirmPassword, {
    message: "Passwords don't match",
    path: ["confirmPassword"], // Error attaches directly to confirmPassword field
    });
    export type FormSchemaType = z.infer<typeof formSchema>;



Step 2: Build a Reusable Input Component
    import React from 'react';

    const FormInput = React.forwardRef(({ label, error, ...props }, ref) => (
    <div className="form-group">
        <label>{label}</label>
        <input ref={ref} {...props} className={error ? 'input-error' : ''} />
        {error && <span className="error-msg">{error.message}</span>}
    </div>
    ));

    export default FormInput;

Step 3: Connect in the Form Container
import React from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { formSchema } from './formSchema';
import FormInput from './FormInput';

export function RegistrationForm() {
  const {
    register,
    handleSubmit,
    formState: { errors, isSubmitting },
  } = useForm({
    resolver: zodResolver(formSchema),
    mode: 'onBlur', // Validates when user leaves the field (reduces intrusive warnings while typing)
  });

  const onSubmit = async (data) => {
    console.log('Form Submitted successfully:', data);
    // API call here
  };

  return (
    <form onSubmit={handleSubmit(onSubmit)}>
      <FormInput
        label="Full Name"
        {...register('fullName')}
        error={errors.fullName}
      />

      <FormInput
        label="Email"
        type="email"
        {...register('email')}
        error={errors.email}
      />

      <FormInput
        label="Age"
        type="number"
        {...register('age')}
        error={errors.age}
      />

      <FormInput
        label="Password"
        type="password"
        {...register('password')}
        error={errors.password}
      />

      <FormInput
        label="Confirm Password"
        type="password"
        {...register('confirmPassword')}
        error={errors.confirmPassword}
      />

      <button type="submit" disabled={isSubmitting}>
        {isSubmitting ? 'Submitting...' : 'Register'}
      </button>
    </form>
  );
}
