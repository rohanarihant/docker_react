A Pure Component
    in React is a component that renders the exact same UI output for the exact same set of props and state
    It achieves performance optimizations by skipping re-renders when its incoming props and state haven't changed
    using a shallow comparison (comparing primitive values by value and objects/arrays by reference)

    1. Functional Components (React.memo)
        React.memo wraps your functional component. Before triggering a re-render, React compares the new props against the previous props. If nothing changed, React reuses the last rendered output instead of re-executing the component body.
    2. Class-Based Components (React.PureComponent)
        In class-based components, purity is achieved by extending React.PureComponent instead of React.Component.
        React.PureComponent automatically implements the shouldComponentUpdate()
        lifecycle method with a shallow prop and state comparison.

        shouldComponentUpdate(nextProps, nextState) {
            // Return true if props or state changed, false if identical
            return !shallowEqual(this.props, nextProps) || !shallowEqual(this.state, nextState);
        }
