# forwardRef
    is a built-in React function that allows a custom component to take a ref
    received from its parent and "forward" it down to an internal DOM node or child component

If you pass a ref directly to a standard functional component like <CustomInput ref="{myRef}"/>
React won't pass ref in the component's props object. In React 18 and earlier,
doing so triggers a warning and evaluates ref as undefined

forwardRef bridges this gap by explicitly exposing a component's internal DOM node to its parent.

How It Works (Code Example)
    Here is how a parent component uses forwardRef to focus an <input> element inside a custom child component:

    import React, { useRef, forwardRef } from 'react';

    // 1. Wrap the child component with forwardRef
    // Notice the callback accepts TWO arguments: (props, ref)
    const CustomInput = forwardRef((props, ref) => {
    return (
        <div className="input-wrapper">
        <label>{props.label}</label>
        {/* 2. Attach the forwarded ref to the actual DOM element */}
        <input ref={ref} type="text" placeholder={props.placeholder} />
        </div>
    );
    });

    // Parent component
    function ParentForm() {
    const inputRef = useRef(null);

    const handleFocus = () => {
        // 3. Directly access and control the child's DOM node
        inputRef.current.focus();
    };

    return (
        <div>
        <CustomInput ref={inputRef} label="Username" placeholder="Enter username" />
        <button onClick={handleFocus}>Focus the Input</button>
        </div>
    );
    }

Note on React 19+: 
    Starting in React 19, ref can be passed directly as a standard prop to functional components
    without needing forwardRef! forwardRef remains heavily used across existing codebases and React 18 apps.

