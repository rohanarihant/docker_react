# Server-side rendering vs React Server Component


# SSR
    server sends fully rendered HTMl
        server will renders the full page on the server
    |
    |
    HTML :- fully rendered HTML is sent to the client
    |
    |
    Client :- (Browser)
    Receives HTML and displays the page
    (immediately viewable)


# CSR
    server sends JS, client render HTMl
    |
    |
    Server :- sends JS bundle (e.g main.js)
    |
    |
    JS :- JS bundle is sent to the client
    |
    |
    Client (Browser):- 
        Download JS, runs it
        then render HTMl
        (in UI appear after JS load)


# RSC
    server sends component payload, client renders HTMl
    |
    |
    Server :-
        render React Server Components and sends FLight Payload
        |
        |
        Flight payload
            RSC payload is sent to the client
        |
        |
        Client (browser)
        Uses React to process the payload and renders HTML (fast, less JS sent)

        page.tsx (async RSC)
            |
            |
        renderToReadableStream()  <--- start the RSC process
            |
            |
        O:["$","div",null,{"children":"hello"}]. <---   RSC payload (serialized tree)
        1:I["./Button.js,[],"Button"]
            |
            |
        initial HTML
            |
            | (Client)
            |
        const treePromis = createFromReadableStream(RSC)
            |
            |
        function root(){
            return use(treePromise)
        }
