# Lazy loading
    in modern JavaScript applications relies on a combination of ES Module Dynamic Imports (import()),
    Webpack's dependency graph chunking, and browser network fetching.

#   1. How Dynamic Imports Work (import())
    // ✅ Dynamic import: Returns a JavaScript Promise
    const Home = React.lazy(() => import('./Home'));

#   2. How Webpack Creates Multiple Chunks
    where webpack see the dynamic import it will create seperate chunk 
    it marks ./About (and all of its child dependencies that aren't shared) as a separate entry point.

    Chunk Emission: Webpack generates separate .js files (chunks):
        bundle.js / main.js — Contains the app shell, router, and static components.
        src_pages_About_js.chunk.js — Contains only the code needed for the About component.

#       Webpack Runtime Code Injection
        Inside main.js, Webpack embeds a lightweight runtime module function
        called __webpack_require__.e (which stands for "ensure chunk").

#   3. How and When the Browser Fetches Chunks on Route Change
    User Clicks Link -> Client Router updates location -> React renders Lazy Component
        │
        ▼
    React calls import('./About') -> Webpack __webpack_require__.e('about')
        │
        ▼
    Browser injects <script src="about.chunk.js"> into <head>
        │
        ▼
    Network Request Sent -> Script Downloaded -> Script Evaluated in Browser
        │
        ▼
    Promise Resolves -> React Suspense removes Fallback UI -> UI Rendered

#       Preloading & Prefetching (Optimization)
        you can instruct Webpack and the browser to fetch the chunk in advance using
    Webpack Magic Comments :-
        
        // Webpack Prefetch: Downloads chunk in background during browser idle time
            const About = React.lazy(() => 
            import(/* webpackPrefetch: true */ './About')
            );
        
        When Webpack sees webpackPrefetch: true, it automatically appends a link tag to the HTML head on page load:
            <link rel="prefetch" href="/static/js/about.chunk.js" as="script">