# Profiler tool
    inspect in chrome
    move to profiler tab
*    on each event click it will highlight the re-rendered dom
        we can check if anything we can improve or we can stop re-rendering

# Performance Tab
    inspect in chrome
    move to Performance tab
*       will give us the LCP, INP and CLS
            we can check those metrics and improve them

*       we can start recording of the UI page and trigger some events
        based on the events we can track the perfomace in metrics

*       in Schedular (Custom) tab
            it will show the these events
                Blocking :- here all events are blocking
                            if we can zoom in and see the sequence of events
                            we will see
                                event -> render ->
                                    we can see number of components got re-renders
                                    we can click on any re-rendered component and check its summary
                                    try to add memo, or compiler if needed
                                    summary will tell which components are actually make it rerender
                                    props changes makes rerender

                Transition  :- we can move those tasks which are not important and not to block the main threads
                        like we can move some animation related updates
                Suspense :-
                    here we can put our changes in suspense, the data which can be lazyly loaded or not much important
                    to display instantly

    why is component re-rendering?
    which components are re-rendering?
    what is causing them to re-rendering?

    Use profile to highlight why components are re-rendering
    Use performance tracks to identify blocking components
        will let us know which of the component are spending most of the time in blocking phase
        figure out ways to optamize that by moving some interactions
        
