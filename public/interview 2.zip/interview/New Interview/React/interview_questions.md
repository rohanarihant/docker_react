# What is state scheduling in react.js
    is the internal process of deciding when and how state updates are applied
    When you call setState multiple times
    React often groups (or "batches") these updates together.
    It waits for all the code in your event handler to finish running before re-rendering the UI just once

    Prioritizing Updates (Concurrent Features)
        scheduling can also prioritize updates to keep the app responsive
        Urgent Updates: User interactions like typing or clicking are handled immediately to maintain responsiveness
        Non-Urgent (Transition) Updates: Heavy rendering tasks (e.g., filtering a large list) can be wrapped with startTransition or useTransition. React marks these as lower priority and can pause them to handle more urgent work first

# React 16 vs React 18
    The primary difference between React 16 and React 18 is the introduction of the Concurrent Rendering engine
    shifting React from a purely synchronous architecture to one capable of pausing, resuming, and abandoning UI renders
    While React 16 established the foundational "Hooks" paradigm
    React 18 focuses heavily on core rendering performance, smoother transitions, and architectural optimizations

    Feature / Concept               React 16                    React 18
    Rendering Model
        Synchronous: Blocking and uninterrupted transaction.
        Concurrent: Non-blocking; breaks rendering into interruptible chunks.
    State Batching
        Manual/Limited: Batched state updates only inside React event handlers.
        Automatic: Batches updates everywhere (Promises, timeouts, native events).
    Root API
        ReactDOM.render(<App />, container)
        ReactDOM.createRoot(container).render(<App />)
    Server-Side SSR
        Standard, basic string-based HTML hydration.
        Streaming SSR via Suspense; blocks load incrementally.
    Strict Mode Check
        Validates basic lifecycle safety checks.
        Double-invokes effects to test resilience to unmounting/remounting.

# What is reconciliation in react.js
Reconciliation is the process React uses to update the real DOM efficiently by comparing a new Virtual DOM tree with the previous one. Instead of rebuilding the entire webpage from scratch whenever a component's state or props change, React uses an intelligent "diffing" algorithm to calculate the minimum number of changes needed to update the browser UI.

How Reconciliation Works
    The entire synchronization process occurs across a structured, multi-step pipeline:
        Trigger: A state or prop change tells React to re-render a component.
        Virtual DOM Generation:
            React creates a new tree of lightweight JavaScript objects representing the updated UI structure.
        Diffing:
            React runs its core comparison algorithm to map out exactly what changed between the old tree and the new tree.
        Commit: React applies only those specific differences (patches) directly to the real browser DOM.

Core Heuristics of the Diffing Algorithm
    Comparing two trees fully has a massive computational complexity of O(n³).
    To keep apps lightning-fast, React relies on two smart assumptions (heuristics) to
    cut this complexity down to O(n):

    1. Elements of Different Types
        If two elements change their tag or component type, React will completely tear down the old UI subtree and build the new one from scratch.
        Changing <div> to <span> causes React to unmount the entire original node and all of its nested children.
        Component state is completely destroyed during this type of structural swap.
    
    2. Elements of the Same Type
        If two elements have the exact same HTML or component type,
        React keeps the underlying DOM node and only updates the modified attributes or props.

# how keys impact on performance for react list rendering
    Keys directly impact list rendering performance by telling React
    whether it can reuse existing DOM nodes or if it must destroy and recreate them.

    The Problem: Default Index-Based MatchingWhen a list has no keys, React matches the new array items to the old array items by their sequential position (index 0 to index 0, index 1 to index 1).
        If you insert a new item at the very beginning of a 1,000-item list:
            React sees that index 0 has changed.
            It mutates the text of index 0.
            It sees index 1 has changed, so it mutates index 1.
            This domino effect forces React to mutate all 1,000 existing DOM elements and append a new one at the end.

    The Solution: Unique KeysWhen you provide a unique identifier (like an ID from a database),
    React matches elements by their key instead of their index.
        If you insert that same item at the beginning with a unique key:
            React matches the 1,000 existing keys to the new tree.
            It realizes those 1,000 items simply shifted position.
            React performs exactly one DOM insertion at the top.
            The remaining 1,000 DOM nodes are completely reused without being updated

# Difference between Redux and Redux Toolkit
    Redux Toolkit (RTK) is the modern, official standard for writing Redux logic that wraps around the core Redux library to eliminate boilerplate code and force best practices.
    Core Redux is the low-level, minimalistic state management library, while Redux Toolkit is an opinionated abstraction layer built on top of it

    Boilerplate
        High (Requires separate actions, constants, and reducers)
        Low (Combines actions and reducers into "Slices")
    State Mutation
        Forbidden (Must manually copy state with spread operators)
        Handled safely under the hood (Uses Immer library)
    Store Setup
        Manual configuration (Tedious setup for middleware, devtools)
        Automatic (configureStore sets up devtools and middleware)
    Async Logic
        Requires installing extra packages (like redux-thunk or saga)
        Built-in via createAsyncThunk or RTK Query

# How do you prevent XSS and CSRF attacks?
    Cross-Site Scripting (XSS) :-
        XSS exploits the trust a user has in a specific website by injecting malicious scripts into it
    
    Preventing Cross-Site Scripting (XSS)
        when an application includes untrusted data in a web page without proper validation or escaping

        1. Context-Aware Output Encoding (Primary Defense):-
            Never insert untrusted data directly into the DOM.
            Convert dangerous characters into safe HTML entities before rendering them.
                HTML Body: Convert < to &lt;, > to &gt;, & to &amp;
                React Implementation:
                    React automatically escapes strings rendered in JSX templates
                    (e.g., {userData}) to protect against XSS by default.
            Avoid Dangerous Features:-
                Avoid using dangerouslySetInnerHTML in React or innerHTML in vanilla JS.
                If you must use them, sanitize the HTML string first using a library like DOMPurify.
        2. Implement a Strict Content Security Policy
            A CSP is an HTTP response header that restricts the resources (such as JavaScript, CSS, Images)
            that the browser is allowed to load for a given page.
            Disallow inline scripts (unsafe-inline) so attackers cannot execute injected <script> tags.

            Content-Security-Policy: default-src 'self'; script-src 'self' https://trustedscripts.com;
        3. Secure Cookies
            If you store session tokens in cookies, block JavaScript access entirely to prevent malicious scripts
            from stealing tokens during an XSS attack.
                Append the HttpOnly flag to your session cookies.


    Preventing Cross-Site Request Forgery (CSRF)
        CSRF occurs when a malicious website tricks a user's browser into making an unwanted request to a site
        where the user is currently authenticated.

        1. Use the SameSite Cookie Attribute (Primary Defense)
            The SameSite attribute controls whether cookies are sent with cross-site requests.
            Setting this correctly blocks the browser from automatically sending authentication
            credentials during a CSRF attempt.

            SameSite=Strict: The cookie is never sent in cross-site requests (e.g., clicking a link from an external site to your bank).
            SameSite=Lax: The cookie is withheld on cross-site subrequests (like images or AJAX calls) but sent when a user navigates to the origin site normally. This is the safe modern default for most applications.
            Implementation Requirement: Ensure cookies also use the Secure flag (HTTPS only).

# What is Service Worker?
    A Service Worker is a specialized JavaScript file that runs in the browser background,
    completely independent of your web page, acting as a programmable network proxy.

        Core Capabilities of a Service Worker
            Offline Support & Caching
            Push Notifications
            Background Sync
            PWA Foundation

# How to cancel previous API requests
    To cancel a request, instantiate an AbortController,
    pass its signal property into the fetch options configuration,
    and call .abort() when a new request is triggere

    import React, { useState, useEffect } from 'react'; 

    function SearchComponent({ query }) {  
        const \[results, setResults\] = useState(\[\]); 

        useEffect(() => {  
            // 1. Create a fresh instance of AbortController for this render cycle  
            const controller = new AbortController();  
            const { signal } = controller; 

            async function fetchData() {  
                try {  
                    const response = await fetch(`https://example.com{query}`, { signal });  
                    const data = await response.json();  
                    setResults(data);  
                } catch (error) {  
                    // 2. Handle the aborted request gracefully  
                    if (error.name === 'AbortError') {  
                    console.log('Previous request was successfully canceled.');  
                } else {  
                    console.error('An actual network error occurred:', error);  
                }  
            }  
        } 

        if (query) {  
        fetchData();  
        } 

        // 3. React cleanup: Aborts the fetch when query changes OR component unmounts  
        return () => {  
        controller.abort();  
        };  
        }, \[query\]); // Re-runs whenever the query variable changes 

        return {/\* Render results here \*/};  
        } 

    export default SearchComponent;

# How do you optimize performance of an react application
    minimizing two main performance bottlenecks:
    how often components render (CPU) and how much JavaScript the browser has to download (Network)

    1. Optimize Component Rendering (CPU)
        By default, when a parent component state changes, React recursively re-renders all of its child components.
        You can bypass this process for components that do not need updates.

        React.memo
        useCallback
        useMemo
    State Colocation:
        Move state as close to where it is used as possible.
        Keeping a state variable inside a localized child component
        prevents the entire page or parent tree from updating

    2. Reduce Asset Bundle Sizes (Network & Loading)
        Loading a giant JavaScript file slows down the initial Page Speed and increases Time to Interactive (TTI).

        Code Splitting (React.lazy and Suspense):
            Split your application bundle into smaller chunks and load them on demand
            (e.g., only loading a dashboard route when the user clicks it).
        
        const HeavyDashboard = React.lazy(() => import('./Dashboard'));
        function App() {
        return (
            <Suspense fallback={<div>Loading Page...</div>}>
            <HeavyDashboard />
            </Suspense>
        );
        }

    Tree Shaking: Ensure your dependencies support tree-shaking (like using lodash-es instead of lodash)
                    so your bundler automatically strips out unused JavaScript functions.

    3. Handle Long Lists Efficiently
        Rendering thousands of HTML items to the browser DOM causes major UI lag.

        Windowing / Virtualization:
                Use libraries like react-window or react-virtualized.
                These tools only render the exact items currently visible inside the user's viewport screen,
                swapping nodes dynamically as the user scrolls.
        Stable Keys: Always use stable, unique IDs for list arrays to maximize React's reconciliation efficiency.

    4. Optimize Images and Static Assets
        Modern Layout Formats: Convert images into lightweight formats like WebP or AVIF.
        Lazy Loading Images: Use the native HTML loading attribute
            <img src="..." loading="lazy" /> to defer image fetching until they approach the viewport.
    5. Transition to Concurrent Features
        If you are using React 18 or later, leverage its core asynchronous rendering architectures:
        useTransition:
            Mark low-priority state updates (like a massive list filtering action) as non-blocking transitions.
            This allows urgent user interactions (like typing in a text field) to render instantly without stuttering
        useDeferredValue:
            Postpone updating a slow, secondary part of your UI to keep input fields smooth and responsive.

# Can you share multiple ways to intercept API requests in React projects?
    Intercepting API requests in React allows you to globally
    inject authentication tokens (like JWTs), manage loading states,
    refresh expired sessions, format large payloads,
    and handle errors in a single centralized place.

# React Server Components (RSCs)
    are a modern architectural paradigm where components execute exclusively on the server,
    streaming their UI output directly to the client without sending
    any of their underlying JavaScript source code to the browser
    Introduced natively in React 19,
    RSCs fundamentally change how full-stack React applications partition data fetching and interactive UI

    rendering ahead of time and sending a special payload to the client instead of JavaScript bundles

    Environment
        Runs on the server (at build time or per request)
        Runs in the browser (on the client)
    Bundle Size
        No JavaScript sent to the browser, reducing bundle size
        JavaScript is sent to the browser and executed
    Code Features
        Can use async/await to directly access databases or file systems
        Can use React hooks like useState, useEffect and browser APIs
    Interactivity
        No interactivity; cannot use useState or event handlers
        Fully interactive; handles user events and state changes

# Rehydration in react
    Rehydration (also called "hydration") is the process React uses to bring a server-rendered HTML page
    to life on the client side.

    React sends a fully built HTML page to the browser so the user can see the content instantly
    However, that HTML is just a static snapshot—it has no interactivity, event handlers, or state
    Rehydration is the step where React attaches JavaScript logic to that
    existing HTML so it becomes a fully interactive app

    Here is how the step-by-step flow works:

    Server sends HTML: The server renders your React components to HTML strings and sends them to the browser.
    The user sees the page content immediately.
    Browser loads JavaScript: While the user is reading, the browser downloads the JavaScript bundles for that page.
    React "hydrates": React runs in the browser, looks at the existing DOM tree, and "reconciles" it with its virtual DOM. It attaches event listeners (like onClick), sets up internal state, and connects the tree to React's update system.
    App becomes interactive: Once hydration is complete, the user can click buttons, type in inputs, and trigger state changes.


# Partial Pre-rendering (PPR)
    is a hybrid rendering strategy that gives you the best of both worlds:
    the instant loading speed of static sites with the flexibility of dynamic, server-rendered content

    🚀 How It Works: Build Time + Request Time
    Build Time (Static Shell): When you build your application, Next.js pre-renders everything it can into a static HTML shell. This includes the layout, headers, footers, and any other content that doesn't depend on user-specific data. Any parts that are dynamic, like a user's shopping cart, are replaced with a placeholder or loading fallback, often defined using React's <Suspense> component

    Initial Load
        Waits for all data to be fetched before sending HTML.
        Sends the static shell instantly.
    Time to First Byte (TTFB)
        Slower (~200-500ms), as server renders the whole page.
        Much faster (~10-50ms), as the server only sends the cached shell.
    Dynamic Content
        Generated once for the entire page on the server.
        Streamed to the client in chunks as it becomes ready.
    User Experience
        User sees a blank page while the server works.
        User sees a functional page skeleton immediately.

# windowing
    Windowing (also called virtualization) is a performance optimization technique in React
    that renders only the items currently visible in the user's viewport, rather than the entire list.

    Without windowing, rendering large lists causes:
        Slow initial load — The browser has to create thousands of DOM nodes upfront, delaying the time to first paint.
        High memory usage — Every DOM node consumes memory. Too many can cause tab crashes on low-powered devices.
        Laggy scrolling — Re-rendering thousands of items on state changes becomes expensive, causing jank.

    Visible Window:
        The library calculates which items should be visible based on the scroll position,
        item height, and container dimensions. It then renders only those items.
    
    react-window — The most popular and lightweight option. It handles basic lists and grids efficiently.
    react-virtualized — The precursor to react-window. More feature-rich but larger in bundle size.
    TanStack Virtual — A modern, framework-agnostic virtualizer that works well with React.
                        It provides more flexibility and supports dynamic item heights more easily.


# WCAG
    Implementing WCAG (Web Content Accessibility Guidelines) in React is about building applications
    that are usable by everyone, including people with disabilities.
    React fully supports building accessible websites, often by using standard HTML techniques.

    1. Prefer Semantic HTML (SC 1.3.1, 4.1.2)
        Semantic HTML is the foundation of accessible web content.
        It gives meaning to elements for assistive technologies.
        Use native elements like <button>, <input>, <nav>, and <header> whenever possible.
        For example, use a <button> for an action on the page and an <a> for links to different routes.
    
    2. Manage Focus Programmatically (SC 2.4.3, 2.4.7)
        In single-page applications, focus can be lost after route changes or when modals open
        
        Focus After Route Change: After navigation, move focus to the main content area.
            Use useRef and useEffect hooks
        
        Focus Trapping in Modals: When a modal opens, focus should be trapped inside it.
        On close, return focus to the element that triggered the modal.
        Use React refs to control focus programmatically.
    3. Use ARIA Attributes Correctly (SC 4.1.2)
        Only use ARIA when semantic HTML is not possible.
        In JSX, aria-* attributes are written in hyphen-case (kebab-case),
        unlike most other React DOM properties which are camelCase

        <input
            type="text"
            aria-label="Search for a product" // Correct hyphen-case
            aria-required="true"
            value={searchValue}
            onChange={handleChange}
        />

    Beyond the Basics
        For a truly accessible React application, also consider these points:

        Keyboard Operability: All interactions must be possible using the keyboard alone,
        with standard keys like Tab, Enter, and Space.

        Focus Order: Ensure the focus order follows a logical sequence that matches the visual layout.

        Announcing Route Changes: Use a hidden aria-live region to announce page navigations to screen reader users.

        Form Labels & Errors: Every input must have a visible or aria-label label.
        All errors must be clearly identified and announced.

        Color Contrast and Indicators: Don't convey information with color alone.
        Pair it with text, icons, or patterns. Ensure contrast ratios meet the minimum 4.5:1 for normal text

# diff bw controlled and uncontrolled component
    The fundamental difference between controlled and uncontrolled components in React lies in where the form data is stored and managed

    In a controlled component, form data is handled by the React component state.
    In an Uncontrolled component, form data is handled directly by the browser DOM.

    🏛️ Structural Comparison
    
    Feature             Controlled Component                                Uncontrolled Component
    Source of Truth     React State (useState)                              The Browser DOM
    Data Retrieval      Read directly from state                            Accessed via a React Ref (useRef)
    Value Tracking      Updates on every single keystroke                   Read only when needed (e.g., on submit)
    Performance         Higher re-renders (renders on every input change)   Higher performance (no re-renders while typing)
    Validation          Easy, instant field-level validation                Done at the end during form submission


# what makes component re-render
    1. Changes in Local State (useState / useReducer)
    2. Changes in Component Props
        If a parent component passes props down to a child component,
        and those props change, the child component will automatically re-render to reflect the new data.
    3. Parent Component Re-rendering
        all of its children components re-render recursively
    4. Changes in React Context (useContext)
        every single component consuming that context will immediately re-render