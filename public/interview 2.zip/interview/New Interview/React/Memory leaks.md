# In React apps, 
    a memory leak happens when allocated memory is not released after a component unmounts.
    The garbage collector cannot clean up the component's memory because a persistent reference to it
    still exists elsewhere in your application.

    Over time, these accumulated leaks slow down the application and eventually crash the user's browser.

1. The Core Culprits (How Leaks Happen)
    
    Uncleared Event Listeners :-
        When you add a global event listener (like window.addEventListener) inside a component,
        it attaches to the browser's global scope. If you don't remove it when the component destroys,
        the global scope keeps a reference to the component's internal functions, trapping it in memory.
    
    Abandoned SetTimeouts and SetIntervals :-
        If a setInterval or setTimeout triggers a state update, 
        but the user navigates away from the page before the timer finishes,
        the timer callback still holds a reference to the state setter (setState).
        The browser keeps the unmounted component alive to execute that pending function.
    
    Uncancelled Network Requests / Subscriptions :-
        If an app triggers a long-running API fetch or opens a WebSocket connection inside a component,
        the promise callback retains a reference to the component. If the component unmounts before the data returns,
        React will try to update state on a nonexistent component, creating a leak.

    Global State or Closures Holding References :-
        Storing a component's reference, DOM node, or callback function in a global object,
        a long-lived context, or an external state manager (like Redux or Zustand) without clearing it
        upon unmounting will prevent garbage collection.