#   Modern Open-Source Frameworks (Developer-Centric)

    Playwright:
    Cypress:
        cy.viewport('iphone-5')
        cy.viewport(390, 844)
    Selenium WebDriver: