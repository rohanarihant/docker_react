# Currying
    Currying is a functional programming technique where a function that takes multiple arguments is transformed into a sequence of functions,
    each taking a single argument.

    // NORMAL FUNCTION - Takes all arguments at once
        function add(a, b, c) {
            return a + b + c;
        }
        console.log(add(1, 2, 3)); // 6

        // CURRIED FUNCTION - Takes arguments one at a time
        function curriedAdd(a) {
            return function(b) {
                return function(c) {
                    return a + b + c;
                };
            };
        }
        console.log(curriedAdd(1)(2)(3)); // 6

        // More readable curried version using arrow functions
        const curriedAddArrow = a => b => c => a + b + c;
        console.log(curriedAddArrow(1)(2)(3)); // 6

        // Another solution
            function add(a) {
                return function(b) {
                    if (b !== undefined) {
                        return add(a + b); // Keep adding and returning the function
                    }
                    return a; // If called empty (), return the total
                };
            }
    
    // Utility to curry any function
        function curry(func) {
            return function curried(...args) {
                if (args.length >= func.length) {
                    return func.apply(this, args);
                } else {
                    return function(...moreArgs) {
                        return curried.apply(this, args.concat(moreArgs));
                    };
                }
            };
        }

        // Usage examples
        function sum(a, b, c, d) {
            return a + b + c + d;
        }

        const curriedSum = curry(sum);
        console.log(curriedSum(1)(2)(3)(4)); // 10
        console.log(curriedSum(1, 2)(3, 4)); // 10
        console.log(curriedSum(1)(2, 3, 4)); // 10

        // With arrow functions
        const multiplyCurried = curry((a, b, c) => a * b * c);
        console.log(multiplyCurried(2)(3)(4)); // 24

