# give me a react example of logging with react-monitoring and datadog

2. Initialize the Monitor
    Create a file, like monitor.js, to initialize the Datadog provider.
    You'll need your Datadog clientToken and applicationId from your Datadog RUM application 

    // monitor.js
        import { monitor } from 'react-monitoring';

        monitor.init({
        provider: 'datadog',
        token: 'YOUR_CLIENT_TOKEN', // Your Datadog client token
        // Optional but recommended parameters:
        environment: 'production', 
        service: 'my-frontend-service',
        site: 'datadoghq.com', // Specify if using a different Datadog site
        trackErrors: true, // Automatically forward runtime errors
        // Default fallback UI for errors caught by ErrorBoundary
        errorBoundaryDefaultValues: {
            fallback: <div>Something went wrong. Please try again.</div>,
            logOptions: {
            level: 'error',
            message: 'An unexpected error occurred in the application',
            },
        },
        });

3. Use the Logger
    Import the logger from react-monitoring anywhere in your React components.
    You can also use the ErrorBoundary component to catch errors in specific parts of your UI 

    // App.js
        import React from 'react';
        import { logger, ErrorBoundary, withErrorBoundary } from 'react-monitoring';
        import './monitor'; // Ensure the monitor is initialized

        function MyComponent() {
        const handleClick = () => {
            // Log an info event
            logger.info({
            message: 'User clicked the button',
            logProperties: { buttonId: 'submit-btn' },
            });
        };

        const handleError = () => {
            try {
            // Some code that might throw an error
            throw new Error('Failed to process data');
            } catch (error) {
            // Log the error explicitly
            logger.error({
                message: 'Error processing form data',
                logProperties: { 
                error: error.message,
                field: 'email',
                },
            });
            }
        };

        return (
            <div>
            <button onClick={handleClick}>Click Me</button>
            <button onClick={handleError}>Trigger Error</button>
            </div>
        );
        }

        // Wrap a component with error boundary HOC
        const SafeComponent = withErrorBoundary(MyComponent, {
        level: 'error',
        message: 'Error in MyComponent',
        });

        function App() {
        return (
            // Or use the ErrorBoundary component directly
            <ErrorBoundary
            fallback={<div>Oops! Something went wrong in this section.</div>}
            logOptions={{
                level: 'error',
                message: 'Error on the homepage',
            }}
            >
            <SafeComponent />
            </ErrorBoundary>
        );
        }

        export default App;



What They Catch vs. What They Miss
    ✅ They WILL catch:
    Errors thrown during rendering of your functional components
    Errors thrown in lifecycle methods (like useEffect in some cases)
    Errors thrown in constructor functions of child components

❌ They will NOT catch:
    Errors in event handlers (like onClick)
    Errors in asynchronous code (like setTimeout or fetch callbacks)
    Errors thrown in server-side rendering (SSR)
    Errors that occur outside the wrapped component tree

    