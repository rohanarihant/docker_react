# frontend-to-backend integration patterns.

    Frontend-to-backend (FE-to-BE) integration patterns define how your user interface
    communicates with your server infrastructure


    1. Direct Client-to-API Pattern
    2. Backend-for-Frontend (BFF) Pattern
        Pros:
            Highly optimized frontend performance
            zero over-fetching of data
            complete decoupling of frontend components from messy backend microservice schemas
        Cons:
            Introduces an extra layer to maintain
            deploy
            monitor
    3. GraphQL / Data Aggregation Layer
        Instead of building multiple distinct BFFs, you can deploy a centralized GraphQL layer (or a federated GraphQL gateway) between the frontend and backend services.

    4. 4. Server-Side Integration (SSR & Server Components)
        How it works: Using React Server Components (RSC) or SSR data loaders, the code that fetches data runs directly on the server hosting the frontend framework. It can securely query databases, communicate with internal APIs via high-speed private networks, and render the final HTML/components before sending anything down to the browser.

    5. Event-Driven Real-Time Streams
        How it works: The client initiates a persistent connection using WebSockets or Server-Sent Events (SSE).
        The backend pushes updates to the client asynchronously the microsecond a data state changes inside the system.