# Real Time dashboard

    React requires a careful balance between data ingestion, state management, and rendering performance
    If your backend is pushing data multiple times per second,
    a naive React architecture will cause excessive re-renders, lagging charts, and an unresponsive UI    

    1. Choose the Right Ingestion Protocol
        WebSockets (ws://):
            Best if the dashboard allows user interaction (e.g., sending commands back or muting channels).
        Server-Sent Events (SSE):
            Ideal for pure visual dashboards (e.g., monitoring metrics, stock tickers)
            because it's unidirectional, runs over standard HTTP, and auto-reconnects natively.
        Polling:
            Avoid this unless you have no control over a legacy REST backend.

    2. High-Performance Architecture Blueprint
        The 3 Core Bottlenecks to Avoid:
            1. The State Spam
            2. Unnecessary Sub-tree Re-renders
            3. Heavy Chart Redraws


        const [metric, setMetric] = useState({ value: 0, status: 'stable' });
        const socketRef = useRef(null);
        const bufferRef = useRef(null); // Holds the latest data between ticks

        useEffect(() => {
            // 1. Establish connection
            socketRef.current = new WebSocket(`wss://api.example.com/sensors/${sensorId}`);

            // 2. Buffer high-frequency incoming data silently without triggering state re-renders
        socketRef.current.onmessage = (event) => {
            const data = JSON.parse(event.data);
            bufferRef.current = data; 
        };

        // 3. Throttle/Batch UI updates to run exactly once every 300ms
        const uiTickInterval = setInterval(() => {
            if (bufferRef.current) {
                setMetric(bufferRef.current);
                bufferRef.current = null; // Clear buffer after pushing to UI
            }
            }, 300);

            // 4. Clean up connections on unmount
            return () => {
                socketRef.current.close();
                clearInterval(uiTickInterval);
            };
        }, [sensorId]);