# Redux Thunk
    Redux Thunk is middleware that allows action creators to return a function instead of an action object, enabling async logic.

        // Regular action creator (sync)
            const addTodo = (todo) => ({
                type: 'ADD_TODO',
                payload: todo
            });

            // Thunk action creator (async)
            const fetchTodos = () => {
                return async (dispatch, getState) => {
                    dispatch({ type: 'FETCH_TODOS_REQUEST' });
                    
                    try {
                        const response = await fetch('/api/todos');
                        const todos = await response.json();
                        
                        dispatch({ type: 'FETCH_TODOS_SUCCESS', payload: todos });
                    } catch (error) {
                        dispatch({ type: 'FETCH_TODOS_ERROR', error });
                    }
                };
            };

            // Use when you need:
            // 1. Async API calls
            // 2. Conditional dispatching
            // 3. Access to getState
            // 4. Multiple dispatches in sequence

# How do you optimize Redux performance?

    //  Use Reselect for memoized selectors
            import { createSelector } from 'reselect';

            const selectTodos = state => state.todos;
            const selectFilter = state => state.filter;

            const selectFilteredTodos = createSelector(
                [selectTodos, selectFilter],
                (todos, filter) => {
                    // Only recomputes when todos or filter changes
                    return todos.filter(todo => todo.status === filter);
                }
            );

            // 2. Normalize state shape
            // ❌ Bad: Nested data
            {
                users: {
                    1: { name: 'John', posts: [{ id: 1, title: 'Post 1' }] }
                }
            }

            // ✅ Good: Normalized
            {
                users: { 1: { name: 'John', postIds: [1] } },
                posts: { 1: { id: 1, title: 'Post 1', userId: 1 } }
            }

            // 3. Use shallow equality checks
            const MyComponent = () => {
                // Only re-renders if reference changes
                const user = useSelector(state => state.user, shallowEqual);
            };

            // 4. Split reducers with combineReducers
            const rootReducer = combineReducers({
                users: userReducer,
                posts: postReducer,
                comments: commentReducer
            });

# What are common Redux patterns and anti-patterns?
    Anti Pattern
        // 1. Storing non-serializable data
                {
                    date: new Date(), // ❌
                    promise: fetch(), // ❌
                    function: () => {} // ❌
                }

                // 2. Mutating state directly
                const reducer = (state, action) => {
                    state.count++; // ❌
                    return state;
                };

                // 3. Putting all state in Redux
                // Don't store UI state like modal open/close in Redux

                // 4. Large action types
                { type: 'USER_PROFILE_UPDATE_USER_EMAIL_ADDRESS' } // Too specific
    
    Best Patterns
        // 1. Use action constants
            const USER_UPDATE = 'user/update';
            const USER_DELETE = 'user/delete';

            // 2. Use action creators
            const updateUser = (user) => ({ type: USER_UPDATE, payload: user });

            // 3. Keep reducers small and focused
            const userReducer = combineReducers({
                profile: profileReducer,
                settings: settingsReducer
            });

            // 4. Use Redux Toolkit
            const userSlice = createSlice({
                name: 'user',
                initialState,
                reducers: {
                    updateUser: (state, action) => {
                        state.user = action.payload; // Safe mutation with Immer
                    }
                }
            });

    

