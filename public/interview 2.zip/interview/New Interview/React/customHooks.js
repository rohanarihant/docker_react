// import { useState, useEffect } from 'react'

// export function useResizeWindow(){
//     const [windowWidth, setWindowWidth] = useState(null);

//     const handleWindowSize = () => setWindowWidth(window.innerWidth)
//     useEffect(() => {
//         window.addEventListener('resize', handleWindowSize)
//         return () => window.removeEventListener('resize', handleWindowSize)
//     },[])
//     return windowWidth;
// }

// const width = useResizeWindow()

// // Use Case 1: Synchronizing State with LocalStorage (useLocalStorage)

// export function useLocalStorage(key, initialValue){
//     const [storedValue, setStoredValue] = useState(() => {
//         try{
//             const item = window.localStorage.getItem(key)
//             return item ? JSON.parse(item) : initialValue
//         }catch(err){
//             console.log(error)
//             return initialValue
//         }
//     })
//     useEffect(() => {
//         try{
//             window.localStorage.setItem(key, JSON.stringify(storedValue))
//         }catch(error){
//             console.log(error,'error')
//         }
//     },[key, storedValue])
//     return [storedValue, setStoredValue]
// }

// const themeType = useLocalStorage('theme-type', false)

// // Use Case 2: Race-Condition Safe Data Fetching (useFetch)
//     // basic fetch requested in useeffect can suffer from race conditions
//     // and do not natively manage the error and loading state cleanly.


// export function useFetch(url){
//     const [data, setData] = useState(null)
//     const [error, setError] = useState(null)
//     const [isLoading, setIsLoading] = useState(false)


//     const 

//     useEffect(() => {
//         let isMounted = true;
//         setIsLoading(true)
//         fetch(url).then((res) => {
//             if(!res.ok) return new Error('Network Error')
        
//                 return res.json()
        
//         }).then((response) => {
//             if(isMounted){
//                 setData(response)
//                 setError(null)
//             }
//         })
//         .catch(error => {
//             setError(error)
//         })
//         .finally(() => {
//             if(isMounted) setIsLoading(false)
//         })

//         return () => {
//             isMounted = false;
//         }
//     },[url])
//     return { data, error, isLoading }
// }

// function UserProfile(){
//     const { data: user, error, isLoading } = useFetch(url)
// }

// // Use Case 3: Monitoring User Network Connection (useOnlineStatus)

// export function useOnlineStatus(){
//     const [isOnline, setIsOnline] = useState(false)

//     useEffect(() => {
//         const handleOnline = () => setIsOnline(true)
//         const handleOffline = () => setIsOnline(false)
    
//         window.addEventListener('online', handleOnline);
//         window.addEventListener('offline', handleOffline);

//         return () => {
//             window.removeEventListener('online', handleOnline)
//             window.removeEventListener('offline', handleOffline)
//         }
//     },[])
//     return isOnline
// }

// const isOnline = useOnlineStatus();

// // Use Case 4 use debounce for api calls

// export function useDebounce(fn, delay = 500){
//     const [debounceValue, setDebounceValue] = useState(null)

//     useEffect(() => {
//         let timer = null;
//         timer = setTimeout(() => {
//             const response = fn()
//             setDebounceValue(response)
//         },delay);
//         return () => clearTimeout(timer)
//     },[])
//     return debounceValue;
// }

// const { debounceValue } = useDebounce(fn, 300);


// # Custom Debounce hook
//     import {useState, useEffect} from 'react'

//     function useDebounce(value, delay=500){
//         const [ debouncedValue, setDebounceValue] = useState(null);

//         useEffect(() => {
//             let handler = setTimeout(() => {
//                 setDebounceValue(value);
//             }, delay);

//             return () => {
//                 clearTimeout(handler)
//             };
//         },[value, delay])
//         return debouncedValue;
//     }



// // inside our react component

//     const seachDebounced = useDebounce(searchQuery, 500)
//     useEffect(() => {
//         fetch('url/${seachDebounced}')
//     },[seachDebounced])





























