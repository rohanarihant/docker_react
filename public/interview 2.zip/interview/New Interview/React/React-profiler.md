# React Profiler
    is a built-in tool provided by React to measure the rendering performance of your application
    It identifies parts of your application that are rendering slowly or rendering too frequently
    allowing you to pinpoint the exact bottlenecks to optimize

    1. Visual Profiling (React DevTools)
        How to use it:
            Open your app in the browser and open Developer Tools (F12).
            Switch to the Profiler tab.
            Click the Record circle button.
            Interact with your app (e.g., click a button, open a modal, type in a form).
            Click the Stop recording button.
        
        How to read the charts:
            The Flame Chart:
                Represents the state of your component tree
                width :- shows how long it took to render
                color :- tells you how heavy it was
                    Yellow = slow/heavy
                    Blue = fast/light
                    Gray = did not render at all during this commit
            The Ranked Chart:
                Sorts components flatly by their exact render duration
                components that took the absolute most time appear at the very top
            Why Did This Render?
                Record why each component rendered
    
    2. Programmatic Profiling (<Profiler>)
        <Profiler> component to measure specific parts of your UI tree.

            import React, { Profiler } from 'react';
            
            <Profiler id="SidebarLayout" onRender={onRenderCallback}>
                <Sidebar />
            </Profiler>