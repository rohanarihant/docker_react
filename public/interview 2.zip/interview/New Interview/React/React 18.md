# Heavy Compute Offloading Strategies

    1. Web Workers (Best for CPU-intensive tasks)
        // worker.js
            self.onmessage = (e) => {
            const result = heavyCalculation(e.data);
            self.postMessage(result);
            };

            // Component.jsx
            const worker = useRef(new Worker(new URL('./worker.js', import.meta.url)));

            useEffect(() => {
            worker.current.onmessage = (e) => setResult(e.data);
            }, []);

            const handleHeavyTask = () => {
            worker.current.postMessage(inputData); // Doesn't block UI
            };
    
    2. requestIdleCallback (For non-urgent work)
        function processInChunks(data) {
            let index = 0;
            
            function processChunk(deadline) {
                while (index < data.length && deadline.timeRemaining() > 0) {
                // Process one item
                processItem(data[index]);
                index++;
                }
                
                if (index < data.length) {
                requestIdleCallback(processChunk);
                }
            }
            
            requestIdleCallback(processChunk);
        }
    
    3. Generator Functions + Yielding
        async function* processLargeArray(arr) {
        for (let i = 0; i < arr.length; i++) {
            // Process item
            yield transform(arr[i]);
            
            // Yield control every 100 items
            if (i % 100 === 0) await new Promise(r => setTimeout(r, 0));
        }
        }

        async function process() {
        const generator = processLargeArray(data);
        for await (const item of generator) {
            updateProgress(item);
        }
        }
    4. React 18+ with useTransition
        const [isPending, startTransition] = useTransition();

        // Mark heavy state updates as low priority
        const handleHeavyCompute = () => {
        startTransition(() => {
            setHeavyResult(expensiveComputation(input));
        });
        // UI stays responsive while computation runs
        };

# React Fiber: The Reconciler Rewrite
    Fiber is React's complete rewrite of the reconciliation algorithm.
    It's a reimplementation of the stack as linked list nodes that can be paused, resumed, and prioritized.

    Core Difference: Stack vs. Fiber
    Aspect	                Stack Reconciler (Pre-16)	            Fiber Reconciler (16+)
    Traversal	            Recursive (depth-first)	                Iterative (while loop)
    Interruptibility	    ❌ Once started, can't stop	           ✅ Can pause, resume, abort
    Priority	            ❌ No prioritization	                   ✅ Priority lanes
    Memory	                Call stack grows	                    Fixed-size linked list

    How Fiber Works: The Two-Phase Process
        1. Render Phase (Interruptible)
        2. Commit Phase (Non-interruptible)

    Key Fiber Features
        1. Incremental Rendering
        2. Double Buffering


    Fiber transformed React from a synchronous, recursive, "all-or-nothing" reconciler to an asynchronous, interruptible, priority-aware one. The linked-list structure enables time-slicing, making React suitable for complex UIs with high interaction requirements.

