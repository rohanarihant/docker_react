# React 19 features
    automating state synchronization, eliminating manual rendering optimizations,
    and expanding full-stack architecture primitives

    1. Unified Async Operations (The "Actions" Architecture)
        React 19 replaces manual loading, error,
        and pending state tracking flags with built-in async capabilities called Actions

        Native <form> Actions:
            You can pass your async data handlers directly to the <form> HTML action prop.
            React automatically provides loading states and resets uncontrolled form inputs upon successful mutations
        
        useActionState Hook:
            Manages async data submission flows automatically, returning the form's raw return value,
            a submission wrapper, and an explicit isPending boolean flag.
        
            const [state, formAction, isPending] = useActionState(asyncAction, initialState);

        useFormStatus Hook:
            Reads a parent form's submission progress like a Context consumer.
            This eliminates deep prop-drilling for child submit components.

            import { useFormStatus } from 'react-dom'; // Note: Imported from 'react-dom', not 'react'
              const { pending, data, method, action } = useFormStatus();
              return (
                    <button type="submit" disabled={pending}>
                    {pending ? 'Saving Changes...' : 'Save'}
                    </button>
                );
        useOptimistic Hook:
            Updates the UI immediately during async calls,
            providing instant visual feedback while gracefully rolling back if the final server response fails.

            const [optimisticState, setOptimisticState] = useOptimistic(passthroughState, updateFn);

    2. The New use API
        new use() function allows you to read async resources—like Promises or Context—directly
        inline during runtime rendering

        import { use } from 'react';
        function WeatherWidget({ dataPromise }) {
            // React suspends rendering automatically until this resolution finishes
            const weather = use(dataPromise); 
            return <p>Current Temperature: {weather.temp}°C</p>;
        }

    3. Developer Quality-of-Life Primitives
        Ref as a Standard Prop: can pass ref as props directly no need of ForwardRef
        Smarter Context Provider: You can use <ThemeContext> directly as the provider
                                  instead of calling <ThemeContext.Provider>
        Ref Cleanup Functions: 
            Callback refs can now return an explicit cleanup function, mirroring the behavior of useEffect teardown patterns
    4. Built-in Document Metadata Hoisting:
            Native support for placing <title>, <meta>, and <link> tags anywhere in your layout tree. React detects them and automatically hoists them into the document <head>
    5. Hydration and Server Architecture Stabilities
        Full-Stack Server Components (RSC):
                React Server Components are fully stable.
                They let you run heavy data-fetching components entirely on the server environment
                to strip down client-side bundle weight.
    

