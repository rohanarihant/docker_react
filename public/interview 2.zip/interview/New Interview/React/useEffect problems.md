#   problem occurs if useEffect is not used in correct way?
    When useEffect is implemented incorrectly,
    it introduces distinct runtime bugs that degrade application stability and break the user experience.
    Because useEffect runs asynchronously after the DOM updates, architectural mistakes impact rendering,
    network traffic, and memory allocation.

    1. Infinite Render Loops
        The component renders, executes the effect, triggers a state update, forces a re-render, and runs the effect again

        // ❌ CRASHES APPLICATION: The state change re-triggers the effect instantly
            useEffect(() => {
                setUserData(fetchUser());
            }, [userData]); 

    2. Stale Closures (Outdated State Values)
        JavaScript closures lock in variables from the specific render cycle in which they were created.
        If a variable is read inside an effect but omitted from the dependency array,
        the effect remains blind to subsequent updates.

        The Cause: Providing an empty dependency array [] when the internal effect logic references active state or props
        The Impact: The logic processes stale data. Timers calculate incorrect intervals,
                    events reference old state values, and conditional logic evaluates false positives
    
            // ❌ BUGGY: 'count' inside the interval is permanently locked at 0
                useEffect(() => {
                const id = setInterval(() => {
                    console.log(count); 
                }, 1000);
                return () => clearInterval(id);
                }, []); // ❌ Missing [count] dependency

    3. Cumulative Memory Leaks
        When a useEffect establishes a persistent connection, a global listener, or an asynchronous timer, it claims system resources that must be explicitly relinquished when the component disappears.
        The Cause: Forgetting to return a cleanup function from the effect block.
        The Impact:
            When components mount and unmount repeatedly (such as toggling a modal or switching routes),
            multiple active instances of event listeners, global intervals,
            or open WebSockets accumulate in the background.
            This creates a severe memory leak that slows down the client browser over time.

            // ❌ MEMORY LEAK: Listener is never detached when component unmounts
                useEffect(() => {
                    window.addEventListener('keydown', handleKeyPress);
                }, []); // ❌ No cleanup return statement provided
    
    4. Data Race Conditions
        When asynchronous network fetches are managed inside an unmonitored useEffect,
        rapid user interactions (like fast-typing in an autocomplete search box or clicking tabs in quick succession) trigger multiple network streams simultaneously.

        The Cause:
            Initiating an asynchronous operation without a mechanism to discard stale,
            unresolved promises if a new operation begins.
        The Impact:
            Network responses resolve out of order. A slower, older API request might finish after a newer request, overwriting the user interface with obsolete, mismatched data.
