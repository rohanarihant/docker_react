1. useState - Managing State :- The most basic hook for managing component state.
2. useEffect - Handling Side Effects :- Run code when component renders, updates, or unmounts.
3. useContext - Access Context Values :- Access context values without prop drilling.
4. useReducer - Complex State Logic :- Alternative to useState for complex state transitions.
5. useCallback - Memoize Functions :- Prevent unnecessary re-creation of functions.
6. useMemo - Memoize Values :- Prevent expensive calculations on every render.
    // Expensive calculation function
        function expensiveCalculation(num) {
            console.log('Calculating...');
            for (let i = 0; i < 1000000000; i++) {}
            return num * 2;
        }

    // WITH useMemo - only recalculates when 'number' changes
        const doubled = useMemo(() => {
            return expensiveCalculation(number);
        }, [number]); // Re-run only when number changes

7. useRef - Access DOM Elements & Persist Values :- Access DOM nodes directly or persist values without re-rendering.
    // Focus input on mount
        function TextInputWithFocus() {
            const inputRef = useRef(null);
            
            useEffect(() => {
                // Focus the input when component mounts
                inputRef.current.focus();
            }, []);
            
            return <input ref={inputRef} type="text" />;
        }

    // Store previous value
        function CounterWithPreviousValue() {
            const [count, setCount] = useState(0);
            const prevCountRef = useRef();
            
            useEffect(() => {
                // Store previous count after render
                prevCountRef.current = count;
            }, [count]);
            
            const prevCount = prevCountRef.current;
            
            return (
                <div>
                    <p>Now: {count}, Before: {prevCount}</p>
                    <button onClick={() => setCount(count + 1)}>Increment</button>
                </div>
            );
        }

9. useImperativeHandle - Customize Ref Exposed Values :- Exposing specific methods to parents component
    Control what values are exposed when a parent uses ref.

    useImperativeHandle is a React Hook that allows you to customize the instance value that is exposed when a parent component uses ref to access a child component.

    // Child Component
        import React, { forwardRef, useImperativeHandle, useRef } from 'react';

        const VideoPlayer = forwardRef(({ src, ...props }, ref) => {
        // Internal DOM ref for the actual video element
        const videoRef = useRef(null);

        // Expose specific methods to the parent
        useImperativeHandle(ref, () => ({
            // Parent can call playerRef.current.play()
            play: () => {
            videoRef.current.play();
            },
            // Parent can call playerRef.current.pause()
            pause: () => {
            videoRef.current.pause();
            },
            // Parent can call playerRef.current.seekTo(30)
            seekTo: (time) => {
            videoRef.current.currentTime = time;
            },
            // Expose a read-only property
            get currentTime() {
            return videoRef.current.currentTime;
            }
        }), []); // Empty deps = methods never change
        return <video ref={videoRef} src={src} {...props} />;
        });
        export default VideoPlayer;

    // Parent Component
        import React, { useRef } from 'react';
        import VideoPlayer from './VideoPlayer';

        function App() {
        const playerRef = useRef(null);

        const handlePlay = () => {
            // Calling the child's exposed method!
            playerRef.current.play();
        };

        const handlePause = () => {
            playerRef.current.pause();
        };

        const handleSeek = () => {
            playerRef.current.seekTo(120); // Jump to 2 minutes
        };

        return (
            <div>
            <VideoPlayer ref={playerRef} src="/video.mp4" width="600" />
            <button onClick={handlePlay}>Play</button>
            <button onClick={handlePause}>Pause</button>
            <button onClick={handleSeek}>Jump to 2:00</button>
            </div>
        );
        }

10. useLayoutEffect (The Synchronous Effect)
    What it does: Identical to useEffect, but it fires synchronously after all DOM mutations but before the browser paints the screen.

    Use Case: Measuring the DOM (e.g., getting an element's offsetHeight) or synchronously applying styles to prevent visual flashes.

    The Rule: Avoid it unless absolutely necessary. It blocks the browser's paint, which can damage your FCP and LCP. 99% of the time, useEffect is what you actually want.


11. useDeferredValue
    useDeferredValue: Defers the update of a value.
    allows you to defer updating a non-urgent part of your UI, keeping the critical parts completely responsive.
    It is designed to solve performance issues where a user input (like typing in a search bar) triggers a heavy,
    laggy UI update (like filtering a massive list of 1,000 items).
    Instead of lagging the entire page, useDeferredValue lets React process the heavy computation in the background.

    const [searchQuery, setSearchQuery] = useState('');
    // 💡 Pass the rapid state value into useDeferredValue
    const deferredSearchQuery = useDeferredValue(searchQuery);

    // Check if the current state doesn't match the deferred background state yet
    const isStale = searchQuery !== deferredSearchQuery;

12. useTransition: Wraps a state update to mark it as non-urgent.

    Use Case: An input search bar. When the user types, the input field should update instantly. The massive filtered list can update later, in the background, without freezing the keyboard input.

    const [searchTerm, setSearchTerm] = useState('');
    const [isPending, startTransition] = useTransition();

    const handleChange = (e) => {
    const value = e.target.value;
    setSearchTerm(value); // Urgent (updates the input)
    
    startTransition(() => {
        setFilteredData(filterData(value)); // Non-urgent (can be slow)
    });
    };