# The 3 Core Principles

# Principle 1: Single Source of Truth
    The entire global state of your application is stored inside a single JavaScript object tree within a single store.

# Principle 2: State is Read-Only
    The only way to change the state is by emitting an action—an object describing what happened.

# Principle 3: Changes are Made with Pure Functions (Reducers)
    To specify how the state tree is transformed by actions, you write pure reducer functions.
