# how load balancer will manage millions of requests?
    It distributes the incoming flood of users across a massive fleet of backend servers,
    ensuring no single server becomes overwhelmed

    🛠️ The Foundation: Massive Hardware and Clusters
    
    🧠 The Core Process: How Distribution Works
        1. Health Checks:
            It constantly checks on your backend servers (the ones running your React app's API).
            If a server is slow, overloaded, or unresponsive, the load balancer stops sending it new requests
        2. Smart Algorithm Selection:
            It uses an algorithm to decide which healthy server should get the request.

*            Round Robin: Simply cycles through the list of servers in order.

*            Least Connections: Sends the request to the server with the fewest active connections.

*            Consistent Hashing:
                A more advanced method for stateful applications.
                It uses a hash of the request (e.g., user ID) to route a specific user to the same server every time.
                This is crucial for session persistence and caching, as it minimizes "cache churn"
                by ensuring requests from the same user are always mapped to the same pod
        
        3. Forwarding:
            The request is then forwarded to the chosen backend server via a private,
            high-speed network, and the server's response is sent back to the user
