# Observable

    In React, "observable" usually refers to integrating reactive programming (especially with RxJS) into your components, using it for state management. This is done through custom React hooks that connect observable data streams to your UI.

    🧩 The Role of Hooks: useObservable
        The primary way to use observables in functional React components is through a useObservable hook.
        This hook subscribes to an observable stream and automatically re-renders your component when new values are emitted

        How it works:
            The hook manages the subscription lifecycle. It subscribes when the component mounts,
            updates the component's state with each new value from the observable,
            and unsubscribes when the component unmounts to prevent memory leaks
        Simple Example:
            A counter that updates every second can be created with a single hook and an RxJS interval observable
            
            import { useObservable } from 'use-observable-hooks';
            import { interval } from 'rxjs';

            function Timer() {
            // Subscribes to an observable that emits a number every second
            const [count, error] = useObservable(interval(1000));
            return <div>Count: {count ?? 'Loading...'}</div>;
            }

    🔧 RxJS: The Most Common Approach
        RxJS is the standard library for reactive programming in JavaScript,
        and it's often the source of observables in React

        From DOM Events: Use fromEvent to create an observable from events like window resizing
        Custom Sources: Use new Observable() to create custom streams, such as one that emits a user's geolocation over time
        

