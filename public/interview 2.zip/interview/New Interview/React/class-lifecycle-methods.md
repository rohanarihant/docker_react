1. The Mounting Phase (Birth)
    constructor(props)
        Purpose: Initializes local state and binds event handler methods.
        Rule: Always call super(props) first, or this.props will be undefined. Do not introduce side effects (like API calls) here
    
    static getDerivedStateFromProps(props, state)
        Purpose: A rare lifecycle method used when state depends on changes to props over time.
        Rule: It is a static method, meaning it has no access to this.
              It must return an object to update the state, or null.
    
    render()
        Purpose: The only required method in a class component. It examines this.props and this.state and returns JSX.
        Rule: Must be pure. It should not modify component state or interact with the browser DOM.

    componentDidMount()
        Purpose: Runs immediately after the component is inserted into the DOM tree.
        Best Used For: Fetching data from remote APIs, setting up subscriptions,
                        or initializing DOM-dependent libraries (e.g., charts).
    
2. The Updating Phase (Growth)
    An update can be triggered by changes to props, changes to state, or calling forceUpdate().

    static getDerivedStateFromProps(props, state)
        Identical to the mounting phase; runs right before rendering during an update.
    
    shouldComponentUpdate(nextProps, nextState)
        Purpose: Performance optimization.
                 It lets you tell React to skip rendering if the data hasn't significantly changed.
        Rule: Must return a boolean (true or false).
                Returning false prevents render() and subsequent lifecycles from firing.
    render()
        Executes again to recalculate the virtual DOM tree based on changes.
    getSnapshotBeforeUpdate(prevProps, prevState)
        Purpose: Captures DOM information (like scroll position) right before the changes are committed to the actual DOM.
        Rule: Any value returned by this method is passed as the third argument (snapshot) to componentDidUpdate.
    componentDidUpdate(prevProps, prevState, snapshot)
        Purpose: Runs immediately after the DOM update is flushed.
        Best Used For: Performing DOM operations or making network requests based on a comparison of old vs.
                        new props (e.g., re-fetching data when a user ID changes).
        Rule: If you call this.setState() here, it must be wrapped in a conditional statement

3. The Unmounting Phase (Death)
    This method handles cleanup before a component leaves the application.

    componentWillUnmount()
        Purpose: Runs immediately before a component is destroyed and removed from the DOM.
        Best Used For: Cleaning up subscriptions, invalidating timers (clearInterval),
                    and canceling network requests to prevent memory leaks.
