# UseDebounce

function useDebounce(value, delay=300){
    const [debouncedValue, setDebouncedValue] = useState('');

    useEffect(() => {
        let timer = setTimeout(() => {
            setDebouncedValue(value);
        },delay)
        return () => clearTimeout(timer);
    },[value]);
    return debouncedValue;
}

const debounce = useDebounce(searchQuery, 300);


# usePrevious
function usePrevious(value){
    let ref = useRef();
    useEffect(() => {
        ref.current = value;
    },value);
    return ref.current;
}

# Implement a useFetch hook with loading/error states

function useFetch(url){
    const [isLoading, setIsLoading] = useState(false);
    const [data, setData] = useState(null);
    const [error, setError] = useState(null);
    
    useEffect(() => {
        let isMount = false;
        setIsLoading(true);
        fetch(url).then(res => {
            if(!res.ok) throw new Error(`HTTP ${res.status}`)
            res.json();
        }).then((response) => {
            if(!isMount){
                setData(response);
                setIsLoading(false);
            }
        }).catch((error) => {
            if(!isMount){
                setError(error);
                setIsLoading(false);
            }
        })
        return () => { isMount = true }
    },[url]);
    return { loading, error, data };
}

# Infinite scroll

function useInfiniteScroll(loadMore){
    let observeRef = useRef();
    const lastItemRef = useCallback((node) => {
        if(observeRef.current) observeRef.current.disconnect();
        observeRef.current = new IntersectionObserver(entries => {
            if(entries[0].isIntersecting) loadMore();
        })
        if(node) observeRef.current.observe();
    },[loadMore])
    return lastItemRef;
}

function List({ items, loadMore}){
    const lastItemRef = useInfiniteScroll(loadMore);
    return items.map((item, i) => (
        <div ref={i === items.length-1 ? lastItemRef : null}>{item.text}</div>
    ))
}

# build a controlled accordion (open one panel at a time)
import React, { useState } from 'react';

const faqData = [
  { title: "What is React?", content: "React is a JS UI library." },
  { title: "What is State?", content: "State is component memory." },
  {
    title: "What is a Hook?",
    content: "Hooks let you use state in functions.",
  },
];

const Accordion = () => {
  const [openIndex, setOpenIndex] = useState(null);

  const toggleAccordion = (index) => {
    setOpenIndex(openIndex === index ? null : index);
  };

  return (
    <div className="accordion-container">
      {faqData.map((item, index) => (
        <div key={index} className="accordion-item">
          <button
            className="accordion-header"
            onClick={() => toggleAccordion(index)}
          >
            <span>{item.title}</span>
            <span className="accordion-icon">
              {openIndex === index ? '−' : '+'}
            </span>
          </button>
          
          {openIndex === index && (
            <div className="accordion-content">
              {item.content}
            </div>
          )}
        </div>
      ))}
    </div>
  );
};

export default Accordion;

# useLocalStorage

function useLocalStorage(key, initialValue){
    const [value, setValue] = useState(() => {
        try{
            const storage = localStorage.getItem(key);
            return storage ? JSON.parse(storage) : initialValue;
        }catch(error){
            return initialValue;
        }
    })

    useEffect(() => {
        
    })

}