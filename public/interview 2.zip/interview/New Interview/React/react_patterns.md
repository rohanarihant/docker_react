# Design Patterns

# The Container & Presentational Pattern (The Classic)
    Container Component: Handles data fetching, state management, and business logic. Tells the presentational component what to display via props.

    Presentational Component: Pure UI. Receives data and callbacks via props. Contains zero logic—just JSX and styles.

# The Compound Components Pattern (The Flexible API)
    What it is: A pattern where a parent component shares implicit state with its children components, allowing you to build highly flexible and declarative UIs. Think of <select> and <option> in HTML.

    When to use: Building reusable UI libraries (modals, tabs, dropdowns, accordions) where the developer using your component needs complete control over the layout.

    The Mechanism: Uses React.cloneElement and React.Children.map (or better, Context API) to pass state down to children
        <Tabs>
            <TabList>
                <Tab>Tab 1</Tab>
                <Tab>Tab 2</Tab>
            </TabList>
            <TabPanels>
                <TabPanel>Content 1</TabPanel>
                <TabPanel>Content 2</TabPanel>
            </TabPanels>
        </Tabs>
        
        With the Compound Components Pattern,
                you break it into sub-components, giving the consumer complete structural freedom over the layout:
    //  The Compound Component Way
        <Dropdown>
        <Dropdown.Trigger>Click Me</Dropdown.Trigger>
        <Dropdown.Menu>
            <Dropdown.Item onClick={handleProf}>
            <ProfileIcon /> Profile
            </Dropdown.Item>
            <Dropdown.Divider />
            <Dropdown.Item>Logout</Dropdown.Item>
        </Dropdown.Menu>
        </Dropdown>

# The HOC (Higher-Order Component) Pattern (The Wrapper)
    What it is: A function that takes a component and returns a new enhanced component with extra props or behavior.

    When to use: Cross-cutting concerns like authentication, logging, or injecting a theme—where you need to reuse logic across many unrelated components.

    The Catch: HOCs can lead to "Wrapper Hell" (a deeply nested tree of <div>s). Hooks have largely replaced HOCs for logic reuse, but HOCs are still excellent for rendering hijacking or props manipulation.

    function withAuth(Component) {
    return function AuthenticatedComponent(props) {
        const user = useContext(AuthContext);
        if (!user) return <Navigate to="/login" />;
        return <Component {...props} user={user} />;
    };
    }

    // Usage
    const ProtectedProfile = withAuth(Profile);

# The Render Props Pattern (The Inversion of Control)
    What it is: A pattern where a component accepts a function as a prop (usually called render or children) and calls that function to determine what to render, passing its internal state to it.

    When to use: When you need to share logic but the consuming component needs to control exactly how the UI is rendered (e.g., a MouseTracker that shares X/Y coordinates).

    The Modern Shift: Render Props are largely obsolete now. Custom Hooks (like useMousePosition) achieve the exact same logic-sharing without nesting functions inside JSX, making the code far more readable.

# The Provider Pattern (The Dependency Injector)
    What it is: Uses React's Context API to make a value available to all components in a subtree without prop drilling.

    When to use: Global state (themes, user auth, localization). This is the foundational pattern for Redux, React Router, and Styled-Components.

    The Pitfall: Everything consuming the Context re-renders when the value changes. Use useMemo and useCallback on the provider's value to mitigate this.

# The State Reducer Pattern (The Ultimate Flexibility)
    What it is: Used heavily in useReducer and Redux. Instead of the component handling state changes internally, it exposes a reducer prop, allowing the user of the component to intercept and modify state updates before they happen.

    When to use: Building complex, highly customizable UI libraries (like a dropdown where clicking an item can trigger custom logic or validation before the state updates).

    Example: useReducer itself is the implementation of this pattern.

# The Controller/View Pattern (The State Machine)
    What it is: A modern evolution of Container/Presentational. The "Controller" manages all the logic, state, and side-effects (using useReducer or useState). The "View" is a pure presentation component that receives everything as props. Often seen in combination with the State Machine (XState) pattern.

# Category 3: Performance & Optimization Patterns

# The Memoization Pattern (React.memo, useMemo, useCallback)
    What it is: Preventing unnecessary re-renders by caching components, values, and functions.

    React.memo: A HOC that memoizes the entire component. It only re-renders if its props change.

    useMemo: Memoizes expensive calculations.

    useCallback: Memoizes function definitions to prevent child components from re-rendering unnecessarily.

    The Rule: Do not over-optimize. Memoization has a memory cost. Use it only for large components or heavy computations.

# The Lazy Loading Pattern (Code Splitting)
    What it is: Loading components only when they are needed (e.g., when a user navigates to a route or clicks a modal).
    Mechanism: React.lazy() + Suspense.
    Impact: Dramatically improves FCP and LCP by reducing the initial JavaScript bundle size.

    const Dashboard = React.lazy(() => import('./Dashboard'));

    function App() {
    return (
        <Suspense fallback={<Spinner />}>
        <Dashboard />
        </Suspense>
    );
    }

# Category 4: Architectural Patterns
# The Atomic Design Pattern (UI Organization)
    What it is: A methodology for creating design systems by breaking components into five distinct levels:

    Atoms: Smallest building blocks (e.g., <Button>, <Input>, <Label>).
    Molecules: Groups of atoms (e.g., <SearchInput> = <Input> + <Button>).
    Organisms: Complex UI sections (e.g., <Header> = <Logo> + <Nav> + <SearchInput>).
    Templates: Page-level layouts (e.g., <ProductPageLayout> = <Header> + <Sidebar> + <MainContent>).
    Pages: The final view (e.g., /products renders <ProductPageLayout> with data).
    When to use: Large teams and design systems. It enforces consistency and reusability.

# The Feature-Sliced Pattern (File Structure)
    What it is: Organizing your codebase by features (e.g., users/, products/, cart/) rather than by file type (e.g., components/, utils/, hooks/).

    The Benefit: High cohesion. Everything related to "Products" (components, hooks, API calls, types) lives in one folder. Makes it easy to delete or refactor a feature without breaking unrelated parts of the app.

    src/
    ├── features/
    │   ├── auth/
    │   │   ├── components/ (LoginForm, SignupForm)
    │   │   ├── hooks/ (useAuth)
    │   │   └── api/ (authApi)
    │   └── cart/
    │       ├── components/ (CartItem, Checkout)
    │       └── hooks/ (useCart)
    ├── shared/ (Reusable atoms, utils, UI kit)
    └── app/ (App layout, routing, global providers)