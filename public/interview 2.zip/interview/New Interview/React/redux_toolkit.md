# What is Redux Toolkit?
    Redux Toolkit (RTK) is the official, opinionated, batteries-included toolset for efficient Redux development.
    It was created to solve the three biggest complaints developers had with "vanilla" Redux:
    Too much boilerplate: Writing action creators, action types, and reducers in separate files was tedious.
    Mutable logic errors: Manually writing { ...state, items: [...state.items, payload] } was error-prone and easy to mess up.
    Complex setup: Configuring the store with middleware (like Thunk for async actions) required deep Redux knowledge.
    RTK wraps around the core Redux library and provides utilities that drastically simplify all of this.

# The Core Building Blocks of RTK
RTK introduces four primary functions you must master:

configureStore(): Sets up the Redux store with good defaults (automatically combines reducers, adds the Redux DevTools extension, and includes default middleware like redux-thunk).

createSlice(): The heart of RTK. Automatically generates action creators and action types for you, based on the reducer functions you provide. It allows you to write "mutating" logic safely, thanks to the Immer library.

createAsyncThunk(): Handles asynchronous logic (API calls). It automatically dispatches three lifecycle actions: pending, fulfilled, and rejected.

createSelector(): Creates memoized selector functions (derived data) to prevent unnecessary re-renders.
