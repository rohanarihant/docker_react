# All promises types and their polyfills


1. Promise.all
    handle multiple apis together
    array of promises

    p1 -> 3sec, p2 -> 1sec, p3 -> 2sec

    if all apis success (o/p will be array of result)
    final will return the response after all promises got resolved (3sec)

    if any one of the promise got failed
    it will return the error (1sec if p2 got failed)

    Polyfill :- 
        const p1 = new Promise((resolve, reject) => {
            setTimeout(() => {
                reject("P1 reject")
            },1000);
        })
        const p2 = new Promise((resolve, reject) => {
            setTimeout(() => {
                resolve("P2 resolved")
            },2000);
        })
        const p3 = new Promise((resolve, reject) => {
            setTimeout(() => {
                resolve("P3 resolved")
            },3000);
        })
        const myPromise = function(taskList){
            let promiseResponse = [];
            let taskCounter = 0;
            return new Promise((resolve, reject) => {
                taskList.map((promise, i) => {
                    promise.then((data) => {
                        promiseResponse[i] = data;
                        taskCounter++;
                        if(taskCounter === taskList.length){
                            resolve(promiseResponse);
                        }
                    }).catch(error => {
                        reject(error);
                    })
                })
            })
        }
       myPromise([p1,p2,p3]).then((data) => { console.log(data)});




2. Promise.allSettled([p1,p2,p3])

    it will wait for all promises to settled 
    and if any of them fails then it will return the error after all settled
    waits for ALL of them to complete (either resolve OR reject), then returns an array of objects describing each promise's outcome

    all vs allSettled
    will return if any of the api fail
    will return if any of the api fail then will wait for all promises to get setteled then return the failed msg

const promiseAllSettled = (promises) => 
    Promise.all(promises.map((p) => 
        Promise.resolve(p)  // Ensure non-promises are wrapped
            .then(data => ({ status: "fulfilled", value: data }))  // Fixed property names
            .catch(error => ({ status: "rejected", reason: error }))  // Fixed status name
    ));

// Test with your promises
const p1 = new Promise((resolve, reject) => {
    setTimeout(() => reject("p1 rejected"), 1000);
});

const p2 = new Promise((resolve, reject) => {
    setTimeout(() => reject("p2 rejected"), 2000);
});

const p3 = new Promise((resolve, reject) => {
    setTimeout(() => reject("p3 rejected"), 3000);
});

// Using the fixed function
promiseAllSettled([p1, p2, p3])
    .then(results => console.log(results))
    .catch(err => console.error('Unexpected error:', err));

3. Promise.race([p1,p2,p3])

    it will be a race amoung all promises 
    who will win the race their response/error will be returned
    if p2 resolved/rejected first (1sec) then it will return the result of it

        const p1 = new Promise((resolve, reject) => {
            setTimeout(() => {
                reject("P1 reject")
            },2400);
        })
        const p2 = new Promise((resolve, reject) => {
            setTimeout(() => {
                resolve("P2 resolve")
            },2000);
        })
        const p3 = new Promise((resolve, reject) => {
            setTimeout(() => {
                reject("P3 reject")
            },3000);
        })

    const newPromiseRace = (taskList) => {
        let result = [];
        let counter = 0;
        return new Promise((resolve, reject) => {
            taskList.map((promise, i) => {
                promise.then((data) => {
                    resolve(data);
                }).catch((error) => {
                    reject(error);
                })
            })
        })
    }

    newPromiseRace([p1,p2,p3]).then((data) => console.log(data)).catch((error) => console.log(error))


4. Promise.any([p1,p2,p3])

    it will wait for the first fulfilled(success) promise
    if p2 resolved first then it will return it
    if p2 failed first then it will ignore this and then wait for another promise to get resolved then return the result

    if everything fails then it will return the aggregated error
    it will be an array of all 3 errors


    const p1 = new Promise((resolve, reject) => {
            setTimeout(() => {
                reject("P1 reject")
            },1000);
        })
        const p2 = new Promise((resolve, reject) => {
            setTimeout(() => {
                reject("P2 reject")
            },2000);
        })
        const p3 = new Promise((resolve, reject) => {
            setTimeout(() => {
                reject("P3 reject")
            },3000);
        })
        const myPromise = function(taskList){
            let promiseResponse = [];
            let taskCounter = 0;
            return new Promise((resolve, reject) => {
                taskList.map((promise, i) => {
                    promise.then((data) => {
                        resolve(data);
                    }).catch(error => {
                        promiseResponse[i] = error;
                        taskCounter++;
                        if(taskCounter === taskList.length){
                            reject(promiseResponse);
                        }
                    })
                })
            })
        }
       myPromise([p1,p2,p3]).then((data) => { console.log(data)}).catch(err => console.log(err));



5. Promise.finally 
    schedule a function, the cb func, to be called when promise settled
    immediately return an equivelent promise object, allowing you to chain the other promise object.

    function checkMail = () => {
        return new Promise((resolve, reject) => {
            if(Math.random() > 0.5){
                resolve("Mail received);
            }else{
                reject(new Error("Mail failed"));
            }
        })
    }

    checkMail().then((mail) => console.log(mail)).catch(error => console.log(error)).finally(() => console.log("fianlly called"))



6. custom Promise











    