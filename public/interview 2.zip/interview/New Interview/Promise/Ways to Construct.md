#   🏗️ Basic Promise Construction with Chaining
    1. Simple Promise with Chain
        // Creating a promise
const myPromise = new Promise((resolve, reject) => {
  // Asynchronous operation
  setTimeout(() => {
    const success = true;
    if (success) {
      resolve({ data: 'Initial data', timestamp: Date.now() });
    } else {
      reject(new Error('Something went wrong!'));
    }
  }, 1000);
});

// Chaining .then() handlers
myPromise
  .then((result) => {
    console.log('Step 1:', result.data);
    // Return a value for the next .then()
    return result.data.toUpperCase();
  })
  .then((uppercaseData) => {
    console.log('Step 2:', uppercaseData);
    // Return a new promise
    return new Promise((resolve) => {
      setTimeout(() => {
        resolve(`Processed: ${uppercaseData}`);
      }, 500);
    });
  })
  .then((processedData) => {
    console.log('Step 3:', processedData);
    return { final: processedData, status: 'completed' };
  })
  .then((finalResult) => {
    console.log('Final Result:', finalResult);
  })
  .catch((error) => {
    console.error('Error:', error.message);
  })
  .finally(() => {
    console.log('Promise chain completed');
  });

/* Output:
Step 1: Initial data
Step 2: INITIAL DATA
Step 3: Processed: INITIAL DATA
Final Result: { final: 'Processed: INITIAL DATA', status: 'completed' }
Promise chain completed
*/


#   🛠️ Different Ways to Construct Promises
    1️⃣ The Promise Constructor (new Promise())
        const promise = new Promise((resolve, reject) => {
            // Asynchronous operation
            if (/* success */) {
                resolve(value);
            } else {
                reject(error);
            }
        });
    
    2️⃣ Promise.resolve() - Immediate Resolution
        Creates a resolved promise with a given value.

            // Basic usage
            const promise1 = Promise.resolve('Immediate value');
            promise1.then(value => console.log(value)); // 'Immediate value'

            // With different value types
            Promise.resolve(42)
            .then(num => console.log('Number:', num));
    
    3️⃣ Promise.reject() - Immediate Rejection
        Creates a rejected promise with a given error.

            // Basic usage
            const promise1 = Promise.reject(new Error('Immediate error'));
            promise1
            .then(value => console.log(value))
            .catch(error => console.error('Caught:', error.message));

            // With different error types
            Promise.reject('Simple string error')
            .catch(error => console.error('String error:', error));
    
    4️⃣ Async/Await Functions
        Async functions always return a Promise. This is syntactic sugar over promises.

            // Basic async function
            async function getData() {
            return 'Data from async function';
            }

            getData().then(result => console.log(result)); // 'Data from async function'

            // Async with await
            async function fetchUserData() {
            const user = await new Promise((resolve) => {
                setTimeout(() => resolve({ id: 1, name: 'Alice' }), 1000);
            });
            
            const posts = await new Promise((resolve) => {
                setTimeout(() => resolve(['Post 1', 'Post 2']), 1000);
            });
            
            return { user, posts };
            }

            fetchUserData()
            .then(data => console.log('Fetched:', data))
            .catch(error => console.error('Error:', error));

    