# What is a Namespace?
    organize code into logical groups
    preventing naming collisions by wrapping variables, functions, classes, and interfaces inside a container

// Basic namespace declaration
namespace MyNamespace {
    // NOT accessible outside namespace
        const privateVar = 'secret';
        function privateFunc() {
            return 'hidden';
        }

    export const name = 'John';
    export function greet(): string {
        return `Hello, ${name}`;
    }
    export class Person {
        constructor(public name: string) {}
    }
}

// Access namespace members
console.log(MyNamespace.name);      // 'John'
console.log(MyNamespace.greet());   // 'Hello, John'
const person = new MyNamespace.Person('Alice');

# Generics :- Type reusability & flexibility
    Generics allow you to create reusable components that work with multiple types while maintaining type safety.
    They act as placeholders for types.

        // Basic generic function
            function identity<T>(value: T): T {
                return value;
            }

            identity<string>("hello");     // T is string
            identity<number>(42);          // T is number
            identity("auto");              // TypeScript infers T

            // Generic interface
            interface Box<T> {
                content: T;
            }

# Unions :- allow a value to be one of several types
    Unions allow a value to be one of several types, using the pipe (|) symbol.

        // Basic union types
            let value: string | number;
            value = "hello";    // OK
            value = 42;         // OK
            // value = true;    // Error: boolean not allowed

        // Union in function parameters
            function format(input: string | number): string {
                return `Formatted: ${input}`;
            }

        // Union with custom types
            type Status = "pending" | "success" | "error";
            type User = { name: string } | { id: number };

        // Union with arrays
            let mixedArray: (string | number)[] = [1, "two", 3, "four"];

# Narrowing :- Type refinement for safety
    Narrowing is the process of refining a broad type (like a union) to a more specific type within a code block.
        means put a check and return if type confirmed

        // typeof narrowing
            function process(value: string | number) {
                if (typeof value === "string") {
                    // Here TypeScript knows value is string
                    return value.toUpperCase();
                } else {
                    // Here value is number
                    return value.toFixed(2);
                }
            }

        // instanceof narrowing
            class Dog { bark() { return "woof"; } }
            class Cat { meow() { return "meow"; } }

            function makeSound(animal: Dog | Cat) {
                if (animal instanceof Dog) {
                    return animal.bark();  // animal is Dog
                } else {
                    return animal.meow();  // animal is Cat
                }
            }

        // in operator narrowing
            type Fish = { swim: () => void };
            type Bird = { fly: () => void };

            function move(animal: Fish | Bird) {
                if ("swim" in animal) {
                    animal.swim();  // animal is Fish
                } else {
                    animal.fly();   // animal is Bird
                }
            }

            // Truthiness narrowing
            function printLength(str: string | null) {
                if (str) {
                    console.log(str.length);  // str is string (not null)
                }
            }

        // Discriminated unions (type narrowing with a common property)
            type Circle = { kind: "circle"; radius: number };
            type Square = { kind: "square"; side: number };

            function area(shape: Circle | Square) {
                switch (shape.kind) {
                    case "circle":
                        return Math.PI * shape.radius ** 2;  // shape is Circle
                    case "square":
                        return shape.side ** 2;              // shape is Square
                }
            }

# Utility Types
    Built-in types that transform existing types into new ones.

    // Partial - Makes all properties optional
        interface User {
            id: number;
            name: string;
            email: string;
            age: number;
        }

        function updateUser(id: number, updates: Partial<User>): User {
            // Partial allows partial updates
            return { id, name: "default", email: "default", age: 0, ...updates };
        }
        updateUser(1, { name: "John" }); // ✅ Only name provided

    // Required - Makes all properties required
        type CompleteUser = Required<Partial<User>>; // Back to full requirement

    // Readonly - Makes properties immutable
        type ReadonlyUser = Readonly<User>;
        const user: ReadonlyUser = { id: 1, name: "John", email: "john@example.com", age: 30 };
        // user.name = "Jane"; // ❌ Error: Cannot assign to readonly property

    // Pick - Select specific properties
        type UserPreview = Pick<User, "id" | "name">;
        const preview: UserPreview = { id: 1, name: "John" };

    // Omit - Exclude specific properties
        type UserWithoutEmail = Omit<User, "email">;
        const userWithoutEmail: UserWithoutEmail = { id: 1, name: "John", age: 30 };

    // Record - Create type with specific keys and values
        type Role = "admin" | "user" | "guest";
        type RolePermissions = Record<Role, string[]>;
        const permissions: RolePermissions = {
            admin: ["read", "write", "delete"],
            user: ["read", "write"],
            guest: ["read"]
        };

    // Exclude & Extract - Filter union types
        type Status = "success" | "error" | "pending" | "loading";
        type NonLoadingStatus = Exclude<Status, "loading">; // "success" | "error" | "pending"
        type LoadingOrPending = Extract<Status, "loading" | "pending">; // "loading" | "pending"

    // ReturnType - Get return type of a function
        function fetchData(): Promise<{ id: number; name: string }> {
            return Promise.resolve({ id: 1, name: "John" });
        }
        type FetchDataReturn = ReturnType<typeof fetchData>; // Promise<{ id: number; name: string }>

    // Parameters - Get parameter types as tuple
        type FetchParams = Parameters<typeof fetchData>; // [] (empty tuple)

    // Awaited - Unwrap Promise type
        type Data = Awaited<FetchDataReturn>; // { id: number; name: string }

# tuple
    A tuple is a specialized array type in TypeScript with two unique characteristics:
    the exact number of elements is fixed, and the data type of each element at each specific index is known in advance.

        // Declaring a tuple that must contain a string followed by a number
            let employee: [string, number];

            // Correct Initialization
            employee = ["John Doe", 30]; 

            // Error: Type mismatch at index 0 and 1
            employee = [30, "John Doe"];

# tsconfig.json configures the TypeScript compiler
    {
        "compilerOptions": {
            "target": "ES2020",
            "module": "commonjs",
            "strict": true,
            "outDir": "./dist",
            "rootDir": "./src",
            "paths": { "@/*": ["src/*"] }
            }
    }

# What is `strictNullChecks` and why does it matter?
    With strictNullChecks enabled, `null` and `undefined` are not assignable to other types.
    This eliminates a huge class of runtime errors like 'Cannot read property of null'.

    // strictNullChecks: false
    let name: string = null; // allowed

    // strictNullChecks: true
    let name: string = null; // Error!
    let name: string | null = null; // must declare intent

# How do you define optional and readonly properties?
    Use `?` for optional properties and `readonly` keyword to prevent reassignment after initialization.

    interface Config {
        readonly apiUrl: string; // cannot be changed
        timeout?: number; // may be undefined
    }
    const cfg: Config = { apiUrl: 'https://api.example.com' };
    cfg.apiUrl = 'other'; // Error: readonly

# What are enums in TypeScript?
    Enums define a set of named constants.
    Numeric enums auto-increment;
    string enums require explicit values.
    `const enum` is inlined at compile time for zero runtime cost.

    enum Direction { Up, Down, Left, Right } // 0,1,2,3 enum
    Status { Active = 'ACTIVE', Inactive = 'INACTIVE' }
    const enum Color { Red, Green, Blue } // inlined, no JS object emitted

# Explain Union and Intersection types.
    Union (`|`): a value can be one of several types.
    Intersection (`&`): a value must satisfy all types simultaneously.

    type StringOrNum = string | number;
    type Admin = User & { adminLevel: number };
    // Admin must have all User properties PLUS adminLevel

# What are generics and why are they useful?
    Generics enable writing reusable, type-safe components that work over a variety of types.
    They capture the type at the call site, preserving type information throughout.
        function identity(arg: T): T {
            return arg; 
        }
        const n = identity(42); // T = number
        const s = identity('hello'); // T inferred as string
        function first(arr: T[]): T | undefined { return arr[0]; }

# What are type guards? Name the common patterns.
    Type guards narrow types within a conditional block.
    Patterns: typeof, instanceof, `in` operator, equality checks, and user-defined type predicates (is).

    function process(val: string | number) {
        if (typeof val === 'string')
            val.toUpperCase(); //string
        else val.toFixed(2); // number
    }
    function isUser(obj: any): obj is User {
        return 'name' in obj && 'email' in obj;
    }

# Explain the keyof and typeof operators.
    `keyof` produces a union of an object type's keys.
    `typeof` (in a type position) extracts the TypeScript type of a value.
        interface User { id: number; name: string; }
        type UserKeys = keyof User; // 'id' | 'name'
        const config = { timeout: 3000, retries: 3 };
        type ConfigType = typeof config; // { timeout: number; retries: number }

# What are mapped types?
    Mapped types iterate over keys of a type to produce a new type.
    They're the foundation of utility types like Partial, Required, Readonly, and Record.
        type Partial = { [K in keyof T]?: T[K] };
        type Readonly = { readonly [K in keyof T]: T[K] };
        type Nullable = { [K in keyof T]: T[K] | null };

# What are conditional types?
    Conditional types select a type based on a condition: `T extends U ? X : Y`.
    They enable powerful type-level logic, especially with the `infer` keyword.
        type NonNullable = T extends null | undefined ? never : T;
        type ReturnType = T extends (...args: any[]) => infer R ? R : never;
        type Flatten = T extends Array ? Item : T;

# Explain template literal types.
    Template literal types compose string literal types, producing new string union types at the type level
    — mirroring JS template literals.
        type EventName = 'click' | 'focus' | 'blur';
        type Handler = `on${Capitalize}`; // 'onClick' | 'onFocus' | 'onBlur'
        type Route = `/${string}`; // any string starting with

# What are the built-in utility types you use most?
    Key utility types: Partial, Required, Readonly, Pick, Omit, Record, Exclude,
    Extract, NonNullable, ReturnType, Parameters, InstanceType, Awaited.
        type UserPreview = Pick;
        type UserWithoutId = Omit;
        type Cache = Record;
        type AsyncResult = Awaited>; // User

# What is declaration merging?
    compiler combines two or more separate declarations with the same name into a single definition.
        interface User {
            name: string;
        }

        interface User {
            age: number;
        }

        // The final User interface is equivalent to:
        // interface User {
        //   name: string;
        //   age: number;
        // }

    Namespaces
        namespace Animals {
            export class Cat {}
        }
        namespace Animals {
            export class Dog {}
        }
        // Merged result: Animals.Cat and Animals.Dog both exist



# What is the `infer` keyword and how does it work?
    `infer` introduces a type variable within a `extends` clause of a conditional type,
    tool that you place inside the extends clause of a conditional type to declare a temporary type variable
        type MyConditional<T> = T extends SomePattern<infer R> ? R : never;
            If T matches SomePattern<...>, TypeScript will figure out what the actual type is at that spot,
            assign it to R, and make R available to use.
        type ElementType<T> = T extends (infer U)[] ? U : never;

# How does TypeScript handle variance (covariance/contravariance)?
    Function parameters are contravariant (wider types safe), return types are covariant (narrower types safe).
    TypeScript 4.7+ introduced variance annotations (`in`, `out`) for explicit control in generic types.
        type Producer = () => T; // covariant type Consumer = (val: T) => void; // contravariant //
        A Dog[] is assignable to Animal[] (covariant arrays) // But (Animal => void) is assignable
        to (Dog => void) (contravariant fns)

# What are discriminated unions and how do you use them?
    Discriminated unions are union types with a common literal property ('discriminant') that TypeScript uses to
    narrow the type in control flow, enabling exhaustive pattern matching.
        type Shape = | { kind: 'circle'; radius: number } | { kind: 'square'; side: number };
        function area(s: Shape): number {
            switch (s.kind) {
                case 'circle': return Math.PI * s.radius ** 2;
                case 'square'  return s.side ** 2;
                default: const _: never = s;
                return _; //
                exhaustiveness
            }
        }

# How do you implement module augmentation in TypeScript?
    Module augmentation extends existing types from third-party libraries without modifying their source.
    You re-declare the module and merge new types into its existing interfaces.
        // Augment Express Request to add 'user' import 'express';
        declare module 'express' { interface Request { user?: { id: string; role: string }; } }
        // Now req.user is typed everywhere in your app

# What are decorators and how do you use them in TypeScript?
    Decorators are functions that modify classes, methods, properties, or parameters at design time.
    They're heavily used in Angular and NestJS. Requires `experimentalDecorators: true` in tsconfig.
        function Log(target: any, key: string, desc: PropertyDescriptor) {
            const orig = desc.value;
            desc.value = function(...args: any[]) {
                console.log(`Calling ${key}`, args);
                return orig.apply(this, args);
            };
        }
        class Service {
            @Log
            fetchUser(id: string) {
                /* ... */
            }
        }

# How do you type recursive data structures?
    Use interface self-reference or recursive type aliases.
    Interfaces naturally support recursion;
    type aliases need careful use of conditional types or wrapping to avoid cycles.
        interface TreeNode {
            value: T; children: TreeNode[];
        }
        type JSONValue = | string | number | boolean | null | JSONValue[] | { [key: string]: JSONValue };

# What is the `satisfies` operator (TS 4.9+)?
    `satisfies` validates that an expression matches a type without widening it.
    Unlike an explicit annotation, it preserves the most specific inferred type for downstream use.
        type Color = 'red' | 'green' | 'blue';
        type Palette = Record;
        const palette = { primary: 'red', secondary: 'blue', }
        satisfies Palette; // palette.primary is 'red' (literal), not string
        const upper = palette.primary.toUpperCase(); // OK

# How do you implement a type-safe event emitter in TypeScript?
    Use a generic map type to correlate event names with their payload types,
    then constrain the emit/on methods using mapped/conditional types for full type safety.
        type EventMap = {
            login: { userId: string };
            logout: void;
        };
        class TypedEmitter> {
            on(event: K, cb: (data: T[K]) => void) {}
            emit(event: K, data: T[K]) {}
        }
        const emitter = new TypedEmitter();
        emitter.on('login', ({ userId }) => console.log(userId));
        emitter.emit('login', { userId: '123' });

# How does TypeScript's control flow analysis work?
    TypeScript analyses every branch of your code,
    tracking how the type of a variable changes after narrowing operations.
    Variables can have different types in different branches.
        function process(val: string | null) {
            if (!val) return; // null eliminated below // val:
            string here val = Math.random() > 0.5 ? val : null; // val: string | null again
            val?.toUpperCase(); // optional chain for safety }
