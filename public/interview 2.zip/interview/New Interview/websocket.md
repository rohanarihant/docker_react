# WebSocket
    An application establishes a WebSocket connection by initiating a standard HTTP request
    and immediately requesting a protocol upgrade to WebSocket (WS/WSS) via a process called the WebSocket Handshake
    Once the server approves this handshake, the underlying TCP connection remains open,
    allowing continuous, two-way data exchange without standard HTTP overhead


    The Network Handshake (Under the Hood)
        1. The Client Request: 
            The app sends an ordinary HTTP GET request to the server,
            but includes specific headers asking to switch protocols:
                Upgrade: websocket
                Connection: Upgrade
                Sec-WebSocket-Key: [Random Base64 String]
        2. The Server Evaluation: The server verifies the incoming request and ensures it supports WebSockets.
        3. The Server Response:
                If everything aligns, the server returns an HTTP status code 101 (Switching Protocols).
                It hashes the client's Sec-WebSocket-Key with a specialized security string and returns it
                via a Sec-WebSocket-Accept header to prove the connection is valid
        4. Persistent Connection Created:
                The HTTP protocol is formally discarded. The underlying network pipe (TCP socket) stays alive,
                transforming into a lightweight,
                full-duplex tunnel where both sides can transmit data freely at any moment.

    3. Key Protocols Used
        ws:// (WebSocket): Runs unencrypted over port 80.
        wss:// (WebSocket Secure):
                Runs with TLS/SSL encryption over port 443.
                This is highly recommended for production apps to safely bypass aggressive firewalls and proxy caches.

#   for security websocket url can be modified? how you would handle that ?
    Yes, a WebSocket URL can be modified, but changing the URL format itself does not make it secure.
    Attackers can still intercept, decompile, or spoof connection requests.

    To genuinely secure your WebSockets, you must secure the handshake phase and encrypt the data pipe.

    1. The Strategy: How to Secure the Connection
        Because WebSockets bypass standard HTTP protections (like CORS) once the connection is open,
        you must handle security at the architectural level.

    Enforce Encrypted Traffic (WSS Only)
        Never use ws://. Always enforce wss://.
        This wraps the connection in TLS/SSL, encrypting data in transit.
        It protects against Man-in-the-Middle (MitM) attacks and packet sniffing

    Protect the Handshake with Tokens
        WebSockets do not naturally support custom HTTP headers in the browser API.
        Pass a short-lived, single-use cryptographically signed token (like a JWT)
            inside the URL query string or the Subprotocol header.
        Example: wss://://example.com
        The server must immediately validate this token and drop the connection if it is expired or forged.
    Validate the Origin Header
        During the HTTP handshake, browsers automatically attach an Origin header.
        Your backend server must check this header against a strict allowlist
            (e.g., allow https://my-app.com, reject everything else).
        This prevents Cross-Site WebSocket Hijacking (CSWSH).
    Implement Rate Limiting and Payload Restrictions
        Limit how many connection requests a single IP can make per minute.
        Configure your backend to drop connections that attempt to send abnormally large data payloads
            (protects against Denial of Service attacks).