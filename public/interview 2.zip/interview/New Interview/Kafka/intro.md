# What is Kafka
    Apache Kafka is a distributed event streaming platform designed for high-throughput, fault-tolerant, real-time data pipelines.
    Think of it as a commit log (like a database's transaction log) that multiple systems can read from and write to.

# Topics (Categories/Folders)
    // Topics are logical channels for messages
        topic: "financial_transactions"
        topic: "user_activity"
        topic: "system_logs"

# Partitions (Parallelism Units)
    // Each topic is split into partitions for scaling
        Topic "transactions" with 3 partitions:
        ├── Partition 0: Transactions 1-1000
        ├── Partition 1: Transactions 1001-2000  
        └── Partition 2: Transactions 2001-3000

        // Messages within partition are ORDERED
        // Across partitions - NO global order
    
# Producers (Write data)
    // Node.js Producer Example
        const { Kafka } = require('kafkajs');

        const kafka = new Kafka({
        clientId: 'financial-app',
        brokers: ['kafka1:9092', 'kafka2:9092', 'kafka3:9092']
        });

        const producer = kafka.producer();

        async function produceTransaction(transaction) {
        await producer.connect();
        
        // Send with partition key (ensures order per account)
        await producer.send({
            topic: 'transactions',
            messages: [{
            key: transaction.account_id,  // All messages for same account → same partition
            value: JSON.stringify(transaction),
            headers: {
                'source': 'payment-gateway',
                'timestamp': Date.now().toString()
            }
            }]
        });
        }

# Consumers (Read data)
    // Consumer Group - Multiple consumers reading together
        const consumer = kafka.consumer({ 
        groupId: 'fraud-detection-group' 
        });

        await consumer.connect();
        await consumer.subscribe({ 
        topic: 'transactions', 
        fromBeginning: false  // Start from latest message
        });

        // Process messages
        await consumer.run({
        eachMessage: async ({ topic, partition, message }) => {
            console.log({
            key: message.key.toString(),
            value: JSON.parse(message.value.toString()),
            offset: message.offset,
            timestamp: message.timestamp
            });
            
            // Process transaction for fraud
            await analyzeFraud(JSON.parse(message.value));
        }
        });

# Kafka Architecture Deep Dive
    Kafka Architecture Deep Dive
        ┌─────────────────────────────────────────────────────────┐
        │                    Kafka Cluster                        │
        │  ┌──────────┐  ┌──────────┐  ┌──────────┐               │
        │  │ Broker 1 │  │ Broker 2 │  │ Broker 3 │               │
        │  │(Leader P0)│ │(Leader P1)│ │(Leader P2)│              │
        │  │ Follower │  │ Follower │  │ Follower │               │
        │  │   P2     │  │   P0     │  │   P1     │               │
        │  └──────────┘  └──────────┘  └──────────┘               │
        └─────────────────────────────────────────────────────────┘
                 ▲               ▲               ▲
                 │               │               │
            ┌────┴────┐    ┌────┴────┐    ┌────┴────┐
            │Producer │    │Producer │    │Consumer │
            │   App   │    │   App   │    │  Group  │
            └─────────┘    └─────────┘    └─────────┘

# Offset
    if a consumer is not able to read the info at the time
    it can go back in time and it can read the info from the topic

# General FLow
    producer is producing 100k requests at a time
    Topic will create multiple partitions
    Consumers will consume those by reading from there respective partition
    like 1 pod for cosumer 1 and that will real from partition 1

# 3 Broker Kafka cluster is highly available Kafka cluster

# Disadvantages of Kafka
    if we dont use efficiently then it will be costly

# Managed Kafka solutions
    Aiven
    Confluent


# Kafka -> Distributed event driven system
# Topic -> Virtual thing where producer write the info and consumer reads it
# Partition -> p0 | p1 | p2 -> multiple partitions of a Topic
# Partition Leader -> if there are 3 brokers -> P0 will be assign to PL1
    for High available system, if we dont want to loose the info,
    Its broker's responsibility to write the info to the storage
        it can be S3, EBS volums or EFS volums
    its broker reponsibility to storing the info and duplicating the info
# Broker - is node within the Kafka, we can create multi broker kafka cluster