# What is Pub/Sub
    Pub/Sub (Publish/Subscribe) is Google Cloud's asynchronous messaging service designed for high reliability and scalability .
    It decouples services that produce events from services that consume them

        ┌─────────────┐     ┌─────────┐     ┌─────────────┐
        │  Publisher  │ ──→ │  Topic  │ ──→ │ Subscriber A│
        │  (Service A)│     │         │     └─────────────┘
        └─────────────┘     │         │     ┌─────────────┐
                            │         │ ──→ │ Subscriber B│
        ┌─────────────┐     │         │     └─────────────┘
        │  Publisher  │ ──→ └─────────┘     ┌─────────────┐
        │  (Service B)│          │          │ Subscriber C│
        └─────────────┘          │          └─────────────┘
                                ↓
                    Messages delivered to ALL subscribers

    
# Core Pub/Sub Concepts
Concept	Explanation
Topic -> Named resource where publishers send messages 
Subscription ->  Named entity representing intent to receive messages from a topic 
Message	Data  ->  payload sent from publisher to subscribers 
Publisher -> Service that creates and sends messages
Subscriber -> Service that receives and processes messages

# How Pub/Sub Works (Message Lifecycle)
According to Google Cloud's architecture documentation, a message goes through these steps :
    Publisher sends message to a topic
    Message written to storage across multiple clusters (for durability)
    Acknowledgment sent back to publisher (guarantees delivery)
    Message forwarded to all subscribers while being stored
    Subscribers acknowledge after processing
    Message deleted after all subscribers confirm

