# Google Cloud Functions
    Cloud Run functions (formerly Google Cloud Functions) is Google's serverless Functions-as-a-Service (FaaS) platform that lets you run code in response to events without managing any servers 

    Think of it as writing small, single-purpose functions that automatically execute when specific events happen in your cloud environment

        // Simple HTTP-triggered Cloud Function (Node.js)
            exports.helloWorld = (req, res) => {
                res.send('Hello from Cloud Functions!');
            };

            // Event-triggered function (responds to Pub/Sub messages)
                exports.processTransaction = (event, context) => {
                const message = Buffer.from(event.data, 'base64').toString();
                console.log(`Received transaction: ${message}`);
            // Process the transaction
            };