**Doctype**
    The HTML document type declaration, also known as DOCTYPE, is the first line of code required in every HTML or XHTML document. The DOCTYPE declaration is an instruction to the web browser about what version of HTML the page is written in. This ensures that the web page is parsed the same way by different web browsers.

    HTML 4.01
    Strict DTD: Used for web pages that exclude attributes and elements that W3C expects to phase out as CSS support grows
    Transitional DTD: Used for web pages that include attributes and elements that W3C expects to phase out as CSS support grows
    Frameset DTD: Used for web pages with frames
    <!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">  

    HTML 5
    <!DOCTYPE html>


# center a div 

    1. div{
        background-color: black;
        position:absolute;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
    }

    2. css for the parent of div using FLex
        .parent {
            display: flex;
            justify-content: center;
            align-items: center;
            width: 100%;
            height: 100vh;
        }

    4. css for the parent of div using Grid
        .parent {
            display: grid;
            justify-content: center;
            align-items: center;
            width: 100%;
            height: 100vh;
        }


# css Box Modal
    width, height
    padding
    border
    margin

    all four combined in  box model

# semantics elements
    A semantic element clearly describes its meaning to both the browser and the developer.

    Examples of non-semantic elements: <div> and <span> - Tells nothing about its content.

    Examples of semantic elements: <form>, <table>, <section> and <article> - Clearly defines its content.
        The <section> element defines a section in a document.
        According to W3C's HTML documentation: "A section is a thematic grouping of content, typically with a heading."

        The <article> element specifies independent, self-contained content.
        Examples of where the <article> element can be used:
            Forum posts
            Blog posts
            User comments
            Product cards
            Newspaper articles


    List of new semantic elements
        The semantic elements added in HTML5 are:

        <article>
            An article is intended to be independently distributable or reusable.
        <aside>
            element is intended for content that is not part of the flow of the text in which it appears, however still related in some way
        <details>
        <figcaption>
        <figure>
            is for wrapping your image content around it, and <figcaption> is to caption your image.
        <footer>
        <header>
        <main>
        <mark>
        <nav>
        <small>
            usually contain copyright information or legal disclaimers
        <section>
            A section is a thematic grouping of content.
        <summary>
        <time>
            element allows an unambiguous ISO 8601 date to be attached to a human-readable version of that date
        <hgroup>
            The <hgroup> element should be used where you want a main heading with one or more subheadings.

    Benefits :- 
        easier to read.
        It has greater accessibility
            Search engines and assistive technologies (like screen readers for users with a sight impairment) are also 
        consistent code

# Responsive Websites (Best Practices)

<!-- Use Media Queries -->
    Media queries help you to define different breakpoints for your website.
    These breakpoints help you specify different CSS properties to use based on the size of the user's screen
    Common examples of breakpoints include 480px, 768px, 1024px, and 1280px.
    defining two (mobile-desktop) to three (mobile-tablet-desktop) different breakpoints

            @media (min-width:600px) {
        When working with media queries, you can define the min-width or max-width.

<!-- Use Flexible Layouts -->
    By using CSS properties like Flexbox, Grid, and so on, you can easily achieve this

    CSS Grid: CSS Grid is a two-dimensional layout system for creating responsive web designs.
                It allows you to define rows and columns in a grid, and then place and align content within those grid cells.
                Grid is typically used for more complex layouts, such as those with multiple rows and columns. It gives you fine-grained control over how content is placed and spaced within the grid cells, and can even be used for overlapping content.
                With the grid layout, you can easily have your website rearranged when used with media queries.

    Flexbox: CSS Flexbox is a one-dimensional layout system for creating flexible and responsive web designs.

            It allows you to define a flexible container and then align and distribute items within that container along a single axis (either horizontally or vertically).

            Flexbox is best used for simpler layouts where items need to be arranged along a single axis. It allows you to easily control the spacing and alignment of those items, and can be used for both horizontal and vertical layouts.

<!-- Use Flexible Units -->
    Another fundamental concept in web development is units. Depending on the kind of unit you use, it can make your website look orderly or disorderly.

        There are different units you can use to define, for example, the size of a box or circle. And while there is a wide range of units to choose from (like rem, cm, px, inches, and more), they can be broadly classified into two types:

        Relative units: These are the units that change value based on the screen size. This kind of unit doesn't have a fixed dimension, but can easily expand or contrast based on the size of the device. Examples include percentage, rem (root element's font-size) or em.

        Absolute units: These are units whose values remain the same no matter the sreen size. Regardless of the size of the screen, the space occupied will always remain the same
