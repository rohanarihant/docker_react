# HTML5
    introduced structural semantic tags, native multimedia support, forms enhancements,
    and powerful browser APIs that eliminated the need for external plugins like Flash.

    1. Semantic Structural Elements
        Instead of using <div class="header"> or <div id="footer"> for everything,
        HTML5 introduced native structural tags to help search engine crawlers
        and screen readers understand web page layouts.

        <header> & <footer>: Define headers and footers for the document or specific sections.
        <nav>: Wraps the primary navigation links of a website.
        <main>: Contains the unique, central content of the document.
        <article> & <section>: Group independent, self-contained content or logical thematic chapters.
        <aside>: Holds secondary content related tangentially to the main text (like a sidebar).

    2. Native Multimedia Support
        HTML5 allows developers to embed audio and video directly into a page without relying on third-party plugins.
        
        <video>: Plays movies, clips, or background video loops directly in the browser with native player controls.<audio>: Embeds sound files, music streams, or podcasts natively.
        <track>: Adds timed text tracks, subtitles, and captions to audio or video elements
    
    3. Graphics & Visual Capabilities
        <canvas>:
            A scriptable 2D/3D area used to draw shapes, build browser games,
                or render charts dynamically using JavaScript.
        Native SVG Support:
            Allows developers to embed scalable vector graphics (<svg>)
            directly inside the HTML file without an external asset file.

    4. Advanced Form Input Controls
        HTML5 redesigned inputs by adding automatic mobile keyboards,
        client-side validation rules, and specialized UI components.

        New Input Types:
            Includes type="email", type="url", type="date", type="number", type="color", and type="range"
        Validation Attributes:
            Features like required, pattern, placeholder, min, and max enforce clean data submissions
                before hitting JavaScript or backend processing.
    
    5. Powerful Browser & Web APIs
        HTML5 turned browsers into fully functional application platforms through integrated JavaScript APIs.
            Web Storage:
                Introduced localStorage (persistent data) and sessionStorage (data erased on tab close)
                    to save user settings directly inside the browser safely.
            Geolocation API:
                Allows users to opt-in and share their physical coordinates with applications
                    (e.g., finding mapping directions).
            Drag and Drop API:
                Enables native dragging and dropping of elements or external user files directly across web containers.
