# Babel
    is a JavaScript compiler that transforms modern JavaScript code into backward-compatible versions
    that can run in older browsers and environments.

// Modern JavaScript (ES2024)
const greet = (name) => `Hello ${name}`;
const numbers = [1, 2, 3];
const doubled = numbers.map(n => n * 2);
const [first, ...rest] = numbers;

// Problem: This won't run in IE11 or older browsers!

// Babel transforms it to:
"use strict";
var greet = function greet(name) {
  return "Hello " + name;
};
var numbers = [1, 2, 3];
var doubled = numbers.map(function(n) {
  return n * 2;
});
var first = numbers[0];
var rest = numbers.slice(1);
// Now it runs everywhere!


# Core Babel Concepts
1. Presets
    Presets are pre-configured sets of plugins that tell Babel how to transform your code.

    // .babelrc or babel.config.js
        {
        "presets": [
            "@babel/preset-env",      // ES6+ to ES5
            "@babel/preset-react",     // React JSX
            "@babel/preset-typescript", // TypeScript
            "@babel/preset-flow"      // Flow types
        ]
        }
    
    @babel/preset-env in Detail:
        {
            "presets": [
                [
                "@babel/preset-env",
                {
                    // Target specific browsers
                    "targets": {
                    "browsers": [
                        "> 0.5%",           // Market share
                        "last 2 versions",   // Recent versions
                        "not dead",          // Not discontinued
                        "ie >= 11"           // Specific browsers
                    ],
                    "node": "14"           // Node.js version
                    },
                    
                    // Polyfill handling
                    "useBuiltIns": "usage",  // Import polyfills automatically
                    "corejs": 3,             // Core-js version
                    
                    // Module format
                    "modules": "auto",       // ESM, CJS, etc.
                    
                    // Debug mode
                    "debug": true            // Show what's being transformed
                }
                ]
            ]
        }

2. Plugins
    Plugins are individual transformations that Babel applies to your code.

    // Individual plugins (instead of presets)
        {
        "plugins": [
            "@babel/plugin-transform-arrow-functions",    // Arrow functions
            "@babel/plugin-transform-classes",            // Classes
            "@babel/plugin-transform-destructuring",      // Destructuring
            "@babel/plugin-transform-spread",             // Spread operator
            "@babel/plugin-proposal-class-properties",    // Class properties
            "@babel/plugin-proposal-optional-chaining",   // ?. operator
            "@babel/plugin-proposal-nullish-coalescing"   // ?? operator
        ]
        }

    Plugin vs Preset:
        // Without preset (verbose)
            {
            "plugins": [
                "@babel/plugin-transform-arrow-functions",
                "@babel/plugin-transform-classes",
                "@babel/plugin-transform-destructuring",
                // ... 50+ more plugins
            ]
            }

            // With preset (clean)
            {
            "presets": ["@babel/preset-env"]
            }

3. Polyfills
    Polyfills are pieces of code that add missing JavaScript features to older browsers.

    The Polyfill Problem:
        // Modern code using Array.includes()
        const arr = [1, 2, 3];
        console.log(arr.includes(2)); // true

        // Babel transforms syntax, but not methods!
        // Array.includes() doesn't exist in IE11
        // Need POLYFILL for the method itself

4. Babel Runtime
    @babel/runtime and @babel/plugin-transform-runtime help avoid code duplication.

    // Every file that uses classes gets helper functions
        // File1.js
        class MyClass {}
        // Babel adds: function _classCallCheck(instance, Constructor) { ... }

        // File2.js  
        class AnotherClass {}
        // Babel adds the SAME helper function again! 😱

    Solution: @babel/runtime
        {
  "plugins": [
            [
            "@babel/plugin-transform-runtime",
            {
                "corejs": 3,        // Use core-js polyfills
                "helpers": true,    // Use runtime helpers
                "regenerator": true // Use regenerator-runtime
            }
            ]
            ]
        }

        // Instead of duplicating helpers:
        // File1.js
        import _classCallCheck from "@babel/runtime/helpers/classCallCheck";
        _classCallCheck(this, MyClass);

        // File2.js
        import _classCallCheck from "@babel/runtime/helpers/classCallCheck";
        _classCallCheck(this, AnotherClass);

        // Now helper is imported once! 🎉

5. JSX Transformation
    Babel transforms React JSX into JavaScript function calls.

    // Input JSX
        const App = () => (
        <div className="container">
            <h1>Hello, {name}!</h1>
            <button onClick={handleClick}>Click me</button>
        </div>
        );

        // Output with React 17+ (automatic runtime)
        import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
        const App = () => _jsxs("div", {
        className: "container",
        children: [
            _jsx("h1", {
            children: ["Hello, ", name, "!"]
            }),
            _jsx("button", {
            onClick: handleClick,
            children: "Click me"
            })
        ]
        });

        // Output with older React
        const App = function App() {
        return React.createElement(
            "div",
            { className: "container" },
            React.createElement("h1", null, "Hello, ", name, "!"),
            React.createElement("button", { onClick: handleClick }, "Click me")
        );
        };

6. Babel Configuration Files
    babel.config.json (highest priority)
        ↓
    .babelrc (per folder)
        ↓
    .babelrc.js
        ↓
    package.json ("babel" field) (lowest priority)

7. Babel CLI and Integration
    # Install Babel CLI
    npm install --save-dev @babel/core @babel/cli @babel/preset-env

    # Transform a file
    npx babel src/index.js --out-file dist/index.js

    # Transform a directory
    npx babel src --out-dir dist

    # Watch mode
    npx babel src --out-dir dist --watch

    # With source maps
    npx babel src --out-dir dist --source-maps

8. Babel AST (Abstract Syntax Tree)
    Babel works by parsing code into an AST and transforming it.

        Source Code
            ↓
        [Parser] → AST (Abstract Syntax Tree)
            ↓
        [Traverser] → Analyze AST
            ↓
        [Transformer] → Modify AST
            ↓
        [Generator] → Generate Code
            ↓
        Transformed Code

9. Babel Macro
    Macros allow you to run Babel transformations at compile-time.

    // Using babel-plugin-macros
    import { css } from '@emotion/react';

    const styles = css`
    color: blue;
    &:hover {
        color: red;
    }
    `;

    // Babel macro transforms this at compile-time
    // No runtime parsing needed! 🚀

11. Babel Performance Optimization
    // 1. Cache configuration
        module.exports = function(api) {
        api.cache(true); // Cache forever
        // or
        api.cache.never(); // Never cache
        // or
        api.cache.using(() => process.env.NODE_ENV); // Cache based on env
        };

        // 2. Exclude node_modules
        module.exports = {
        module: {
            rules: [
            {
                test: /\.js$/,
                exclude: /node_modules/, // Skip node_modules
                use: 'babel-loader'
            }
            ]
        }
        };

        // 3. Use cacheDirectory in Webpack
        {
        loader: 'babel-loader',
        options: {
            cacheDirectory: true,
            cacheCompression: false // Faster, but larger
        }
        }

        // 4. Use Babel's compact mode
        {
        presets: [
            ['@babel/preset-env', {
            compact: true, // Minify output
            minified: true
            }]
        ]
        }

#   babel-loader
    babel-loader is the bridge that connects Babel and Webpack.

    babel-loader is a Webpack loader that allows Webpack to process JavaScript files through Babel during the bundling process.
    It's the integration layer that makes Babel work seamlessly with Webpack.


