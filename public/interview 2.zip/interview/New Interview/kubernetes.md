Kubernetes
    open source contaier orchesration tool
    help you to manage containerized apps in diff deployment envs

    need of kuber
        increased usage of containers
        managing those containers across multitple places using script is very difficult
        that is the need of connianer orchestration tech

    what features do orchestration tools offer?
        High availability or no downtime
        Scalability or high perf
        Disaster Recovery - backup and restore
            if infra is having some problem like data loss or server problem the structure has to have pick up the data and restore it to prev state


    Node/ virtual node
        simple server, physical or virtual machine

    Pod 
        smallest unit of k8s
        abstraction over a container

        it provide the running env or layer on top of the container
        you only interact with the kubernetes layer

        pod is meant to run one app conntainer inside of it
        usually 1 app per pod

        how multiple pods will comm to each other
            kubernetes provides the each pods its own IP address (internal)
            when pod die or restart new ip address will be created

    Service and Ingress
        is static or permanent IP address
        can be atatched to each service
        lifecycle of Pod and service NOT connected
            even if pod dies service will stay

    Ingress
        with the secure protocol url
        instead of services req first goes to ingress
        then it will be forwarded from ingress to service

    Config Map
        if we have db url stored in build app
        if we change that then we will have to rebuild it and rebuild the pods
        config Map will contain exernal config of your app
        you just connect it with the Pods
        then pods will gets the data that configMap contains

        if we will change the name of the service or service change we dont need to go through the whole cycle.

    Secret
        if we will have to store the secret info we cant store that in config map
        we can store that in secret
        used to store secret data
        will store data in base 64 encoded format

        the build in security machanism is not enable by default
        we can access the datta from config map or secrets using env var or as properties files

    Volumes
        attaches a physical storage on a hard drive on pod
        that cann be onn the local machine meaning on the same server node where the pod is running
        or it could be on remote storage meaning outside of the kubernetes cluster
        it could be cloud storage

        its imp to understand the distinction b/w the k8s clusters and all its comps and the storage reg of whether its local or remote storage 
        think of the storage as hard drive plugged in to k8s cluster because k8s explicitly manange any data persistence
        you as a admin will have to manage this

    Deployment
        we don't need to create a replica for our pods
        we just need tto define a blueprint of the app and specify how many replicas we would like to run
        we are creating deployments and specify how manny replicas we need
        we can also scale up and scale down the no of replicas of pods we need
        deployment is another abstraction on top of pods

        if one pod will die service will pass the req to another pod

        we can't replicate the db in deployment, because it has state(data) 
        if we want to have multiple pods for db we need to have machannism to note down which pod is writing annd which is reading to db.
        to manage inconsistencies.
    Stateful Set
        this is meant only for app like dbs
        mysql, mongo, elastic should be created using stateful sets not deployments

        DBs are oftenn hosted outside of k8s cluster

    Worker Machine
        Node is the worker machine that actually do the work
        each node has multiple pods in it
        3 processes must be installed on every node (container, kubelet, 2nd -> services, 3rd -> kubeproxy)
        worker nodes do the actual work
    
    Kubelet
        innteract with both :-
            tthe container and node both
            kubelet start the pod with the container inside

    kubeproxy
        forwarding the proxy
        intelligent forwarding logic inside, that make sure that the comm work in a performant way with low overhead
        e.g if my-app replica is making a req db instead of service just randomly forwarding the req to any replica
        but ott will acttually forward it to replica that is running on the same node as the pods that initiate the req
        this way avoiding the nn/w overhead of sending the req to another machine
    
    * kubernnetes process kubelet and kubeproxy must be installed onn every k8s worker nodes alonng with the independent container
      runtime in order k8s cluster to func properly
    
    ? how do you innteract with this cluster?
        which node a nnew app  pode or db pod should be schedule
        or if replica pods dies what processes actually monitors itt and then reschedules it or restart it again
        or when we add another server how does it join the cluster to become another node and get pods and other components created on it.

    Master service/node
        have completely diff services/processes running inside and these are four processes that run, every masternode that control thhe cluster state
        4 services run on every API server
            api server :- whenn runnning a new server we will be interactive with the API server, like client, k8s ui server or cmd line
                like cluster gateway - getts the innitial req of any updates into the cluster or even the queries from the cluster.
                also act as a gatekeeper for auth
            sccheduler
                if we send a req to a API server, it will validate  the req will actually hand it over to the schedular in order to start the app nnod eone of the worker node.
                intelligent way of deciding which specific worker node will be scheduled and next comp will be scheduled
                it will check the resources (cpu/memory) and check which node have resources available and assign to it
                kubelet will take the info from schedular and start the pod 
            conroller manager
                detects cluster state changes
                    e.g crashing of pods, it detect that and try to recover the cluster state ASAP.
                    itt req to schedular to schedule the pods
            etcd 
                key value state of the cluster
                all those changes to cluster like (new pods, restart pods) it will be saved in the etcd key value store
                all controller manager work because of this data.

