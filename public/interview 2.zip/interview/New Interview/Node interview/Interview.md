# how file upload in handled in node.js
    In Node.js,
    handling file uploads is a multi-step process that typically involves parsing the multipart/form-data request, validating the file, and then storing it. While you can work with the raw data using streams or a multipart parser,
    the most common and efficient approach is to use a middleware library called Multer.

    🔧 The Standard Solution: Multer
        Multer is the go-to Node.js middleware for handling multipart/form-data 
        It processes incoming uploads and adds the file(s) and text fields to the request object,
        making them easy to access

        How it works:

            Setup: You create a Multer instance, optionally configuring where to store the file (diskStorage for saving to disk or memoryStorage to keep the file as a Buffer in memory) 
            
            Middleware: You attach the instance to your route, using methods like .single() for one file, .array() for multiple files from the same field, or .fields() for multiple files from different fields 
            
            Access: In your route handler, the uploaded file's metadata and buffer/path are available on req.file (for a single file) or req.files (for multiple files). Regular form text fields are on req.body 

        A Basic Example

            const express = require('express');
const multer = require('multer');
const path = require('path');
const fs = require('fs');

const app = express();
const uploadsDir = path.join(__dirname, 'uploads');

// Ensure the upload directory exists
if (!fs.existsSync(uploadsDir)) {
    fs.mkdirSync(uploadsDir);
}

// 1. Configure storage settings
const storage = multer.diskStorage({
    destination: function (req, file, cb) {
        cb(null, 'uploads/'); // Save files to the 'uploads' folder
    },
    filename: function (req, file, cb) {
        // Generate a unique filename to avoid conflicts
        const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
        cb(null, file.fieldname + '-' + uniqueSuffix + path.extname(file.originalname));
    }
});

// 2. Create the multer instance with configuration
const upload = multer({
    storage: storage,
    limits: { fileSize: 10 * 1024 * 1024 } // Set a 10MB file size limit
});

// 3. Route to handle a single file upload from a field named 'avatar'
app.post('/upload', upload.single('avatar'), (req, res) => {
    if (!req.file) {
        return res.status(400).json({ error: 'No file uploaded' });
    }

    // Access the uploaded file's information
    // Example: req.file.filename, req.file.path, req.file.size, req.file.mimetype
    res.json({
        message: 'File uploaded successfully!',
        fileInfo: {
            filename: req.file.filename,
            originalName: req.file.originalname,
            size: req.file.size,
            path: req.file.path,
        }
    });
});

app.listen(3000, () => console.log('Server running on port 3000'));


