z-inxed //
find 1st not repeating character //
what happen if kafka consumer down
what is CMS, have you worked with any cms tool
resolve 100000 requests cming to a Node.js application

diff useTransition and useDefferedValue 
    why they use wrap?
if we want to log every api call how can we do that?
what is Next.js

how do you handle errors in tool execution and how would you design retries for the same ensure consistency?
cluster in Node.js and when do you use the cluster in node.js
what if there are 2 package.json file in a repo?

diff browsers have diff default styles, how do you avoid that? //
what meta tag is? //
center a div //
diff positions //
feauters in HTMl5  //
!important //
piority order //
what is redis and how it is diff from kafka
what is dependency injection?
memory leak in node.js

Adobe analytics, crowl and meta tags
brute force attacks
search engine crawlers
screen readers
spread operator
memory leaks in react
problem occurs if useEffect is not used in correct way?
diff bw controlled and uncontrolled component
what makes component re-render
this keyword diff in arrow and normal function
hoisting
clousers
if you are fetching role data from api, how do you change and update it?
event loop
virtual dom
you have multiple component on a page, how you call the independent apis?
diff bw angular and react?
folder structure explanation
if you dont receive document on KT, what approach to next tasks
app performance tech
handle 3rd party api calls efficiently
what type of UI and feature exite you more and why?
what type of bugs you have fixed explain in details
points keep in mind while creating project from srach
mobile vs desktop which approach you pick and why
minimize the rendering
LCP and CLS
react query

