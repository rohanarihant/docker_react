# Closure
    A closure is the combination of a function bundled together with references to its surrounding state (lexical environment).
    In simpler terms: an inner function has access to variables of its outer function even after the outer function has returned.

        function outerFunction(outerVariable) {
        // This variable persists even after outerFunction returns
        return function innerFunction(innerVariable) {
            console.log(`Outer: ${outerVariable}, Inner: ${innerVariable}`);
            return outerVariable + innerVariable;
        };
        }

        const closure = outerFunction(10); // outerFunction returns, but closure "remembers" outerVariable = 10
        console.log(closure(5)); // Output: Outer: 10, Inner: 5, Returns: 15


        function fibonnaci(n){
            if(n<=1) return n;
            return fibonnaci(n-1) + fibonnaci(n-2)
        }
        function memoize(fn){
            const cache = {}

            return function(...args){
                const key = JSON.stringify()

                if(cache[key] !== undefined){
                    return cache[key]
                }

                const result = fn(...args);
                cache[key] = result
                return result
            }
        }
        const memoizedFibonaci = memoize(fibonnaci)
        console.log(memoizedFibonaci(10))