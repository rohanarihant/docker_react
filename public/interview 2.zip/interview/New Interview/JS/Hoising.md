# Hoisting

Hoisting is JavaScript's default behavior of moving declarations to the top of their containing scope during the compilation phase, before code execution.
Key Insight: JavaScript reads through your code twice - first to collect declarations (hoisting), then to execute the code.

let and const Hoisting (Temporal Dead Zone)
    // console.log(myLet);   // ReferenceError: Cannot access before initialization
        let myLet = 5;

        // console.log(myConst); // ReferenceError: Cannot access before initialization
        const myConst = 10;

        // They ARE hoisted, but NOT initialized
        // The period between hoisting and initialization is called the "Temporal Dead Zone" (TDZ)    

# Temporal Dead Zone
    // The period between hoisting and initialization is called the "Temporal Dead Zone" (TDZ)
    // Temporal Dead Zone demonstration
        {
            // TDZ starts at beginning of scope
            // console.log(x);   // ReferenceError (in TDZ)
            let x = 3;           // TDZ ends here
            console.log(x);      // 3 (now accessible)
        }

# Function Declarations Hoisting
    // Function declarations hoist over variable declarations
        console.log(foo);        // [Function: foo] (function wins)

        function foo() {
            return 1;
        }

        var foo = 2;

        console.log(foo);        // 2 (assignment overrides)

# Function Expressions Hoisting
    // Function expressions are NOT hoisted (var behaves differently)
    // console.log(subtract(5, 2));  // TypeError: subtract is not a function

    var subtract = function(a, b) {
        return a - b;
    };

    console.log(subtract(5, 2));  // 3 (works after declaration)

    // What happens:
    var subtract;                 // var is hoisted (undefined)
    // subtract(5, 2);            // TypeError if called here
    subtract = function(a, b) {   // Assignment happens here
        return a - b;
    };
    
