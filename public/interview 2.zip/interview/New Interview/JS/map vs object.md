# Map vs Object

Key Types
    Map allows keys of any data type (including functions, objects, primitives)
    Object only allows strings and symbols as keys

Element Order
    Maintained strickly by insertion order
    Object - no strictly guaranteed

Size Retrieval
    build in .size property
    Object.keys().length

Inheritence
