# Intersection Observer
    both are asynchronous browser APIs designed to monitor changes in the DOM without clogging the main UI thread

IntersectionObserver :- monitors visibility and geometry
        Is an element visible on screen, and how much of it is in view?
        detects when a target element enters or exits a specific container or the browser viewport.
        Primary Use Cases:
            Lazy-loading: Defer loading images or iframe content until the user scrolls near them.
            Infinite Scrolling: Detect when a footer sentinel element enters the viewport to fetch the next batch of data.
            Scroll-based Animations: Trigger animations when elements scroll into view.
            Ad Viewability: Track whether an ad unit was actually visible to a user.

            const observer = new IntersectionObserver((entries) => {
                entries.forEach(entry => {
                    if (entry.isIntersecting) {
                    console.log('Element is visible!', entry.target);
                    }
                });
                }, { threshold: 0.5 }); // Triggers when 50% visible

            observer.observe(document.querySelector('.target-box'));



MutationObserver :- monitors DOM structure and content
        Were nodes added/removed, or were attributes/text modified?
        detects direct mutations to the DOM tree inside a specified node or subtree
        Third-party Scripts: Detecting when external widgets or browser extensions inject unwanted DOM elements.
        Custom UI Components: Responding when children, text nodes, or attributes (like class or disabled) change.
        Accessibility & Auto-sizing: Recalculating dynamic layout sizes when inner HTML content mutates.

    const observer = new MutationObserver((mutationsList) => {
        for (const mutation of mutationsList) {
            if (mutation.type === 'childList') {
            console.log('A child node was added or removed.');
            } else if (mutation.type === 'attributes') {
            console.log(`The ${mutation.attributeName} attribute was modified.`);
            }
        }
    });

    observer.observe(document.querySelector('#container'), {
        childList: true,
        attributes: true,
        subtree: true
    });
