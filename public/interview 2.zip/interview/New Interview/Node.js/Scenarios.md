# 1. your node.js application needs to implement real-time updates, such as notifications or a live chat features

#    how would you implement real-time communication in Node.js application ?

    Implementation Strategy (using Socket.io / Node.js)
    A production-grade real-time setup requires authentication on connection,
    room/channel isolation, and structured event handling.

        // server.js
            const express = require('express');
            const { createServer } = require('http');
            const { Server } = require('socket.io');
            const jwt = require('jsonwebtoken');

            const app = express();
            const httpServer = createServer(app);
            const io = new Server(httpServer, {
            cors: { origin: 'https://yourdomain.com' },
            pingTimeout: 60000, // Detect dead connections quickly
            pingInterval: 25000,
            });

            // 1. Authentication Middleware (Verify JWT before handshake completes)
            io.use((socket, next) => {
            const token = socket.handshake.auth?.token;
            if (!token) return next(new Error('Authentication error: Token missing'));

            try {
                const decoded = jwt.verify(token, process.env.JWT_SECRET);
                socket.user = decoded; // Attach user info (userId, roles) to the socket
                next();
            } catch (err) {
                next(new Error('Authentication error: Invalid token'));
            }
            });

            // 2. Event & Room Management
            io.on('connection', (socket) => {
            const { userId } = socket.user;
            
            // Join a private room for targeted personal notifications
            socket.join(`user:${userId}`);
            console.log(`User ${userId} connected on socket ${socket.id}`);

            // Join a specific chat room
            socket.on('join_chat', (chatRoomId) => {
                socket.join(`chat:${chatRoomId}`);
            });

            // Handle incoming chat message
            socket.on('send_message', async (data) => {
                const { chatRoomId, message } = data;

                const formattedMessage = {
                senderId: userId,
                message,
                timestamp: new Date(),
                };

                // Broadcast to everyone in the chat room EXCEPT the sender
                socket.to(`chat:${chatRoomId}`).emit('new_message', formattedMessage);
                
                // Save to DB asynchronously (offloaded if high throughput)
                await saveMessageToDb(chatRoomId, formattedMessage);
            });

            socket.on('disconnect', (reason) => {
                console.log(`User ${userId} disconnected: ${reason}`);
            });
            });

            httpServer.listen(3000, () => console.log('Real-time server running on port 3000'));


#    how would you handle large volume of real-time connections ?
        However, a single Node.js process cannot handle millions of concurrent WebSockets alone
        due to single-thread CPU limits and memory limits per process (~1.5 GB default V8 memory)

        To handle large volumes (100,000+ concurrent connections), apply a horizontal scaling architecture:

        Strategy 1: Horizontal Scaling with Redis Pub/Sub
            When user A is connected to Server1 and userB is connected to Server 2, Server 1 has no memory record of user B.

            To bridge servers, attach a Redis Pub/Sub Adapter (@socket.io/redis-adapter):
            When Server 1 emits a message to room chat:456, it publishes the event to Redis.
            Redis broadcasts it to Server 2 and Server 3.
            Server 2 receives the event from Redis and forwards it to User B attached to its active WebSocket.

        Strategy 2: Load Balancing with Sticky Sessions
            If using Socket.io (which defaults to HTTP long-polling before upgrading to WebSockets),
            the load balancer must enable Sticky Sessions (Session Affinity) based on IP or Cookie.
                Without sticky sessions, HTTP polling requests from the same client will hit different servers
                    during handshake, resulting in 400 Session ID unknown errors.
                If using pure raw WebSockets (ws package), sticky sessions are not required because
                    the TCP connection stays open to one server once established.
        
        Strategy 3: Memory & OS Kernel Optimization
            At high scale, operating system limits will hit long before Node.js code fails.

        Strategy 4: Separate Real-Time Infrastructure from API Servers
            Do not run real-time WebSocket servers inside the main monolithic REST/GraphQL API app.
                Separate your application into an API Service (handles HTTP endpoints, DB writes)
                    and a Real-Time Gateway Service (handles persistent TCP connections).
                When a REST API endpoint updates data, it publishes a message to a message queue (Kafka/RabbitMQ/Redis), and the Real-Time Gateway pushes it out to clients.


# 2. your node.js API is slowing down due to frequent and complex database queries. Users are experiencing long response times.

How would you implement proper error handling for asynchronous operations to prevent the app from crashing?
    An unhandled promise rejection in Node.js can cause memory leaks, hanging HTTP requests, or abrupt process crashes

    1. Centralized Async Route Wrapper
        In Express, thrown errors inside async route handlers do not automatically
        reach Express's global error handler unless passed to next().
        Use an asyncHandler wrapper (or the express-async-errors package) to intercept all async exceptions cleanly:
            // utils/asyncHandler.js
                const asyncHandler = (fn) => (req, res, next) => {
                Promise.resolve(fn(req, res, next)).catch(next);
                };

                // Usage in Route:
                app.get('/users/report', asyncHandler(async (req, res) => {
                    // If DB query fails or times out, the error is safely caught and sent to global handler
                    const data = await db.query('SELECT * FROM complex_report_view');
                    res.json(data);
                }));

    2. Database Connection Pool & Query Timeouts
        Database queries that hang indefinitely will exhaust the connection pool,
        locking up Node.js event loop workers. Always configure timeouts and handle pool-level error events:

            const { Pool } = require('pg');
            const pool = new Pool({
                max: 20,                  // Maximum connections in pool
                idleTimeoutMillis: 30000,  // Close idle clients after 30s
                connectionTimeoutMillis: 2000, // Timeout after 2s if pool is full
                statement_timeout: 5000,   // Abort any query taking longer than 5s
            });

            // Handle idle client errors without crashing the process
            pool.on('error', (err, client) => {
                console.error('Unexpected error on idle database client', err);
            });

    3. Process-Level Safety Nets & Graceful Shutdown
        Always catch unhandled process rejection events and shut down gracefully
        rather than leaving the server in an inconsistent state:
            // Catch unhandled Promise rejections globally
            process.on('unhandledRejection', (reason, promise) => {
            console.error('Unhandled Rejection at:', promise, 'reason:', reason);
            // Log error to monitoring tool (e.g., Sentry, Datadog)
            });

            // Catch uncaught exceptions and gracefully shut down
            process.on('uncaughtException', (error) => {
            console.error('Uncaught Exception thrown:', error);
            
            // Close HTTP server & DB pools before exiting
            server.close(() => {
                pool.end();
                process.exit(1); // Exit process so process manager (PM2/Kubernetes) can restart it
            });
            });


how would you optimize the performance of your Node.js API, particularly in relation to database queries? 
    Slow database queries in Node.js usually stem from unindexed fields, N+1 query patterns,
    excessive data transfer, or blocking synchronous execution.

    1. Database Indexing & Execution Plans
        Run EXPLAIN ANALYZE (PostgreSQL) or .explain('executionStats') (MongoDB)
            on your slow queries to identify full table scans and missing indexes.

        Add B-Tree Indexes on fields used in WHERE, JOIN, ORDER BY, and GROUP BY clauses.

        Use Compound Indexes for queries filtering on multiple columns simultaneously
            (e.g., WHERE status = 'ACTIVE' AND created_at > ...).
    
    2. Eliminate the N+1 Query Problem
        A common performance killer in Node.js ORMs (Prisma, TypeORM, Mongoose, Sequelize)
            is running a loop that performs a query on every iteration.
        
            ❌ Bad (N+1 Queries):
            const users = await User.findAll();
            for (let user of users) {
                // Executes 1 DB query per user!
                user.orders = await Order.findAll({ where: { userId: user.id } });
            }

            ✅ Good (Single JOIN or Batch Query):
            // Executes 1 single JOIN query
            const usersWithOrders = await User.findAll({ include: [Order] });

    3. Parallelize Independent Queries with Promise.all()
        If your API endpoint needs to fetch data from multiple unrelated database tables,
        do not run them sequentially with await. Run them in parallel using Promise.all():

        ❌ Sequential (Slow): Total time = $200\text{ms} + 150\text{ms} + 100\text{ms} = 450\text{ms}$
            const user = await getUser(userId);
            const orders = await getOrders(userId);
            const metrics = await getMetrics(userId);

        ✅ Parallel (Fast): Total time = $\max(200\text{ms}, 150\text{ms}, 100\text{ms}) = 200\text{ms}$
            const [user, orders, metrics] = await Promise.all([
                getUser(userId),
                getOrders(userId),
                getMetrics(userId)
            ]);
    
    5. Add a Caching Layer (Redis)
        For complex queries whose data doesn't change every second (e.g., dashboards, product catalogs, user settings), cache query results in Redis:

        async function getCachedDashboardData(userId) {
        const cacheKey = `dashboard:${userId}`;
        
        // 1. Check Redis cache first
        const cachedData = await redis.get(cacheKey);
        if (cachedData) return JSON.parse(cachedData);

        // 2. Cache miss -> Query DB and set TTL (e.g., 5 minutes)
        const dbData = await fetchComplexDashboardFromDb(userId);
        await redis.set(cacheKey, JSON.stringify(dbData), 'EX', 300);

        return dbData;
        }
    4. Fetch Only Required Data (Field Selection & Pagination)
        Select Specific Columns:
            Never use SELECT * in production if you only need 3 fields.
        Use Cursor-Based Pagination:
            Avoid high-offset pagination (LIMIT 20 OFFSET 10000),
                as the database must scan 10,000 discarded rows before returning 20.
                Instead, use cursor pagination (WHERE id > last_seen_id LIMIT 20).


# 2. 