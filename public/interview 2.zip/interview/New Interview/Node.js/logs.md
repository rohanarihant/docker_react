# How to restrict personal data send in logs ? 

# Restricting Personal Identifiable Information (PII) and sensitive data
(passwords, credit cards, tokens, SSNs, health data)
from leaking into application logs requires a Defense-in-Depth strategy

    Application-Level Logger Redaction
        Option A: Using Pino (Fastify / Express Default)

        import pino from 'pino';

        const logger = pino({
        redact: {
            paths: [
            'req.headers.authorization',
            'req.headers.cookie',
            'password',
            '*.password',
            '*.token',
            '*.creditCard',
            '*.ssn',
            'user.email',
            'user.phoneNumber'
            ],
            censor: '[REDACTED]' // Replaces matching values with this string
        }
        });

        // Even if password is present, pino will automatically output: { "password": "[REDACTED]" }
        logger.info({ user: { id: 101, email: 'alex@example.com', password: 'SecretPassword123' } });

#   Request & Error Sanitization Middleware
        HTTP requests and unhandled error stack traces often contain PII in query parameters, headers, or request bodies.
        Sanitize Headers: Automatically strip Authorization, Cookie, Set-Cookie, and X-API-Key from request logs.
        Sanitize Query Strings: Avoid putting PII in GET request URLs (e.g., /api/users?email=test@example.com). If legacy endpoints require it, parse and sanitize req.query before logging.
        Sanitize Stack Traces: Ensure custom error objects do not attach full request payloads to error properties.


#   Ingestion-Level Log Scrubbing (Log Collectors)
    Even if application-level redaction is bypassed, set up a safety net at the log collector level (Datadog, Logstash, Vector, Fluentd, or AWS CloudWatch).
        Credit Card Number	\b(?:4[0-9]{12}(?:[0-9]{3})?|5[1-5][0-9]{14})\b	[MASKED_CREDIT_CARD]
        Email Address	[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}	[MASKED_EMAIL]
        SSN / Identity Number	\b\d{3}-\d{2}-\d{4}\b	[MASKED_SSN]
        JWT / Bearer Tokens	Bearer\s+[A-Za-z0-9\-\._~\+\/]+=*	Bearer [MASKED_TOKEN]
