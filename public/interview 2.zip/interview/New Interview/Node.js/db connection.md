Complete Guide: Handling Database Connections in Node.js

    Managing database connections properly is crucial for application performance, stability, and scalability.
    Poor connection handling leads to connection leaks, memory issues, and application crashes.

    Why Connection Management Matters
        Problem	                            Consequence
        Too many connections	            Database overload, connection refused errors
        Connection leaks	                Memory exhaustion, application crashes
        No connection pooling	            High latency, poor performance
        No retry logic	                    Application fails on temporary DB issues
        No graceful shutdown	            Lost queries, corrupted data

    🎯 1. Connection Pooling (The Foundation)
        Connection pooling is the most important concept in database connection management. Instead of opening/closing a connection for every query, you maintain a pool of reusable connections.

            const { Pool } = require('pg'); // PostgreSQL
const mysql = require('mysql2/promise');
const mongoose = require('mongoose');

// ============ PostgreSQL Example ============
const pgPool = new Pool({
  host: process.env.DB_HOST,
  port: process.env.DB_PORT,
  database: process.env.DB_NAME,
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  
  // Pool configuration
  max: 20,              // Maximum number of clients in the pool
  min: 2,               // Minimum number of clients to keep
  idleTimeoutMillis: 30000, // Close idle clients after 30 seconds
  connectionTimeoutMillis: 5000, // Return error if connection not established in 5s
  maxUses: 7500,        // Close connection after 7500 queries (for load balancing)
});

// ============ MySQL Example ============
const mysqlPool = mysql.createPool({
  host: process.env.DB_HOST,
  port: process.env.DB_PORT,
  database: process.env.DB_NAME,
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  waitForConnections: true,
  connectionLimit: 20,
  queueLimit: 0,
  enableKeepAlive: true,
  keepAliveInitialDelay: 0
});

// ============ MongoDB Example ============
mongoose.connect(process.env.MONGODB_URI, {
  maxPoolSize: 20,
  minPoolSize: 2,
  maxIdleTimeMS: 30000,
  connectTimeoutMS: 5000,
  socketTimeoutMS: 45000,
  family: 4 // Use IPv4, skip trying IPv6
});


    Choosing the Right Pool Size
        // Calculate ideal pool size
function calculatePoolSize() {
  const CPU_COUNT = require('os').cpus().length;
  const MAX_CONNECTIONS_PER_CORE = 2; // Rule of thumb
  
  // Formula: (CPU cores * 2) + number of replicas
  const idealSize = (CPU_COUNT * 2) + 1;
  
  // Database max connections limit
  const DB_MAX = 100; // Configured on database server
  
  return Math.min(idealSize, DB_MAX);
}

const poolSize = calculatePoolSize();
console.log(`Connection pool size: ${poolSize}`);

// Usage
const pool = new Pool({ max: poolSize });


    🏗️ 2. Connection Manager Pattern
        Create a dedicated connection manager to handle all database interactions.

            // db/connection-manager.js
class DatabaseConnectionManager {
  constructor() {
    this.pool = null;
    this.isConnected = false;
    this.connectionAttempts = 0;
    this.maxRetries = 5;
    this.retryDelay = 1000; // Start with 1 second
  }

  async connect() {
    if (this.isConnected && this.pool) {
      console.log('Already connected to database');
      return this.pool;
    }

    try {
      console.log(`Attempting to connect to database (attempt ${this.connectionAttempts + 1})`);
      
      this.pool = new Pool({
        host: process.env.DB_HOST,
        port: process.env.DB_PORT,
        database: process.env.DB_NAME,
        user: process.env.DB_USER,
        password: process.env.DB_PASSWORD,
        max: 20,
        min: 2,
        idleTimeoutMillis: 30000,
        connectionTimeoutMillis: 5000,
      });

      // Test the connection
      await this.pool.query('SELECT 1');
      
      this.isConnected = true;
      this.connectionAttempts = 0;
      console.log('✅ Database connected successfully');
      
      return this.pool;
    } catch (error) {
      console.error('❌ Database connection failed:', error.message);
      this.isConnected = false;
      
      this.connectionAttempts++;
      
      if (this.connectionAttempts < this.maxRetries) {
        const delay = this.retryDelay * Math.pow(2, this.connectionAttempts - 1);
        console.log(`Retrying in ${delay}ms...`);
        await this.sleep(delay);
        return this.connect(); // Retry
      }
      
      throw new Error(`Failed to connect after ${this.maxRetries} attempts`);
    }
  }

  async disconnect() {
    if (this.pool) {
      console.log('Closing database connections...');
      await this.pool.end();
      this.isConnected = false;
      this.pool = null;
      console.log('Database connections closed');
    }
  }

  async getConnection() {
    if (!this.pool) {
      await this.connect();
    }
    return this.pool;
  }

  async query(sql, params) {
    try {
      const pool = await this.getConnection();
      return await pool.query(sql, params);
    } catch (error) {
      // If connection is lost, attempt to reconnect once
      if (error.code === 'ECONNRESET' || error.code === 'PROTOCOL_CONNECTION_LOST') {
        console.log('Connection lost, attempting to reconnect...');
        this.isConnected = false;
        await this.connect();
        const pool = await this.getConnection();
        return await pool.query(sql, params);
      }
      throw error;
    }
  }

  sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }

  // Get pool status
  getStatus() {
    if (!this.pool) {
      return { connected: false, poolSize: 0, active: 0, idle: 0 };
    }
    
    const poolStatus = this.pool._pool ? {
      connected: this.isConnected,
      poolSize: this.pool._pool?.size || 0,
      available: this.pool._pool?.available || 0,
      pending: this.pool._pool?.pending || 0
    } : { connected: this.isConnected };
    
    return poolStatus;
  }
}

module.exports = new DatabaseConnectionManager();

        


