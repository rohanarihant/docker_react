# API Retry
import fetch from "node-fetch";

 service.fetch = async (url, init, retry = config.retries) => {
    let response;
    try {
      response = await service.fetchRequest(url, init);
    } catch (error) {
      console.error(error);
    }
    if (!response) {
      if (retry > 0) {
        console.log(
          `Delay to retry to fetch ${url} with params ${JSON.stringify(init)}`
        );
        await new Promise((resolve) => setTimeout(resolve, config.retryDelay));
        console.log(
          `Retry to retry to fetch ${url} with params ${JSON.stringify(init)}`
        );
        response = await service.fetch(url, init, retry - 1);
        console.log(
          `Recovered to retry to fetch ${url} with params ${JSON.stringify(
            init
          )}`
        );
      } else {
        throw `Error on retries to fetch ${url} with params ${JSON.stringify(
          init
        )}`;
      }
    }
    return response;
  };