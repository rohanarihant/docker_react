#   how to determine memory leak in node application ?

    Detecting a memory leak in a Node.js application is a systematic process.
    The key signs are a steady, continuous increase in memory usage over time,
    which often leads to sluggish performance or out-of-memory crashes

    To diagnose this effectively, you can use a combination of monitoring and powerful analysis tools

    🔭 Step 1: Look for the Signs
        The primary symptom is memory usage that grows and never returns to a baseline after garbage collection

        Global Variables and Caches: Data stored in global, Map, or Set objects that grows without limit

        Event Listeners: Registering listeners with .on() without ever removing them with .removeListener()

        Timers: setInterval that is never cleared with clearInterval, especially if it holds references to objects

        Closures:
            Inner functions that inadvertently hold references to large outer variables, preventing them from being garbage-collected

    🧰 Step 2: Monitoring Memory Usage
        To track memory growth, you can implement a simple memory monitor.

            const v8 = require('node:v8');

        class MemoryMonitor {
        constructor(options = {}) {
            this.intervalMs = options.intervalMs || 30000; // Check every 30 seconds
            this.thresholdMb = options.thresholdMb || 100;
            this.history = [];
            this.baseline = null;
        }

        start() {
            this.timer = setInterval(() => this.check(), this.intervalMs);
            this.baseline = this.getHeapUsed();
            console.log(`Memory monitor started. Baseline: ${this.baseline.toFixed(2)}MB`);
        }

        stop() {
            clearInterval(this.timer);
        }

        getHeapUsed() {
            const stats = v8.getHeapStatistics();
            return stats.used_heap_size / 1024 / 1024;
        }

        check() {
            const current = this.getHeapUsed();
            const delta = current - this.baseline;
            this.history.push({ timestamp: Date.now(), used: current, delta });

            // Keep last 100 measurements
            if (this.history.length > 100) {
            this.history.shift();
            }

            // Check for consistent growth in the last 10 measurements
            if (this.history.length >= 10) {
            const recent = this.history.slice(-10);
            const allGrowing = recent.every((m, i) => i === 0 || m.used > recent[i - 1].used);
            
            if (allGrowing && delta > this.thresholdMb) {
                console.warn(`[MEMORY WARNING] Heap grew by ${delta.toFixed(2)}MB`);
                console.warn(`  Current: ${current.toFixed(2)}MB`);
                console.warn(`  Baseline: ${this.baseline.toFixed(2)}MB`);
            }
            }
        }
        }

    🔬 Step 3: Deep Dive with Heap Snapshots
        1. Generating a Snapshot
            Via Chrome DevTools: Run your app with the --inspect flag (node --inspect server.js), open chrome://inspect in Chrome, and attach to your Node.js process. In the Memory tab, take a Heap Snapshot .

        Programmatically: Use the built-in node:v8 module to write a snapshot to disk during execution.

        const v8 = require('node:v8');
        const snapshotFile = v8.writeHeapSnapshot();
        console.log(`Heap snapshot written to ${snapshotFile}`);


        2. The "Three Snapshot" Method
            To isolate the leaking objects, follow this procedure:

            Baseline: Let your app boot up, then take a snapshot (Snapshot 1).

            Load: Exercise the suspect functionality (e.g., make API calls) to trigger memory allocation.

            Baseline 2: Take a second snapshot (Snapshot 2).

            Load Again: Repeat the same functionality.

            Final: Take a third snapshot (Snapshot 3).



# how to fix the memory leak in node.js
    Fixing a memory leak in Node.js involves first identifying the exact source of the leak,
    and then applying targeted code fixes.
    A systematic approach is key, as memory leaks often manifest as a slow but steady rise in RAM usage

    🔍 Step 1: Identify the Leak's Source
        Before you can fix a leak, you need to know where it is.
        The most effective way is to compare two heap snapshots to see which objects are growing over time

        How to capture and compare snapshots:

            Start your app with debugging enabled: Run your application with the --inspect flag: node --inspect app.js.

            Open Chrome DevTools: In a Chrome browser, go to chrome://inspect and click on "Open dedicated DevTools for Node".

            Take a baseline snapshot: In the Memory tab, take a "Heap snapshot". This is your "before" picture.

            Run the suspected operation: Perform the action in your app that you think might be causing the leak.

            Take a second snapshot: Take another "Heap snapshot" after the operation completes.

            Take a third snapshot: Repeat the operation, take a third snapshot.

            Compare the snapshots: Select the Comparison view, and compare the third snapshot to the first. Look at the # Delta column. Objects with a large, positive delta are likely the ones leaking.

    Production (or hard-to-reproduce) Leaks
        For leaks that are only visible in production,
        you can use the heapdump package to generate snapshots programmatically

        const heapdump = require('heapdump');

        // ... your application code ...

        // Write a snapshot when memory usage gets high
        if (memoryUsage > threshold) {
        heapdump.writeSnapshot(`/tmp/heap-${Date.now()}.heapsnapshot`);
        }

        You can also trigger heap dumps via a signal without restarting your app
    
        🛠️ Step 2: Fix the Common Leak Patterns
            1. 🔄 Unbounded Caches & Global Variables
                This is a very common source of leaks
                . Holding data in a global object, Map,
                or Set without a limit prevents garbage collection

                const cache = {}; // This object lives for the entire lifetime of the process
                function storeData(key, value) {
                    cache[key] = value; // Data is never evicted
                }
            
            Every time storeData is called, memory usage grows because cache never frees old entries

            The Fix:
            Use a cache with a bounded size and a TTL (Time To Live), like an LRU (Least Recently Used)

            import { LRUCache } from 'lru-cache';

            // Creates a cache with a hard cap of 100,000 items
            const cache = new LRUCache({
                max: 100000,
                ttl: 1000 * 60 * 60, // Expire items after 1 hour
            });

            2. 🕒 Unclear Timers & Intervals
                setInterval and setTimeout create references to the functions they execute.
                If these functions hold references to other objects, those objects cannot be garbage collected.
                If you don't clear them, they will keep running and accumulating memory indefinitely

                function startPolling() {
                    // This interval runs forever, and any object it closes over stays in memory
                    setInterval(() => {
                        console.log('Polling...');
                    }, 1000);
                }

                The Fix:
                Always clear your timers when they are no longer needed
                    const interval = setInterval(() => {
                        console.log('Polling...');
                        }, 1000);

                        // Later, when you're done with the timer
                    clearInterval(interval);
            
            3. 👂 Event Listeners Not Removed
                Attaching event listeners without removing them is another common leak,
                especially if the listener is attached repeatedly.

                // Attached inside a function that runs many times
                function setupListener() {
                process.on('someEvent', () => {
                    // Do something
                });
                }
            Each call to setupListener adds a new listener, which never gets cleaned up

            4. 🔗 Closures Holding Large Objects
                A closure is a function that "remembers" its outer scope.
                If a closure holds a reference to a large object,
                that object cannot be garbage collected until the closure itself is gone

                function heavyFunction() {
                const hugeBuffer = Buffer.alloc(1024 * 1024 * 100); // 100MB

                // The inner function closes over hugeBuffer
                return function() {
                    // Even if it only uses a small part, hugeBuffer is kept alive
                    console.log('Done');
                };
                }
                const inner = heavyFunction();

                Even if inner doesn't use hugeBuffer, the buffer stays in memory as long as inner exists.

