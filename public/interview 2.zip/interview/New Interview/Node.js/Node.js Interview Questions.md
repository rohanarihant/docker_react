# Explain worker threads vs cluster module vs child_process. When would you use each?

// When to use each:

// Worker Threads: 
      when we are doing CPU intensive tasks
// ✅ CPU-intensive operations (image processing, encryption, data compression)
// ✅ Shared memory needs (large datasets, real-time collaboration)
// ✅ Parallel computing (matrix operations, scientific computing)

// Cluster:
      Http Load Balancing
// ✅ HTTP/S server load balancing
// ✅ Zero-downtime deployments
// ✅ Maximizing multi-core utilization for I/O operations

// Child Process:
    External Commands, script
// ✅ Running external executables (ffmpeg, imagemagick)
// ✅ Isolating unstable code
// ✅ Running scripts in other languages (Python, Ruby, Go)
// ✅ Handling untrusted user code (sandboxing)

# What is a Buffer? 
(a stream of 0s and 1s)
A Buffer is a global class in Node.js that provides a way to work with raw binary data directly in memory.

It is a fixed-size chunk of memory allocated outside of the V8 JavaScript engine's heap (it uses C++ under the hood via malloc).

It acts like an array of integers, but each integer represents a single byte (0 to 255) of binary data.

Why does JavaScript need this? 
Originally, JavaScript only handled strings (UTF-16). But when you read a file from the filesystem (fs.readFile), receive a TCP packet, or handle an image upload via multer, the data is not text—it's raw bytes. Buffer bridges the gap between binary data and JavaScript.

# Node is single threaded, how can we achieve multi thread ?
      Node.js can achieve multi-threading
      Node.js provides specific, built-in tools to run code in parallel and leverage multi-core CPUs.

      🧵 Method 1: Worker Threads (For CPU-Intensive Tasks)
            The worker_threads module is the most direct way to create independent threads for parallel execution
            This is the ideal solution for offloading CPU-heavy tasks like complex calculations,
            image processing, or password hashing

            How It Works:
                  Isolated Context:
                        Each Worker thread runs its own instance of the V8 engine and event loop,
                        completely isolated from the main thread and other workers
                  Message Passing:
                        Communication is done via a message-passing system. You can't share functions,
                        but you can share data (or SharedArrayBuffer for zero-copy sharing)
                  Non-Blocking:
                        This prevents CPU-intensive operations from freezing the main thread's event loop,
                        keeping the server responsive to new requests
            
            1. The Worker File (worker.js)
                  This file will be executed in a separate thread.
                  It listens for a message and sends the result back.

                  // worker.js
                  const { parentPort } = require('worker_threads');

                  parentPort.on('message', (n) => {
                        // --- CPU-intensive task (e.g., a heavy calculation) ---
                        let sum = 0;
                        for (let i = 0; i < n; i++) {
                        sum += i;
                        }
                        // Send the result back to the main thread
                        parentPort.postMessage(sum);
                  });

            2. The Main Thread (server.js)
                  This is your main Express server.
                  It spawns a Worker for the heavy task and sends the result once the Worker finishes.

                  // server.js
                        const express = require('express');
                        const { Worker } = require('worker_threads');

                        const app = express();
                        const port = 3000;

                        app.get('/sum/:n', (req, res) => {
                        const n = parseInt(req.params.n);

                        // --- Create a new worker for this request ---
                        const worker = new Worker('./worker.js');

                        // Listen for the result from the worker
                        worker.on('message', (sum) => {
                        res.status(200).send(`Sum from 1 to ${n} is ${sum}`);
                        });

                        // Listen for any errors from the worker
                        worker.on('error', (error) => {
                        res.status(500).send(`Worker error: ${error.message}`);
                        });

                        // Send the task to the worker
                        worker.postMessage(n);
                        });

                        app.get('/hello', (req, res) => {
                        res.send('Hello, this route is not blocked by the CPU-heavy task!');
                        });

                        app.listen(port, () => {
                        console.log(`Example app listening on port ${port}`);
                        });
                  
      🌐 Method 2: Cluster Mode (For Multi-Core Scalability)
            The cluster module creates multiple independent Node.js processes, not just threads
            Each process runs on a different CPU core, which is the best way to scale your application to handle a massive volume of concurrent incoming requests.

            How It Works:
                  Multiple Processes:
                        It uses the child_process.fork() method to spawn copies of your main application.
                  Load Balancing:
                        A primary/master process listens on a port and distributes incoming connections among the worker processes.
                  True Parallelism:
                        Since each process runs on a separate core, your app can process multiple requests simultaneously in a truly parallel fashion

            Example: Basic Cluster Setup
                  This code creates a worker process for every CPU core on your machine.

                  // server.js
const cluster = require('cluster');
const http = require('http');
const { availableParallelism } = require('os');
const process = require('process');

const numCPUs = availableParallelism();

if (cluster.isPrimary) {
  // --- This code runs in the master process ---
  console.log(`Primary ${process.pid} is running`);

  // Fork workers for each CPU core
  for (let i = 0; i < numCPUs; i++) {
    cluster.fork();
  }

  cluster.on('exit', (worker, code, signal) => {
    console.log(`Worker ${worker.process.pid} died, restarting...`);
    // A best practice is to restart a worker if it crashes
    cluster.fork();
  });

} else {
  // --- This code runs in EACH worker process ---
  // Workers can share the same TCP connection (e.g., an HTTP server)
  http.createServer((req, res) => {
    if (req.url === '/heavy') {
      // A CPU-heavy task that will block this worker's event loop
      let sum = 0;
      for (let i = 0; i < 1e9; i++) sum += i;
      res.end(`Sum calculated: ${sum}`);
    } else {
      res.end(`Hello from worker ${process.pid}`);
    }
  }).listen(8000);

  console.log(`Worker ${process.pid} started`);
}


      Feature                 Worker Threads (worker_threads)                Cluster Mode (cluster)
      Use Case           Offloading CPU-intensive tasks to keep                Scaling your application to handle many 
                         the main thread responsive                            concurrent requests on a multi-core system
      Concurrency Model  Multi-threading                                       Multi-processing 
                          (lightweight, within the same process)               (heavier, multiple processes)
      Memory Usage       Lower memory footprint.                               Higher memory footprint.
                         Data can be shared via SharedArrayBuffer.             Each process has its own separate memory
      Communication      Message passing                                       Message passing via IPC 
                         via postMessage and on('message') events              (Inter-Process Communication) channels


#  how do you know how many nodes are needed to be split into after deployment ?
      You should not split your Node.js process into more "nodes" or workers than
      the number of logical CPU cores available to your system

      Creating more processes than cores leads to overhead from the operating system
      constantly switching between them, which can hurt performance

      🚀 How to Find the Number of Logical Cores
            os.cpus().length
      
      💡 Scaling Beyond a Single Server
            Once you've optimized a single machine using the cluster module,
            further scaling requires horizontal scaling by adding more servers.

            Container Orchestration (Kubernetes):
                  If you deploy your app with Docker and Kubernetes, you can set up a Horizontal Pod Autoscaler (HPA).
                  This will automatically increase or decrease the number of running containers (pods)
                  based on metrics like CPU usage

            Process Managers (PM2):
                  Tools like PM2 provide an easier way to manage the cluster module in production,
                  with commands like pm2 start app.js -i max to utilize all cores.
      
      🧠 Summary
            Start with os.availableParallelism() or os.cpus().length in your master process to fork workers

            Don't blindly trust it. Run load tests
            (e.g., using autocannon or loadtest) to find the number that gives you the best throughput and
            latency for your specific app
            

