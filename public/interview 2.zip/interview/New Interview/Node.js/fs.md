
# use cases of fs package in node.js and its methods
    The fs (file system) module in Node.js is a core,
    built-in library that acts as a "master key" for interacting with the file system .

    It's the go-to tool for any server-side operation involving files and directories,
    from reading configuration files to serving static assets.

    Its main use cases and key methods are grouped below.

    🎯 Key Use Cases
        Reading and Writing Data: This is the foundation of the fs module. You can read configuration files (like package.json), log application activity, or serve static files for a web app 

        Managing Directories: The module allows you to programmatically create, list, and delete directories. This is essential for structuring file uploads or organizing logs 

        File System Administration: For more advanced admin tasks, fs can check file permissions, retrieve metadata (size, modification date), rename, move, and delete files .

        Processing Large Files: For performance, fs provides streaming capabilities. This allows you to handle very large files (like videos or database dumps) in chunks instead of loading them entirely into memory 

    File Operations
        Method (Async)               Purpose                    Description
        fs.readFile()                Read a file                Asynchronously reads the entire contents of a file 
        fs.writeFile()               Write to a file            Asynchronously writes data to a file,
                                                                replacing the file if it already exists 
        fs.appendFile()              Append to a file           Asynchronously appends data to a file,
                                                                creating the file if it doesn't exist 
        fs.unlink()                  Delete a file              Asynchronously removes a file 
        fs.rename()                 Rename or move a file       Asynchronously renames a file or directory 
        fs.copyFile()               Copy a file                 Asynchronously copies a file from source to destination 

    Directory & Meta Operations
        fs.mkdir()                  Create a directory          Asynchronously creates a new directory 
        fs.readdir()                Read a directory            Asynchronously reads the contents of a directory 
        fs.rmdir()                  Remove a directory          Asynchronously removes a directory (must be empty)
                                                                Use fs.rm() for recursive deletion
        fs.stat()                   Get file/dir info           Asynchronously retrieves information  
                                                                    (size, permissions, type) about a file or directory

    Advanced Operations
        fs.createReadStream()       Stream file reading         Reads a file in chunks, ideal for large files 
        fs.createWriteStream()      Stream file writing         Writes data in chunks, ideal for large files 
        fs.watch()                  Watch for changes           Watches a file or directory for changes 


    
    const fs = require('fs');
    const path = require('path');
    const express = require('express');

    const app = express();
    // __dirname is the current directory. This creates a safe path to your file.
    const usersFilePath = path.join(__dirname, 'users.json');

    // An endpoint to get all users
    app.get('/users', (req, res) => {
    // Asynchronously read the file
    fs.readFile(usersFilePath, 'utf-8', (error, data) => {
        if (error) {
        // Return a 500 Internal Server Error if the file can't be read
        return res.status(500).json({ error: 'Error reading user data' });
        }
        
        try {
        // The data is read as a JSON string, so we parse it into a JavaScript object
        const users = JSON.parse(data);
        res.json(users);
        } catch (parseError) {
        // Handle cases where the JSON file is malformed
        return res.status(500).json({ error: 'Invalid user data format' });
        }
    });
    });

    app.listen(3000, () => console.log('Server running on port 3000'));


# fs.createReadStream() in Node.js
    const fs = require('fs');

    // ============ CREATE READ STREAM ============
    const readStream = fs.createReadStream('large-file.txt', {
    encoding: 'utf8',
    highWaterMark: 64 * 1024 // 64KB chunks (default)
    });

    // ============ EVENT HANDLERS ============

    // 'data' event - called for each chunk
    readStream.on('data', (chunk) => {
    console.log(`Received ${chunk.length} bytes`);
    console.log(chunk);
    });

    // 'end' event - called when all data is read
    readStream.on('end', () => {
    console.log('✅ File reading completed');
    });

    // 'error' event - called if an error occurs
    readStream.on('error', (err) => {
    console.error('❌ Error reading file:', err);
    });

    // 'open' event - called when file is opened
    readStream.on('open', (fd) => {
    console.log(`File opened with file descriptor: ${fd}`);
    });

    // 'close' event - called when file is closed
    readStream.on('close', () => {
    console.log('File closed');
    });