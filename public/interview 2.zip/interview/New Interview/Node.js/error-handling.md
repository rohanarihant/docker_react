
#   how to organize the global error handling, instead of having code inside each route ?

    The key to clean error handling is centralizing it.
    Instead of wrapping every route handler with try/catch,
    you create a global error handler that catches all errors and sends consistent responses.

    ❌ Bad Approach: Error Handling in Every Route
        // BAD: Repetitive try/catch in every route
            app.get('/users', async (req, res) => {
            try {
                const users = await User.find();
                res.json(users);
            } catch (error) {
                res.status(500).json({ error: error.message });
            }
            });

        // ❌ Problems:
        // - Duplicate error handling code everywhere
        // - Inconsistent error responses
        // - Hard to maintain
        // - Easy to forget error handling

    ✅ The Solution: Centralized Error Handling
        1. Global Error Handler Architecture
        
    ┌─────────────────────────────────────────────────────────────┐
    │                      Express App                           │
    ├─────────────────────────────────────────────────────────────┤
    │                                                             │
    │  1. Middleware (logger, parser, cors)                      │
    │                                                             │
    │  2. Routes                                                  │
    │     ┌─────────────────────────────────────┐                │
    │     │  Route Handler (no try/catch)       │                │
    │     │  ↓                                  │                │
    │     │  throw error  OR  next(error)       │                │
    │     └─────────────────────────────────────┘                │
    │                                                             │
    │  3. Global Error Handler (CATCHES ALL errors)             │
    │     ┌─────────────────────────────────────┐                │
    │     │  process error                       │                │
    │     │  log error                           │                │
    │     │  send consistent response            │                │
    │     └─────────────────────────────────────┘                │
    │                                                             │
    └─────────────────────────────────────────────────────────────┘

    📁 Organized Project Structure
        src/
        ├── app.js                    # Main app setup
        ├── server.js                 # Server entry point
        ├── config/
        │   └── error-config.js       # Error configuration
        ├── middleware/
        │   ├── error-handler.js      # Global error middleware
        │   ├── async-handler.js      # Async wrapper
        │   └── not-found.js          # 404 handler
        ├── errors/
        │   ├── app-error.js          # Base error class
        │   ├── validation-error.js   # Custom errors
        │   ├── not-found-error.js
        │   └── unauthorized-error.js
        ├── routes/
        │   └── user.routes.js        # Routes (clean)
        ├── controllers/
        │   └── user.controller.js    # Controllers (no try/catch)
        └── services/
            └── user.service.js       # Business logic


    🛠️ Complete Implementation
        Step 1: Custom Error Classes
        
        // src/errors/app-error.js
        class AppError extends Error {
        constructor(message, statusCode, errorCode = null, details = null) {
            super(message);
            this.statusCode = statusCode;
            this.errorCode = errorCode || `ERROR_${statusCode}`;
            this.details = details;
            this.isOperational = true;
            this.timestamp = new Date().toISOString();
            
            // Capture stack trace
            Error.captureStackTrace(this, this.constructor);
        }
        }

        module.exports = AppError;

        // src/errors/validation-error.js
            const AppError = require('./app-error');

            class ValidationError extends AppError {
            constructor(message = 'Validation failed', details = null) {
                super(message, 400, 'VALIDATION_ERROR', details);
            }
            }

            module.exports = ValidationError;

        // src/errors/not-found-error.js
            const AppError = require('./app-error');

            class NotFoundError extends AppError {
            constructor(resource = 'Resource') {
                super(`${resource} not found`, 404, 'NOT_FOUND_ERROR');
            }
            }

            module.exports = NotFoundError;

        // src/errors/unauthorized-error.js
            const AppError = require('./app-error');

            class UnauthorizedError extends AppError {
            constructor(message = 'Authentication required') {
                super(message, 401, 'UNAUTHORIZED');
            }
            }

            module.exports = UnauthorizedError;

        
    Step 2: Async Handler Wrapper
        // src/middleware/async-handler.js
        const asyncHandler = (fn) => {
        return (req, res, next) => {
            Promise.resolve(fn(req, res, next)).catch(next);
        };
        };

        module.exports = asyncHandler;

    Step 3: Global Error Handler
        // src/middleware/error-handler.js
        const { AppError } = require('../errors');
        const logger = require('../utils/logger'); // Optional: Winston/Pino

        /**
        * Global error handling middleware
        * This catches ALL errors passed to next()
        */
        const errorHandler = (err, req, res, next) => {
        // Log the error
        logger.error({
            error: err.message,
            stack: err.stack,
            path: req.path,
            method: req.method,
            ip: req.ip,
            userId: req.user?.id,
            timestamp: new Date().toISOString()
        });

        // Handle specific error types
        let statusCode = 500;
        let errorCode = 'INTERNAL_ERROR';
        let message = 'An unexpected error occurred';
        let details = null;

        // 1. Our custom AppError
        if (err instanceof AppError) {
            statusCode = err.statusCode;
            errorCode = err.errorCode;
            message = err.message;
            details = err.details;
        }
        
        // 2. Mongoose Validation Error
        else if (err.name === 'ValidationError') {
            statusCode = 400;
            errorCode = 'VALIDATION_ERROR';
            message = 'Validation failed';
            details = Object.values(err.errors).map(e => ({
            field: e.path,
            message: e.message
            }));
        }
        
        // 3. Mongoose Duplicate Key Error
        else if (err.code === 11000) {
            statusCode = 409;
            errorCode = 'DUPLICATE_KEY';
            const field = Object.keys(err.keyPattern)[0];
            message = `Duplicate value for field: ${field}`;
            details = { field };
        }
        
        // 4. Mongoose Cast Error (invalid ObjectId)
        else if (err.name === 'CastError') {
            statusCode = 400;
            errorCode = 'INVALID_ID';
            message = `Invalid ${err.path}`;
            details = { path: err.path, value: err.value };
        }
        
        // 5. JWT Errors
        else if (err.name === 'JsonWebTokenError') {
            statusCode = 401;
            errorCode = 'INVALID_TOKEN';
            message = 'Invalid authentication token';
        }
        else if (err.name === 'TokenExpiredError') {
            statusCode = 401;
            errorCode = 'TOKEN_EXPIRED';
            message = 'Token has expired';
        }
        
        // 6. Multer Errors
        else if (err.code === 'LIMIT_FILE_SIZE') {
            statusCode = 400;
            errorCode = 'FILE_TOO_LARGE';
            message = 'File size exceeds limit';
        }
        
        // 7. Development environment - show stack trace
        const isDevelopment = process.env.NODE_ENV === 'development';
        const response = {
            success: false,
            error: {
            code: errorCode,
            message: message,
            ...(details && { details }),
            ...(isDevelopment && { stack: err.stack }),
            ...(isDevelopment && { raw: err.message })
            }
        };

        res.status(statusCode).json(response);
        };

        module.exports = errorHandler;