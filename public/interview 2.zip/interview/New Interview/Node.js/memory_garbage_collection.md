# Garbage collection
    is the automatic memory management mechanism in Node.js
    that identifies and reclaims memory occupied by objects
    that are no longer reachable or in use by the application.

Core Concepts
Term	           Description
Heap	            Memory region where objects, functions, arrays are stored
Stack	            Memory for primitive values and function calls
Reachable	        Objects still accessible from root references
Unreachable	        Objects with no references - candidates for GC
Memory Leak	        Unreachable objects not being collected


V8 Memory Layout visualization

# Node.js leverages Google's V8 engine to manage memory automatically through GC
    generational garbage collector
        which splits the heap into New space and old space based on object lifecycle
    
    New Space: (Young Generation): (Scavenge Algorithm)
        A highly dynamic area where almost all new objects are initially allocated.
        small 16gb to 64gb and designed rapid cleanup

        Mechanics of Cheney's Algorithm
            A New Space is divided into the 2 semi-spaces
                From-space and To-Space
        
            1. Allocation Phase: New objects are written sequentially to the active From-Space.
            2. Trigger Phase: When the From-Space fills up, a Minor GC cycle initiates.
    
    Old Space : (Old Generation):
        contains objects that have survived multiple cleanup cycles in the new spce are promoted here
        
        When the Old Space approaches capacity limits, V8 triggers a Major GC execution.
        Because the Old Space is vast, V8 cannot copy objects back and forth efficiently.
        It instead relies on a three-phase Mark-Sweep-Compact

        The Three Phases
            Mark (Tri-color Marking):
                The GC utilizes a logical graph-traversal system to identify live memory.
                Objects are classified via internal states:
                    White (unvisited/potential garbage),
                    Grey (visited, but child references are pending evaluation),
                    Black (visited alongside all downstream references).Once the marking process exhausts the graph, any remaining White objects are verified as unreachable dead memory.
            
            Sweep: The engine iterates across the unallocated or dead object addresses.
                   The memory addresses containing White objects are released back to the operating system's virtual memory map and recorded inside internal Free Lists.
            
            Compact: Continuous sweeping results in memory fragmentation (holes of free space scattered between surviving objects).
            The Compaction phase shifts surviving Black objects together into contiguous blocks to close these gaps, optimizing memory layout for faster sequential allocations.
            
        
        