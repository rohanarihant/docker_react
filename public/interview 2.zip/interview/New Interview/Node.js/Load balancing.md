# Cluster Load Balancing in Node.js
    Distribute incoming connections across multiple CPU cores by spawning child processes (workers)
    that share the same server port, overcoming Node.js's single-threaded limitation.

    Load Balancing Strategies
        Strategy	                    How it Works	                        Best For
        Round-Robin (default on Linux)	Cycles through workers sequentially	    Even distribution, simple workloads
        OS-based (SO_REUSEPORT)	        OS distributes connections	            High throughput, less predictable
        Custom (sticky sessions)	    Route based on IP/hash	                Stateful applications

        // Without clustering: 1 core used
        // 8-core server: 87.5% idle ❌

        // With clustering: All cores active
        // 8-core server: ~7-8x throughput ✅

    Under the Hood
        Master process:
            Listens on port
            Accepts connections
            Distributes to workers (round-robin)
            Doesn't process application logic
        Worker processes:
            Each runs separate Node instance
            Own event loop, memory space
            Processes requests independently
    
    Comparison Table
        Aspect	                Single Process	            Cluster Mode
        CPU utilization	        1 core only	                All cores
        Memory usage	        Low	                        Higher (N × memory)
        Fault tolerance	        Fatal crash	                Workers auto-restart
        Shared state	        N/A	                        Need Redis/external
        Throughput (8 cores)	1x	                        ~6-7x (some overhead)

    PM2, Container orchestration (K8s), Worker Threads


