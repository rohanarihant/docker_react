# Complete List of Global Properties
    // List all global properties
console.log(Object.keys(global));

/* Output (Node.js 18+):
[
  'global',
  'clearImmediate',
  'setImmediate',
  'clearInterval',
  'setInterval',
  'clearTimeout',
  'setTimeout',
  'queueMicrotask',
  'performance',
  'atob',
  'btoa',
  'fetch',
  'structuredClone',
  'FormData',
  'Headers',
  'Request',
  'Response',
  'AbortController',
  'AbortSignal',
  'Blob',
  'File',
  'Buffer',
  'process',
  'console',
  'URL',
  'URLSearchParams',
  'TextEncoder',
  'TextDecoder',
  'WebAssembly'
]
*/