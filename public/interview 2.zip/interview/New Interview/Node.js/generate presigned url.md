
Generating a presigned URL in Node.js is typically done using the AWS SDK for JavaScript (v3). A presigned URL lets you grant temporary, secure access to a specific object in an S3 bucket without exposing your AWS credentials

Configure your AWS credentials via environment variables, the AWS CLI, or IAM roles
. Ensure the IAM user/role has the necessary permissions (s3:PutObject for uploads, s3:GetObject for downloads)

⬆️ Generating a Presigned URL for Upload (PUT)
    This generates a URL that allows a client to upload a file directly to S3 using a PUT request.

    import { S3Client, PutObjectCommand } from "@aws-sdk/client-s3";
import { getSignedUrl } from "@aws-sdk/s3-request-presigner";

const s3Client = new S3Client({ region: "us-east-1" });

/**
 * Generates a presigned URL for uploading a file to S3
 * @param {string} bucketName - S3 bucket name
 * @param {string} key - Object key (path in bucket)
 * @param {number} expiresIn - Expiration time in seconds (default: 3600)
 * @param {string} contentType - Expected content type for validation
 * @returns {Promise<string>} Presigned URL
 */
export async function generateUploadUrl(bucketName, key, expiresIn = 3600, contentType) {
  const command = new PutObjectCommand({
    Bucket: bucketName,
    Key: key,
    ContentType: contentType, // Optional but recommended
    // ACL: 'bucket-owner-full-control' // Uncomment if needed for cross-account access
  });

  try {
    const signedUrl = await getSignedUrl(s3Client, command, { expiresIn });
    return signedUrl;
  } catch (error) {
    console.error("Error generating upload URL:", error);
    throw error;
  }
}


⬇️ Generating a Presigned URL for Download (GET)
    This generates a URL for downloading a private S3 object

    import { S3Client, GetObjectCommand } from "@aws-sdk/client-s3";
import { getSignedUrl } from "@aws-sdk/s3-request-presigner";

const s3Client = new S3Client({ region: "us-east-1" });

/**
 * Generates a presigned URL for downloading a file from S3
 * @param {string} bucketName - S3 bucket name
 * @param {string} key - Object key (path in bucket)
 * @param {number} expiresIn - Expiration time in seconds (default: 3600)
 * @returns {Promise<string>} Presigned URL
 */
export async function generateDownloadUrl(bucketName, key, expiresIn = 3600) {
  const command = new GetObjectCommand({
    Bucket: bucketName,
    Key: key,
  });

  try {
    const signedUrl = await getSignedUrl(s3Client, command, { expiresIn });
    return signedUrl;
  } catch (error) {
    console.error("Error generating download URL:", error);
    throw error;
  }
}

const downloadUrl = await generateDownloadUrl('my-bucket', 'reports/sales.pdf', 120);
console.log('Download URL:', downloadUrl);
// Client can now GET the file from this URL


🚀 Express.js API Endpoint Example
    Here's how you can expose these functionalities via a REST API endpoint:

    import express from 'express';
import { generateUploadUrl, generateDownloadUrl } from './s3-service.js';

const app = express();
app.use(express.json());

// Endpoint to get an upload URL
app.post('/api/upload-url', async (req, res) => {
  try {
    const { fileName, folder = 'uploads', fileType } = req.body;
    
    if (!fileName) {
      return res.status(400).json({ error: 'fileName is required' });
    }

    const key = `${folder}/${Date.now()}-${fileName}`;
    const signedUrl = await generateUploadUrl(
      process.env.S3_BUCKET_NAME,
      key,
      3600, // 1 hour
      fileType
    );

    res.json({
      uploadUrl: signedUrl,
      key: key,
      expiresIn: 3600
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Endpoint to get a download URL
app.get('/api/download-url/:key', async (req, res) => {
  try {
    const { key } = req.params;
    
    if (!key) {
      return res.status(400).json({ error: 'Key is required' });
    }

    const signedUrl = await generateDownloadUrl(
      process.env.S3_BUCKET_NAME,
      key,
      300 // 5 minutes
    );

    res.json({
      downloadUrl: signedUrl,
      expiresIn: 300
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.listen(3000, () => {
  console.log('Server running on port 3000');
});