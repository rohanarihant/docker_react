# Node.js Architecture
    when running any code in Node.js


                    V8 Engine                                                   Libuv
    Memory heap             call stack



# Libuv and async operations
    help to handle async operations
        like handeling n/w requests, it rely on OS primitives
        like async operations like reading a file that has no native OS support
            it reply on thread pool to ensure the main thread is not blocked


# Event loop
    its a design pattern that orchestrates or coordinates the execution of sync and async code in node.js
    EL will run continously as long as your node.js app is up and running
    handeling multiple operations executing concurrently

    6 different queues in event loop
    each holding one or more callback functions that need to be executed on the call stack eventually

    1st queue :- Time Queue,
        which hold callbacks associated with setTimeout and setInverval
    2nd Queue :- I/O Queue
        contains cb assiciated with async methods like fs and http modules
    3rd Queue :- Check Queue
        hold cb associated with the setImmediate func, which us specific to Node
    4th :- Close Queue
        hold cb associated with the close event of an async task
    
    Microtask Queue
        Next Tick Queue
            hold cb associated with process.nextTick function
        Promise Queue
            holds cb associated with native Promise in JS

    Imp:-
        Timer, I/O, Check and Close queues are all part of Libuv
        2 microtask queues are not part of libuv
            but they are part of Node Runtime and play and imp role in order of execution of cbs

            