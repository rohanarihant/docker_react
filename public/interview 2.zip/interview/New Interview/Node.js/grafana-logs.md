#   how to add logs from node express app to grafana ?

    🧱 The Core Architecture: Express + Loki
        Grafana Loki: A horizontally-scalable, highly-available log aggregation system that indexes your logs.
        Grafana: Connects to Loki as a data source, allowing you to query and visualize the logs in the Explore view

    🚀 Implementation Methods
        Method 1: Using a Logger with Built-in Loki Transport
            This is often the simplest method. Libraries like @zzazz/logger
            provide a comprehensive solution with minimal configuration

            Install: npm install @zzazz/logger
            Set Environment Variables: The library will automatically configure itself for Loki when these are set.
                USE_LOKI=true
                LOKI_URL='http://localhost:3100' # Or your Grafana Cloud Loki URL
                # LOKI_USERNAME and LOKI_PASSWORD if needed
            

            import express from 'express';
            import { requestLoggerMiddleware, logger } from '@zzazz/logger';

            const app = express();
            app.use(requestLoggerMiddleware); // Automatically logs requests

            app.get('/', (req, res) => {
            logger.info('Handling request', { path: req.path });
            res.send('Hello World');
            });

#   Method 2: Configuring a Loki Transport for Pino or Winston
        If you prefer using a dedicated logging library like Pino or Winston, you can add a Loki transport.

        Install: npm install pino pino-loki
        Configure: Create a Pino logger that uses the Loki transport to send logs in batches
            import pino from 'pino';
            import { LokiOptions } from 'pino-loki';

            const transport = pino.transport({
            target: "pino-loki",
            options: {
                host: 'https://your-loki-instance:3100',
                basicAuth: { username: "username", password: "password" },
                labels: { app: 'my-express-app' },
                batching: { interval: 5 } // Send logs every 5 seconds
            }
            });

            const logger = pino(transport);
            logger.info('This log goes to Loki!');

        pino-loki is highly configurable,
        allowing you to set labels,
        adjust batching intervals,
        and add authentication

#   🔑 Best Practices for Logging

        Use Structured (JSON) Logging: Don't log plain text. JSON logs are the standard for Loki and allow for powerful querying with LogQL.

        Add Labels: Use labels like app, service, and environment to easily filter and organize your logs in Grafana. Many logger integrations allow setting default labels.

        Include Correlation IDs: For distributed tracing, include IDs like trace_id and span_id in your logs. This allows you to trace a single request across multiple services. Middleware from logging libraries often does this automatically.