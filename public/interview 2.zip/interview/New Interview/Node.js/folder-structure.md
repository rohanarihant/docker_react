src/
├── config/
│   └── database.js
├── models/
│   ├── User.js
│   └── Product.js
├── controllers/
│   ├── userController.js
│   └── productController.js
├── services/
│   ├── userService.js
│   └── productService.js
├── middleware/
│   ├── auth.js
│   ├── validation.js
│   └── errorHandler.js
├── routes/
│   ├── index.js
│   ├── userRoutes.js
│   └── productRoutes.js
├── validators/
│   ├── userValidator.js
│   └── productValidator.js
├── utils/
│   ├── catchAsync.js
│   └── apiFeatures.js
└── app.js