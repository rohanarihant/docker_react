# 📚 What is the Cluster Module?
    The cluster module in Node.js allows you to create multiple child processes (workers)
    that all share the same server port.
    This enables you to take advantage of multi-core systems by
    distributing incoming connections across multiple CPU cores.

    🎯 Why Do We Need Clustering?
        The Problem: Single-Threaded Nature

        // A simple server running on a single core
            const http = require('http');

            const server = http.createServer((req, res) => {
            // CPU-intensive task blocks the event loop
            let sum = 0;
            for (let i = 0; i < 1e9; i++) {
                sum += i;
            }
            res.end(`Sum: ${sum}`);
            });

            server.listen(3000);
            // ❌ Only uses ONE CPU core
            // ❌ Heavy tasks block ALL requests

        The Solution: Clustering
            const cluster = require('cluster');
            const http = require('http');
            const os = require('os');

            const numCPUs = os.cpus().length;

            if (cluster.isMaster) {
            console.log(`Master ${process.pid} is running`);
            
            // Fork workers for each CPU core
            for (let i = 0; i < numCPUs; i++) {
                cluster.fork();
            }
            
            // Restart workers if they die
            cluster.on('exit', (worker, code, signal) => {
                console.log(`Worker ${worker.process.pid} died, restarting...`);
                cluster.fork();
            });
            } else {
            // Workers share the same port
            http.createServer((req, res) => {
                res.end(`Hello from worker ${process.pid}`);
            }).listen(3000);
            
            console.log(`Worker ${process.pid} started`);
            }

        🔄 How Cluster Works
            Architecture Diagram

                    ┌─────────────────────────────────────┐
                    │          Master Process             │
                    │         (Load Balancer)             │
                    └─────────────────────────────────────┘
                               │      │      │
                    ┌──────────┴──────┴──────┴──────────┐
                    │              │      │             │
            ┌───────▼───────┐ ┌───▼───────▼───┐ ┌──────▼──────┐
            │   Worker 1    │ │   Worker 2    │ │  Worker 3   │
            │   (Core 0)    │ │   (Core 1)    │ │  (Core 2)   │
            │   PID: 1234   │ │   PID: 1235   │ │  PID: 1236  │
            └───────────────┘ └───────────────┘ └─────────────┘

        Key Concepts
        Master Process:
            Primary process that manages workers
            Listens for incoming connections
            Distributes requests to workers
            Doesn't process requests itself

        Worker Processes:
            Child processes that handle actual requests
            Each runs on a different CPU core
            Identical to the master except they're workers
            Can crash independently without affecting others
        Load Balancing:
            Master uses a round-robin algorithm by default
            Distributes incoming connections evenly
            No single worker gets overwhelmed