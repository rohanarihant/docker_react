# Node.js

javascript is single threaded, blocking and synchronous


# Asynchronous in node.js
key component for asynchronous programming in Node.js is the external dependency, libuv
role is to provide support for handling asynchronous operations

# libuv
we execute an asynchronous method, libuv takes over the execution of the task. Libuv then runs the task using native asynchronous mechanisms of the operating system. In case the native mechanisms are not available or inadequate, it utilizes its thread pool to run the task, ensuring that the main thread is not blocked

# Event loop
it as a design pattern that orchestrates or coordinates the execution of synchronous and asynchronous code in Node.js

There are six different queues in every loop, each holding one or more callback functions that need to be executed on the call stack eventually (part of Libuv)

1st :- there is the timer queue which holds callbacks associated with setTimeout and setInterval
2nd :- is the I/O queue which contains callbacks associated with all the async methods such as methods associated with the fs and http modules
Idle/Prepare (Internal use)
Poll Phase (New I/O events, waiting)
3rd :- is the check queue which holds callbacks associated with the setImmediate function, which is specific to Node
4th :- is the close queue which holds callbacks associated with the close event of an async task

there is the microtask queue which contains two separate queues (not part of Libuv)
    nextTick queue which holds callbacks associated with the process.nextTick function
    Promise queue which holds callbacks associated with the native Promise in JavaScript

# 📊 Complete Request Flow
    How a Request is Processed

    ┌─────────────────────────────────────────────────────────────────┐
    │ 1. Client makes HTTP request                                    │
    │                                                                 │
    │    ┌─────────────────────────────────────────────────────┐      │
    │    │ 2. Event Loop receives request                      │      │
    │    │    - Checks if async operation needed               │      │
    │    └─────────────────────────────────────────────────────┘      │
    │                         │                                       │
    │                         ▼                                       │
    │    ┌─────────────────────────────────────────────────────┐      │
    │    │ 3. Is it a blocking operation?                      │      │
    │    │    (File I/O, DB query, crypto, etc.)               │      │
    │    └─────────────────────────────────────────────────────┘      │
    │                │                        │                       │
    │          Yes   │                        │   No                  │
    │                ▼                        ▼                       │
    │    ┌─────────────────────────────────────────────────────┐      │
    │    │ 4a. Offload to Thread Pool                          │      │
    │    │     - libuv handles blocking operation              │      │
    │    │     - Main thread continues                         │      │
    │    └─────────────────────────────────────────────────────┘      │
    │                         │                                       │
    │                         ▼                                       │
    │    ┌─────────────────────────────────────────────────────┐     │
    │    │ 5. Operation completes                              │     │
    │    │    - Callback is queued in event loop               │     │
    │    └─────────────────────────────────────────────────────┘     │
    │                         │                                       │
    │                         ▼                                       │
    │    ┌─────────────────────────────────────────────────────┐     │
    │    │ 6. Event loop picks up callback                    │     │
    │    │    - Executes callback in main thread             │     │
    │    └─────────────────────────────────────────────────────┘     │
    │                         │                                       │
    │                         ▼                                       │
    │    ┌─────────────────────────────────────────────────────┐     │
    │    │ 7. Response sent to client                         │     │
    │    └─────────────────────────────────────────────────────┘     │
    └─────────────────────────────────────────────────────────────────┘



# libuv in thread pool
as Node.js’s internal background worker pool for some expensive native operations.
some operations would block if Node did them directly, so Node sends them to libuv’s worker pool.

worker pool is used for things like:
    most async fs APIs
    crypto.pbkdf2(), crypto.scrypt(), crypto.randomBytes(), etc.
    dns.lookup()
    async zlib APIs

Default size is 4 threads, configurable with UV_THREADPOOL_SIZE before Node starts


## the libuv pool does not execute your JavaScript code. It executes internal native work. For CPU-heavy JS, use worker_threads

    # Thread Pool Starvation
        if all 4 threads are busy then it will wait for them to free

    # Increasing Pool Size
        Run this from terminal: UV_THREADPOOL_SIZE=8 node app.js

    # Network I/O Usually Does Not Use Thread Pool
        Most socket/network I/O is handled by the OS through non-blocking mechanisms and the event loop


# Streams
Node.js streams are a way to handle data piece by piece, instead of loading the whole data into memory at once.
They are used for large files, HTTP requests/responses, compression, uploads, downloads, logs, etc.

# Backpressure
 is Node’s way of preventing memory overload when data is produced faster than it is consumed. Writable streams signal pressure by returning false from write(), and emit drain when they are ready again.

when read speed is more then the write speed. in that case it will block or increases the list with number of requests
in that case it will proceed the requests in limit like read 5 and then write 5

# Graceful shutdown
 in Node.js means stopping an app in an orderly way instead of killing it abruptly.
For a server, it usually means:

Receive a shutdown signal, like SIGTERM or SIGINT
Stop accepting new requests
Let active requests finish
Close resources like database connections, queues, sockets, timers
Exit the process cleanly

Why it matters: without graceful shutdown, your app might drop active requests, leave database connections open, interrupt file writes, or lose queued work.

# Observability 
 in Node.js means making your application easy to understand from the outside while it is running.

 Instead of only knowing “the app is broken,” observability helps you answer:
    What happened?
    Where did it happen?
    Why did it happen?
    How bad is it?
    Which users or requests were affected?

    In Node.js, observability usually has three main parts:
    1. Logs
        Human-readable records of events.
    2. Metrics
        Numeric measurements over time, like request count, error rate, memory usage, CPU usage, response time, queue size.
        Example: “API latency is 450ms” or “error rate is 3%”.
    3. Traces
        A request’s journey through your system, especially useful in microservices.
        Example: one HTTP request hits your Node.js API, then calls a database, then a payment service, then returns a response.

    pino, winston for logging
    Prometheus/Grafana for metrics
    OpenTelemetry for traces
    Datadog, New Relic, Honeycomb, Sentry, Elastic, etc.

# Security
    in Node.js is about reducing the chances that your app leaks data, accepts malicious input, exposes secrets, or lets attackers abuse your server.

    1. Validate Input :- always validate the input like req.body, query and params
    2. Avoid SQL injection :- Do not build SQL with string concatenation.
    3. Hash passwords properly :- store encrypted passwords
    4. Use secure HTTP headers :- use helmet for secure headers
    5. Protect authentication tokens :- store secrets in env file
    6. Set safe cookies :- 
        res.cookie("session", token, {
            httpOnly: true,      :- prevents JavaScript access
            secure: true,        :- requires HTTPS
            sameSite: "strict".  :- helps reduce CSRF risk
        });
    7. add rate limiting
    8. handle cors carefully
    9. Do not leak errors
        Return safe messages to users, but log details internally.
    10. Limit request size
        app.use(express.json({ limit: "100kb" }));

# Streams and types
    A stream is an abstract interface for working with streaming data. It's particularly useful when dealing with large files or network communication, as it allows you to process data in small chunks rather than loading it all into memory at once.
    four fundamental types of streams

    1. Readable Streams
        A Readable stream is an abstraction for a source from which data can be consumed (read)
        You can pull data out of it, but you cannot write data to it
            Examples: fs.createReadStream(), process.stdin
    2. Writable Streams
        Writable stream is an abstraction for a destination to which data can be written
        You can send data to it, but you cannot read data from it
            Examples: fs.createWriteStream(), process.stdout, process.stderr, or HTTP server responses (on the server side)
    3. Duplex Streams
        implements both Readable and Writable interfaces
        reading and writing sides operate completely independently of each other
        Data written to the stream is not automatically available to be read from it
            Examples: Network sockets (net.Socket), crypto streams, or compression streams
    4. Transform Streams
        is a special type of Duplex stream where the output is causally computed from the input
        It manipulates or transforms the data while reading and writing
        Whatever you write into the stream is processed, modified, and then passed to the readable side
            Examples: zlib.createGzip() (compression), crypto.createCipheriv() (encryption)


# Explain the role of the EventEmitter.
    The EventEmitter is a class in Node.js that allows you to create custom events and listen for them. It's a key part of event-driven programming, enabling objects to communicate with each other through a notification mechanism.

# Describe the read-eval-print loop (REPL) in Node.js.
    The read-eval-print loop (REPL) is an interactive CLI tool that lets you execute code one line at a time.
    It's useful for testing small snippets of code and exploring the built-in Node object methods.

# Differentiate between child_process.fork() and child_process.spawn() in the child process module.
    child_process.spawn() launches a new process with a specific command, streaming its I/O.
    child_process.fork(), on the other hand, is a special case of spawn() that's designed for Node.js modules. It establishes a communication channel between the parent and child processes, allowing them to exchange messages.

# When would you use worker threads instead of a child process?
    Worker threads are ideal for CPU-intensive tasks that would otherwise block the main single thread. Unlike child processes, they share memory, making it easier to exchange data, but they should only be used for computation, not I/O.

# How does Node.js handle garbage collection?
    Node.js uses the V8 engine's garbage collector.
    It works in two phases:
    the "Scavenge" phase for new objects and
    the "Mark-Sweep" and "Mark-Compact" phases for older, more persistent objects.


# Cluster Module
    create multiple child processes (workers) that all shares the same server ports
    it enables node.js application to take advantage of multi core systems by distributing the load across multiple CPU cores

    by default Node.js is Single THreaded, it uses the one CPU core

    Cluster Module solve this :-
        Load Balancing :- incoming connections across multiple workers
        Zero Downtime :- during restarts (rolling restarts)
        Increased Performance :- and throughput
        Fault Isolation :- one worker crash will not bring the whole app down

# Worker Theads
    allow Node.js to perform CPU intensive JS operations in parallel threads
    unlike the cluster module, worker threads share memory and can transfer data more efficiently

        Key Differences from Cluster
            Feature	                Worker Threads	                    Cluster
            Memory	                Shared memory (SharedArrayBuffer)	Separate memory per process
            Communication	        Faster (memory sharing)	            Slower (serialization)
            Use Case	            CPU-intensive tasks	                Load balancing HTTP requests
            Overhead	            Lower	                            Higher
            Isolation	            Less isolated	                    Fully isolated


# Concurrency :- 
    Handling multiple tasks simultaneously
    Node.js Approach :- Async I/O + Event Loop
# Parallelism :-
    Executing multiple tasks at exact same time
        Worker Threads / Cluster

# Consistent hashing
    a distributed systems algorithmic pattern used to distribute data across a cluster of servers
    Unlike traditional hashing, which requires remapping nearly all keys when a server is added or removed
    consistent hashing ensures that only a tiny fraction of keys change locations during cluster resizing

    How Consistent Hashing Works
            [Server A] (Token: 90)
             /       \
            /         \
 [Server C]             [Server B] (Token: 180)
 (Token: 270)           /
            \         /
             \       /
           (Token: 360/0)

    1. The Hash Ring
        Instead of mapping keys directly to servers,
        both servers and data keys are mapped onto a conceptual circular space called a Hash Ring.
            The ring represents a fixed range of integer hash values, typically from 0 to 2³²-1.
            The circle wraps around so that 2³²-1 connects right back to 0.
    2. Placing Servers and Keys
        Servers are hashed by their identifier (like their IP address) 
        Data Keys are hashed using the exact same hashing function
    3. Routing Mechanism
        To find which server holds a specific data key,
        you locate the key's coordinate on the ring and walk clockwise until you encounter the first available server

# bundled dependencies
    Standard (dependencies)
        Downloaded dynamically from npm during consumer install.
        Registry Access Required? :- Yes, connection to registry is mandatory.
        Yes, semantic versioning (^ or ~) can fetch different patches.
    Bundled (bundledDependencies)
        Downloaded upfront by author; shipped inside your package .tgz.
        Registry Access Required? :- No, can install completely offline.
        No, consumer gets the exact byte-for-byte version you compiled.
    
    {
    "name": "my-enterprise-tool",
    "version": "1.0.0",
    "dependencies": {
        "lodash": "^4.17.21",
        "chalk": "^4.1.2",
        "axios": "^1.6.0"
    },
    "bundledDependencies": [
        "lodash",
        "chalk"
    ]
    }

        my-enterprise-tool-1.0.0.tgz
    ├── package/
    │   ├── package.json
    │   ├── index.js
    │   └── node_modules/         <-- Bundled packages are baked directly inside here
    │       ├── lodash/
    │       └── chalk/

# usePeerDependencies
    npm packages that a library requires to run
    but expects the host (consuming) application to provide

    The Problem Peer Dependencies Solve (The React Example)
        building a custom UI calendar component library called my-cool-calendar. It requires react to work

        if you install react 19 as a dependency and the global react is already there
        JavaScript bundles now have two distinct versions of React running simultaneously
        Because React maintains an internal global state instance,
        running duplicate copies causes runtime crashes and balloons bundle sizes

    If you use peerDependencies
        You state that you require react, but refuse to bundle it.
        The host app provides its own single copy,
        ensuring both your library and the main application share the exact same runtime instance.
    
    {
        "name": "my-cool-calendar",
        "version": "1.0.0",
        "peerDependencies": {
            "react": "^18.0.0 || ^19.0.0"
        }
    }

# lock down the versions in package-lock.json
    To lock down package versions securely and ensure identical builds across all environments,
    you must use specific npm commands and configuration strategies rather than editing package-lock.json manually

    1. Enforce Clean Installations (npm ci)
        Never use npm install on production, staging, or CI/CD servers.
        Instead, use npm ci (Clean Install).

        Strict Alignment:
            It deletes your node_modules folder and reconstructs
            it using only the exact versions specified in package-lock.json.
        Zero Modification:
            If package-lock.json does not perfectly match package.json,
            npm ci throws an immediate error and crashes the build instead of updating the lockfile
