# Complete Guide: Event Emitter in Node.js
    📚 What is Event Emitter?
        Event Emitter is a core Node.js module that implements the Observer Pattern. It allows objects to emit named events and listen for those events using callback functions. It's the backbone of Node.js's asynchronous, event-driven architecture.

        Think of it as a publish-subscribe system where:
            Emitters publish events
            Listeners subscribe to events
            When an event occurs, all subscribed listeners are notified
        
        🏗️ Basic Usage
            1. Creating an Event Emitter

            const EventEmitter = require('events');

            // Create an instance
            const myEmitter = new EventEmitter();

            // OR extend EventEmitter
            class MyClass extends EventEmitter {
            constructor() {
                super();
            }
            }

            2. Core Methods
                Method	                            Description
                .on(event, listener)	            Register a listener for an event
                .once(event, listener)	            Register a one-time listener
                .emit(event, ...args)	            Trigger an event with optional arguments
                .removeListener(event, listener)	Remove a specific listener
                .off(event, listener)	            Alias for removeListener
                .removeAllListeners([event])	    Remove all listeners for an event
                .listenerCount(event)	            Get number of listeners
                .eventNames()	                    Get array of event names

            3. Basic Example
                const EventEmitter = require('events');
                const emitter = new EventEmitter();

                // Register a listener
                emitter.on('greet', (name) => {
                console.log(`Hello, ${name}!`);
                });

                // Register another listener for same event
                emitter.on('greet', (name) => {
                console.log(`Welcome to the system, ${name}!`);
                });

                // Emit the event
                emitter.emit('greet', 'Alice');

                /* Output:
                Hello, Alice!
                Welcome to the system, Alice!
                */
            
            🚀 Real-World Examples
            1. HTTP Server (Built-in Node.js)
                Node.js's HTTP server is built on EventEmitter!

                const http = require('http');

                // Create server (extends EventEmitter internally)
                const server = http.createServer((req, res) => {
                // Handle request
                });

                // Listen for 'request' event
                server.on('request', (req, res) => {
                console.log(`Request received: ${req.url}`);
                res.end('Hello World');
                });

                // Listen for 'connection' event
                server.on('connection', (socket) => {
                console.log('New client connected');
                });

                // Listen for 'close' event
                server.on('close', () => {
                console.log('Server shutting down');
                });

                server.listen(3000);


