A chunking strategy is the systematic approach you use to break down large data, files, or operations into smaller, manageable pieces (chunks).
The right strategy depends on your specific use case—processing files, handling API responses, database operations, or streaming data.



# 🔥 Strategy 1: Batch Processing (Most Common)
    Use Case: Processing large datasets, database operations, API calls.

    Core Implementation
        // ============ GENERIC BATCH PROCESSOR ============
class BatchProcessor {
  constructor(options = {}) {
    this.batchSize = options.batchSize || 100;
    this.delayBetweenBatches = options.delayBetweenBatches || 100;
    this.maxConcurrent = options.maxConcurrent || 5;
    this.retryAttempts = options.retryAttempts || 3;
  }

  async process(items, processor, progressCallback = null) {
    const results = [];
    const total = items.length;
    let processed = 0;
    let failed = 0;

    // Create batches
    const batches = [];
    for (let i = 0; i < items.length; i += this.batchSize) {
      batches.push(items.slice(i, i + this.batchSize));
    }

    console.log(`📦 Total: ${total} items, ${batches.length} batches`);

    // Process batches with concurrency control
    const batchPromises = batches.map(async (batch, index) => {
      // Add delay between batches to prevent overwhelming
      if (index > 0) {
        await this.delay(this.delayBetweenBatches);
      }

      try {
        console.log(`📦 Processing batch ${index + 1}/${batches.length}...`);
        
        const batchResult = await this.processBatchWithRetry(batch, processor);
        processed += batchResult.processed;
        failed += batchResult.failed || 0;

        if (progressCallback) {
          progressCallback({
            batchIndex: index,
            totalBatches: batches.length,
            processed,
            total,
            failed,
            percentage: Math.round((processed / total) * 100)
          });
        }

        return batchResult;
      } catch (error) {
        console.error(`❌ Batch ${index + 1} failed:`, error);
        failed += batch.length;
        return { processed: 0, failed: batch.length, error };
      }
    });

    const batchResults = await Promise.all(batchPromises);
    
    return {
      total,
      processed,
      failed,
      results: batchResults,
      percentage: Math.round((processed / total) * 100)
    };
  }

  async processBatchWithRetry(batch, processor) {
    let lastError;
    
    for (let attempt = 1; attempt <= this.retryAttempts; attempt++) {
      try {
        // Parallel processing within batch
        const batchPromises = batch.map(item => processor(item));
        const results = await Promise.all(batchPromises);
        
        return {
          processed: results.length,
          failed: 0,
          results,
          attempts: attempt
        };
      } catch (error) {
        lastError = error;
        console.warn(`⚠️ Batch failed (attempt ${attempt}/${this.retryAttempts}):`, error.message);
        
        if (attempt < this.retryAttempts) {
          await this.delay(this.delayBetweenBatches * attempt);
        }
      }
    }

    throw lastError;
  }

  delay(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }
}

// ============ USAGE ============

// Example: Process database records
async function updateUsers() {
  const processor = new BatchProcessor({
    batchSize: 50,
    delayBetweenBatches: 200,
    maxConcurrent: 3,
    retryAttempts: 3
  });

  const users = await User.find({ status: 'pending' });
  
  const updateUser = async (user) => {
    user.status = 'active';
    user.updatedAt = new Date();
    await user.save();
    return user;
  };

  const progressCallback = (progress) => {
    console.log(`📊 Progress: ${progress.percentage}% (${progress.processed}/${progress.total})`);
  };

  const result = await processor.process(users, updateUser, progressCallback);
  
  console.log(`✅ Complete: ${result.processed} updated, ${result.failed} failed`);
  return result;
}


# 📁 Strategy 2: File Processing with Streams
    Use Case: Processing large files (logs, CSVs, videos) without memory issues.

    // ============ STREAM-BASED FILE PROCESSOR ============
const fs = require('fs');
const readline = require('readline');
const { Transform, pipeline } = require('stream');

class StreamFileProcessor {
  constructor(options = {}) {
    this.chunkSize = options.chunkSize || 64 * 1024; // 64KB
    this.highWaterMark = options.highWaterMark || 16 * 1024 * 1024; // 16MB
    this.encoding = options.encoding || 'utf8';
  }

  // ============ PROCESS LINE BY LINE (CSV/Logs) ============
  async processLineByLine(filePath, lineProcessor, batchSize = 100) {
    return new Promise((resolve, reject) => {
      let batch = [];
      let totalProcessed = 0;
      let batchCount = 0;

      const rl = readline.createInterface({
        input: fs.createReadStream(filePath, {
          highWaterMark: this.highWaterMark
        }),
        output: process.stdout,
        terminal: false
      });

      rl.on('line', async (line) => {
        // Pause stream if batch is full
        if (batch.length >= batchSize) {
          rl.pause();
          
          try {
            // Process batch
            const results = await Promise.all(
              batch.map(item => lineProcessor(item))
            );
            
            batchCount++;
            totalProcessed += results.length;
            console.log(`📦 Processed batch ${batchCount}: ${results.length} lines`);
            
            // Clear batch and resume
            batch = [];
            rl.resume();
          } catch (error) {
            rl.close();
            reject(error);
          }
        } else {
          batch.push(line);
        }
      });

      rl.on('close', async () => {
        // Process remaining lines
        if (batch.length > 0) {
          try {
            const results = await Promise.all(
              batch.map(item => lineProcessor(item))
            );
            totalProcessed += results.length;
            console.log(`📦 Final batch: ${results.length} lines`);
          } catch (error) {
            reject(error);
          }
        }
        
        console.log(`✅ Complete: Processed ${totalProcessed} lines`);
        resolve({ totalProcessed, batchCount });
      });

      rl.on('error', reject);
    });
  }

  // ============ PROCESS WITH TRANSFORM STREAM ============
  processWithTransform(inputPath, outputPath, transformFn) {
    return new Promise((resolve, reject) => {
      const readStream = fs.createReadStream(inputPath, {
        highWaterMark: this.highWaterMark
      });
      
      const writeStream = fs.createWriteStream(outputPath);
      
      const transformStream = new Transform({
        objectMode: true,
        transform: async (chunk, encoding, callback) => {
          try {
            const result = await transformFn(chunk.toString());
            callback(null, result);
          } catch (error) {
            callback(error);
          }
        }
      });

      pipeline(
        readStream,
        transformStream,
        writeStream,
        (error) => {
          if (error) {
            reject(error);
          } else {
            console.log('✅ File processed successfully');
            resolve();
          }
        }
      );
    });
  }

  // ============ PROCESS IN CHUNKS (Manual) ============
  async processInChunks(filePath, chunkProcessor) {
    const stats = fs.statSync(filePath);
    const fileSize = stats.size;
    const CHUNK_SIZE = this.chunkSize;
    let position = 0;
    let chunkNumber = 0;

    console.log(`📊 File size: ${(fileSize / 1024 / 1024).toFixed(2)} MB`);

    while (position < fileSize) {
      const fd = fs.openSync(filePath, 'r');
      const buffer = Buffer.alloc(CHUNK_SIZE);
      
      const bytesRead = fs.readSync(fd, buffer, 0, CHUNK_SIZE, position);
      fs.closeSync(fd);
      
      if (bytesRead === 0) break;
      
      chunkNumber++;
      console.log(`📦 Processing chunk ${chunkNumber} (${bytesRead} bytes)`);
      
      await chunkProcessor(buffer.slice(0, bytesRead), chunkNumber);
      
      position += bytesRead;
    }

    console.log(`✅ Complete: ${chunkNumber} chunks processed`);
  }
}

// ============ USAGE ============

// Example 1: Process CSV line by line
async function processCSV() {
  const processor = new StreamFileProcessor({
    chunkSize: 64 * 1024,
    highWaterMark: 16 * 1024 * 1024
  });

  const processUserLine = async (line) => {
    const [name, email, age] = line.split(',');
    // Process user data
    return { name, email, age: parseInt(age) };
  };

  const result = await processor.processLineByLine('users.csv', processUserLine, 100);
  console.log('✅ CSV processed:', result);
}

// Example 2: Process large log file
async function processLargeLogs() {
  const processor = new StreamFileProcessor();
  
  const processor = async (line) => {
    // Parse log line
    if (line.includes('ERROR')) {
      // Store error logs
      await storeErrorLog(line);
    }
    return { processed: true, line: line.substring(0, 100) };
  };

  await processor.processLineByLine('application.log', processor, 50);
}


# 🌐 Strategy 3: API Pagination
    Use Case: Handling large API responses with pagination.

    // ============ API PAGINATION HANDLER ============
class APIPaginator {
  constructor(options = {}) {
    this.pageSize = options.pageSize || 100;
    this.maxPages = options.maxPages || Infinity;
    this.delayBetweenRequests = options.delayBetweenRequests || 500;
    this.maxRetries = options.maxRetries || 3;
  }

  async fetchAll(fetcher) {
    let page = 1;
    let allData = [];
    let hasMore = true;

    while (hasMore && page <= this.maxPages) {
      console.log(`📦 Fetching page ${page}...`);
      
      try {
        const response = await this.fetchWithRetry(() => fetcher(page, this.pageSize));
        
        if (!response.data || response.data.length === 0) {
          hasMore = false;
          break;
        }

        allData = allData.concat(response.data);
        console.log(`✅ Page ${page}: ${response.data.length} items (Total: ${allData.length})`);

        // Check if we have all pages
        if (response.totalPages && page >= response.totalPages) {
          hasMore = false;
        }

        page++;

        // Add delay between requests
        if (hasMore && page <= this.maxPages) {
          await this.delay(this.delayBetweenRequests);
        }

      } catch (error) {
        console.error(`❌ Failed to fetch page ${page}:`, error);
        break;
      }
    }

    console.log(`✅ Complete: ${allData.length} items fetched across ${page - 1} pages`);
    return allData;
  }

  async fetchWithRetry(fetcher) {
    let lastError;
    
    for (let attempt = 1; attempt <= this.maxRetries; attempt++) {
      try {
        return await fetcher();
      } catch (error) {
        lastError = error;
        console.warn(`⚠️ Attempt ${attempt}/${this.maxRetries} failed`);
        
        if (attempt < this.maxRetries) {
          await this.delay(this.delayBetweenRequests * attempt);
        }
      }
    }
    
    throw lastError;
  }

  // ============ STREAMING PAGINATION ============
  async *fetchStream(fetcher) {
    let page = 1;
    let hasMore = true;

    while (hasMore && page <= this.maxPages) {
      try {
        const response = await this.fetchWithRetry(() => fetcher(page, this.pageSize));
        
        if (!response.data || response.data.length === 0) {
          hasMore = false;
          break;
        }

        yield {
          page,
          data: response.data,
          total: response.total || null,
          pages: response.totalPages || null
        };

        if (response.totalPages && page >= response.totalPages) {
          hasMore = false;
        }

        page++;

        if (hasMore && page <= this.maxPages) {
          await this.delay(this.delayBetweenRequests);
        }
      } catch (error) {
        console.error(`❌ Failed to fetch page ${page}:`, error);
        break;
      }
    }
  }

  delay(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }
}

// ============ USAGE ============

// Example: Fetch all users from API
async function fetchAllUsers() {
  const paginator = new APIPaginator({
    pageSize: 50,
    maxPages: 20,
    delayBetweenRequests: 200
  });

  const fetcher = async (page, limit) => {
    const response = await fetch(
      `https://api.example.com/users?page=${page}&limit=${limit}`
    );
    return response.json();
  };

  const allUsers = await paginator.fetchAll(fetcher);
  console.log(`✅ Total users: ${allUsers.length}`);
  return allUsers;
}

// Example: Stream API responses
async function streamUsers() {
  const paginator = new APIPaginator({ pageSize: 100 });
  
  const fetcher = async (page, limit) => {
    const response = await fetch(
      `https://api.example.com/users?page=${page}&limit=${limit}`
    );
    return response.json();
  };

  for await (const pageData of paginator.fetchStream(fetcher)) {
    console.log(`📦 Page ${pageData.page}: ${pageData.data.length} users`);
    // Process page data immediately
    await processUserBatch(pageData.data);
  }
}

# 🗄️ Strategy 4: Database Batch Processing
    Use Case: Large database operations (migrations, updates, exports).

    // ============ DATABASE BATCH PROCESSOR ============
class DatabaseBatchProcessor {
  constructor(model, options = {}) {
    this.model = model;
    this.batchSize = options.batchSize || 100;
    this.maxRetries = options.maxRetries || 3;
    this.delayBetweenBatches = options.delayBetweenBatches || 100;
  }

  // ============ BULK UPDATE ============
  async bulkUpdate(filter, update, options = {}) {
    const {
      batchSize = this.batchSize,
      progressCallback = null
    } = options;

    let totalUpdated = 0;
    let totalMatched = 0;
    let batchCount = 0;

    // Get total count
    const total = await this.model.countDocuments(filter);
    console.log(`📊 Total records to update: ${total}`);

    // Process in batches using pagination
    let skip = 0;
    
    while (skip < total) {
      batchCount++;
      
      const batch = await this.model.find(filter)
        .skip(skip)
        .limit(batchSize)
        .lean();

      if (batch.length === 0) break;

      try {
        const result = await this.model.updateMany(
          { _id: { $in: batch.map(doc => doc._id) } },
          update,
          { multi: true }
        );

        totalMatched += result.matchedCount || 0;
        totalUpdated += result.modifiedCount || 0;

        console.log(`📦 Batch ${batchCount}: ${batch.length} records (${totalUpdated}/${total} updated)`);

        if (progressCallback) {
          progressCallback({
            batch: batchCount,
            processed: Math.min(skip + batch.length, total),
            total,
            matched: totalMatched,
            updated: totalUpdated,
            percentage: Math.round((Math.min(skip + batch.length, total) / total) * 100)
          });
        }

        skip += batch.length;

        if (skip < total) {
          await this.delay(this.delayBetweenBatches);
        }

      } catch (error) {
        console.error(`❌ Batch ${batchCount} failed:`, error);
        // Retry batch
        if (batchCount <= this.maxRetries) {
          console.log(`🔄 Retrying batch ${batchCount}...`);
          continue;
        }
        break;
      }
    }

    return { total, totalMatched, totalUpdated, batchCount };
  }

#  // ============ BULK INSERT ============
  async bulkInsert(data, batchSize = this.batchSize) {
    const batches = [];
    for (let i = 0; i < data.length; i += batchSize) {
      batches.push(data.slice(i, i + batchSize));
    }

    console.log(`📦 Inserting ${data.length} items in ${batches.length} batches`);

    let totalInserted = 0;
    
    for (let i = 0; i < batches.length; i++) {
      try {
        const result = await this.model.insertMany(batches[i], {
          ordered: false // Continue on errors
        });
        
        totalInserted += result.length;
        console.log(`✅ Batch ${i + 1}/${batches.length}: ${result.length} inserted`);
        
        await this.delay(this.delayBetweenBatches);
        
      } catch (error) {
        console.error(`❌ Batch ${i + 1} failed:`, error);
        // Handle partial failures
        // You could retry or log failed items
      }
    }

    console.log(`✅ Total inserted: ${totalInserted} items`);
    return totalInserted;
  }

  // ============ STREAM PROCESSING ============
  async processWithStream(filter, processor, options = {}) {
    const {
      batchSize = this.batchSize,
      progressCallback = null
    } = options;

    const stream = this.model.find(filter)
      .lean()
      .cursor();

    let batch = [];
    let processed = 0;
    let batchCount = 0;

    return new Promise((resolve, reject) => {
      stream.on('data', async (doc) => {
        batch.push(doc);

        if (batch.length >= batchSize) {
          stream.pause();
          
          try {
            const results = await Promise.all(
              batch.map(doc => processor(doc))
            );
            
            batchCount++;
            processed += batch.length;
            
            console.log(`📦 Batch ${batchCount}: ${batch.length} records processed (${processed} total)`);
            
            if (progressCallback) {
              progressCallback({
                processed,
                batch: batchCount
              });
            }
            
            batch = [];
            stream.resume();
            
          } catch (error) {
            stream.destroy();
            reject(error);
          }
        }
      });

      stream.on('close', () => {
        // Process remaining items
        if (batch.length > 0) {
          Promise.all(batch.map(doc => processor(doc)))
            .then(() => {
              processed += batch.length;
              console.log(`✅ Final batch: ${batch.length} records`);
              resolve({ processed, batches: batchCount + 1 });
            })
            .catch(reject);
        } else {
          resolve({ processed, batches: batchCount });
        }
      });

      stream.on('error', reject);
    });
  }

  delay(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }
}

// ============ USAGE ============

// Example 1: Bulk update with progress
async function migrateUsers() {
  const processor = new DatabaseBatchProcessor(User, {
    batchSize: 200,
    delayBetweenBatches: 200,
    maxRetries: 3
  });

  const progressCallback = (progress) => {
    console.log(`📊 ${progress.percentage}% complete`);
  };

  const result = await processor.bulkUpdate(
    { status: 'pending' },
    { 
      $set: { 
        status: 'active',
        updatedAt: new Date()
      } 
    },
    { progressCallback }
  );

  console.log(`✅ Updated ${result.totalUpdated} users`);
}

// Example 2: Stream processing
async function processUserStream() {
  const processor = new DatabaseBatchProcessor(User);
  
  const processUser = async (user) => {
    // Custom processing per user
    if (user.score > 100) {
      user.tier = 'premium';
      await user.save();
    }
    return user;
  };

  const result = await processor.processWithStream(
    { status: 'active' },
    processUser,
    { batchSize: 50 }
  );

  console.log(`✅ Processed ${result.processed} users in ${result.batches} batches`);
}

# 🎯 Strategy 5: File Upload/Download Chunking
    Use Case: Large file transfers, resumable uploads.

    // ============ FILE CHUNK MANAGER ============
class FileChunkManager {
  constructor(options = {}) {
    this.chunkSize = options.chunkSize || 1024 * 1024; // 1MB
    this.uploadDir = options.uploadDir || './uploads';
    this.cache = new Map();
    this.timeout = options.timeout || 30 * 60 * 1000; // 30 minutes
  }

  // ============ CHUNK UPLOAD ============
  async uploadChunk(fileId, chunkIndex, totalChunks, data, filename) {
    const key = `${fileId}:${filename}`;
    
    // Get or create upload session
    if (!this.cache.has(key)) {
      this.cache.set(key, {
        chunks: new Map(),
        totalChunks,
        filename,
        created: Date.now()
      });
    }

    const session = this.cache.get(key);
    session.chunks.set(chunkIndex, data);
    session.lastUpdated = Date.now();

    console.log(`📦 Chunk ${chunkIndex + 1}/${totalChunks} received`);

    // Check if all chunks received
    if (session.chunks.size === totalChunks) {
      return await this.assembleFile(key);
    }

    return { status: 'in_progress', received: session.chunks.size, total: totalChunks };
  }

  // ============ ASSEMBLE FILE ============
  async assembleFile(key) {
    const session = this.cache.get(key);
    
    if (!session) {
      throw new Error('Session not found');
    }

    const { chunks, totalChunks, filename } = session;
    
    // Validate all chunks
    if (chunks.size !== totalChunks) {
      throw new Error(`Incomplete: ${chunks.size}/${totalChunks} chunks received`);
    }

    console.log(`🔨 Assembling ${filename}...`);

    // Ensure directory exists
    if (!fs.existsSync(this.uploadDir)) {
      fs.mkdirSync(this.uploadDir, { recursive: true });
    }

    // Assemble file
    const outputPath = path.join(this.uploadDir, `${Date.now()}-${filename}`);
    const writeStream = fs.createWriteStream(outputPath);

    // Write chunks in order
    for (let i = 0; i < totalChunks; i++) {
      const chunk = chunks.get(i);
      if (!chunk) {
        throw new Error(`Missing chunk ${i}`);
      }
      writeStream.write(chunk);
    }

    writeStream.end();

    // Clean up session
    this.cache.delete(key);

    console.log(`✅ File assembled: ${outputPath}`);
    
    return {
      path: outputPath,
      filename,
      size: fs.statSync(outputPath).size,
      chunks: totalChunks
    };
  }

  // ============ GET STATUS ============
  getUploadStatus(fileId, filename) {
    const key = `${fileId}:${filename}`;
    const session = this.cache.get(key);
    
    if (!session) {
      return { status: 'not_found' };
    }

    return {
      status: 'in_progress',
      received: session.chunks.size,
      total: session.totalChunks,
      percentage: Math.round((session.chunks.size / session.totalChunks) * 100),
      created: session.created,
      lastUpdated: session.lastUpdated
    };
  }

  // ============ CLEANUP ============
  cleanup() {
    const now = Date.now();
    let cleaned = 0;
    
    for (const [key, session] of this.cache) {
      if (now - session.lastUpdated > this.timeout) {
        this.cache.delete(key);
        cleaned++;
      }
    }
    
    if (cleaned > 0) {
      console.log(`🧹 Cleaned ${cleaned} expired upload sessions`);
    }
  }

  // Start cleanup interval
  startCleanup(interval = 5 * 60 * 1000) {
    setInterval(() => this.cleanup(), interval);
  }
}

// ============ EXPRESS ROUTE ============
const chunkManager = new FileChunkManager({
  chunkSize: 1024 * 1024,
  uploadDir: './uploads',
  timeout: 30 * 60 * 1000
});

// Start cleanup
chunkManager.startCleanup();

// Upload chunk endpoint
app.post('/upload/chunk', async (req, res) => {
  try {
    const { fileId, chunkIndex, totalChunks, filename } = req.body;
    const chunkData = Buffer.from(req.body.chunk, 'base64');
    
    const result = await chunkManager.uploadChunk(
      fileId,
      parseInt(chunkIndex),
      parseInt(totalChunks),
      chunkData,
      filename
    );
    
    res.json(result);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Upload status endpoint
app.get('/upload/status/:fileId/:filename', (req, res) => {
  const { fileId, filename } = req.params;
  const status = chunkManager.getUploadStatus(fileId, filename);
  res.json(status);
});

