# Complete Guide: File Uploading in Node.js
    File uploading is a common requirement in web applications. Node.js offers several approaches,
    from simple single-file uploads to complex multi-file streaming solutions.

    🚀 Method 1: Multer (Recommended)
        Multer is the most popular and easiest way to handle file uploads in Node.js.

        npm install multer

        Basic Setup

        const express = require('express');
const multer = require('multer');
const path = require('path');
const fs = require('fs');

const app = express();

// ============ CONFIGURATION ============

// 1. Configure storage
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    const uploadDir = 'uploads/';
    // Create directory if it doesn't exist
    if (!fs.existsSync(uploadDir)) {
      fs.mkdirSync(uploadDir, { recursive: true });
    }
    cb(null, uploadDir);
  },
  filename: (req, file, cb) => {
    // Generate unique filename
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
    const ext = path.extname(file.originalname);
    cb(null, file.fieldname + '-' + uniqueSuffix + ext);
  }
});

// 2. File filter (optional)
const fileFilter = (req, file, cb) => {
  const allowedTypes = ['image/jpeg', 'image/png', 'image/gif', 'application/pdf'];
  
  if (allowedTypes.includes(file.mimetype)) {
    cb(null, true);
  } else {
    cb(new Error('Invalid file type. Only JPEG, PNG, GIF, and PDF are allowed'), false);
  }
};

// 3. Create multer instance
const upload = multer({
  storage: storage,
  fileFilter: fileFilter,
  limits: {
    fileSize: 5 * 1024 * 1024 // 5MB limit
  }
});

// ============ ROUTES ============

// 1. Single file upload (field name: 'avatar')
app.post('/upload/single', upload.single('avatar'), (req, res) => {
  if (!req.file) {
    return res.status(400).json({ error: 'No file uploaded' });
  }

  res.json({
    message: 'File uploaded successfully!',
    file: {
      filename: req.file.filename,
      originalName: req.file.originalname,
      size: req.file.size,
      path: req.file.path,
      mimetype: req.file.mimetype
    },
    body: req.body // Other form fields
  });
}, (error, req, res, next) => {
  // Multer error handling
  res.status(400).json({ error: error.message });
});

// 2. Multiple files (same field)
app.post('/upload/multiple', upload.array('photos', 5), (req, res) => {
  if (!req.files || req.files.length === 0) {
    return res.status(400).json({ error: 'No files uploaded' });
  }

  res.json({
    message: `${req.files.length} files uploaded successfully!`,
    files: req.files.map(file => ({
      filename: file.filename,
      originalName: file.originalname,
      size: file.size,
      path: file.path
    })),
    body: req.body
  });
});

// 3. Multiple files (different fields)
app.post('/upload/fields', upload.fields([
  { name: 'avatar', maxCount: 1 },
  { name: 'gallery', maxCount: 5 },
  { name: 'documents', maxCount: 3 }
]), (req, res) => {
  res.json({
    message: 'Files uploaded successfully!',
    files: req.files,
    body: req.body
  });
});

app.listen(3000);