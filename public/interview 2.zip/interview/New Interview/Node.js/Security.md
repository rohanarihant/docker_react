# Securing a Node.js application requires a multi-layered Defense-in-Depth strategy

# 1. Preventing SQL & NoSQL Injection (SQLi / NoSQLi)
    Attackers inject malicious database commands into form fields or URL parameters to bypass authentication
    read sensitive data, or drop database tables

    // ❌ DANGEROUS: String concatenation allows SQL Injection
    const query = `SELECT * FROM users WHERE email = '${req.body.email}' AND password = '${req.body.password}'`;

    The Fix:
    Use Parameterized Queries / Prepared Statements: Always separate the query command from user-supplied data.
    Use an ORM/Query Builder: Libraries like Prisma, Knex, or Sequelize handle parameterization under the hood.

    // ✅ SECURE: Parameterized Query (pg / mysql2)
    const query = 'SELECT * FROM users WHERE email = $1 AND password_hash = $2';
    const values = [req.body.email, hashedPassword];
    const user = await db.query(query, values);

    // ✅ SECURE: Using an ORM (Prisma)
    const user = await prisma.user.findUnique({
    where: { email: req.body.email }
    });

    For MongoDB / Mongoose (NoSQL Injection):
        Sanitize query objects to prevent operators like {$ne: ""} from bypassing checks.
        Use express-mongo-sanitize to strip out $ and . characters from incoming request bodies.
    
#   2. Preventing Cross-Site Scripting (XSS)
    The Threat: Attackers inject malicious client-side JavaScript into your application,
        which gets rendered and executed in another user's browser (stealing session tokens or logging keystrokes).

    The Fix:
        Store Authentication Tokens in HttpOnly Cookies:
        JavaScript cannot read HttpOnly cookies, preventing XSS-based token theft.
        Sanitize HTML Input:
            If users are allowed to submit rich HTML text, sanitize it using libraries like isomorphic-dompurify or sanitize-html.
        Use Content Security Policy (CSP) Headers:
            Instruct browsers to only load scripts from trusted domains.
    
    // ✅ SECURE: Setting HttpOnly cookie for session/JWT
        res.cookie('token', token, {
        httpOnly: true, // Blocks client-side JS from reading cookie
        secure: process.env.NODE_ENV === 'production', // Requires HTTPS
        sameSite: 'strict',
        maxAge: 15 * 60 * 1000
    });

#   3. Preventing Cross-Site Request Forgery (CSRF)
    The Threat:
        An attacker tricks an authenticated user's browser into sending an unauthorized HTTP request
        (e.g., transfer money or change password) to your site using their active session cookies.
    The Fix:
        Set SameSite Flag on Cookies: Setting SameSite=Lax or SameSite=Strict prevents browsers from sending session cookies on cross-origin requests.
        Use Anti-CSRF Tokens: For state-changing requests (POST, PUT, DELETE), generate and validate an anti-CSRF token (e.g., using csrf-csrf or Double Submit Cookie pattern).
    
    // Setting SameSite flag on session cookies
    app.use(session({
    secret: process.env.SESSION_SECRET,
    cookie: {
        sameSite: 'lax', // Protects against most cross-site form POST attacks
        secure: true,
        httpOnly: true
    }
    }));

#   4. Hardening HTTP Headers with Helmet
    By default, Express advertises its framework identity (X-Powered-By: Express) and lacks security headers that browsers rely on to mitigate attacks.

    The Fix:
    Install and use helmet, which sets 15+ essential security headers automatically:

    const express = require('express');
    const helmet = require('helmet');
    const app = express();
    // Set security headers
    app.use(helmet());
    Helmet automatically enforces:
    X-Content-Type-Options: nosniff (Prevents MIME-type sniffing)
    X-Frame-Options: SAMEORIGIN (Prevents Clickjacking inside <iframe> tags)
    Strict-Transport-Security (HSTS: Forces HTTPS connections)
    Content-Security-Policy (Mitigates XSS)

#   5. Preventing Denial of Service (DoS) & Brute-Force Attacks
    The Threat: Attackers flood your endpoints with thousands of requests per second or submit oversized JSON payloads to crash your server process.

    The Fix:
        Apply Rate Limiting:
            Restrict the number of requests a single IP can make within a time window using express-rate-limit.

    Limit Request Payload Sizes: Prevent memory exhaustion by capping incoming JSON body sizes.

    const rateLimit = require('express-rate-limit');

    // Limit payload size (Default is 100kb if unspecified, but keep it tight)
    app.use(express.json({ limit: '10kb' }));

    // Rate limiter: Max 100 requests per 15 minutes per IP
    const limiter = rateLimit({
    windowMs: 15 * 60 * 1000,
    max: 100,
    message: { status: 429, message: 'Too many requests, please try again later.' }
    });

    // Apply rate limiter to all routes or sensitive endpoints (e.g., /api/auth/login)
    app.use('/api/', limiter);

#   6. Securing Dependencies & Supply Chain
    The Threat:
        Third-party npm packages can contain known vulnerabilities or malicious code injected via supply chain attacks.
    The Fix:
        Audit Dependencies Regularly: Run npm audit or pnpm audit in your CI/CD pipeline.
        Automate Fixes: Use tools like npm audit fix or integration services like Snyk or GitHub Dependabot.
        Lock Dependencies: Always commit package-lock.json or pnpm-lock.yaml to ensure deterministic builds.

