# maintain WebSocket-based interfaces
    WebSockets are persistent, stateful, bidirectional connections

    1. Connection Lifecycle Management (Heartbeats)
        The internet is full of quiet firewalls, proxies, and load balancers
        that will automatically kill idle TCP connections if no data passes through them for a few minutes.
        To keep connections alive, you must implement a Heartbeat (Ping/Pong) mechanism

        How it works: The server (or client) sends a lightweight ping packet every 20–30 seconds.
        The receiving end must instantly reply with a pong.

        Dead Connection Detection: If the server sends a ping and doesn't receive a pong within a specific timeout window, it should assume the client is dead, terminate the socket cleanly, and free up server memory.

    3. Horizontal Scaling and State Distribution
        A single server can only hold a finite number of concurrent open sockets
        To scale horizontally, you must place multiple backend nodes behind a load balancer.

            The Problem: Cross-Server Communication
                If User A is connected to Server 1, and User B is connected to Server 2,
                Server 1 has no native way to forward a message from User A to User B.

            The Solution: Redis Pub/Sub Adapter
                To solve this, connect all your WebSocket servers to a shared Redis Pub/Sub layer
                or message broker (like RabbitMQ/Kafka).

    WebSockets via Reverse Proxies: If running Nginx in front of your app,
    you must explicitly pass the connection upgrade headers:
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "Upgrade";

