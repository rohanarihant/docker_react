# Streaming APIs
    A Streaming API is an API design pattern that allows a server to send a continuous,
    real-time flow of data to a client over a single, long-lived network connection.

    Streaming API: 
        The client connects once. The server holds the connection open and streams
        a continuous pipeline of data packets (usually text, JSON, or binary chunks) down the wire.

    1. Server-Sent Events (SSE)
        SSE is a built-in web standard allowing servers to push real-time text updates to a browser over standard HTTP
        It is strictly unidirectional (data only flows from the server to the client).
            ** It uses the standard text/event-stream HTTP header to keep the connection alive.
    
    2. WebSockets
        WebSockets provide a full-duplex, bidirectional communication channel over a single TCP connection
        Both the client and the server can send data to each other at the exact same time with virtually zero latency

            The client establishes a standard HTTP connection and requests a protocol upgrade (Upgrade: websocket).
            Once approved, the underlying TCP connection stays open.

    3. gRPC Streaming (via HTTP/2)
        gRPC is an open-source, high-performance RPC framework created by Google.
        It leverages HTTP/2 to allow for true binary streaming
        It supports unary (standard request/response), server-side streaming, client-side streaming,
        and full bidirectional streaming

        How it works:
        It uses Protocol Buffers (Protobuf) to serialize data into an ultra-compact binary format instead of heavy JSON text strings