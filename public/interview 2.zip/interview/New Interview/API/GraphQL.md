# GraphQL
    is a query language for APIs and a runtime for executing those queries.
    Unlike REST, where you get fixed data structures, GraphQL allows clients to request exactly the data they need.

# typeDef
    accept string
    we are defining the schema in Todo and type Query for the query
        
        const server = new ApolloServer({
            typeDefs: `
            type todo {
                id: ID! (! is not null)
                title: String!
                completed: boolean
            }
            type Query {
                getTodos: [Todo]
            }
            `,
            resolvers: {
                Query: {
                    getTodos: async() => (await axios.get('https://jsonplaceholder.typicode.com/todos').data)
                }
            }
        })

# Client Query
    import { ApolloClient, InMemoryCache } from "@apollo/client"
    const client = new ApolloClient({
        uri: 'http://localhost:8000/graphql',
        cache: new InMemoryCache()
    })
    const query = `
        query GetTodos {
            getTodos {
                title
                completed
                user {
                  name
                }
            }
        }`
    <ApolloClient client={client}>
        <App>
    </ApolloClient>

    // ------------------------------------------------------------------------------------------------
        inside App.js
            import { gql, useQuery } from "@apollo/client"

            const query = gql`
                query GetTodosWithUser {
                    getTodos {
                        id
                        title
                        completed
                        user {
                            id
                            name
                        }
                    }
                }
            `

            function App(){
                const {data, loading} = useQuery(query)
            }

# What is GraphQL and how does it differ from REST?
    GraphQL is a query language for APIs developed by Facebook. Key differences from REST:
        Single endpoint: GraphQL uses one endpoint vs multiple REST endpoints
        Client-specified queries: Clients request exactly what they need, preventing over-fetching/under-fetching
        Strong typing: Schema defines all possible data and operations
        Real-time updates: Built-in support for subscriptions

# Explain GraphQL Schema and Types
    The schema is the contract between client and server. Key types include:

        # Scalar types
            type User {
                id: ID!          # Unique identifier (! Indicates that the field is Non-Nullable)
                name: String!    # Required string
                age: Int         # Nullable integer
                isActive: Boolean
                score: Float
                createdAt: DateTime  # Custom scalar
            }

        # Object types can implement interfaces
            interface Node {
                id: ID!
            }

        # Enum types
            enum UserRole {
            ADMIN
            USER
            GUEST
            }

# What are Resolvers and how do they work
    Resolvers are functions that resolve the value for a type or field. They follow a resolver chain:
        const resolvers = {
            // if we want to show user details which owns the todo
            Todo: {
                user: async(todo) => (
                    await axios.get(`https://jsonplaceholder.typical.com/users/${todo.id}`)
                ).data
            },
            Query: {
                user: (parent, args, context, info) => {
                // parent: result from parent resolver
                // args: arguments passed in query
                // context: shared context (auth, DB)
                // info: AST of the query
                return db.users.find(args.id);
                }
            }
        };