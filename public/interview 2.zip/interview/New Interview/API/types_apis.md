# Types of APIs


# REST
    2 main things
        URL and Method
            URL :-  where is the server
            Method :- get, post, put, patch and delete
    
    Anatomy of REST URL. :- server, version, resource, id, sub-resource

    No Bi-directional communication
        single req at a time

# GraphQ
    instead of sending the whole data it will responsd with specific requested data
    you exactly specify in query what piece of data you require

    3 main components
        Query :- GET to fetch Data
        Mutation :- PUT/Patch/Delete to change data
        Subscription :- Websocket Receive real-time updates

# Websocket API
    make a continues connection between client and server where they send and receive data
        client sends HTTP req with upgrade header
            GET /chat HTTP/1.1
            Upgrade: websocket
            Connection: Upgrade
            Sec-WebSocket-Key: sdafdfsdsfaf-fsadfdsfas
        
    Server Agrees
        HTTP/1.1 101 Switching Protocols
        Upgrade: websocket

    Connection States :-
        STATE               VALUE               MEANING
        connecting           0                  Handshake going on
        Open                 1                  Connected Can Send/Receive Messages
        Closing              2                  Connection Closing Down
        Closed               3                  Connection Closed Down

# Webhook
    is a machenism where server respond to server after an operation is done by requesting a API call

    Security in Webhook
        once payment is done server will req the url with secret token
        our app will first verify is this token is valid or not

# gRPC
    in microservices
        services will communicate with each other
        will comm through binary format not json
        5 times faster then REST

    GRPC Calls
        Unary :- one response for one request
        Server Streaming :- multiple responses for one request. e.g :- Live Order Tracking
        Client Streaming :- one response for multiple requests, e.g like file uploading
        Unary :- multiple responses for multiple requests

# HTTP2
    use multiplexing
        in one connection we can send multiple requests


    

