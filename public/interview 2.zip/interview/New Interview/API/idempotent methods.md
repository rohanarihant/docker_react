# Idempotent method
    is an HTTP or API request that can be called multiple times with the exact same side effects as calling it a single time


    HTTP Method Classification
    
    HTTP Method  Idempotent?   Safe? (Read-Only)      Description / Behavior
    GET          Yes           Yes                    Retrieving a resource multiple times changes nothing on the server.HEAD         Yes           Yes                    Same as GET, but only returns the headers 
    OPTIONS      Yes           Yes                    Inspects available communication options/methods for a URL.
    PUT          Yes           No                     Replaces a target resource entirely.
                                                      Updating it 1 time or 10 times results in the exact same state.
    DELETE      Yes             No                    Removes a resource. The first call deletes it;
                                                      subsequent calls find nothing, but the resource remains deleted.
    POST        No              No                    Creates a new resource.
                                                      Sending it 5 times creates 5 distinct, identical database records.
    PATCH       No              No                    Modifies parts of a resource.
                                                      Can be idempotent depending on implementation,
                                                      but is fundamentally non-idempotent (e.g., an increment instruction).
