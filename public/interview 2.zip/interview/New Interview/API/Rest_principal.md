# REST Principal

    Client-Server Separation

    Stateless
        ✅ No session state stored on server
        ✅ All state is stored on client
        ✅ Authentication tokens are sent with each request

    Cacheable
        ✅ Use HTTP caching headers
        ✅ Reduce server load
        ✅ Improve performance
        ✅ Cache-Control, ETag, Last-Modified

    Uniform Interface
        A consistent interface simplifies and decouples the architecture.
        This is the most important principle and has 4 sub-principles.

        a. Resource Identification
        b. Resource Manipulation Through Representations
            Resources are manipulated using representations (JSON, XML, etc.).
        c. Self-Descriptive Messages
            Each message contains enough information to describe how to process it.
        d. Hypermedia as the Engine of Application State (HATEOAS)
            Include links to related resources in the response.
            
    Layered System
        Client → Load Balancer → API Gateway → Authentication → Application Server → Database
        ↑                                                                    ↑
        └──────────────── Intermediaries are invisible ─────────────────────┘

    Code on Demand (optional)