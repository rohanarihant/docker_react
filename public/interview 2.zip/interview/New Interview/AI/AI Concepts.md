# Agentic AI


# Embeddings
    instead of storing text as words, we are storing it as number
    convert meaning into numbers
    embeding model takes a text and convert this into a vector.

# Langchain
    why we need?
        storing chat messages
        maintaining conversation context
        connecting to any personal information source
        might need to switch from one to another LLM

    Langchain is a abstraction layer
    that help us build AI agent with minimal code
