# LangChain
    is a framework that makes building LLM powered app easy
    used mainly to build straight forward chains and retrieval flows

    will unify the AI Api calling
    Community plugin :- there are couple of community packages. wheres
        if we are going to send a pdf to llm, and that pdf is having 1lakh tokens
        then we dont need to send all,
        we can use community package - pdf loader - it will create a chunk of pdf
        100 chunks of a pdf by using pdfLoader

        Vector - PDF - Vector
        vector search
        vector - DB store, PG vector

        Langchain will simplify this AI API calling, prebuild utility tools, prebuild packages, lot of pre build packages

# Langraph
    is a framework to orchestrate multi-step, stateful workflows using LLMs with a graph based structure

    e.g :- for a dynamic flow, for multiple steps, we can make a graph with langgraph
    for example a flight booking application


# LangSmith
    is a debugging and observability platform for LLP apps
        debugging, playground, prompt management, annotation, testing, monitoring

    track application lifecycle
    colleboration
    monitor LLM application
    
# feature
    Purpose
        LC :- toolkit to build LLM apps(chains tool, agents)
            if we are writing a simple linear workflows
        LG - framework to manage complex workflows with state
            used mainly for agents, use complex agents
    Styles
        Linear or reactive chains
            reactive - if we give sometask, it will return response
        Graph based, supports loops, retries, memory
    Best Use Case
        simple chatbots, RAG apps, tool usage
        Multi step workflows, agents with memory, conditional paths
    State handling
        statless or partially stateful
        fully statefull, remembers and transitions based on lofic
    Example Use
        Book a flight using a flight API
        plan a vaccation (ask budget -> choose flight -> book hotel -> loop if error)



    


