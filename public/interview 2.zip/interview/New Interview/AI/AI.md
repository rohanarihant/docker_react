# we can create some custom agents
    which will gonna tell what needs to be done
    do and don't
    instructions of what design and coding standards to follow

# custom agents
    in chat in agents drop down we can select an agent option
    or select the cutom agent option

* good practice to save them under .github folder

# 
    Orchestrator agent (send instruction to planner) ->
    Planner Agent (plan for changes) ->
    Coder Agent (not have any content will do the changes)

# subagent
    both agent and subagent let you parallelize the work
    but they operate differently
    choose based on wheather agents need to comm with each other

            Main Agent
        
    subagent    Subagent    Subagent
        |           |           |
      work        work        work
        |           |           |
      result      result      result
    
# Agent teams
            Main Agent
                |
        Spawn Team & Assign Tasks
                |
            Shared Task List
        |
    comm and
    claim tasks
        |
    Teammate
        |
      work

# Hooks
    shell scripts that fire at some specific lifecycle events regardless of what the model decides

    e.g sessionStart, sessionEnd, userPromptSubmitted

* Gilfoyle Code Review *

# Instruction
    Extensions to Agents.md that are loaded only on-demand to avoid initially polluting the context

# Model
    is by nature is an approaximation and it predicts the response based on the requests and data

# Prompt
    behind the scenes what happened when prompt run behind the scene
    text is broken into the tokens
    tekens :- are the actual units that model can read and write
              it can be word, sub-word, punctuation mark, or even parts of text that are broken into chunks
              given an integer number based on large vocabulary that the tokenizer uses
              each model comes with its own tokenizer
              so, no of token the same statement can produce could be diff based on the model which we choose to use
            
    context window :- these tokens are stored into the context window
        it is the maximum no of tokens that LLM can handle in single req
        hard limit is set for the model in training
    
        req tokens are sent to the LLM and response tokens are also stored in the context window
        now these response tokens are converted back into the response and sent back to us

        when we send the follow up questions, the history of previous messages are sent to LLM
        that is how it will produce a more relevent and more contextual info that is based on the conversation

        if context window is full, then it will remove the older messages

    Context Drift :-
        happens when a context window really grows and the recent messages takes more weightage over the past messages

        to avoid this, mostly tools use compaction
    Compaction :-
        is the process where chat application automatically summerize the previous messages
        so that automatic compaction doesn't happen
        we dont loose the core info, we maintain in the context
    
# Prompt Engg
    craft of phrasing a prompt tp reliably get good outputs
    including clear instructions, clar examples, role definations
    ouput formats, specifications, step-by-step guide etc

# System prompt
    get passed to the sys every single req that goes in
    this is like our claude.md or instructions file
    or github co-pilot instructions file that we create
    having a well defined prompt for system prompt help us to avoid context drift
    help us producing a good output w/o burning lot of tokens

# RAG (Retrieval Augmented Generation)
    we are able to retrieve data from external sources, that is not a part of actual training data
    we are augment the prompt and generate the response with new data
    we used special model called Embedding model
    when req prompt comes in
    passed to embedding model
    model generates series of vector embeddings
    they are not same as the tokens
    they are diff, are based on the relevance of the words and their meanings
    these embeddings turn the words into geometry, that allow us to perform special kind of search
    that is called semantic search
    that is not based on the keyword but based on the meaning
    e.g - questions like, how to fix an error?
    will be able to find troubleshooting guide as a relevent match
    once we got the top most matches. they are added to the original req prompt
    now that prompt has more info to be given to the LLM
    so that response could be more accurate

# Tools
    if we need real time info, we can use tools
    can be used independently or with RAG
    tools generally has the schema of all the tools that is available for LLM
    within this perticular app

# AI Agent
    is a system where LLM doesn't just answer a question
    or generate a single turn response
    but it is able to run this whole process in loop
    it is able to plan, call a tool, observe the result
    decide the next step and repeat this till the final goal is reached

    it is not only able to think, but able to act to achieve a goal based on clear executed plan




