# Hook
    Hooks are automatic triggers that enforce strict rules or run tasks at specific moments
    (e.g., auto-formatting a file every time it is saved, or blocking dangerous commands).

        Event-Driven: They are triggered by actions like Submitting a Prompt, Before a Tool Runs, After a Tool Runs, or Saving a File.

    
    
    claude.md is used 80% of the time
    but hook is used 100% of the time

    in .claude/strrings.local.json file
    write all the permissions that you allow
    you can specify hooks that you want claude to definitely use

    example :- 
         A "Pre-Tool Use" hook can automatically scan for forbidden terminal commands and block them before they run (e.g., stopping an accidental rm -rf).

    hooks: {
        PostToolUse: [
            {
                matcher: "Edit|Write"
                hooks: [
                    {
                        command: "npx prettier --write \"$CLAUDE_FILE_PATH\" || true
                    },

                ]
            },
            {
                matcher: "Edit|Write"
                hooks: [
                    {
                        command: "\"$CLAUDE_FILE_PATH\" && npm run typecheck
                    },

                ]
            }
        ]
    }