# Plugins
    are tools that connect an AI to external systems to fetch data or take actions
    (e.g., checking flight prices or adding a calendar event).


#   Plugins: The AI's Tools
        Plugins act as bridges between the AI's brain and external software applications.
        By default, a Large Language Model (LLM) only knows the data it was trained on
        and cannot interact with the live internet. Plugins solve this by providing API connections.

        Action-Oriented: They allow the AI to read or write data to external platforms.
        On-Demand: The AI decides to call a plugin only when your prompt requires it.
        Examples:
            Data Retrieval: A plugin that searches live stock market data.
            Workflow Automation: A plugin that allows the AI to create a Jira ticket or send a Slack message.
            Utility: A plugin that lets the AI execute Python code in a secure sandbox to solve complex math.   