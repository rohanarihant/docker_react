# /compact
    which frees up context and let you compact your conversation
    claude still remember what it is talking about
    but instead of keeping the entire memory in context
    it reduces and compact that memory

    it is also important to note down how much tokens our skills are using

# /clear
    which starts a completely new session
    empties out all of the memory it has


# create a subagent
    create a subagent to write tests for this repo
        it will free up the main thread of the claude code
        so you can continue to use Claude code for your task by writing code