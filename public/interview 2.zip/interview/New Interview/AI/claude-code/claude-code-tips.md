# Claude.md
    Provide Context to your best practices - Claude.md

    we can create with the best practices like
        1. Stack: React, Typescript, Next.js, React Query, Vite, Redux
        2. Code Style rules: no default exports, named functions, no iline styles
        3. Architectural decision :- why we choose x over y
        4. Rules: no commiting secrets, no skipping assessibility rules


    ## Code Style Rules

    - **No default exports** - always use named exports
    - **Named function declarations** - always use named exports
    - **No Inline styles** - always use named exports
    - **Typescript strict** - no `any`, no type assertions without justifications
    - **One Component per file** - file name matches the exported component name
    
    ## Architectural Decision
    
    - **Tank Stack query over plain `useEffect` + `useState`** - always use named exports

    ## Rules
    - **No secrets in commits** - never commit API keys, tokens,
    - **No skipping accessability attributes** - never commit API keys, tokens,