# Skills
    Skills are reusable instructions that teach the AI how to do specific,
    complex tasks (e.g., how to write code, review differences, or format a database query).

    
*    React-best-practices from vercel-labs

    we can download that repo from github and move it inside our
    .claude/skills folder

    inside skills we will start seeing them

*   Fallow skills
        delete dead code with confidence
        review hot-path changes harder
        refector where it pays
        retire stale feature flags

