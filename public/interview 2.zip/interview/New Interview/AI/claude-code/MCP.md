#   Model Context Protocol (MCP)
    MCP standardises how Large Language Models (LLMs) securely connect to data sources, tools, and developer platforms
    It solves the problem of needing to build a custom connection for every new tool or service you want your AI to access


    Before MCP,
        if you wanted five different AI models to interact with ten separate enterprise databases or tools,
        you had to build 50 unique custom integrations (N × M complexity)
    
        50 unique custom integrations (N × M complexity).
        With MCP, you build one standard client layer and one server layer.
        They communicate natively through JSON-RPC 2.0 via standard I/O (local terminal processes) or SSE (Server-Sent Events over HTTP)

    💡 Core Architectural Concepts
        MCP Host:
            The core software app where the AI model actually runs (e.g., Claude Desktop, Cursor, VS Code).
        MCP Client:
            An embedded module inside the application that maintains a secure, 1:1 data stream with external systems.
        MCP Server:
            A ultra-lightweight service that translates external systems (like databases, APIs, or filesystems)
            into structured tools, resources, and templates that the AI can instantly discover and use.

    An MCP Server exposes three main native primitives:
        Tools:
            Executable blocks of code controlled by the model (e.g., execute_sql_query, fetch_github_issue).
        Resources:
            Read-only data properties controlled by the application (e.g., file contents, API payloads).
        Prompts:
            Predefined conversational templates controlled directly by the end-user.
    
    ⚛️ Real-World Example: Building an MCP Client in React.js
        In modern production environments,
        React.js web applications frequently connect to remote
        MCP servers to embed robust chat assistant flows directly into customer UIs.


