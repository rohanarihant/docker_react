#   Custom Agents
    are specialized AI assistants configured with a specific persona, instructions,
    and tools to handle a dedicated role (e.g., a customer support agent or a coding expert).


#   Custom Agents: The Specialized Roles
    A custom agent is an independent AI setup configured to perform a specific job autonomously.
    It combines an LLM with specific system instructions, an internal memory structure,
    a reasoning loop, and access to a curated set of plugins or tools.

    Goal-Driven:
        You give an agent a high-level goal,
        and it breaks that goal down into a series of smaller tasks without needing step-by-step guidance.
    Persona & Guardrails:
        It operates under a strict system prompt that defines its boundaries, behavior, and tone.
    Examples:
        Custom GPTs / Claude Projects:
            A tailored assistant pre-loaded with your company's brand guidelines to write marketing copy.
        Autonomous Coding Agents:
            An agent that takes a bug report, reads the codebase, writes a fix, runs tests, and submits a pull request.
        Research Agents:
            An agent tasked with browsing multiple websites,
            cross-referencing information, and writing a comprehensive market report.
    