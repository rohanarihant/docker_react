# Big Bang Deployment
    we push all our changes at once
    this  causes a bit of downtime as we have to shut down the old sys to swtch on the new one.

    the downtme is usually short, but be careful.
    it can sting if things don't go as planned.
    if things go wrong we rollback to the previous version.
    rolling back is not a pain free process

    we still might disirupt users and there could be data implications.
    we need to have a solid roll back plan.

    this process is the only choice,
        when an intricate db upgrade is involved
        then we have the rolling deployment
        its more like a marathon than a sprint

    The process for a Big Bang deployment is straightforward:
        Prepare and test everything thoroughly in a pre-production environment.
        Stop all running instances of the current version of the software. This often includes a period of planned downtime.Deploy the new version, starting all its instances.
        Bring the system back online and direct all user traffic to the new version.

# Rolling Deployment :-

    this method let us incrementally update diff parts of the sys over time.
    its a staged rollout where we gradually deploy the new version of the app to the prod env

    e.g :-
    if we have 10 servers running our app
    we might deploy the new version to 1 server and bring it back online.
    once we confirm f everythiing is working as expected, we'll move on the second server and so on.

    this approach allows the new one to replace the old one, server by server, until the entire sys is updated.

    adv :- it usually prevents downtime.
    while we are updatng the one server, the others are still up and running, servng our users.
    Another adv is that we can spot and mitiigate any issues early during the rollout.

    this reduces the risk of widespread problems
    we are only ever exposing a small part of our sys to the new ver at any one time.

    rolling process is a slower process.
    while it reduces the risk of sys wide issues, it doesn't entirely eliminate it.

    this stretegy doesnt support targeted roll out.
    we can't controll whch users get the new version during the rollout.
    all users will gradually see the new ver as we update the servers.

    we can't direct the new ver to specific users based onn the creteria liike location, device type etc.

# Blue Green deployment
    here we maintain 2 identical prod envs, cleverly named blue and green.
    any given time, one side is active and visible and the other is idle.

    the active env(blue) serves the current live version of app to the users

    the idle(green) is our playground where  we can safely deploy and test the new version.

    when we have a new versoin ready to go, we deploy it to the green env
    while this is happening, the blue env is still live and serving the current version.
    QA will test the new version to the new env
    this give us the chance to catch and fix any bugs or issues before they reach our users.

    once the new versionn in the green env is deemed ready, we simply switch the load balancer to redirect traffic from the blue env to green one.

    users are seamlessly transitioned to the new version of the app with 0 downtime.
    now the blue env becomes idle and serves as our safety net.

    if we encounter any issue with new version
    quickly swtich back to the blue env.
    effectly rolling back to the previous version.

    while blue-green deployment allows for seamless transitions and easy rollbacks, there's a catch.
    we can't direct the new ver to specific users.
    the switch from blue to green happens for all users at once.

    it is also resource intensive
    maintaining 2 identical prod ennv doubles the infra and resource needs
    we could spin down the idle env b/w deplys but this introduces the complexity

    Blue Green dep have its high level if control and minimized risk,
    it will remainn a popular stretegy for smooth user exp and reliable rollbacks.


# Canary deployment
    iinstead of deploying the new version to all servers or users, we choose a small subset
    it can be a percentage of servers or a group of users, often selected based on certaiin creteria

    for e.g
        we might start deploying to a single server, or a small cluster, or even a certaiin graphiical location
        this allows us to monitor the performance of new version under real-world conds
        but much smaller scale

        if everything goes well and our new version performs as expected, we can gradually roll it out to the rest of the servers or users.
        if something got wrong we got a safety net
        we can halt the deployemnt, fix the issues and try again, all w/o impacting the majority of user base.

        this incremental approach offers us both safety and control.

        it also give us targetted rollback
        unliike rolling or blue-green depl, we can direct our canaries based on user-specific creteria like geo loc and device type

        challenges :-
            it req careful monitoring and automated testing for canaries.
            it req somewhat compelicated infra tooling to ramp up or halt the depl as needed.
            thisi can be complex to implement and manage, while dealiing with db schema and api compatibility changes

        this is not a single stretegy
        its often combined with Rolling dep to create an approach that brings together

    Routing Techniques for Targeted Canary Deployments
        Header-based Routing: 
            Routes requests based on a specific HTTP header.
            For example, a rule can send users with the header x-user-group: beta to the new version 
            Beta testing with specific user groups, A/B testing.
        Cookie-based Routing
            A user with a canary_user=true cookie will always see the canary version 
            Creating "sticky" sessions for a consistent user experience.
        Weight-based Routing
            Routes a fixed percentage (e.g., 10%) of all requests to the new version.
            This is often implemented with a hashing algorithm on a user ID or IP
            to keep the decision consistent for the same user 

            A simple first step for gradual, low-risk rollouts.
            
# feature toggles
    it stand a bit apart from other stretegies
    it not about dep a new version of entire app,
    rather managing a new feature within the app
    we introduce a toggle or switch in the code for new features.
    it allow us to turn on/off features for certain users or circumtances.

    like a gate, it controls who gets to see the new features.
    it can be used with any other stretegies we discussed
