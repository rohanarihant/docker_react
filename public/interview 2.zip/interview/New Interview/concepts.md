concepts

Microservices
MicroFrontend
Webpack (configuration and optimization)
GitHub Actions
kafka
gcp pub/sub
babel, vite
eslint, sonarcube
typescript
js
Frontend and Backend design patterns
transitive dependencies
abort controller
react 18+
CRP
