SOLID

**Single Responsibility Principal**
    class should have a single responsibility
    giving multiple responsibility to a class means when do like to make a  change can intruduce some bugs
    class should have one  reason to channge

    e.g
    Student class is responsible for doing the operations  for  studentt  related tasks   

    it doesn't mean class should do only one hing
    it means whattever class do can end up in blotted classes

**Open closed**
    code should be  open to extension and closed to modification
    if you need to add some  additional  functitonality  to app you shouldn't be editing existing classes
    or methods to do that.

    may cause some consecuences
    or you endup writinng or breaking the unit ttest cases

    instead of changing the code we can create a new class that implement the same innterface, we can acall this new method w/o affecting the other code in our app
    can use extennsion methods

**Liskov Substitution**
    it sates that a child class should be able to  do what a parent class can

    if we have a Parent class
                    |
                  child class
    
    if child class cant do all the functioanlities provided by parent then its not following the pricipal

    inn that case itt could be like that

                        Human
                    |           |
                |                   |
            |                           |
          Adult                       Child

**Interface Segregation**
    provide a contract which class have to implement

    you should only to implement the methods that you are actually going to use and you dont need to worry about calling some code that hasnn't bee implemented yet. 

**Dependency  Inversion**
    High level  modules shouldn't depend on Low-Level modules.
    thay should both depend on an abstractions.

    for e.g
    you have a service class that used to save some data to DB
    you can create an instance of the respository class on service

    but service will  depend upon lower level component repository
    to overcome this we can create ann interface for repo
    then inject an innterface of the repo into that class via consructor
    



are ACID compliannce
            Atomicity :- all or nothing transections
            Consistency :- data is valid before and after
            isolated :- multiple transections at a same time
            Durability :- Committed data is never lost