# Redis
    in-memory key-value data store, commonly used for caching, sessions, rate limiting, queues, pub/sub, and distributed locks

    Basic commands: GET, SET, DEL, EXISTS, EXPIRE, TTL, INCR, DECR.
    TTL/expiration: keys can expire automatically.
    Eviction policies: what Redis removes when memory is full, like allkeys-lru, volatile-lru, allkeys-lfu.
    Persistence: RDB snapshots, AOF logs, or both.
    Pipelining: send multiple commands at once to reduce network overhead.
    Replication: primary-replica setup.
    Cluster/sharding: split data across nodes.
    Use cases: cache, session store, rate limiter, leaderboard, queue, real-time counters.
    Common risks: stale cache, cache stampede, hot keys, memory pressure, missing TTLs.


# Caching Patterns

    1. Cache-Aside / Lazy Loading
        Your app checks Redis first. If data is missing, it loads from DB, stores in Redis, then returns it.
            Good for: read-heavy APIs.
            Risk: data can become stale if DB changes but cache is not updated.

                async function getUser(userId) {
                    const cacheKey = `user:${userId}`;

                    const cached = await redis.get(cacheKey);
                    if (cached) {
                        return JSON.parse(cached);
                    }

                    const user = await db.users.findById(userId);

                    await redis.set(cacheKey, JSON.stringify(user), {
                        EX: 300
                    });

                    return user;
                }
    
    2.  Write-Through Cache
        When writing data, the app writes to Redis and DB together.
            Good for: keeping cache fresh after writes.
            Risk: writes are slower because both DB and cache are updated.

                async function updateUser(userId, updates) {
                    const user = await db.users.update(userId, updates);

                    await redis.set(`user:${userId}`, JSON.stringify(user), {
                        EX: 300
                    });

                    return user;
                }
    
    3. Write-Around Cache
        Writes go only to the DB. Cache is updated later only when someone reads the data.
        Then next read uses cache-aside and reloads from DB.
            async function updateUser(userId, updates) {
                await db.users.update(userId, updates);
                await redis.del(`user:${userId}`);
            }
        // when we write the data it will writes to db and when we try to read it will read from db and update the cache with that data
        Good for: data that is written often but not always read.
        Risk: first read after update is slower.
    
    4. Write-Behind / Write-Back Cache
        App writes to Redis first. Redis or a background worker writes to DB later.
            async function updateViewCount(postId) {
                await redis.incr(`post:${postId}:views`);
            }
                Later, a worker syncs counts to DB:
            async function syncViewCounts(postId) {
                const views = await redis.get(`post:${postId}:views`);

                await db.posts.update(postId, {
                    views: Number(views)
                });
            }

        Good for: high-volume counters, analytics, likes, views.
        Risk: possible data loss if Redis fails before data is saved to DB.

    5. Read-Through Cache
        The app asks the cache for data, and the cache itself knows how to load from DB on miss.
        Conceptually:
            const user = await cache.get("user:42");
            The cache layer handles:

        if missing -> load from DB -> store -> return
        In Node.js, this is usually implemented with a wrapper function or caching library.

        Good for: cleaner application code.
        Risk: more abstraction and harder debugging.
    
    6. Cache Invalidation
        When DB data changes, delete or update the cache.
        async function deleteUser(userId) {
            await db.users.delete(userId);
            await redis.del(`user:${userId}`);
        }
            Common strategy:
                Update DB first
                Then delete Redis key
                Why delete instead of update? Because the next read will fetch fresh data from DB.
    
    7. Cache Stampede Protection
        A cache stampede happens when many requests miss the cache at the same time and all hit the DB.
            Bad:
                1000 requests -> Redis miss -> 1000 DB queries

    Quick Interview Summary
        Cache-aside: app reads Redis, falls back to DB on miss.
        Write-through: write DB and cache together.
        Write-around: write DB, delete/skip cache.
        Write-behind: write cache first, DB later.
        Read-through: cache layer loads DB automatically.
        Invalidation: delete/update cache when DB changes.
        Stampede control: lock or single-flight so one request rebuilds cache.

    
# Streams
    Redis Streams are append-only logs of events.
    They are useful for queues, event processing, background jobs, audit logs, and async workflows.

    Interview note:
        XADD adds event
        XREAD reads stream
        XGROUP creates consumer group
        XREADGROUP lets workers share work
        XACK marks event as processed
        Pending entries are messages delivered but not acknowledged

# Memory / Eviction
    Redis stores data in memory, so memory management is important.

    Common eviction policies:
        Policy	Meaning
        noeviction	    Do not remove keys; writes fail when memory is full
        allkeys-lru	    Remove least recently used key from all keys
        volatile-lru	Remove least recently used key only among keys with TTL
        allkeys-lfu	    Remove least frequently used key from all keys
        volatile-lfu	Remove least frequently used key only among keys with TTL
        allkeys-random	Remove random key
        volatile-ttl	Remove keys with nearest expiry first
