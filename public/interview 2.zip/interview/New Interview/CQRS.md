# CQRS Architecture Explained
    Separate the responsibility for handling commands (writes) from queries (reads)
        different models, often different databases, potentially different optimization strategies.

            // Traditional CRUD: Same model for reads/writes
                class OrderController {
                updateOrder(id, data) {
                    const order = Order.findById(id);     // Read
                    order.status = data.status;           // Modify
                    order.save();                         // Write
                    return order;                         // Return same model
                }
                }

                // CQRS: Separate models entirely
                class OrderCommandHandler {
                handle(command) {
                    // Write-optimized model
                    OrderWriteModel.updateStatus(command.id, command.status);
                    eventBus.publish(new OrderUpdatedEvent(command.id));
                }
                }

                class OrderQueryHandler {
                query(id) {
                    // Read-optimized model (denormalized, cached)
                    return OrderReadModel.findById(id);  // Pre-joined, aggregated
                }
                }

# Why CQRS Excels in High-Throughput
    Challenge	            Traditional	            CQRS
    Read/write contention	Same DB = locks	        Separate DBs = zero contention
    Scaling requirements	Compromised	            Read/write scale independently
    Query complexity	    Slows writes	        Optimized for each operation
    Cache strategy	        Invalidation hell	    Read models pre-cached