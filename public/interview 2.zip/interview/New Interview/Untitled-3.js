// deep compare 2 objects in js

// check if null undefined
// check types
// check length
// check each key
// check recurrsively


function validateNestedObjects(obj1, obj2){
    if(obj1 === obj2){
        return true
    }
    if(!obj1 || !obj2){
        return false
    }
    if(typeof obj1 !== typeof obj2){
        return false
    }
    if(typeof obj1 !== 'object'){
        return obj1 === obj2
    }

    const keys1 = Object.keys(obj1)
    const keys2 = Object.keys(obj2)

    if(keys1.length !== keys2.length){
        return false
    }
    for(let key in keys1){
        if(!keys1.include(key)) return false

        const val1 = Object.values(obj1)
        const val2 = Object.values(obj2)
    
        if(!validateNestedObjects(val1, val2)) return false
    }
    return true
}

const objA = { name: "John", age: 25, address: { city: "NYC", zip: 10001 } };
const objB = { name: "John", age: 25, address: { city: "NYC", zip: 10001 } };
const objC = { name: "John", age: 30, address: { city: "NYC", zip: 10001 } };

console.log(validateNestedObjects(objA, objB)); // true
console.log(validateNestedObjects(objA, objC)); // false
