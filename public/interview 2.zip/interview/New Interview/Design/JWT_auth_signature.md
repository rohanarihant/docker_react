# JWT Authentication Signature Complete Guide

📚 What is JWT Signature?
    A JWT (JSON Web Token) signature is a cryptographic signature that verifies:
        Integrity - The token hasn't been tampered with
        Authentication - The token was issued by a trusted source
        Non-repudiation - The issuer can't deny creating it
    
    🔐 JWT Structure
        A JWT consists of three parts separated by dots:
            Header.Payload.Signature
        Example:
            eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjEyMywidXNlcm5hbWUiOiJqb2huZG9lIiwiaWF0IjoxNTE2MjM5MDIyfQ.SflKxwRJSMeKKF2QT4fwpMeJf36POk6yJV_adQssw5c
        
        🛠️ Signature Algorithms
            1. HS256 (HMAC with SHA-256) - Symmetric
                // Single secret key (shared between parties)
                    const signature = HMACSHA256(
                        base64UrlEncode(header) + "." + base64UrlEncode(payload),
                        secret
                    );
            
            2. RS256 (RSA with SHA-256) - Asymmetric
                // Private key for signing, public key for verification
                    const signature = RSASHA256(
                        base64UrlEncode(header) + "." + base64UrlEncode(payload),
                        privateKey
                    );
    
    📦 Complete Node.js Implementation
        npm install jsonwebtoken bcryptjs dotenv

        1. Basic JWT with HS256 (Symmetric)
            // auth.js
                const jwt = require('jsonwebtoken');
                const bcrypt = require('bcryptjs');

                // Secret key (store in .env)
                const JWT_SECRET = process.env.JWT_SECRET || 'your-secret-key-change-this';
                const JWT_EXPIRY = '7d';

                // ---------- SIGN (Create Token) ----------
                function signToken(userId, username, email) {
                // Payload - the data we want to encode
                const payload = {
                    userId: userId,
                    username: username,
                    email: email,
                    // Optional: add more claims
                    role: 'user',
                    permissions: ['read', 'write']
                };

                // Sign the token
                const token = jwt.sign(
                    payload,           // Payload
                    JWT_SECRET,        // Secret key
                    { 
                    expiresIn: JWT_EXPIRY,
                    issuer: 'my-app',
                    audience: 'my-app-users',
                    algorithm: 'HS256'
                    }
                );

                return token;
                }

                // ---------- VERIFY (Validate Token) ----------
                function verifyToken(token) {
                try {
                    const decoded = jwt.verify(token, JWT_SECRET, {
                    issuer: 'my-app',
                    audience: 'my-app-users'
                    });
                    return { valid: true, decoded };
                } catch (error) {
                    return { 
                    valid: false, 
                    error: error.message,
                    expired: error.name === 'TokenExpiredError'
                    };
                }
                }

                // ---------- DECODE (Without Verification) ----------
                function decodeToken(token) {
                return jwt.decode(token);
                }

                // ---------- Full Example ----------
                async function authExample() {
                // 1. Create token
                const token = signToken(123, 'john_doe', 'john@example.com');
                console.log('Generated Token:', token);
                console.log('Token Length:', token.length);

                // 2. Decode without verification (dangerous!)
                const decoded = decodeToken(token);
                console.log('Decoded (unverified):', decoded);

                // 3. Verify token
                const result = verifyToken(token);
                console.log('Verification Result:', result);

                // 4. Try with tampered token
                const tamperedToken = token.slice(0, -5) + 'xxxxx';
                const tamperedResult = verifyToken(tamperedToken);
                console.log('Tampered Verification:', tamperedResult);

                return token;
                }

                authExample();

    🚀 Express.js Authentication Middleware

    2. Complete Auth System with User Registration & Login
        // server.js
const express = require('express');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const mongoose = require('mongoose');

const app = express();
app.use(express.json());

// ---------- Database Models ----------
const UserSchema = new mongoose.Schema({
  username: { type: String, required: true, unique: true },
  email: { type: String, required: true, unique: true },
  password: { type: String, required: true },
  role: { type: String, enum: ['user', 'admin'], default: 'user' },
  refreshTokens: [{ type: String }],
  createdAt: { type: Date, default: Date.now }
});

const User = mongoose.model('User', UserSchema);

// ---------- Configuration ----------
const JWT_SECRET = process.env.JWT_SECRET || 'your-super-secret-key-12345';
const REFRESH_SECRET = process.env.REFRESH_SECRET || 'refresh-secret-key-67890';
const ACCESS_EXPIRY = '15m';      // Short-lived access token
const REFRESH_EXPIRY = '7d';      // Long-lived refresh token

// ---------- Token Generation Functions ----------
function generateAccessToken(user) {
  const payload = {
    userId: user._id,
    username: user.username,
    email: user.email,
    role: user.role
  };

  return jwt.sign(
    payload,
    JWT_SECRET,
    { 
      expiresIn: ACCESS_EXPIRY,
      issuer: 'my-app',
      audience: 'my-app-users'
    }
  );
}

function generateRefreshToken(user) {
  const payload = {
    userId: user._id,
    type: 'refresh'
  };

  return jwt.sign(
    payload,
    REFRESH_SECRET,
    { 
      expiresIn: REFRESH_EXPIRY,
      issuer: 'my-app',
      audience: 'my-app-users'
    }
  );
}

function generateTokens(user) {
  const accessToken = generateAccessToken(user);
  const refreshToken = generateRefreshToken(user);
  
  return {
    accessToken,
    refreshToken,
    expiresIn: '15m'
  };
}

// ---------- Authentication Middleware ----------
function authenticateJWT(req, res, next) {
  // Get token from Authorization header
  const authHeader = req.headers.authorization;
  const token = authHeader && authHeader.split(' ')[1]; // Bearer TOKEN

  if (!token) {
    return res.status(401).json({ 
      error: 'Access token required',
      message: 'No token provided'
    });
  }

  try {
    // Verify the token
    const decoded = jwt.verify(token, JWT_SECRET, {
      issuer: 'my-app',
      audience: 'my-app-users'
    });

    // Attach user info to request
    req.user = decoded;
    next();
  } catch (error) {
    if (error.name === 'TokenExpiredError') {
      return res.status(401).json({ 
        error: 'Token expired',
        code: 'TOKEN_EXPIRED'
      });
    }
    return res.status(403).json({ 
      error: 'Invalid token',
      message: error.message 
    });
  }
}

    // ---------- Role-Based Authorization Middleware ----------
    function authorize(roles = []) {
    return (req, res, next) => {
        if (!req.user) {
        return res.status(401).json({ error: 'Unauthorized' });
        }

        if (roles.length && !roles.includes(req.user.role)) {
        return res.status(403).json({ 
            error: 'Forbidden',
            message: 'Insufficient permissions'
        });
        }

        next();
    };
    }

    // ---------- Routes ----------

    // 1. Register
    app.post('/api/auth/register', async (req, res) => {
    try {
        const { username, email, password } = req.body;

        // Check if user exists
        const existingUser = await User.findOne({ 
        $or: [{ email }, { username }] 
        });

        if (existingUser) {
        return res.status(400).json({ 
            error: 'User already exists' 
        });
        }

        // Hash password
        const hashedPassword = await bcrypt.hash(password, 10);

        // Create user
        const user = new User({
        username,
        email,
        password: hashedPassword,
        role: 'user'
        });

        await user.save();

        // Generate tokens
        const tokens = generateTokens(user);

        res.status(201).json({
        message: 'User created successfully',
        user: {
            id: user._id,
            username: user.username,
            email: user.email,
            role: user.role
        },
        ...tokens
        });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
    });

    // 2. Login
    app.post('/api/auth/login', async (req, res) => {
    try {
        const { username, password } = req.body;

        // Find user
        const user = await User.findOne({ username });
        if (!user) {
        return res.status(401).json({ 
            error: 'Invalid credentials' 
        });
        }

        // Check password
        const isValidPassword = await bcrypt.compare(password, user.password);
        if (!isValidPassword) {
        return res.status(401).json({ 
            error: 'Invalid credentials' 
        });
        }

        // Update last login
        user.lastLogin = new Date();
        await user.save();

        // Generate tokens
        const tokens = generateTokens(user);

        res.json({
        message: 'Login successful',
        user: {
            id: user._id,
            username: user.username,
            email: user.email,
            role: user.role
        },
        ...tokens
        });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
    });

    // 3. Refresh Token
    app.post('/api/auth/refresh', async (req, res) => {
    try {
        const { refreshToken } = req.body;

        if (!refreshToken) {
        return res.status(401).json({ error: 'Refresh token required' });
        }

        // Verify refresh token
        let decoded;
        try {
        decoded = jwt.verify(refreshToken, REFRESH_SECRET);
        } catch (error) {
        return res.status(403).json({ error: 'Invalid refresh token' });
        }

        // Find user
        const user = await User.findById(decoded.userId);
        if (!user) {
        return res.status(404).json({ error: 'User not found' });
        }

        // Generate new tokens
        const tokens = generateTokens(user);

        res.json({
        message: 'Token refreshed',
        ...tokens
        });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
    });

    // 4. Logout
    app.post('/api/auth/logout', authenticateJWT, async (req, res) => {
    try {
        // Invalidate refresh token (if stored in DB)
        // For stateless JWT, client just discards token
        res.json({ message: 'Logged out successfully' });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
    });

    // 5. Get Current User (Protected)
    app.get('/api/auth/me', authenticateJWT, async (req, res) => {
    try {
        const user = await User.findById(req.user.userId).select('-password');
        if (!user) {
        return res.status(404).json({ error: 'User not found' });
        }
        res.json(user);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
    });

    // 6. Admin Only Route
    app.get('/api/admin/users', 
    authenticateJWT, 
    authorize(['admin']), 
    async (req, res) => {
        try {
        const users = await User.find().select('-password');
        res.json(users);
        } catch (error) {
        res.status(500).json({ error: error.message });
        }
    }
    );

    // 7. Public Route
    app.get('/api/public', (req, res) => {
    res.json({ message: 'This is a public endpoint' });
    });

    app.listen(3000, () => {
    console.log('Server running on port 3000');
    });


#   3. Use Secure Algorithms
    // ❌ BAD - Unsecure algorithms
    jwt.sign(payload, secret, { algorithm: 'none' }); // Never use!
    jwt.sign(payload, secret, { algorithm: 'HS256' }); // OK for simple apps
    jwt.verify(token, secret, { algorithms: ['HS256'] }); // Specify allowed algorithms

    // ✅ GOOD - More secure
    jwt.sign(payload, privateKey, { algorithm: 'RS256' });
    jwt.verify(token, publicKey, { algorithms: ['RS256', 'HS256'] });

#   4. Validate Issuer and Audience
    // Signing
    jwt.sign(payload, secret, {
        issuer: 'my-app',
        audience: 'my-app-users'
    });

    // Verification
    jwt.verify(token, secret, {
        issuer: 'my-app',
        audience: 'my-app-users'
    });

#   5. Include Required Claims
    // Standard claims
        const payload = {
            sub: userId,              // Subject (user ID)
            iss: 'my-app',            // Issuer
            aud: 'my-app-users',      // Audience
            exp: Math.floor(Date.now() / 1000) + (60 * 15), // Expiration
            iat: Math.floor(Date.now() / 1000), // Issued at
            nbf: Math.floor(Date.now() / 1000), // Not before
            jti: crypto.randomUUID()  // JWT ID (for revocation)
        };
