# Microservice
    Microservices is an architectural style where an application is composed of small, independent services that communicate over a network (usually HTTP/REST, gRPC, or message brokers).

    Key Characteristics
        Single Responsibility - Each service does one thing well
        Independent Deployment - Deploy without affecting others
        Decentralized Data - Each service owns its database
        Technology Agnostic - Different services can use different stacks
        Resilient - Failure in one doesn't crash everything



    Disadvantages
        Disadvantage	            Impact	                                        Mitigation
        Distributed transactions	Hard to maintain consistency	                Saga pattern, event sourcing
        Network                     latency	Slower than in-memory calls	Caching,    async communication
        Debugging complexity	    Tracing across services	                        Distributed tracing (Jaeger)
        Operational overhead	    More services to manage	Kubernetes,             containers
        Data consistency	        Eventual consistency needed	CQRS,               event-driven
        End-to-end testing	        Complex to test all services	                Contract testing, consumer-driven

# Design Patterns
    1. Decomposition Patterns
        Before you build, you must decide how to break your application apart cleanly into separate services.

        Decompose by Business Capability:
        Decompose by Subdomain (Domain-Driven Design):
        Strangler Fig Pattern: migrating old monalithic to microservices
    
    2. Integration and API Patterns
        API Gateway Pattern
            Instead of forcing a mobile client to make 15 separate HTTP requests to 15 separate microservices to render a single dashboard,
            the client connects to a single entry point: the API Gateway. The gateway acts as a reverse proxy, routing requests, aggregating data, and handling authentication/rate-limiting centrally.
        Backend for Frontends (BFF) Pattern
            A variation of the API Gateway. If you have both a desktop web app and a mobile app,
            they have different screen real estate and network constraints. You build a separate, dedicated gateway (BFF) for the mobile app (which returns lightweight, compressed data JSONs) and a separate BFF for the web app.
    
    3. Data Management Patterns
        CQRS (Command Query Responsibility Segregation)
            In a distributed system, a complex query might require joining data across 5 different service databases.
            CQRS solves this by completely splitting your application database architecture into two:

            Command Database: Highly optimized for writes/updates.
            Query Database: A separate read-only copy (often using an elasticsearch or a denormalized NoSQL database) highly optimized for fast, complex queries. They synchronize asynchronously using events.

            SAGA pattern
    4. Observability and Cross-Cutting Patterns 
        When an error occurs in a distributed system, tracing which microservice caused the bug can be incredibly difficult.
            Log Aggregation:
            Distributed Tracing:
            Health Check API:
    5. Resilience / Fault Tolerance Patterns
        If Service A calls Service B, and Service B is experiencing massive network latency,
        Service A's connection pool will back up, cascading the failure and crashing the whole application ecosystem.
            Closed State: Everything is normal; requests pass through.

            Open State: If a microservice starts failing repeatedly, the circuit breaker trips Open. Instead of wasting resources waiting for a timed-out connection, it immediately returns a fast error response or a cached fallback data payload to the user.

            Half-Open State: After a timeout period, the circuit enters a testing phase to see if the downstream service has recovered. If successful, the circuit closes again.
# How do microservices communicate
    Synchronous (HTTP/REST, gRPC)
        // Order service calls Payment service directly
            async function processOrder(order) {
            const payment = await axios.post('http://payment-service/charge', {
                amount: order.total,
                card: order.cardDetails
            });
            
            if (payment.data.success) {
                await updateOrderStatus(order.id, 'paid');
            }
            }
    Asynchronous (Message Broker - RabbitMQ, Kafka)
        // Order service publishes event
            async function processOrder(order) {
            await rabbitMQ.publish('order.created', {
                orderId: order.id,
                amount: order.total
            });
            // Don't wait for payment service
            }

            // Payment service listens
            rabbitMQ.consume('order.created', async (event) => {
            await chargeCard(event.amount);
            await rabbitMQ.publish('payment.processed', event.orderId);
            });

# What is API Gateway? Why use it?
    API Gateway is a single entry point for all microservices
        Request Routing:
        Authentication & Authorization: 
        Rate Limiting & Throttling:
        Load Balancing:
        Protocol Translation:
        Data Transformation: Modifies request or response payloads to match client or server expectations

        // Without Gateway - Client calls multiple services
            fetch('http://user-service/users/123');
            fetch('http://order-service/orders');
            fetch('http://product-service/products');

            // With Gateway - Client calls one endpoint
            fetch('http://api-gateway.com/api/users/123/orders/products');
            // Gateway routes to appropriate services

# How do you handle database transactions across services
    Use the Saga Pattern - a sequence of local transactions where each service updates its database and publishes events

    Order Processing Saga
        // Order Service - Start saga
            async function createOrder(orderData) {
            // Step 1: Create order (pending)
            const order = await Order.create({
                ...orderData,
                status: 'PENDING'
            });
            
            // Step 2: Reserve inventory
            await publishEvent('ORDER_CREATED', order);
            }

            // Inventory Service - Handle event
            async function handleOrderCreated(event) {
            try {
                await Inventory.reserveItems(event.orderId, event.items);
                await publishEvent('INVENTORY_RESERVED', event.orderId);
            } catch (err) {
                // Compensating transaction
                await publishEvent('INVENTORY_FAILED', event.orderId);
            }
            }

            // Payment Service - Handle inventory success
            async function handleInventoryReserved(event) {
            try {
                await Payment.chargeCard(event.orderId);
                await publishEvent('PAYMENT_SUCCESS', event.orderId);
            } catch (err) {
                await publishEvent('PAYMENT_FAILED', event.orderId);
            }
            }

            // Order Service - Handle payment success
            async function handlePaymentSuccess(event) {
            await Order.update(event.orderId, { status: 'COMPLETED' });
            }

            // Compensation (Rollback) handler
            async function handlePaymentFailed(event) {
            await publishEvent('ORDER_FAILED', event.orderId);
            // Inventory service will release reservation
            }

# How do you handle service discovery
    Service discovery allows services to find each other without hardcoded URLs
        Client-side discovery (Netflix Eureka)
            // Service registers itself
                @ServiceRegistry
                class ProductService {
                    @PostConstruct
                    register() {
                        eurekaClient.register({
                        app: 'product-service',
                        host: '192.168.1.100',
                        port: 3002,
                        healthCheckUrl: '/health'
                        });
                    }
                }

                // Client discovers service
                class OrderService {
                async callProductService(productId) {
                    // Get available instance
                    const instances = await eurekaClient.getInstances('product-service');
                    const productService = instances[0]; // Load balancing
                    
                    const product = await axios.get(`${productService.host}:${productService.port}/products/${productId}`);
                    return product;
                }
                }
    
        Server-side discovery (Kubernetes)
            # Kubernetes Service
                apiVersion: v1
                kind: Service
                metadata:
                name: product-service
                spec:
                selector:
                    app: product
                ports:
                    - port: 80
                    targetPort: 3002

                # Kubernetes automatically provides DNS
                # Order service calls: http://product-service/products/123

        Option 3: Service Mesh (Istio)
            # Istio VirtualService for intelligent routing
                apiVersion: networking.istio.io/v1beta1
                kind: VirtualService
                metadata:
                name: product-service
                spec:
                hosts:
                - product-service
                http:
                - match:
                    - headers:
                        version:
                        exact: v2
                    route:
                    - destination:
                        host: product-service
                        subset: v2
                - route:
                    - destination:
                        host: product-service
                        subset: v1

# Explain Circuit Breaker pattern
    Prevents cascade failures by stopping calls to failing services
        const CircuitBreaker = require('opossum');

            class PaymentService {
            constructor() {
                this.breaker = new CircuitBreaker(this.makePayment, {
                timeout: 5000,           // 5 second timeout
                errorThresholdPercentage: 50,  // Open at 50% failure
                resetTimeout: 30000      // Try again after 30 sec
                });
                
                this.breaker.on('open', () => {
                console.log('Circuit opened - Payment service is down');
                });
                
                this.breaker.on('halfOpen', () => {
                console.log('Testing if payment service recovered');
                });
            }
            
            async makePayment(paymentData) {
                return await axios.post('http://payment-service/charge', paymentData);
            }
            
            async processOrder(order) {
                try {
                const result = await this.breaker.fire(order.payment);
                
                // Success!
                return { status: 'success', transactionId: result.id };
                
                } catch (err) {
                // Circuit is OPEN or service failed
                
                if (this.breaker.opened) {
                    // Fallback: Save to retry queue
                    await this.saveToRetryQueue(order);
                    return { 
                    status: 'queued', 
                    message: 'Payment service unavailable, will retry later' 
                    };
                }
                
                // Other errors
                return { status: 'failed', error: err.message };
                }
            }
            
            async saveToRetryQueue(order) {
                await db.retryQueue.insert({
                orderId: order.id,
                retryCount: 0,
                createdAt: new Date()
                });
            }
            }

# What is the Database per Service pattern?
    Each microservice has its own database, never shared.
        // User Service - PostgreSQL
            const userDb = {
            host: 'postgres-user.cluster.com',
            database: 'user_db'
            };

            // Order Service - MongoDB (different tech!)
            const orderDb = {
            host: 'mongodb-order.cluster.com',
            database: 'order_db'
            };

            // Analytics Service - Cassandra
            const analyticsDb = {
            hosts: ['cassandra1:9042', 'cassandra2:9042'],
            keyspace: 'analytics'
            };

# How do you implement distributed tracing
    // Shared tracing library
        const { v4: uuidv4 } = require('uuid');
        const axios = require('axios');

        class Tracer {
        static createSpan(operationName, parentSpanId = null) {
            return {
            traceId: uuidv4(),
            spanId: uuidv4(),
            parentSpanId,
            operationName,
            startTime: Date.now()
            };
        }
        
        static injectHeaders(span) {
            return {
            'X-Trace-Id': span.traceId,
            'X-Span-Id': span.spanId,
            'X-Parent-Span-Id': span.parentSpanId || ''
            };
        }
        
        static extractHeaders(headers) {
            return {
            traceId: headers['x-trace-id'],
            spanId: headers['x-span-id'],
            parentSpanId: headers['x-parent-span-id']
            };
        }
        }

        // Order Service
        async function createOrder(orderData) {
        const span = Tracer.createSpan('create-order');
        
        console.log(`[Trace: ${span.traceId}] Creating order`);
        
        // Call User Service
        const userSpan = Tracer.createSpan('get-user', span.spanId);
        const user = await axios.get('http://user-service/users/123', {
            headers: Tracer.injectHeaders(userSpan)
        });
        
        // Call Payment Service  
        const paymentSpan = Tracer.createSpan('process-payment', span.spanId);
        const payment = await axios.post('http://payment-service/charge', 
            orderData.payment,
            { headers: Tracer.injectHeaders(paymentSpan) }
        );
        
        console.log(`[Trace: ${span.traceId}] Order completed in ${Date.now() - span.startTime}ms`);
        
        return { orderId: '123', traceId: span.traceId };
        }

        // Each service logs with trace ID
        // Later, use Jaeger to visualize entire request flow

# What is the Strangler Pattern for migration
    Gradually replace monolith with microservices
        // Step 1: Start with API Gateway routing to monolith
        // Strangler Application
        class StranglerGateway {
        constructor() {
            this.routes = {
            '/api/*': 'http://monolith:8080',  // All to monolith
            };
        }
        }

        // Step 2: Extract one feature
        class StranglerGateway {
        constructor() {
            this.routes = {
            '/api/users/*': 'http://user-service:3001',    // New microservice
            '/api/*': 'http://monolith:8080',              // Rest to monolith
            };
        }
        }

        // Step 3: Gradually extract more
        class StranglerGateway {
        constructor() {
            this.routes = {
            '/api/users/*': 'http://user-service:3001',
            '/api/products/*': 'http://product-service:3002', 
            '/api/orders/*': 'http://order-service:3003',
            '/api/reports/*': 'http://monolith:8080',      // Only reports left
            };
        }
        }

# How to handle configuration in microservices
    Externalized configuration with Config Server
        