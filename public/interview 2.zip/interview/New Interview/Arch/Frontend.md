#   FCP is "Did it start?"
    LCP is "Did it show up?"
    INP is "Does it respond?"

# Critical rendering Path
    is the process the browser needs to do
    in order to go from html, css and js to pixels on screen

    while rendering our code to browser
    first step is to render the html 
    it will generate the DOM tree of HTml element
    
    css will be the render block task
    it will load all of the css files then render it to the browser

    CSSOM
        only those node which has styles in it can be rendered

    Script tag
        it is parser blocking 
        it will download the 1st file and parse it and keep renndering
        then rest of the file keep on downloading and rendering

    Render Tree
        contains only those elements which are going to be displayed
        e.g :- display:none will not been displayed

        dom tree + css tree = render tree

    Layout
        will calculate the layout space, like width height for screen. desktop and mobile

    Paint
        take the nodes from render tree and screen size form layout and display it to screen

    Reflow
        

                                                    Server

                                                    HTML

                                        CSS         JS          FONT

                                        CSSOM             DOM

                                               RENDER TREE

                                                 RENDER

                                                 1. Style
                                                 2. Layout
                                                 3. Paint
                                                 4. Composite

                                               Display

# First Contentful Paint
    when browser renders the first piece of DOM content (text, images, canvas, svg etc)
    FCP is when the user knows the page is actually loading.
    FCP should be ≤ 1.8 seconds

    where it is working
        in Critical Rendering path
            FCP occure at the end of the sequence

        in CRP at the end after Layout
        at the time of the Paint -> The browser converts the Render Tree into pixels on the screen. This moment is FCP

    why it got delayed
        If your HTML contains a <script> tag (without async or defer),
        the browser stops parsing HTML, downloads,
        and executes the JavaScript before it can finish building the DOM.
        This delays FCP.

    Fast FCP (FCP is "Did it start?")
        A. Eliminate Render-Blocking Resources
            for critical CSS directly in the <head> using a <style> tag
            for non critical CSS load asynchronously using rel="preload" or media="print" trick.
           JavaScript :
            Add async or defer to all third-party and non-critical JS tags
            This prevents the browser from pausing DOM construction to download scripts.
        
        B. Minify and Compress
            Minify HTML, CSS, and JS (remove spaces, comments, unused code).
            Enable Brotli or Gzip compression on your web server. Smaller file sizes = faster download = faster FCP.


# Core Web Vitals
    empirical metrics that measure how fast a page load(CRP) and how fast it respond to input

    Largest Contentful paint (LCP) :- (Measure loading speed)
        measure at the time of Initial Render
        is the exact moment when the largest visible element in the viewport finishes rendering.
            This is usually:
                A hero image or carousel banner.
                A large heading (<h1>).
                A full-width video poster image.
                A background image loaded via CSS url().
                    The "Good" Threshold:
                        According to Google's Core Web Vitals, LCP must occur within ≤ 2.5 seconds of the page
                        starting to load.

        How LCP is calculated ?
            * Text/HTML elements: LCP happens during the initial Render Tree construction (fast).
            * <img> tags: LCP happens after the browser downloads the image file and decodes it into pixels.
            * CSS background images: LCP happens after the browser downloads the CSS file,
                parses it, realizes there is a background image, downloads that image, and decodes it.
            * <video> posters: LCP happens after the poster frame downloads.               

        Strategies to Optimize LCP
            Prioritize the LCP Image
                <link rel="preload"> specifically for your LCP image
            Add the fetchpriority="high" attribute directly to the <img> tag
                to tell the browser's scheduler to prioritize its decoding process
            Ditch Background Images for LCP
                If your image is a CSS background image
                    browser has to:
                        Download HTML → Parse HTML → Download CSS → Parse CSS → Discover background URL → Download image
                    Use a standard <img> tag in your HTML for LCP elements.
                        The browser discovers <img> src URLs while parsing HTML,
                        often a full 500ms faster than CSS backgrounds
            Upgrade to Next-Gen Formats
                A 5MB PNG will ruin your LCP. Use WebP or AVIF.
                    They are 25–50% smaller than JPEG/PNG with the same visual quality.
                    Smaller bytes = faster download = faster LCP

# Interaction on Next paint (INP) :- INP is "Does it actually work when I touch it?" (Measures responsiveness)
        measure at the time of Re-Render
            Interaction to Next Paint is a metric that measures responsiveness
                It captures the exact time (in milliseconds) from when a user initiates an interaction
                    (clicking a button, tapping a screen, or pressing a keyboard key)
                to the moment the browser visually paints the next frame in response to that interaction
                    The "Good" Threshold: INP score must be ≤ 200 milliseconds.
    
    The Crucial Shift: INP officially replaced First Input Delay (FID) in March 2024.
        FID only measured the delay before the browser could start processing the event.
        INP measures the entire round trip: the input delay + the event processing + the visual rendering time.
            It observes all interactions on the page, not just the first one.

        The Three Phases of INP :-
            Input Delay: The time between the user tapping/clicking and the browser's
                    main thread being able to start processing the event.
                    (If the main thread is busy parsing a giant JS file, this delay is huge).
            Processing Time: The time it takes for your JavaScript Event Listeners
                    (e.g., onClick, onKeyDown) to execute their callbacks.
            Presentation Delay: The time it takes for the browser to paint the new visual state
                    (the "Next Paint") to the screen after the JavaScript finishes.


# Cumulative Layout Shift (CLS) :- (Measure visual stability)
    measure at the time of Initial Render
    Cumulative Layout Shift is a metric that measures visual stability.
        It quantifies how much the visible elements on your page move (shift)
        unexpectedly during the entire lifespan of the page load.
    like text jumping when an ad loads.
    Target under 0.1

    Unlike FCP, LCP, and INP—which measure time (milliseconds)—CLS is a unitless score.


# Http Caching
    reusing the file (js, css) for a predefined time after first receiving it TTL
    we are caching the js, css and store them in browser cache

    server controls caching entirely through HTTP Response Headers
        A. Cache-Control (The Boss)
            max-age=31536000 :- browser can cache this for that much milliseconds
            no-cache :- it forces the browser to revalidate with the server every time before using the cached copy.
            no-store :- Do not store this file anywhere, not even on disk."
                        Used for sensitive data like bank account balances or CSRF tokens
            public :-  tells intermediate cache (like CDN) to cache this file
            private :- tells intermediate to not cache, only browser can cache this

        B. Expires :- by that specified date and time,
                      is older cache, takes time, until that time browser can cache

    Two Caching Strategies (Frontend Patterns)
        Strategy A: "Fingerprinted" Assets (Long Cache)
            Files: Bundled JS, CSS, and images
            Header: Cache-Control: public, max-age=31536000, immutable
                How it works: The immutable flag tells the browser "This file will NEVER change,
                        even if the user hits refresh." The browser caches it for a full year.
            The Catch: To update this file, you must change its filename (the hash/fingerprint) in your HTML.
                        If you change the code but keep main.js, the user will have the old code for a year.

        Strategy B: "HTML" Assets (Revalidate or Short Cache)
            Files: The main index.html (or the server-rendered page)
            Header: Cache-Control: no-cache (or max-age=300)
            How it works: The HTML file is tiny and acts as the "map" to your fingerprinted assets.
                    You want this to be fetched fresh often so the browser can discover the new main.8f9a3e.js filenames. With no-cache, the browser will always ask the server: "Has this HTML changed?"
                    If not, the server says "304 Not Modified" (saving bandwidth).

                ETag: A unique hash generated by the server for that specific file version (e.g., ETag: "33a64df5").
                Last-Modified: A timestamp of when the file was last edited on the server.

                The Flow:
                    Browser requests style.css. Server responds with Cache-Control: max-age=3600 and ETag: "abc123".
                    1 hour later: The user returns. The cache is stale.
                    Browser sends a conditional request with the header: If-None-Match: "abc123".
                    The server checks: "Yep, that hash still matches my current file."
                    Server responds with HTTP 304 Not Modified (and an empty body)
                    Browser receives the 304, keeps the old file, and resets the max-age timer for another hour.
                    Result: The browser saved downloading 300KB of CSS. It only downloaded a tiny 500-byte HTTP response.   

        Common Frontend Caching Pitfalls (Don't do these!)
            Using no-cache on images: Your hero images will be re-downloaded on every visit,
                    ruining your LCP for returning users. Use max-age=31536000 on images!

            Using no-store on your main JS bundle: This prevents caching entirely.
                    Every returning user will re-download your 2MB React app. (This is why some SPAs feel slow even on repeat visits).

            Using max-age on index.html: If you set your HTML to cache for 1 hour,
                    and you deploy a bugfix 10 minutes after deployment, your users won't see the fix for 50 minutes. Always use no-cache on HTML so deployments are immediate.

# Content Negotiation
    client will talk to server
        request a file but in compressed format

    in Accept headers
        Accept-Encoding :- gzip, deflate, br, zstd (br - brothli)
    
    server will mention the compressed format in response headers
        Content-Encoding :- gzip
        Content-Type :- text/css

# Lazy Loading

    Dynamic Import :- import a js script at run-time vs traditional imports which do it at build time
        button.addeventListener("click", aync () => {
            // Dynamic import
                it will go to server and fetch the chunk
                fetched and executed at runtime
            const {openModal} = await import('./model') 
            openModel({step: 1})
        })

# Bundle Splitting
    lazy loading applied to avoid js bundle

    we use module bundler to
        combine all of our bundles into one file and 
        because its very diff to include all our files into head section of html

        in bundle splitting
            we will take out our dependencies into one common.js file
            and then we will create bulde for each of our paths

# Critical CSS
    normally we need to compute all the CSS before we move on
        we will fetch all the css files from head section
        and render them, will take lot of time

    with Critical CSS, we will focus on above the fold CSS
     we will import first the css for first section showing to the user







