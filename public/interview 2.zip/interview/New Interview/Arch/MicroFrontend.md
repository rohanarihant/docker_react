# MicroFrontend with Module Federation
    Module Federation allows multiple JavaScript applications to share code and dependencies at runtime
    Instead of bundling everything together, apps can expose specific modules and consume modules from other apps dynamically

        // Simple explanation: App A can use a component from App B
        // without including it in its bundle
        import ProductCard from 'app2/ProductCard'; // Works at runtime!


# What are the core concepts in Module Federation
    Host/Container - The main app that consumes remote modules
    Remote - The app that exposes modules for others to use
    Exposes - What a remote app makes available, what we are going to share with others
    Remotes - Where host apps find remote modules, what we consumes from others
    Shared - Dependencies shared between apps (React, etc.)

    javascript
    new ModuleFederationPlugin({
        name: 'app1',           // Unique identifier
        filename: 'remoteEntry.js', // Entry point for sharing
        exposes: {              // What I give to others
            './Button': './src/Button'
        },
        remotes: {              // What I consume from others
            app2: 'app2@http://localhost:3002/remoteEntry.js'
        },
        shared: ['react']       // Shared dependencies
    })

# How do you handle version conflicts with Module Federation?
    Use singleton: true and version checking in the shared configuration.
            shared: {
                react: {
                    singleton: true,           // Only one instance
                    requiredVersion: '^18.0.0', // Version requirement
                    eager: false,              // Load on demand
                    version: '18.2.0'
                }
            }
            Version conflict scenarios:
                Same major version → ✅ Works, uses highest compatible
                Different major versions → ⚠️ Warning but may work
                Incompatible → ❌ Module federation fails gracefully

# What happens if a remote app goes down
    The host app should implement error boundaries and fallbacks
        import React, { Suspense } from 'react';

        const RemoteComponent = React.lazy(() => 
        import('remote/Component')
            .catch(err => {
            console.error('Failed to load remote:', err);
            return { default: () => <div>Component unavailable</div> };
            })
        );

        function App() {
        return (
            <ErrorBoundary fallback={<div>Failed to load microfrontend</div>}>
            <Suspense fallback={<div>Loading...</div>}>
                <RemoteComponent />
            </Suspense>
            </ErrorBoundary>
        );
        }

    Strategies:
        Fallback UI - Show placeholder
        Retry logic - Attempt reload with exponential backoff
        Circuit breaker - Stop trying after N failures
        Cached version - Use previously loaded version

# How do you share state between microfrontends
    Multiple approaches with trade-offs
        // Remote App - Send event (Approach 1: Custom Events)
                window.dispatchEvent(new CustomEvent('cart-updated', { 
                    detail: { items: 3 } 
                }));

                // Host App - Listen
                window.addEventListener('cart-updated', (event) => {
                    updateCartUI(event.detail);
                });
        
        // Approach 2: Shared Global Store (Centralized)
            // shared/store.js (exposed via MF)
                class SharedStore {
                    constructor() {
                        this.listeners = new Map();
                    }
                    set(key, value) {
                        this.listeners.forEach(cb => cb(key, value));
                    }
                    subscribe(callback) {
                        // subscription logic
                    }
                }
               export default new SharedStore();

# Explain eager: true vs eager: false
    eager: true	    Loads dependency immediately with host app	Critical dependencies needed before remote loads
    eager: false	Loads only when remote module is requested	Most dependencies (default behavior)

# How would you implement authentication across microfrontends
    we will fetch jwt token from localStorage
    if token expired then call refresh token

# How do you handle CSS/style conflicts between microfrontends
    Strategy 1: CSS Modules (Recommended)
        // webpack.config.js
            {
                test: /\.module\.css$/,
                use: [
                    'style-loader',
                    {
                    loader: 'css-loader',
                    options: { modules: true }
                    }
                ]
            }

        /* Button.module.css */
        .button { 
            composes: reset from './reset.css';
            background: blue; /* Locally scoped */
        }
    
    Strategy 2: Shadow DOM
        class MicrofrontendWrapper extends HTMLElement {
            constructor() {
                super();
                this.attachShadow({ mode: 'open' });
            }
            
            connectedCallback() {
                this.shadowRoot.innerHTML = `
                <style>/* Isolated styles */</style>
                <div id="app-root"></div>
                `;
                mountReactApp(this.shadowRoot.getElementById('app-root'));
            }
        }
    Strategy 3: CSS-in-JS (Styled Components)
        import styled from 'styled-components';

        const Button = styled.button`
        background: blue; /* Automatically scoped */`;
    Strategy 4: Naming Convention
        /* App-specific prefixes */
            .products-app__button { }
            .container-app__header { }

# How would you implement shared routing between microfrontends
    Use a routing orchestration pattern:
        // Shell App - Main router
            import { BrowserRouter, Routes, Route } from 'react-router-dom';

            function ShellApp() {
            return (
                <BrowserRouter>
                <div>
                    <nav>
                    <Link to="/">Home</Link>
                    <Link to="/products">Products</Link>
                    <Link to="/checkout">Checkout</Link>
                    </nav>
                    
                    <Routes>
                    <Route path="/" element={<Home />} />
                    <Route path="/products/*" element={
                        <Suspense fallback="Loading...">
                        <ProductsApp /> {/* Remote component */}
                        </Suspense>
                    } />
                    <Route path="/checkout/*" element={
                        <Suspense fallback="Loading...">
                        <CheckoutApp />
                        </Suspense>
                    } />
                    </Routes>
                </div>
                </BrowserRouter>
            );
            }
    
    // Products App - Handles /products/* routes
        import { Routes, Route, useNavigate } from 'react-router-dom';

        function ProductsApp() {
        const navigate = useNavigate(); // Works with shell's router
        
        return (
            <Routes>
            <Route path="/" element={<ProductList />} />
            <Route path="/:id" element={<ProductDetail />} />
            </Routes>
        );
    }

# Helper to navigate from any app
        window.navigate = (path) => {
            window.dispatchEvent(new CustomEvent('navigate', { detail: path }));
        };

        // In shell app
            window.addEventListener('navigate', (e) => {
            navigate(e.detail);
        });
    
# How do you optimize bundle size with Module Federation
        Strategy 1: Dynamic Remote Loading
            // Load remote only when needed
                const loadRemote = async (remoteName, moduleName) => {
                const remote = await import(`${remoteName}/${moduleName}`);
                return remote;
                };

                // Usage
                button.addEventListener('click', async () => {
                const { HeavyComponent } = await loadRemote('analytics', 'Dashboard');
                render(HeavyComponent);
                });
        Strategy 2: Split Shared Dependencies
            new ModuleFederationPlugin({
                shared: {
                    // Critical path - eager
                    react: { eager: true },
                    'react-dom': { eager: true },
                    
                    // Heavy libraries - lazy
                    '@mui/material': { eager: false },
                    'moment': { eager: false },
                    
                    // Split large libs
                    'lodash': { 
                    requiredVersion: false,
                    import: false  // Don't share, each app loads own
                    }
                }
            })
        Strategy 3: Version Conflict Optimization
            // Instead of sharing incompatible versions
            shared: {
            'react-router-dom': {
                singleton: true,
                requiredVersion: '^6.0.0',
                version: () => {
                // Return highest version that works for all
                return '6.14.0';
                }
            }
        }

# How do you optimize bundle size with Module Federation
    new ModuleFederationPlugin({
    shared: {
        // Critical path - eager
        react: { eager: true },
        'react-dom': { eager: true },
        
        // Heavy libraries - lazy
        '@mui/material': { eager: false },
        'moment': { eager: false },
        
        // Split large libs
        'lodash': { 
        requiredVersion: false,
        import: false  // Don't share, each app loads own
        }
    }
    })

# Shared Store Instance (Recommended)
    Step 1: Create a shared Redux store in a separate module
        // shared-redux/store.js - This file is EXPOSED via Module Federation
            import { createStore, combineReducers, applyMiddleware } from 'redux';
            import thunk from 'redux-thunk';

            // Define reducers that all apps need
            const cartReducer = (state = { items: [], total: 0 }, action) => {
            switch (action.type) {
                case 'ADD_TO_CART':
                return {
                    ...state,
                    items: [...state.items, action.payload],
                    total: state.total + action.payload.price
                };
                case 'REMOVE_FROM_CART':
                return {
                    ...state,
                    items: state.items.filter(item => item.id !== action.payload),
                    total: state.total - action.payload.price
                };
                default:
                return state;
            }
            };

            const userReducer = (state = { isLoggedIn: false, user: null }, action) => {
            switch (action.type) {
                case 'SET_USER':
                return { ...state, isLoggedIn: true, user: action.payload };
                case 'LOGOUT':
                return { isLoggedIn: false, user: null };
                default:
                return state;
            }
            };

            // Create and EXPORT a SINGLE store instance
            const rootReducer = combineReducers({
                cart: cartReducer,
                user: userReducer
            });

            export const store = createStore(rootReducer, applyMiddleware(thunk));

            // Also export action creators for cross-app usage
            export const actions = {
                addToCart: (item) => ({ type: 'ADD_TO_CART', payload: item }),
                removeFromCart: (id) => ({ type: 'REMOVE_FROM_CART', payload: id }),
                setUser: (user) => ({ type: 'SET_USER', payload: user }),
                logout: () => ({ type: 'LOGOUT' })
            };

    Step 2: Remote App Webpack Config (Expose the store)
            // remote-app/webpack.config.js
            const ModuleFederationPlugin = require('webpack/lib/container/ModuleFederationPlugin');

            module.exports = {
            plugins: [
                new ModuleFederationPlugin({
                name: 'shared_redux',
                filename: 'remoteEntry.js',
                exposes: {
                    './store': './src/shared/store',  // Expose the store!
                    './actions': './src/shared/store' // Or expose actions separately
                },
                shared: {
                    react: { singleton: true, eager: true },
                    'react-dom': { singleton: true, eager: true },
                    redux: { singleton: true },        // MUST be singleton
                    'react-redux': { singleton: true }  // MUST be singleton
                }
                })
            ]
            };

    Step 3: Host App Configuration (Consume the store)
        // host-app/webpack.config.js
            new ModuleFederationPlugin({
            name: 'host',
            remotes: {
                shared_redux: 'shared_redux@http://localhost:3001/remoteEntry.js'
            },
            shared: {
                react: { singleton: true },
                'react-dom': { singleton: true },
                redux: { singleton: true },        // Critical!
                'react-redux': { singleton: true }  // Critical!
            }
            })
    
    Step 4: Use the shared store in Host App
        // host-app/src/App.jsx
            import React, { useEffect, useState } from 'react';
            import { Provider, useSelector, useDispatch } from 'react-redux';

            // Import the shared store from remote
            const sharedRedux = await import('shared_redux/store');
            const { store, actions } = sharedRedux;

            // Host component using shared store
            function ProductList() {
            const dispatch = useDispatch();
            const cartItems = useSelector(state => state.cart.items);
            
            const addToCart = (product) => {
                dispatch(actions.addToCart(product)); // ✅ Updates shared store
            };
            
            return (
                <div>
                <h2>Products (Host App)</h2>
                <button onClick={() => addToCart({ id: 1, name: 'Laptop', price: 999 })}>
                    Add to Cart
                </button>
                <p>Cart Items: {cartItems.length}</p>
                </div>
            );
            }

            // Wrap app with Provider using shared store
            function HostApp() {
            return (
                <Provider store={store}>  {/* Single store instance! */}
                <ProductList />
                <RemoteCart /> {/* Will use same store */}
                </Provider>
            );
            }