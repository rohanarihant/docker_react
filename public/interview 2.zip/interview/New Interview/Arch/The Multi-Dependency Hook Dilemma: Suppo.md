The Multi-Dependency Hook Dilemma: Suppose you have a useEffect hook with two dependencies: name and age. If either changes, the effect fires. How can you isolate the logic so that a specific block inside that effect runs only when age changes?

Batching Mechanics: What happens under the hood when setState is invoked?
 is invoked? How does React handle concurrent rendering with multiple asynchronous updates, and how does it prioritize user inputs over heavy background tasks?

Heavy Compute Offloading: How do you execute long-running tasks or highly intensive calculations in a React application without locking up the single main UI thread?
    Answer Anchor: Use standard Web Workers to hand off calculations or implement useTransition to signal low-priority UI updates.
Fiber Architecture: What is React Fiber, and how does its reconciliation mechanism differ from the older stack-based reconciler?

Node.js The Event Loop: Walk me through the internal phases of the Node.js Event Loop (Timers, Pending Callbacks, Poll, Check, Close). Where do process.nextTick() and Promise.resolve() fit into this execution sequence?

Clustering & Distribution: What is the primary role of cluster load balancing within Node.js, and how does it optimize resource utilization on multi-core servers?
Unidirectional Streaming: How would you handle continuous server-to-client updates in financial data feeds without the full overhead of WebSockets?
    Answer Anchor: Detail the implementation of Server-Sent Events (SSE) for unidirectional real-time messaging.

CQRS Architecture: Explain the Command Query Responsibility Segregation (CQRS) design pattern. Why does it excel in high-throughput applications, and how do you decouple read and write database structures?

Express Middleware Anatomy: How does custom middleware process request and response streams across different application routes? Write a programmatic example showing how to stop a request from reaching a controller if authentication validation fails.

Database Management: How do you control database connection pools and safely map operations between Node.js and SQL/NoSQL databases? Explain when you would choose MongoDB sharding over standard database indexing when handling millions of financial transaction logs.

Array Flattening: Write a recursive algorithm to flatten a deeply nested array of arbitrary depth without utilizing any built-in prototype methods like Array.prototype.flat().

Array Deduplication: Write a function to find and isolate duplicate elements within a collection. Explain the time and space complexity differences between a nested loop approach (O(N²)) and a Set or hash-map tracking approach (O(N)).

Asynchronous Scope: Predict the exact console logging sequence when nesting block-scoped variables, closures, and delayed executions using setTimeout().

Custom Micro-Frameworks: Code a custom, bare-minimum event emitter class or state store complete with subscription, unsubscription, and dispatch mechanics from scratch.

they asked about implementing middleware in Express.js and how it works in handling requests and responses across different routes.

Detailed questions about node architecture and react concepts also they asked about mongo db sharding and indexing

how sql used in node js

controlled, uncontrolled cmp
stateless comp
how to do optimization
prevent unwanted rerender
node unidirectional - sse

What are some React anti-patterns
Explain what happens when setState is called in React
What is Concurrent Mode in React, and how does it improve rendering performance
Explain the composition pattern in React
How to get query parameters in React Router
How does React handle concurrent rendering with multiple updates and prioritize them
Explain server-side rendering of React applications and its benefits
How do you re-render the view when the browser is resized
How would you handle long-running tasks or expensive computations in React applications without blocking the UI
Explain static generation of React applications
Question 1: Suppose you have two dependencies “name” and “age” on useEffect and if either of them gets modified then functionality defined within useEffect for name and age gets triggered. How can we trigger only the age functionality within UseEffect when the age value gets changed?

Question 2: Suppose you have a hierarchy of components A is the parent of B, B is the parent of C and C is the parent of D. You want to pass the data to all the components then what will you do?

Question 3: What is UseContext and implement it?

Question 4: What is Redux and implement it?

Question 5: What is UseCallback and useMemo?

Question 6: What is the Subject Observable?

Question 7: What is Interceptor (I guessed he meant Axios Interceptor)

Question 8: How do you do Unit testing in react?

Q. Explain Generator Function
Q. Explain the event loop.
Q. Explain database indexing, and write a simple SQL query using GROUP BY and ORDER BY.
Explain the Event Loop node.js
What is Libuv
Preventing Event Loop Blocking
Worker Threads vs. Clustering
JavaScript Internals
JWT Authentication Workflow
Server-Sent Events (SSE) vs WebSockets
Stream API Management
Database Scaling & Reliability
SQL Operations
Memory Leak Diagnosis
High-Throughput API Optimization
SOLID Design Principles
Core js, eventloop, hoisting, currying, solid principal, jwt
What is JavaScript OOPS and how do you implement it?
How does prototype work in JavaScript?
Can you explain what callback hell is and how to avoid it?
What is streaming in JavaScript?
What does it mean to be event driven in JavaScript?
retry api
docker use case
useDeferredValue and useTransition 
