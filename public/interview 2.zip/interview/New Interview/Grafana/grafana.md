# what are going to trace in Grafana ?
    Application Health (The RED Method)
        For web services and APIs, Grafana dashboards are usually built around the RED Method:
            Rate (Traffic): How many requests/sec is the application receiving?
                Look for sudden drops or unusual spikes in traffic.
            Errors: What percentage of requests are failing (e.g., HTTP 5xx server errors or 4xx client errors)?
            Duration (Latency): How long are requests taking to complete?
                Check p90 / p95 / p99 response times
                (95% or 99% of users experience response times below this line) rather than simple averages. 

#   Infrastructure & Server Health (The USE Method)
    For servers, Kubernetes clusters, or virtual machines, check host-level resources using the USE Method:
        Utilization:
            CPU Usage: Is the processor running near 100%?
        Memory / RAM: Are services running out of memory (OOM)?
            Disk / Storage: Is the filesystem getting full?
        Saturation:
            Is work piling up in queues
            (e.g., high CPU load average, thread pool exhaustion, or full network socket queues)?
        Errors:
            Are there network packet drops, disk read/write errors, or interface issues?

#   Database & Cache Metrics
    If the application relies on databases (PostgreSQL, MySQL, MongoDB) or caches (Redis):
        Active Connections: Are connection pool limits being hit?
        Slow Queries: Are specific database queries blocking threads?
        Cache Hit Rate: Is Redis serving requests from cache or falling back to disk/database?

#   Logs, Traces, & Active Alerts
    Active Alerts:
        Check the Grafana Alerting panel to see if any threshold alerts
            (e.g., "High Memory", "Disk Full", "5xx Error Spike") are currently firing.
        Log Streams (e.g., Grafana Loki):
            Filter logs by severity (level=error or level=fatal) to see exact stack traces.Distributed Traces (e.g.,
            
        Grafana Tempo / Jaeger):
            If an API endpoint is slow,
            check distributed traces to see which downstream service or DB query is causing the delay.


            
