# Plugins

    What Are Plugins?
        Plugins can do anything at any stage of the build process.
        They work at the bundle level and have access to the entire compilation.

    Build Flow:
    Source Files → [LOADERS] → Bundling → [PLUGINS] → Final Output
                               ↑
                     Can hook into ANY stage

    Common Plugin Examples
        1. HTML Plugin
            const HtmlWebpackPlugin = require('html-webpack-plugin');
            module.exports = {
            plugins: [
                new HtmlWebpackPlugin({
                template: './src/index.html',
                filename: 'index.html',
                minify: {
                    removeComments: true,
                    collapseWhitespace: true
                }
                })
            ]
            };

            // What it does:
            // - Generates HTML file
            // - Injects bundle scripts automatically
            // - Minifies HTML
            // - Adds hash to filenames for caching

        2. Mini CSS Extract Plugin
            const MiniCssExtractPlugin = require('mini-css-extract-plugin');

            module.exports = {
            module: {
                rules: [
                {
                    test: /\.css$/,
                    use: [MiniCssExtractPlugin.loader, 'css-loader']
                }
                ]
            },
            plugins: [
                new MiniCssExtractPlugin({
                filename: '[name].[contenthash].css',
                chunkFilename: '[id].[contenthash].css'
                })
            ]
            };

            // Instead of injecting CSS into JS, creates separate CSS files
            // Better for caching and performance

        3. Clean Plugin
            const { CleanWebpackPlugin } = require('clean-webpack-plugin');

            module.exports = {
            plugins: [
                new CleanWebpackPlugin() // Cleans dist folder before build
            ]
            };

            // Before build: deletes old files in dist/
            // After build: writes new files

        4. Define Plugin
            const webpack = require('webpack');

            module.exports = {
            plugins: [
                new webpack.DefinePlugin({
                'process.env.NODE_ENV': JSON.stringify(process.env.NODE_ENV),
                'API_URL': JSON.stringify('https://api.example.com'),
                'VERSION': JSON.stringify('1.0.0')
                })
            ]
            };

            // In your code:
            console.log(process.env.NODE_ENV); // 'production'
            console.log(API_URL); // 'https://api.example.com'
            // These get replaced at build time!
        
        5. Bundle Analyzer
            const BundleAnalyzerPlugin = require('webpack-bundle-analyzer').BundleAnalyzerPlugin;

            module.exports = {
            plugins: [
                new BundleAnalyzerPlugin({
                analyzerMode: 'static',
                reportFilename: 'bundle-report.html'
                })
            ]
            };

            // Generates visual report of bundle sizes
            // Helps identify large dependencies

Remember: Loaders transform files, Plugins transform the build process! 🚀

