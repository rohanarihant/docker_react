# How Webpack Handles Route-Based Lazy Loading

#   1. Dynamic Import Syntax
    // Instead of static import
    // import HomePage from './pages/HomePage';

    // Route-based lazy loading
    const HomePage = () => import('./pages/HomePage');
    const AboutPage = () => import('./pages/AboutPage');

2. Webpack's Build Process
    Code Splitting Detection
        analyzes the dynamic import() statements during the build phase
        and identifies them as split points where code should be separated
    
    Chunk Generation
        Webpack creates separate chunks for each dynamically imported module:
            // Webpack generates something like:
            // main.bundle.js (core app)
            // 0.chunk.js (HomePage)
            // 1.chunk.js (AboutPage)
            // 2.chunk.js (ContactPage)

3. Naming and Configuration
    // webpack.config.js
    module.exports = {
    output: {
        filename: '[name].[contenthash].js',
        chunkFilename: '[name].[contenthash].chunk.js',
        // For async chunks
        path: path.resolve(__dirname, 'dist'),
    },
    optimization: {
        splitChunks: {
        chunks: 'all',
        // Further optimizations
        }
    }
    };

4. The Build Output Structure
    dist/
    ├── index.html
    ├── main.abc123.js        # Core app bundle
    ├── vendors.def456.js     # Vendor chunks
    ├── HomePage.ghi789.chunk.js
    ├── AboutPage.jkl012.chunk.js
    ├── ContactPage.mno345.chunk.js
    └── 3.framework.chunk.js  # Shared dependencies



#  Core vs Vendor chunk generations

    1. Entry Point Analysis
        Webpack starts from the entry file and builds a dependency graph:
            import App from './App';
            // Webpack: "App is in core because it's directly imported by entry"

            // App.js
            import Header from './components/Header';     // Core (only used here)
            import Footer from './components/Footer';     // Core (only used here)
            import SharedButton from './components/Button'; // Vendor (used everywhere)

    2. Chunk Count (minChunks)
        // Chunk 1: Core bundle (main)
        // Chunk 2: HomePage (lazy)
        // Chunk 3: AboutPage (lazy)

        // Header: Used in Chunk 1 ONLY → Stays in Core
        // Footer: Used in Chunk 1 ONLY → Stays in Core  
        // SharedButton: Used in Chunks 1, 2, 3 → Moves to Vendor ✅

#   The Complete Lazy Loading Mechanism
    2. How Dynamic Imports Trigger Loading
        // Your code
        const HomePage = () => import('./pages/HomePage');

        // Webpack transforms this to:
        const HomePage = () => __webpack_require__.e(/* chunkId */ 2)
        .then(() => __webpack_require__(/* moduleId */ './pages/HomePage.js'));

        // When user navigates, this executes:
        HomePage()  // Returns a Promise that triggers chunk loading
        .then(component => {
            // Render the component
        });


        // Step 1: Initial page load
// ─────────────────────────────────────────────
// main.js + vendor.js loaded
// User sees: HomePage (loaded initially)

// Step 2: User clicks "About"
// ─────────────────────────────────────────────
import('./pages/AboutPage')
  ↓
__webpack_require__.e(3)  // chunkId = 3
  ↓
// Check if already loaded? No
// Create script element
// Add to DOM
// Fetch: /3.chunk.js or /AboutPage.chunk.js

// Step 3: About chunk downloads
// ─────────────────────────────────────────────
// Browser network: GET /3.chunk.js
// File size: ~45KB
// Download time: ~100ms

// Step 4: Chunk execution
// ─────────────────────────────────────────────
// Script executes and registers modules
// Webpack: "Chunk 3 is now available"
// Resolve the promise
// Render AboutPage component

// Step 5: User clicks "Contact"
// ─────────────────────────────────────────────
// Same process but with chunkId = 4
// GET /4.chunk.js

// Step 6: User clicks "Home" again
// ─────────────────────────────────────────────
import('./pages/HomePage')
  ↓
__webpack_require__.e(2)
  ↓
// Check if already loaded? YES (loaded initially)
// Return cached module immediately
// No network request! 🚀

#   how shared node_modules are getting loaded from the build to browser ?
    // Project structure
src/
├── pages/
│   ├── HomePage.jsx    // Uses: React, axios, lodash
│   ├── AboutPage.jsx   // Uses: React, axios, moment
│   └── ContactPage.jsx // Uses: React, axios, lodash
├── components/
│   └── SharedButton.jsx // Uses: React, antd

// Webpack analyzes and finds:
// React: Used by ALL chunks → Shared
// axios: Used by ALL chunks → Shared  
// lodash: Used by HomePage & ContactPage → Shared
// moment: Used ONLY by AboutPage → Could stay in About chunk
// antd: Used ONLY by SharedButton → Could stay with SharedButton

1. The Build-Time Analysis
    During build, Webpack analyzes which node_modules are shared across multiple chunks:
        // Project structure
            src/
            ├── pages/
            │   ├── HomePage.jsx    // Uses: React, axios, lodash
            │   ├── AboutPage.jsx   // Uses: React, axios, moment
            │   └── ContactPage.jsx // Uses: React, axios, lodash
            ├── components/
            │   └── SharedButton.jsx // Uses: React, antd

            // Webpack analyzes and finds:
            // React: Used by ALL chunks → Shared
            // axios: Used by ALL chunks → Shared  
            // lodash: Used by HomePage & ContactPage → Shared
            // moment: Used ONLY by AboutPage → Could stay in About chunk
            // antd: Used ONLY by SharedButton → Could stay with SharedButton

2. How Shared node_modules are Extracted
    Webpack uses SplitChunksPlugin to extract shared modules:
        // webpack.config.js
            optimization: {
            splitChunks: {
                chunks: 'all',
                cacheGroups: {
                // Default vendor group
                vendors: {
                    test: /[\\/]node_modules[\\/]/,
                    name: 'vendors',
                    chunks: 'all',
                    priority: 10,
                    // Extract if used in at least 2 chunks
                    minChunks: 2,
                    // Only if size > 30KB
                    minSize: 30000,
                },
                // React specific group (higher priority)
                react: {
                    test: /[\\/]node_modules[\\/](react|react-dom|react-router)[\\/]/,
                    name: 'react-vendor',
                    chunks: 'all',
                    priority: 20,
                    enforce: true,
                }
                }
            }
            }

3. What Happens During Build
    Step 1: Module Resolution
        // Your code
            import React from 'react';
            import axios from 'axios';

            // Webpack resolves this to:
            // node_modules/react/index.js
            // node_modules/axios/index.js

    Step 2: Module Graph Construction
        // Webpack builds a graph like this:
            Entry (index.js)
            ├── React (node_modules)
            ├── ReactDOM (node_modules)  
            ├── App.js
            │   ├── HomePage (lazy)
            │   │   ├── React (shared) ✅
            │   │   ├── axios (shared) ✅
            │   │   └── lodash (shared) ✅
            │   ├── AboutPage (lazy)
            │   │   ├── React (shared) ✅
            │   │   ├── axios (shared) ✅
            │   │   └── moment (unique) ❌ (stays in chunk)
            │   └── ContactPage (lazy)
            │       ├── React (shared) ✅
            │       ├── axios (shared) ✅
            │       └── lodash (shared) ✅

    Step 3: Chunk Assignment
        // Build output structure:
            vendors.chunk.js    // Contains: React, ReactDOM, ReactRouter, axios
            react-vendor.chunk.js // Contains: React specific (separate for caching)
            main.chunk.js       // Contains: App shell
            HomePage.chunk.js   // Contains: HomePage code + lodash (shared but not extracted)
            AboutPage.chunk.js  // Contains: AboutPage code + moment (unique)
            ContactPage.chunk.js // Contains: ContactPage code + lodash (shared)