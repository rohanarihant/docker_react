#   How to Analyze the Stats File

    Method 1: Using Source Map Explorer
        # Install source-map-explorer
        npm install -g source-map-explorer

    What it shows:
        Visual treemap of bundle size
        Which packages are taking the most space
        Unused code detection
        Dependency size breakdown

    // Example output:
    // 📊 bundle size analysis
    // 
    // main.abc123.js (152.3 KB)
    // ├── react-dom (45.2 KB)
    // ├── react (18.3 KB) 
    // ├── App.js (12.4 KB)
    // ├── components/ (8.7 KB)
    // └── utils/ (5.1 KB)
    // 
    // vendors.def456.js (456.8 KB)
    // ├── lodash (72.3 KB) ⚠️ Large!
    // ├── axios (24.5 KB)
    // ├── moment (67.8 KB) ⚠️ Large!
    // ├── @material-ui/core (156.2 KB) ⚠️ Very Large!
    // └── other (136.0 KB)

Visual output (opens in browser):
    ┌─────────────────────────────────────────────┐
    │              Bundle Visualizer              │
    │                                             │
    │  ┌─────────────┐  ┌──────────────────────┐  │
    │  │   React      │  │     Lodash          │  │
    │  │   (18.3 KB)  │  │    (72.3 KB)        │  │
    │  └─────────────┘  └──────────────────────┘  │
    │                                             │
    │  ┌─────────────┐  ┌──────────────────────┐  │
    │  │  React-DOM  │  │    moment            │  │
    │  │  (45.2 KB)  │  │    (67.8 KB)         │  │
    │  └─────────────┘  └──────────────────────┘  │
    │                                             │
    │  ┌──────────────────────────────────────┐   │
    │  │      Material-UI (156.2 KB)          │   │
    │  │  ┌────┐  ┌────┐  ┌────┐              │   │
    │  │  │Btn  │  │Card │  │Icon│            │   │
    │  │  └────┘  └────┘  └────┘              │   │
    │  └──────────────────────────────────────┘   │
    └─────────────────────────────────────────────┘