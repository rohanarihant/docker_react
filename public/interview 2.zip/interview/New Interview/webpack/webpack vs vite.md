#   Webpack vs Vite

#   Webpack's "Bundle Everything" Approach:
    Webpack starts a development server by first crawling your entire project from the entry file
    building a complete dependency graph
    bundling all your modules together
    This process must complete before you can even see your app
    slows down significantly as your project grows
    often taking tens of seconds for large applications

#   Vite's "Native ESM & On-Demand" Approach:
    When your browser requests a file (e.g., main.jsx)
    Vite intercepts the request
    uses the extremely fast esbuild to transpile it (if necessary)
    This "on-demand" compilation makes Vite's startup time lightning-fast
    and largely independent of your project's total size


⚡ Hot Module Replacement (HMR)
    Webpack:
        When you change a file, Webpack must re-compile and re-bundle that module and its dependencies
        This process becomes slower as your application scales,
        often taking hundreds of milliseconds or even seconds to reflect changes
    
    Vite:
        Vite's HMR is incredibly efficient.
        It only needs to invalidate and re-compile the single changed file,
        pushing the update to the browser via WebSocket.
        This results in near-instant feedback, usually well under 100ms,
        allowing you to see changes almost immediately
    
📦 Production Build: Different Tools, Similar Goal
    Webpack:
        For production, Webpack runs its full, highly optimized bundling process to create a final, production-ready bundle.
    Vite:
        In production, Vite uses Rollup, a mature and powerful bundler, to create optimized bundles. This ensures excellent tree-shaking, code-splitting, and lazy-loading, resulting in small and performant final builds


💡 Why Rolldown? The Problem It Solves
    Before Rolldown, 
    Vite used a two-bundler strategy
        esbuild for speed during development,
        Rollup for a robust, optimized production build
    
    Rolldown solves this by becoming a single, unified bundler that can do it all
        Instead of a JavaScript-based bundler running through a single thread
        its core operations happen in a compiled, statically-typed language that can fully utilize modern multi-core processors
    
    bundling process is broken into 3 distinct stages
        1. Scan:
            It loads all modules, parses them into Abstract Syntax Trees (ASTs)
            and builds a map of imports, exports, and symbols
            This is where its speed first becomes apparent,
            with Rust rapidly processing tens of thousands of modules
        2. Link:
            This stage builds the comprehensive dependency graph.
            It wraps CommonJS (CJS) and ESM modules for correct interoperation (a task often requiring a plugin in Rollup), performs tree-shaking to eliminate dead code, and resolves circular dependencies
        3. Generate:
            Finally, the code is split into chunks. To ensure maximum output quality,
            Rolldown uses an advanced chunking algorithm that can intelligently merge
            and split chunks to avoid unnecessary duplication and produce smaller bundles

