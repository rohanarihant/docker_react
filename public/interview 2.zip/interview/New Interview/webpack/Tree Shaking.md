#   What is Tree Shaking?

    Tree Shaking is a dead code elimination technique that removes unused code from your final bundle.
    It's like pruning a tree - you cut off the dead branches (unused code)
    so the tree (your application) is lighter and healthier.


#   How Tree Shaking Works
    // 1. Code Analysis Phase
    // Webpack/Rollup analyzes your code to find:
    // - Which modules are imported
    // - Which exports are used
    // - Which functions are called

    // 2. Marking Phase
    // Mark used and unused code

    // 3. Elimination Phase
    // Remove unused code from final bundle

    // 4. Optimization Phase
    // Further optimize the bundle

#   Simple Example:
    // math.js (Library)
        export function add(a, b) {
        return a + b;
        }

        export function subtract(a, b) {
        return a - b;
        }

        export function multiply(a, b) {
        return a * b;
        }

        export function divide(a, b) {
        return a / b;
        }

        // app.js (Application)
        import { add, multiply } from './math.js';

        console.log(add(5, 3)); // ✅ Uses add()
        console.log(multiply(5, 3)); // ✅ Uses multiply()

        // ❌ subtract() and divide() are never used
        // They will be removed by tree shaking!

#   Final Bundle After Tree Shaking:
    // bundle.js
        function add(a, b) {
        return a + b;
        }

        function multiply(a, b) {
        return a * b;
        }

        console.log(add(5, 3));
        console.log(multiply(5, 3));

        // ❌ subtract() and divide() are GONE!
        // Smaller bundle size! 🎉

#   Tree Shaking Requirements
    1. ES Modules (ESM) Only
    2. Static Structure
        ES Modules have a static structure, meaning imports/exports must be at the top level and can't be dynamic.
    3. Side Effect Free
        Modules should be free of side effects (code that runs when imported).
            // ❌ Has side effects (can't tree shake)
            // module.js
            console.log('This runs when imported!'); // Side effect
            export const add = (a, b) => a + b;

            // ✅ No side effects (can tree shake)
            // module.js
            export const add = (a, b) => a + b;