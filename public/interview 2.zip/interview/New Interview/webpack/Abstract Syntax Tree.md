# What is an Abstract Syntax Tree?
    is a tree representation of the abstract syntactic structure of source code written in a programming language
    Each node in the tree denotes a construct occurring in the source code.

#   From Source Code to AST
    Source Code → Tokens → AST → Transformed Code

    Example:
    const add = (a, b) => a + b;
        ↓
    [Tokenizer/Lexer] → Tokens
        ↓
    [Parser] → AST
        ↓
    [Transformer] → Modified AST
        ↓
    [Generator] → New Code

Step 1: Tokenization (Lexical Analysis)
    // Source code
    const add = (a, b) => a + b;

    // Tokens (stream of meaningful units)
    [
    { type: 'keyword', value: 'const' },
    { type: 'identifier', value: 'add' },
    { type: 'operator', value: '=' },
    { type: 'punctuation', value: '(' },
    { type: 'identifier', value: 'a' },
    { type: 'punctuation', value: ',' },
    { type: 'identifier', value: 'b' },
    { type: 'punctuation', value: ')' },
    { type: 'operator', value: '=>' },
    { type: 'identifier', value: 'a' },
    { type: 'operator', value: '+' },
    { type: 'identifier', value: 'b' },
    { type: 'punctuation', value: ';' }
    ]

Step 2: Parsing to AST
    // AST (JSON representation)
    {
    type: "Program",
    body: [{
        type: "VariableDeclaration",
        kind: "const",
        declarations: [{
        type: "VariableDeclarator",
        id: {
            type: "Identifier",
            name: "add"
        },
        init: {
            type: "ArrowFunctionExpression",
            params: [
            { type: "Identifier", name: "a" },
            { type: "Identifier", name: "b" }
            ],
            body: {
            type: "BinaryExpression",
            operator: "+",
            left: { type: "Identifier", name: "a" },
            right: { type: "Identifier", name: "b" }
            }
        }
        }]
    }]
    }