# Loader
    Loaders = Translators (transform specific files)

        Loaders are transformers that process individual files before they're added to your bundle.
        They work at the module level.

        Build Flow:
            Source Files → [LOADERS] → Bundled Output
                  ↑
            Transform files
            (one at a time)

        // Without loaders, webpack only understands JavaScript
        import './styles.css'; // ❌ ERROR: Webpack can't parse CSS

        // With loaders, you can import ANYTHING
        import './styles.css'; // ✅ Works with css-loader + style-loader
        import image from './logo.png'; // ✅ Works with file-loader
        import data from './data.json'; // ✅ Works with json-loader


#   Common Loader Examples

    1. CSS Loaders
        // webpack.config.js
            module.exports = {
            module: {
                rules: [
                {
                    test: /\.css$/, // Which files to process
                    use: [
                    'style-loader', // Injects CSS into DOM
                    'css-loader',   // Resolves @import and url()
                    'postcss-loader' // Adds autoprefixer, etc.
                    ]
                }
                ]
            }
            };

            // In your JS:
            import './styles/main.css';
            // Process flow:
            // main.css → css-loader (resolves imports) → style-loader (injects CSS)
    
    2. JavaScript Loaders (Babel)
        module.exports = {
            module: {
                rules: [
                {
                    test: /\.(js|jsx)$/,
                    exclude: /node_modules/,
                    use: {
                    loader: 'babel-loader',
                    options: {
                        presets: ['@babel/preset-env', '@babel/preset-react']
                    }
                    }
                }
                ]
            }
        };

            // Transforms modern JS to browser-compatible JS
            // Input:  const App = () => <div>Hello</div>;
            // Output: var App = function App() { return React.createElement("div", null, "Hello"); };

    3. File Loaders
        module.exports = {
            module: {
                rules: [
                // Images
                {
                    test: /\.(png|jpg|gif)$/,
                    use: [
                    {
                        loader: 'file-loader',
                        options: {
                        name: '[name].[hash].[ext]',
                        outputPath: 'images/'
                        }
                    }
                    ]
                },
                // Fonts
                {
                    test: /\.(woff|woff2|eot|ttf|otf)$/,
                    use: ['file-loader']
                }
                ]
            }
        };

        // In JS:
        import logo from './logo.png';
        // logo becomes: /images/logo.a1b2c3.png

    4. Data Loaders
        module.exports = {
            module: {
                rules: [
                {
                    test: /\.(csv|tsv)$/,
                    use: ['csv-loader']
                },
                {
                    test: /\.xml$/,
                    use: ['xml-loader']
                }
                ]
            }
        };

        // In JS:
        import data from './data.csv';
        // data becomes a JavaScript array/object

    5. Specialized Loaders
        module.exports = {
            module: {
                rules: [
                // TypeScript
                {
                    test: /\.tsx?$/,
                    use: 'ts-loader',
                    exclude: /node_modules/
                },
                // SCSS
                {
                    test: /\.scss$/,
                    use: ['style-loader', 'css-loader', 'sass-loader']
                },
                // Markdown
                {
                    test: /\.md$/,
                    use: ['html-loader', 'markdown-loader']
                },
                // SVG as React Component
                {
                    test: /\.svg$/,
                    use: ['@svgr/webpack']
                }
                ]
            }
        };
    6. Loader Pipeline (Chaining)
        Loaders run in right-to-left order:
            // Example with multiple loaders
            use: ['style-loader', 'css-loader', 'sass-loader']
            // Order: sass-loader → css-loader → style-loader

            // Step-by-step:
            // 1. sass-loader:    SCSS → CSS
            // 2. css-loader:     Resolves @import, url() 
            // 3. style-loader:   Injects CSS into DOM

            // Visual representation:
            // .scss file → [sass-loader] → CSS → [css-loader] → Processed CSS → [style-loader] → DOM

