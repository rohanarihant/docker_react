# 🔎 1. Web Crawlers and Meta Tags (SEO Foundation)
    Web crawlers (like Googlebot or Bingbot) scan your HTML before any JavaScript executes.
    They look at your <head> meta tags to understand what the page is about.

    Crucial Meta Tags for Crawlers
        title & description: Controls how your page looks in Google search results.
        robots: Tells crawlers whether they are allowed to index the page (index, follow vs noindex, nofollow).
        Open Graph (og:) Tags: Controls how your page looks when shared on social platforms (LinkedIn, X, WhatsApp).
    
    <head>
        <title>Analytics Guide | My App</title>
        <meta name="description" content="Learn how to integrate Adobe Analytics safely." />
        <meta name="robots" content="index, follow" />
        <meta property="og:title" content="Analytics Guide" />
    </head>

# 📊 2. Adobe Analytics (Data Layer & Tracking)
    Adobe Analytics tracks user behavior after the page loads.
    It relies on a Data Layer (a JavaScript object on the window) to collect information and send it
    to Adobe’s servers via tags managed by Adobe Experience Platform (AEP) Launch.

    // Example of a standard digitalData Layer
        window.digitalData = {
            page: {
                pageName: "Analytics Guide",
                category: "Tech Documentation",
                language: "en"
            }
        };

# ⚠️ The Problem: How They Clash in Modern Apps
    If you are building a modern client-side application (like React, Angular, or Vue),
    you will run into two massive problems regarding crawlers and Adobe Analytics:

    Problem A: Crawlers see empty meta tags
        In a standard single-page app (SPA), the initial HTML is completely empty.
        The meta tags and content are generated dynamically via JavaScript.
        While Googlebot can wait for JavaScript to execute, many social media crawlers (like LinkedIn or Slack) cannot. They will see blank previews when your links are shared.

    Problem B: Adobe Analytics fires before meta tags update
        If you use a tool to dynamically update meta tags on route changes,
        Adobe Analytics might fire its page-view pixel before the new page name or meta data is injected into the DOM.
        This results in missing or mismatched tracking data in your Adobe reports.


# ✅ The Solution: Best Practices for Implementation
    1. Use Server-Side Rendering (SSR) or Pre-rendering
        To ensure crawlers get the correct meta tags instantly and
        Adobe Analytics has access to the data layer immediately on load,
        use frameworks that render HTML on the server:
    
        Next.js for React
        Nuxt.js for Vue
        Angular Universal for Angular

    2. Sync the Data Layer with Route Changes
        If you must use a standard client-side React app,
        ensure your router updates both the meta tags and the Adobe data layer
        before triggering the Adobe track call.

        // Inside a React Route Change Effect
            useEffect(() => {
                // 1. Update Meta Tags for the browser
                document.title = "New Page Title";
                document.querySelector('meta[name="description"]').setAttribute("content", "New description");

                // 2. Update the Adobe Data Layer
                window.digitalData.page.pageName = "New Page Title";

                // 3. Trigger the Adobe Launch event AFTER the data layer is updated
                if (window._satellite) {
                    window._satellite.track('page_view');
                }
            }, [location.pathname]);

    3. Tell Crawlers to Ignore Adobe Scripts
        Do not let web crawlers trigger Adobe Analytics pixels.
        This inflates your bounce rates and skews your data with bot traffic.
        Adobe handles most known bots automatically,
        but ensuring your data layer only instantiates for real user interactions is best practice.

        To help narrow this down, let me know:
            Are you building a Single Page App (React/Vue) or a Server-Rendered website (WordPress/AEM)?
            Are you experiencing an issue with bot traffic inflating your data, or social links not showing previews?
