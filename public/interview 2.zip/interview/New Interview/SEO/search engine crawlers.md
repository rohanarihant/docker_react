# search engine crawlers
    Search engine crawlers (also known as spiders or bots) are automated programs
    used by search engines like Google, Bing, and Yahoo to continuously scan,
    read, and catalog the contents of the entire internet

    Their primary job is to discover new and updated web pages, understand what those pages are about,
    and add them to the search engine's index so users can find them.

    ⚙️ How Crawlers Work (The 3-Step Process)
    
        Discovery & Crawling: 
            Crawlers start with a list of known web server URLs and sitemaps.
            As they read a page, they extract all the links (hyperlinks) found on that page
            and add them to a queue to crawl next. This creates a continuous cycle of web discovery.
        Parsing & Rendering:
            The crawler downloads the HTML, CSS, and JavaScript files.
            Modern crawlers (like Googlebot) render the page exactly
            like a browser to see what a real human user would see,
            ensuring they can read dynamic JavaScript content.
        Indexing:
            Once parsed, the crawler sends the text, structure, images,
            and video information to the search engine's database (the Index).
            When you search on Google, you are not searching the live web; you are searching this processed index.