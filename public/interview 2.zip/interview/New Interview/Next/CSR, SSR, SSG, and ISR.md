**Client-Side Rendering (CSR)**

    Client-Side Rendering (CSR) is the default rendering strategy in React applications.
    In CSR, the initial request loads a minimal HTML file that includes JavaScript files responsible for rendering the application.
    The client’s browser then executes the JavaScript, fetching data from APIs and rendering the page on the client-side.
    This approach provides a smooth and interactive user experience, but may result in slower initial load times, especially for content-heavy pages.

        To implement CSR in Next.js, you can simply create React components and navigate between pages using the client-side routing system provided by Next.js. Here’s an example:

            import Link from "next/link";
            const HomePage = () => {
                return(
                    <div>
                        <h1>Welcome to the Home Page</h1>
                        <Link href="/about">
                            <a>About</a>
                        </Link>
                    </div>
                )
            }
            export default HomePage;

        In this example, we have a simple homepage component with a link to the about page. When the user clicks the link, Next.js dynamically loads the about page without a full-page refresh.

**Server-Side Rendering (SSR)**
    Server-Side Rendering (SSR) involves rendering the React components on the server and sending the fully rendered HTML to the client. This approach improves initial page load times and ensures that search engines can index the content effectively. SSR is particularly beneficial for applications with dynamic data that changes frequently or requires personalized information.

    Example in Next.js:

    To implement SSR in Next.js, you can export a function called getServerSideProps from your page component. This function runs on the server-side and fetches the necessary data before rendering the component. Here's an example:

        const AboutPage = ({data}) => {
            return(
                <div>
                    <h1>About Page</h1>
                    <p>{data}</p>
                </div>
            )
        };
        export async function getServerSideProps() = {
            const res = await fetch("https://api.example.com/data");
            const data = await res.json();
                return {
                    props: {
                        data
                    }
                }
            }
        export default AboutPage;

    In this example, the getServerSideProps function fetches data from an API before rendering the AboutPage component. The fetched data is passed as props to the component, which is then rendered on the server and sent to the client.

**Static Site Generation (SSG)**
    Static Site Generation (SSG) involves pre-rendering the entire website at build time, generating static HTML files for each page. This approach provides excellent performance and security while reducing the server load. SSG is ideal for websites with content that doesn’t change frequently, such as blogs, marketing pages, or documentation.

    Example in Next.js:

    To implement SSG in Next.js, you can export a function called getStaticProps from your page component. This function runs at build time and fetches the necessary data to render the component. Here's an example:

        const BlogPost = ({posts}) => {
            return(
                <div>
                    <h1>Blog Posts</h1>
                    {posts.map((post) => (
                        <div key={post.id}>
                            <h2>{post.title}</h2>
                            <h2>{post.content}</h2>
                        </div>
                    ))}
                </div>
            )
        };
        export async function getStaticProps() = {
            const res = await fetch("https://api.example.com/data");
            const posts = await res.json();
                return {
                    props: {
                        posts
                    }
                }
            }
        export default BlogPost;


    SSG Code Example
    In this example, the getStaticProps function fetches the blog posts from an API at build time. The fetched posts are passed as props to the BlogPage component, which is then rendered as static HTML files.


**Incremental Static Regeneration (ISR)**
    Incremental Static Regeneration (ISR) builds upon SSG by allowing dynamic parts of a page to be regenerated on-demand. This means that some parts of the page can be static while others can be re-rendered when the data changes. ISR strikes a balance between performance and freshness of content, making it suitable for applications with frequently updated content.

    Example in Next.js:

    To implement ISR in Next.js, you can use the revalidate option in the getStaticProps function. Here's an example:
         export async function getStaticProps() = {
            const res = await fetch("https://api.example.com/data");
            const posts = await res.json();
                return {
                    props: {
                        posts
                    },
                    revalidate: 60, //regenerate the page every 60 seconds
                }
            }
    In this example, the page will be regenerated every 60 seconds, ensuring that the content stays up-to-date without sacrificing performance.