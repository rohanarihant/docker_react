# Authentication and authorization middleware

    const jwt = require('jsonwebtoken');

    function authenticate(req, res, next) {
    // 1. Get the token from the Authorization header
    const authHeader = req.headers.authorization;
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
        return res.status(401).json({ error: 'Missing or invalid token' });
    }

    const token = authHeader.split(' ')[1];

    try {
        // 2. Verify the token
        const decoded = jwt.verify(token, process.env.JWT_SECRET);
        // 3. Attach user data to the request
        req.user = decoded;
        next(); // Proceed to the route handler
    } catch (error) {
        return res.status(401).json({ error: 'Invalid or expired token' });
    }
    }

// Use it to protect routes
app.get('/profile', authenticate, (req, res) => {
  res.json({ user: req.user });
});

# Role-Based Access Control (RBAC):
    function authorize(...allowedRoles) {
    return (req, res, next) => {
            if (!req.user) return res.status(401).json({ error: 'Unauthenticated' });
            if (!allowedRoles.includes(req.user.role)) {
            return res.status(403).json({ error: 'Forbidden' });
            }
            next();
        };
    }

    // Only admins can access this route
    app.delete('/admin/users/:id', authenticate, authorize('admin'), (req, res) => {
    // Delete user logic
    });

# Input Validation Middleware
    const { validateRequest } = require('zod-express-middleware');
    const { z } = require('zod');

    // 1. Define a schema for user registration
    const userSchema = z.object({
        body: z.object({
            email: z.string().email(),
            password: z.string().min(8),
            name: z.string().optional(),
        }),
    });

    // 2. Use the middleware in your route
    app.post(
    '/register',
    validateRequest(userSchema), // Validates req.body, req.query, req.params
    (req, res) => {
        // If we reach here, validation passed
        // req.body is now guaranteed to match the schema
        res.json({ message: 'User created', data: req.body });
    }
    );

# The Global Error Handler Middleware
    This is the final destination for all errors. It must be placed after all your routes in your app.js or server.js file.

    // This must be the LAST middleware added
    app.use((err, req, res, next) => {
    // 1. Log the error for debugging (e.g., using Winston or console)
        console.error('Error:', err.stack);

    // 2. Determine the status code and message
    const statusCode = err.statusCode || 500;
    const message = err.message || 'Internal Server Error';

    // 3. Send a structured JSON response to the client
    res.status(statusCode).json({
        success: false,
        status: statusCode,
        message: message,
        // Only show stack trace in development, not production
        stack: process.env.NODE_ENV === 'production' ? null : err.stack,
    });
    });

# encrypt and decrypt password

// ❌ WRONG - Encrypting passwords (reversible)
const encrypted = encrypt(password); // Can be decrypted!
// If someone gets the key, all passwords are exposed

// ✅ CORRECT - Hashing passwords (irreversible)
const hash = await bcrypt.hash(password, 10); // Cannot be reversed!
// Even if database is compromised, passwords remain safe


// utils/passwordUtils.js
const bcrypt = require('bcrypt');

// Hash password during registration
const hashPassword = async (password) => {
  const saltRounds = 10; // Higher = more secure but slower
  const hashedPassword = await bcrypt.hash(password, saltRounds);
  return hashedPassword;
};

// Compare password during login
const comparePassword = async (plainPassword, hashedPassword) => {
  const isMatch = await bcrypt.compare(plainPassword, hashedPassword);
  return isMatch;
};

module.exports = { hashPassword, comparePassword };