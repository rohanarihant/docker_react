# Express Middleware Anatomy

    Middleware functions have access to the request/response objects and the next function.
    They form a pipeline where each middleware can:
        Process the request
        End the request-response cycle
        Pass control to the next middleware
    
# Error Handeling
    Error handling in Express.js relies on a special type of middleware.
    While standard middleware functions take three arguments (req, res, next),
    error-handling middleware must take exactly four arguments: (err, req, res, next).

    1. Basic Error Handling Middleware
        const express = require('express');
        const app = express();

        // 1. Regular routes
        app.get('/broken', (req, res, next) => {
            throw new Error('Something went wrong!'); // Synchronous error
        });

        // 2. The Error Handler (Must be at the very bottom)
        app.use((err, req, res, next) => {
            console.error(err.stack); // Log the error stack for debugging
        
        res.status(500).json({
            status: 'error',
            message: err.message || 'Internal Server Error'
        });
        });
        app.listen(3000);
    

    2. Handling Synchronous vs. Asynchronous Errors
        Synchronous Code
            If an error is thrown in synchronous code (like the example above),
            Express will automatically catch it and pass it to your error handler.
            You don't need extra setup.

        Asynchronous Code
            For asynchronous code (e.g., database queries, fetch requests, fs.readFile),
            Express cannot catch thrown errors automatically.
            You must pass the error to the next() function manually.
        
        // Using Promises / Async-Await
        app.get('/user/:id', async (req, res, next) => {
        try {
            const user = await database.findUser(req.params.id);
            if (!user) {
            const error = new Error('User not found');
            error.statusCode = 404;
            throw error; // Caught by the catch block
            }
            res.json(user);
        } catch (err) {
            next(err); // Passing the error to the Express error handler
        }
        });