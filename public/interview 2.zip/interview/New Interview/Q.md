Q. What is global state management?
Q. Why is the keyword "debugger" used in JavaScript?
Q. How can you reverse an array without using built-in functions?
Q. Write a useEffect method to fetch data from an API, retrieve the response, and display it in a table format.
Q. What is currying in JavaScript, and how can it be used to create higher-order functions?
Q. What is a deep object in JavaScript?
Q. Questions about CSS.
box model
hoisting in js
async and defer 
temporal dead zone
hoc
pure component
can we pass child to parent in react




deep comparison of arrays, object //
groupBy //
polyfill of map, filter, reduce
this, arrow func, prototype, hoisting, promises
redux implementation and redux toolkit
zustand
typescript

KAFKA
high level scalable application frontend
how we are going to handle the kub ip address change in services? DNS ?
how SSL and TLS implemented in services? ISTIO etc
api configs
api retries in node
event streaming (kafka) vs pub-sub

node.js working
cluster module
worker thread
concurrency in Node.js
RBAC policies
istio policies
how secure express app against common vulnerability xss, csrf and sql injection
    helmet and cors
modeling relationship
hydration in ssr
useTransition
useActions hook
mongodb aggreagation pipeline stages
