# MutationObserver
    is a built-in Web API that allows you to detect when changes are made to the browser's DOM tree.
    it waits for a batch of DOM changes to finish before triggering a single, high-performance callback

    MutationObserver can be configured to watch a specific HTML element
    for three main categories of changes:
        Child Nodes (childList): Adding or removing child elements/text.
        Attributes (attributes): Modifying, adding, or deleting an element's attributes (like class, src, disabled).
        Character Data (characterData): Changing the actual text content inside a text node.

    // 3. Create an observer instance linked to the callback
        const observer = new MutationObserver(callback);

    // 4. Start observing the target node with specific options
        const config = { 
            attributes: true,     // Watch for attribute changes
            childList: true,      // Watch for additions/deletions of children
            subtree: true         // Watch target's children, grandchildren, etc.
        };
    observer.observe(targetNode, config);