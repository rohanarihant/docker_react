# q1

var obj = { name: 'Piyush'}

function sayHello(){
    return 'Hello '+this.name // 'Hello'
}
sayHello()
// solution
console.log(sayHello.call(obj, 24)) // 'Hello Piyush'

#
const person = { name: 'Piyush'}

function sayHi(age){
    return `${this.name} is ${age}`
}

console.log(sayHi.call(person, 24))
console.log(sayHi.bind(person, 20))

#
const age = 10;

var person = {
    name: 'Piyush',
    age: 20,
    getAge: function() {
        return this.age
    }
}

var person2 = {age: 24}
person.getAge.call(person2) // 24

#
var status = "$"

setTimeout(() => {
    const status = "*"
    const data = {
        status: "0",
        getStatus(){
            return this.status
        }
    }
    console.log(data.getStatus())
    console.log(data.getStatus.call(this)) // here this
},0)

// here this never points to a function setTimeout, it will point to the context of that function
// which is window object