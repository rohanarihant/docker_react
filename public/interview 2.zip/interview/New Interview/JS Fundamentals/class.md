Complete Guide: ES6 Classes (ECMAScript 2015)
    ES6 introduced a syntactic sugar over JavaScript's existing prototype-based inheritance. Classes make object-oriented programming in JavaScript more intuitive and familiar to developers coming from other languages.

    📚 Overview of ES6 Classes
        Feature	                        Description
        Introduced	                    ECMAScript 2015 (ES6)
        Type	                        Syntactic sugar over prototypes
        Purpose	                        Cleaner, more intuitive OOP in JavaScript
        Inheritance	                    extends keyword for class inheritance
        Constructor	                    constructor() method
        Methods	                        Defined inside the class body
        Getters/Setters	                get and set keywords
        Static Methods	                static keyword
        Private Fields	                # prefix (ES2022)

    🏗️ Basic Class Syntax
        1. Class Declaration
            // ES6 Class
class Person {
  constructor(name, age) {
    this.name = name;
    this.age = age;
  }

  // Instance method
  greet() {
    return `Hello, my name is ${this.name}`;
  }

  // Getter
  get isAdult() {
    return this.age >= 18;
  }

  // Setter
  set birthYear(year) {
    this.age = new Date().getFullYear() - year;
  }

  // Static method (called on class, not instance)
  static createAnonymous() {
    return new Person('Anonymous', 0);
  }
}

// Usage
const john = new Person('John', 25);
console.log(john.greet()); // "Hello, my name is John"
console.log(john.isAdult); // true
john.birthYear = 2000;
console.log(john.age); // 24 (depending on current year)

const anonymous = Person.createAnonymous();
console.log(anonymous.name); // "Anonymous"


2. Class Expression
        // Anonymous class expression
const Animal = class {
  constructor(name) {
    this.name = name;
  }
  
  speak() {
    console.log(`${this.name} makes a noise.`);
  }
};

// Named class expression
const Dog = class DogClass {
  constructor(name) {
    this.name = name;
  }
  
  bark() {
    console.log(`${this.name} barks!`);
  }
};

const dog = new Dog('Rex');
dog.bark(); // "Rex barks!"

1. Constructor Method
    The constructor method is a special method for creating and initializing objects.

2. Instance Methods
    class Calculator {
  constructor() {
    this.result = 0;
  }

  // Instance method
  add(value) {
    this.result += value;
    return this; // For method chaining
  }

  subtract(value) {
    this.result -= value;
    return this;
  }

  multiply(value) {
    this.result *= value;
    return this;
  }

  getResult() {
    return this.result;
  }

  // Method with default parameters
  power(exponent = 2) {
    this.result = Math.pow(this.result, exponent);
    return this;
  }
}

const calc = new Calculator();
calc.add(10).subtract(3).multiply(2).power(3);
console.log(calc.getResult()); // (10 - 3) * 2^3 = 56

3. Getters and Setters
    class Temperature {
  constructor(celsius) {
    this._celsius = celsius;
  }

  // Getter
  get celsius() {
    return this._celsius;
  }

  // Setter with validation
  set celsius(value) {
    if (value < -273.15) {
      throw new Error('Temperature below absolute zero is impossible');
    }
    this._celsius = value;
  }

  // Computed getter
  get fahrenheit() {
    return (this._celsius * 9/5) + 32;
  }

  // Computed getter with setter
  set fahrenheit(value) {
    this._celsius = (value - 32) * 5/9;
  }

  get kelvin() {
    return this._celsius + 273.15;
  }

  set kelvin(value) {
    this._celsius = value - 273.15;
  }
}

const temp = new Temperature(25);
console.log(temp.celsius); // 25
console.log(temp.fahrenheit); // 77
console.log(temp.kelvin); // 298.15

temp.celsius = 30;
console.log(temp.fahrenheit); // 86

temp.fahrenheit = 100;
console.log(temp.celsius); // 37.777...

4. Static Methods and Properties
    Static methods/properties are called on the class itself, not on instances.

    class MathUtils {
  // Static property
  static PI = 3.14159;

  // Static method
  static add(a, b) {
    return a + b;
  }

  static subtract(a, b) {
    return a - b;
  }

  static multiply(a, b) {
    return a * b;
  }

  static divide(a, b) {
    if (b === 0) {
      throw new Error('Division by zero');
    }
    return a / b;
  }

  // Static method using static properties
  static areaOfCircle(radius) {
    return this.PI * radius * radius;
  }
}

// Usage (no instance needed)
console.log(MathUtils.PI); // 3.14159
console.log(MathUtils.add(5, 3)); // 8
console.log(MathUtils.areaOfCircle(5)); // 78.53975

📚 What is super()?
    super() is a special function call used inside a derived class constructor to call the parent class constructor.
    It's mandatory when you extend a class and need to access this before calling the parent constructor.

