# BOM
    BOM represents the browser environment hosting the webpage
    objects and methods to interact with things outside the actual page content
    like the browser's address bar, history stack, cookies, device screen resolution, and popups
        Scope: The entire browser window and device environment.
        Core Object: window
        W3C Standard: No. There is no official global standard specification for the BOM
        (though major browsers have naturally standardized its APIs over time to ensure web compatibility)

# DOM
    DOM represents the content, structure, and style of the current HTML document.
    parses the HTML and builds a tree structure of objects
        Scope: Limited strictly to the content area inside the viewport tab.
        Core Object: document
        W3C Standard: Yes. The DOM is strictly standardized by the W3C,
        meaning it behaves almost identically across all modern browsers (Chrome, Safari, Firefox)

