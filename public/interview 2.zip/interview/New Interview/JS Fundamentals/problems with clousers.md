# Clousers

A closure is a feature in JavaScript where an inner function retains access to variables from its outer (enclosing) function's scope, even after the outer function has finished executing.

function makeCounter() {
  let count = 0; // Private variable trapped inside the closure

  return function() {
    count++;
    console.log(count);
  };
}

const counter = makeCounter(); // makeCounter() finishes executing here
counter(); // Logs: 1
counter(); // Logs: 2

# Common Problems with Closures

# Problem 1: Memory Consumption & Memory Leaks
    Because closures hold references to variables in their outer scope,
    JavaScript's Garbage Collector cannot clean up those variables
    as long as the closure function reference exists in memory.

    function heavyTask() {
        const hugeData = new Array(10000000).fill("🐘"); // Huge memory allocation

        return function() {
            console.log("Hello!"); // Doesn't even use hugeData, but keeps reference alive!
        };
    }

    const leakyFunc = heavyTask(); 
    // `hugeData` remains stuck in RAM as long as `leakyFunc` exists!

    FIX
    // Remove event listeners or set reference to null when done
    leakyFunc = null; // Garbage collector can now free hugeData

# Problem 2: The Stale Closure Problem (Very Common in React)
    A closure captures the value of variables at the exact moment the closure was created.
    If the outer variable changes later, but the inner closure function is not re-created,
    the closure continues to read the old ("stale") value.

    function setupTimer() {
  let count = 0;

  setInterval(function() {
    // This closure captured `count` at creation time
    console.log(`Count is: ${count}`); 
  }, 1000);

  // Update count later
  setTimeout(() => {
    count = 100; // The interval callback still prints the captured state!
  }, 2000);
}

    In React, stale closures frequently occur inside useEffect, useCallback, or event handlers when state dependencies are omitted from dependency arrays.

#   Problem 3: The Classic for Loop Scope Trap
    Before ES6 let and const, developers used var. Because var is function-scoped (not block-scoped), a single var variable is shared across all iterations of a loop.

    for (var i = 0; i < 3; i++) {
        setTimeout(function() {
            console.log(i); // Logs: 3, 3, 3 (NOT 0, 1, 2!)
        }, 1000);
    }

