#   Shallow Copy vs Deep Copy in JavaScript
    📚 Core Difference
    Shallow Copy                                                Deep Copy
        Copies only the top-level properties                        Copies all nested levels recursively
        References to nested objects are shared                     Nested objects are completely independent
        Changes to nested objects affect both copies                Changes to nested objects affect only the copy
        Fast and memory-efficient                                   Slower and uses more memory
        Sufficient for flat objects                                 Required for complex, nested structures


    🎯 Visual Example
        // Original object with nested structure
            const original = {
            name: 'John',
            age: 30,
            address: {
                city: 'New York',
                zip: '10001'
            },
            hobbies: ['reading', 'gaming']
            };

            // ---------- SHALLOW COPY ----------
            const shallow = { ...original };

            shallow.name = 'Jane';              // ✅ Changes only shallow copy
            shallow.address.city = 'LA';        // ❌ Changes BOTH! (shared reference)
            shallow.hobbies.push('coding');     // ❌ Changes BOTH! (shared reference)

            console.log(original.address.city); // 'LA'  ← Changed!
            console.log(original.hobbies);      // ['reading', 'gaming', 'coding'] ← Changed!

            // ---------- DEEP COPY ----------
            const deep = JSON.parse(JSON.stringify(original));

            deep.name = 'Bob';                 // ✅ Changes only deep copy
            deep.address.city = 'Chicago';     // ✅ Changes only deep copy
            deep.hobbies.push('swimming');     // ✅ Changes only deep copy

            console.log(original.address.city); // 'LA' (unchanged)
            console.log(original.hobbies);      // ['reading', 'gaming', 'coding'] (unchanged)