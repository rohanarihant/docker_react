# Design Pattern
    Design patterns in JavaScript are reusable solutions to commonly occurring problems in software design
    They act as templates for writing organized, maintainable, and scalable code

# 1. Creational Patterns
    These patterns manage object creation mechanisms,
    optimizing how objects are instantiated.

#       Singleton Pattern
    Ensures a class has only one instance globally and provides a single point of access to it
    It is heavily used for shared resources like database connections or global configuration states

    class DatabaseConnection {
    constructor() {
        if (DatabaseConnection.instance) {
        return DatabaseConnection.instance;
        }
        this.connectionString = "mongodb://localhost:27017";
        DatabaseConnection.instance = this;
    }

    connect() {
        console.log(`Connected to ${this.connectionString}`);
    }
    }

    // Usage
    const conn1 = new DatabaseConnection();
    const conn2 = new DatabaseConnection();

    console.log(conn1 === conn2); // true (Both point to the exact same instance)

#       Factory Pattern
    Provides a generic interface for creating objects without specifying their exact concrete classes.
    The logic of object creation is hidden from the client.

    class Developer {
        constructor(name) {
            this.name = name;
            this.type = "Developer";
        }
    }

    class Tester {
        constructor(name) {
            this.name = name;
            this.type = "Tester";
        }
    }

    class EmployeeFactory {
        createEmployee(name, type) {
            switch(type) {
            case "developer": return new Developer(name);
            case "tester": return new Tester(name);
            default: throw new Error("Unknown employee type");
            }
        }
    }

    // Usage
    const factory = new EmployeeFactory();
    const emp1 = factory.createEmployee("Alice", "developer");
    const emp2 = factory.createEmployee("Bob", "tester");

# 2. Structural Patterns
    These patterns deal with object composition and defining relationships between disparate entities.

#       Module Pattern
        Encapsulates code to mimic private and public properties,
        keeping variables clean from polluting the global scope.
        While modern JavaScript uses native ES6 modules, the classic closure-based approach remains fundamental.

        const UserModule = (() => {
        // Private variables and methods
        let privateToken = "secret_123"; 

        const getPrivateToken = () => privateToken;

        // Publicly exposed API
        return {
            getUserStatus: () => {
            return `User is active with token status: ${getPrivateToken() ? "Valid" : "Invalid"}`;
            }
        };
        })();

        // Usage
        console.log(UserModule.getUserStatus()); // User is active with token status: Valid
        console.log(UserModule.privateToken);    // undefined (Cannot access private variable)

#       Proxy Pattern
        Acts as a placeholder or wrapper for another object to control access to it.
        It lets you perform operations before or after the request gets through to the original object.

        const networkCar = { model: "Tesla Model 3", status: "Active" };

        // A proxy protecting access to the networkCar object
        const carProxy = new Proxy(networkCar, {
            get: (target, prop) => {
                console.log(`Accessing property: ${prop}`);
                return target[prop];
            },
            set: (target, prop, value) => {
                if (prop === "status" && value !== "Active" && value !== "Inactive") {
                throw new Error("Invalid status update!");
                }
                target[prop] = value;
                return true;
            }
        });

        // Usage
        console.log(carProxy.model); // Logs: Accessing property: model -> Outputs: Tesla Model 3
        carProxy.status = "Inactive"; // Works fine
        // carProxy.status = "Broken"; // Throws Error: Invalid status update!

# 3. Behavioral Patterns
    These patterns focus on optimizing and improving the communication protocol between different objects.

#       Observer (Pub/Sub) Pattern
        Defines a subscription mechanism where multiple components can listen to events happening on a core subject.
        It is widely used in event-driven UIs and state management.

        class Subject {
        constructor() {
            this.observers = [];
        }

        subscribe(fn) {
            this.observers.push(fn);
        }

        unsubscribe(fn) {
            this.observers = this.observers.filter(sub => sub !== fn);
        }

        notify(data) {
            this.observers.forEach(fn => fn(data));
        }
        }

        // Usage
        const newsFeed = new Subject();

        const user1 = (data) => console.log(`User 1 received: ${data}`);
        const user2 = (data) => console.log(`User 2 received: ${data}`);

        newsFeed.subscribe(user1);
        newsFeed.subscribe(user2);

        newsFeed.notify("Breaking News: JS Design Patterns are powerful!"); 
        // Outputs to both User 1 and User 2


#       Strategy Pattern
        Encapsulates a family of algorithms and makes them interchangeable at runtime.
        The client can easily swap strategies without modifying the underlying application logic.

        // Strategies
        const standardShipping = (amount) => amount + 5;
        const expressShipping = (amount) => amount + 15;
        const freeShipping = (amount) => amount;

        // Context
        class ShippingCart {
        constructor(strategy) {
            this.strategy = strategy;
        }

        setStrategy(strategy) {
            this.strategy = strategy;
        }

        calculateTotal(amount) {
            return this.strategy(amount);
        }
        }

        // Usage
        const cart = new ShippingCart(standardShipping);
        console.log(cart.calculateTotal(100)); // 105

        cart.setStrategy(expressShipping);
        console.log(cart.calculateTotal(100)); // 115


# Dependency Injection Pattern
        To ensure testability and decoupling,
        objects should receive their dependencies from the outside rather than importing or instantiating them directly. This makes mocking databases or third-party APIs during testing incredibly easy

        // UserService doesn't hardcode how to fetch data; it depends on an abstraction
        class UserService {
        constructor(databaseClient) {
            this.db = databaseClient; 
        }

        async getUser(id) {
            return this.db.findById(id);
        }
        }

        // Production Usage
        const productionDb = { findById: async (id) => ({ id, name: "Alice" }) };
        const userService = new UserService(productionDb);

        // Testing Usage (Mocking)
        const mockDb = { findById: async (id) => ({ id, name: "Mocked User" }) };
        const testService = new UserService(mockDb);



# The Factory Pattern (The Object Generator)
What it is: A function that creates and returns objects without requiring the new keyword or a class constructor. It centralizes object creation logic.

When to use: When you need to create multiple objects that share a similar structure but have different properties, or when the creation logic is complex.

Why it's powerful in JS: JavaScript's object literals make factories incredibly lightweight

// Factory function
const createUser = (name, role) => {
  return {
    name,
    role,
    isAdmin: role === 'admin',
    introduce() {
      console.log(`Hi, I'm ${this.name}, a ${this.role}`);
    }
  };
};

const user1 = createUser('Alice', 'admin');
const user2 = createUser('Bob', 'editor');
user1.introduce(); // "Hi, I'm Alice, a admin"


# The Singleton Pattern (The One and Only)
    What it is: Ensures a class has only one instance and provides a global point of access to it.

When to use: Managing global app state, logging, database connections, or configuration objects where having multiple instances would cause conflicts.

Modern JS Implementation: In ES6, modules are already singletons by default. If you export an object from a module, it's shared across your entire app.

// Using a module (the modern singleton)
// config.js
export const AppConfig = {
  apiUrl: 'https://api.example.com',
  theme: 'dark',
  setTheme(newTheme) {
    this.theme = newTheme;
  }
};

// Any file that imports AppConfig gets the SAME instance.


// Classic Singleton using a Class (with a static method)
class DatabaseConnection {
  constructor() {
    if (DatabaseConnection.instance) {
      return DatabaseConnection.instance;
    }
    this.connectionString = 'mongodb://localhost:27017';
    DatabaseConnection.instance = this;
  }

  connect() {
    console.log(`Connecting to ${this.connectionString}`);
  }
}

const db1 = new DatabaseConnection();
const db2 = new DatabaseConnection();
console.log(db1 === db2); // true - They are the exact same instance!


# The Constructor Pattern (The Classy Way)
    What it is: The standard way to create multiple objects of the same "type" using class syntax or constructor functions.

    When to use: When you need inheritance, private fields, or static methods. Modern JS heavily favors classes for domain modeling.

    class Product {
    constructor(name, price) {
        this.name = name;
        this.price = price;
    }

    getDiscountedPrice(discount) {
        return this.price * (1 - discount);
    }
    }

    const laptop = new Product('Laptop', 1200);




