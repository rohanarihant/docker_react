# This
    is used to reference something
    means the context we are currently in
 
# This in Arrow Function
    this keyword value of arrow function comes from its parent function
    if we have a parent func which is a normal func, it will take reference from that func


 # This in normal object
    let user = {
        name: "piyush",
        age: 24,
        getDetails(){
            console.log(this)
        }
    }
    user.getDetails(); // {name: 'piyush', age: 24, getDetails: ƒ}

# this inside nested object and accessing parent object this
    let user = {
        name: "piyush",
        age: 24,
        childObj: {
            newName: 'Roadside Coder',
            getDetails(){
                console.log(this.newName, 'and', this.name);
            }
        }
    }
    user.childObj.getDetails(); // Roadside Coder and undefined

# This inside Arrow Function
    let user = {
        name: "Piyush",
        age: 24,
        getDetails: () => {
            console.log(this.name); // undefined, (this refer to window object)
        }
    }
    user.getDetails();

# This in nested Arrow Function
    let user = {
        name: "Piyush",
        age: 24,
        getDetails(){
            const nestedArrow = () => console.log(this.name) // Piyush
            nestedArrow(); // parent of this func is getDetails and this taking from object user 
        }
    }
    user.getDetails();

# This inside Class

class User {
    constructor(n){
        this.name = n;
    }
    getName(){
        console.log(this.name)
    }
}
const user = new User("Piyush")
console.log(user) // {name: 'Piyush'}
console.log(user.getName()) // 'Piyush'

# this in object with duplicate variable
    const user = {
        firstName: "Piyush!",
        getName() {
            const firstName = 'Piyush Agarwal';
            return this.firstName;
        }
    }
    console.log(user.getName()) // Piyush!

# this with reference in object
    function makeUser() {
        return {
            name: 'John',
            ref: this
        }
    }
    let user = makeUser();
    console.log(user.ref.name) // undefined  (this point to window object)
        // makeUser() is called as a plain function (not as a method on an object, not new, not .call()/.apply()/.bind())
        // when a function is called this way, this defaults to the global object:

# this with reference in object in a method return
    function makeUser(){
        return {
            name: 'John',
            ref() {
                return this
            }
        }
    }
    let user = makeUser();
    console.log(user.ref().name) // 'John'
        // The crucial difference is that ref is now a method (a function attached to an object),
        // not a property that gets evaluated immediately.

# this inside a setTimeout as a callback
    const user = {
        name: 'Piyush Agarwal!',
        logMessage(){
            console.log(this.name)
        }
    }
    setTimeout(user.logMessage, 1000); // will print nothing in the console
        // taking user.logMessage as a callback rather then a method
        // this cb will execute independently and access to the window object

# this inside a setTimeout as a method
    const user = {
        name: 'Piyush Agarwal!',
        logMessage(){
            console.log(this.name)
        }
    }
    setTimeout(function() {
        user.logMessage() // 'Piyush Agarwal!'
    }, 1000);
    This callback is scheduled to run after 1000ms
    This is a method call on the user object

# 
const user = {
    name: "Piyush",
    greet(){
        return `Hello, ${this.name}!`
    },
    farewell: () => {
        return `Goodbye, ${this.name}!`
    }
}
console.log(user.greet()); // Hello Piyush
console.log(user.farewell()); // Goodbye, !

# this with callback
function callback(){
    console.log(this.length)
}

const object = {
    length: 5,
    method(fn){
        fn() // return undefined (this belongs to window)
    }
}
object.method(callback)
    This is a plain function call (no object, no new, no call/apply/bind)
    When a function is called as fn(), this defaults to:
    In non-strict mode: window (global object)
    In strict mode: undefined


// Fix
function callback(){
    console.log(this.length)
}
const object = {
    length: 5,
    method(){
       arguments[0]() 
    }
}
object.method(callback, 2, 3) // 3 (length)

# Regular function in strict mode vs sloppy mode
    function showThis() {
        console.log(this);
    }
    showThis(); // window
 
# Method vs function — spot the difference
    const obj = {
        name: 'Rohan',
        greet: function() {
            console.log(this.name);
            }
        };
    obj.greet(); // Rohan
    const fn = obj.greet;
    fn(); // ""

# Nested regular function loses `this`
    const obj = {
        value: 42,
        outer: function() {
            function inner() {
                console.log(this.value);
            }
            inner();
        }
    };
    obj.outer(); // undefined

# Arrow function captures enclosing `this`
    const obj = {
        value: 10,
        getValue: function() {
            const arrow = () => console.log(this.value);
            arrow();
            }
        };
    obj.getValue(); 10

# Arrow function as an object method
    const obj = {
        name: 'Rohan',
        greet: () => {
            console.log(this.name);
        }
    };
    obj.greet(); "" // window

# Arrow inside setTimeout
    function Timer() {
        this.seconds = 0;
        setInterval(() => {
            this.seconds++;
            console.log(this.seconds);
        }, 1000);
    }
const t = new Timer(); // 1

# Cannot bind/call/apply an arrow function's `this`
    const arrow = () => console.log(this);
    const obj = { name: 'test' };
    arrow.call(obj); // Window
    arrow.apply(obj); // Window
    const bound = arrow.bind(obj);
    bound(); // Window

# call() explicitly sets `this`
    function introduce(city, country) {
        console.log(`${this.name}, ${city}, ${country}`); // Rohan, Bengaluru, India
    }
    const person = {
        name: 'Rohan'
    };
    introduce.call(person, 'Bengaluru', 'India');

# apply() vs call() — array args
    function sum() {
        return Array.from(arguments).reduce((a, b) => a + b, this.initial); 
    }
    const ctx = { initial: 10 };
    console.log(sum.apply(ctx, [1, 2, 3])); // 16

# bind() returns a new function — not called immediately
    const obj = { x: 5 };
    function double() {
        return this.x * 2;
    }
    const boundFn = double.bind(obj);
    console.log(typeof boundFn); // function
    console.log(boundFn()); // 10

# bind() with partial application
    function multiply(a, b) {
        return a * b;
    }
    const double = multiply.bind(null, 2);
    console.log(double(5)); // 10
    console.log(double(10)); // 20

# SECTION 4 — Classes & Constructors
# Constructor function — `this` is the new instance
    function Person(name) {
        this.name = name;
    }
    Person.prototype.greet = function() {
        console.log('Hi, I am ' + this.name);
    };
    const p = new Person('Rohan');
    p.greet(); // Rohan
    const fn = p.greet;
    fn(); // ""

# ES6 class method — `this` lost on destructuring
    class Counter {
        constructor() {
            this.count = 0;
        }
        increment() {
            this.count++;
            console.log(this.count);
        }
    }
    const c = new Counter();
    const { increment } = c;
    increment(); // Cannot read properties of undefined

# Arrow class field — `this` is always the instance
    class Button {
        label = 'Click me';
        handleClick = () => {
            console.log(this.label);
        }
    }
    const btn = new Button();
    const { handleClick } = btn;
    handleClick(); // click me

# SECTION 5 — Tricky & Advanced Scenarios
# Chained method calls — `this` in each
    const calc = {
        val: 0,
        add(n) {
            this.val += n;
            return this;
        },
        mul(n) {
            this.val *= n;
            return this;
        },
        result() {
            return this.val; 
        }
    };
    console.log(calc.add(5).mul(3).result()); // 15

# Event handler — `this` is the DOM element
    // Assume this runs in a browser
    const btn = document.querySelector('button');
    btn.addEventListener('click', function() {
        console.log(this === btn);
    });
    btn.addEventListener('click', () => {
        console.log(this === btn);
    });

# IIFE and `this`
    const obj = {
        name: 'Test',
        init: function() {
            (function() {
                console.log(this.name);  // "" Window
            })();
        }
    };
    obj.init();
    // Inside init, an IIFE is defined and immediately called
    // Plain function calls get this = window (non-strict) or undefined (strict)

# Prototype chain — where does `this` point?
    function Animal(name) {
        this.name = name;
    }
    Animal.prototype.speak = function() {
        console.log(this.name + ' speaks');
    };
    function Dog(name) {
        Animal.call(this, name);
    }
    Dog.prototype = Object.create(Animal.prototype);
    const d = new Dog('Rex');
    d.speak(); // Rex speaks

# Promise chain — `this` is lost
    class ApiService {
        constructor() {
            this.baseUrl = 'https://api.test.com';
        }
        fetch() {
            return Promise.resolve('data').then(function(data) {
                console.log(this.baseUrl); // undefined Window
                return data;
            });
        }
    }
    new ApiService().fetch();

# Double binding — bind() is immutable
    function greet() {
        console.log(this.name);
    }
    const obj1 = {
        name: 'Alice'
    };
    const obj2 = {
        name: 'Bob'
    };
    const fn1 = greet.bind(obj1);
    const fn2 = fn1.bind(obj2);
    fn2(); // Alice

    The Key Rule: bind() Once, Bound Forever
    new function with a permanently bound this value
    You cannot rebind a bound function!