# Content Security Policy
    is a security standard which help to mitigate the cross-site-scripting
        CSS :- when someone injected the malicious scripts into the website.

    these types of attcks are mitigated by CSP

    to protect we need to define some rules iin CCSP
        we need to giive some directive( is what csp take)


CSP Importance: Web security, mitigates attacks, controls resource loading, enhances safety.

HTTP Header Purpose: Defines security rules, sent with response, guards against web threats.

CSP Threat Mitigation: Guards against XSS, data injection, enhances web application security.

Directives in CSP: Define content rules, guide browser behavior, enforce security policies.

default-src Directive: Default source for content without specific directives, foundational in CSP.

script-src Purpose: Controls allowed script sources, mitigates script-related security risks.

'self' Keyword Significance: Restricts content to the same origin, enhances security.

Risks of 'unsafe-inline' and 'unsafe-eval': Allows potentially insecure script execution, increasing vulnerability to attacks.

report-uri/report-to Use: Reports policy violations to specified endpoint, aids security monitoring.

CSP for XSS Prevention: Restricts script sources, mitigates cross-site scripting risks, strengthens security.

CSP Impact on Performance: Balancing security and speed, optimizing directives for efficiency.

Example of Well-Structured CSP Header: Specifies trusted sources, defines content security rules for hypothetical website.


<!-- Add CSP into the web app -->
    using the meta tag
        <meta http-equiv="Content-Security-Policy" content=""/>
            directives :- 
                default-src
                style-src
                script-src

<!-- Exmp :- inject a meta tag with Content Security Policy Dynamically -->
    const policyValue = "default-src 'self: script-src' self https://trusted-scripts.com";
                            self -> same origin,  but from this endpoint

        // create a new Meta Tag
            const metaTag = document.createElement('meta');
            metaTag.httpEquiv = 'Content-Security-Policy';
            metaTag.content = policyValue;

        // Append the meta tag to the document's head
            document.head.appendChild(metaTag);

<!-- default valid CSP headers/directives -->

    default-src :- defines the default policy for featching resources such as js, css, img, font, ajax req, frames, html5 media
    script-src :- self js.example.com; - valid sources of js
    style-src :- self css.example.com; - valid sources of css
    img-src :- self img.example.com; - valid sources of images
    font-src :- self font.example.com; - valid sources of font resources

<!-- how do you report CSP violations -->
    report-uri
    report-to

    Content-Security-Policy : default-src 'self; report-uri/csp-report-endpoint'
    browser will send the violation report to the endpoint


<!-- How to test CSP -->
    should know some tools
    CSP evaluator -> verify the direcctive here
    CSP playground -> define some CSP directive, and check
