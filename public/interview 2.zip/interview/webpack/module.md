npm link
 whenever we are loading a new package.
 it will check that package is a core module of react
 then it will check the realtive path 

 * npm link is cmd allow you to load a module from anywhere on our computer
        go to the pacckage or library folder
            npm link
                (create a symbolic link in the global node module folder)
                whenever in our app level we import this package it will go to the global nnode_module and found it refer to the local path

        go to the folder where we want to import the package
            npm link package-name
                we can access the package there  
 

own package config
    { 
        repository: github link (for people to check our repo)
        author,
        licence
        scripts: {
            "compile" : "rm -rf dist/lib && tsc && tsc --build tsconfig.es5.json"
                                    (generate es6 file)     (generate es5 file)
        }

    }

    inside the dist folder we should have a package.json with this config
        {
            name: unique name,
            main: "lib/es5/indes.js" (with require  keyworrd can import)
            module: "lib/es6/indes.js" (with import keyworrd can import),
            repository: {
                type: git,
                url: "github url to shownn on npm package page"
            }
        }

    inside the dist folder write 
        npm publish
        npm adduser
        npm publish --access=public

