**webpack.config**

webpack config will have all the wbk configs
    we can definne all loaders and pugins

<!-- cmd -->
webpack --config webpack.config.js
