wbk plugins allows to access or plug into wbk lifecycle this allow us to do things such as 
config global constants at compile time
monitor wbk compilation process
create html files to serve bundles wbk creates
* plugins allows to do all things which loaders can't do
we can use the plugin key in a wbk connfig file
wbk plugins cann be local hosted on npm
even built into wbk itself


e.g :- 
htmlWebpackPlugin


const webpack = require("webpack");

module.exports = {
    entry: './src/index.js',
    output: {
        filename: '[name].bundle.js',
        path: '${__dirname}/my-output'
        clean: true
    },
    plugins: [new webpack.PressPlugin()]
}