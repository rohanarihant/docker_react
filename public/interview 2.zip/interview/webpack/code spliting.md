# Code splitting
    a Webpack optimization technique that breaks your application's single bundle into smaller chunks
    These chunks can then be loaded on demand or in parallel,
    significantly reducing initial page load times and saving bandwidth

    Three Methods for Code Splitting :-
        1. Entry Points
            Manually separate your bundles by specifying multiple entry configuration points in webpack.config.js.
            This is ideal for multi-page applications.

            // webpack.config.js
                module.exports = {
                    mode: 'production',
                    entry: {
                        index: './src/index.js',
                        another: './src/another-module.js',
                    },
                    output: {
                        filename: '[name].[contenthash].bundle.js', // Generates distinct filenames
                        path: __dirname + '/dist',
                        clean: true,
                    },
                };
           The Catch:
           If both entry files share third-party dependencies (like lodash or axios),
           those modules will be duplicated inside both final bundles.
        2. Prevent Duplication (SplitChunksPlugin)
            To fix the duplication issue created by multiple entry points,
            configure the optimization.splitChunks block.
            This automatically extracts shared dependencies into an isolated vendor chunk.

            // webpack.config.js
                module.exports = {
                // ... entry and output configurations ...
                    optimization: {
                        splitChunks: {
                        chunks: 'all', // Splitting applies to synchronous and asynchronous chunks
                        },
                    },
                };
        3. Dynamic Imports (On-Demand Loading)
        