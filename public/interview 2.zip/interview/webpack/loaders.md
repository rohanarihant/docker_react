**Loaders**

    its a funnction which trannsform the source code.
        e.g :- loader will trannsform the ts to js
                scss to css
                css to strinngs
            dont need loader for js, webpack knnow js
            loaders are downloaded as a npm dev dependency


    module.exports = {
        entry: "./src/index.js",
        output: {
            filename: "[name].bundle.js",
            path: `${__dirname}/my-output`,
            clean: true // this will delete the index.html and create a new one
        },
        module: {
            rules: [
                {
                    test: /\.css$/,
                    use: 'css-loader'
                    <!-- use: ['style-loader', 'css-loader'] -->
                }
            ]
        }
    }

    module key tells webpack how to diff modules types should be handled
    module is a desccreate chunk of code
    we can tell wbk how it should handle diff module types by usinng rules. 
    rules key can be array of objs, tells wbk how to handle modules

    order of loader is also imp
    here we need css loader to run 1st then style loader

Execution Order: Right-to-Left (Bottom-to-Top)
    module.exports = {
    module: {
        rules: [
        {
            test: /\.s[ac]ss$/i,
            use: [
            'style-loader', // 3. Injects CSS into the DOM via <style> tags
            'css-loader',   // 2. Turns CSS into CommonJS modules
            'sass-loader'   // 1. Compiles Sass/SCSS down into standard CSS
            ]
        }
        ]
    }
    };
        





* npm i css-loader -D (convert css to string)
* npm i style-loader -D  (o/p from css loader and applies to dom)