JS design Pattern

1. Module Pattern
    A module is a file containing JavaScript code and makes it easy to expose and hide certain values.
    The module pattern is a great way to split a larger file into multiple smaller, reusable pieces.
    It also promotes code encapsulation, since the values within modules are kept private inside the module by default, and cannot be modified.
    Only the values that are explicitly exported with the export keyword are accessible to other files.

    HTML TAG :
        When adding JavaScript to HTML files directly, you can use modules by adding the type="module" attribute to the script tags.    
    NODE :
        Adding "type": "module" to your package.json

2. Singleton Pattern
    With the Singleton Pattern, we restrict the instantiation of certain classes to one single instance.
    This single instance is unmodifiable, and can be accessed globally throughout the application.
    This singleton can be shared globally across multiple files within the application.
    The imports of this Singleton all reference the same instance.

        -For example, we can have a Counter singleton, which contains a getCount, increment, and decrement method.
        -The increment method increments the value of counter by 1. Any time the increment method has been invoked anywhere in the         application, thus changing the value of counter, the change is reflected throughout the entire application.


    #Using Class 
        let instance;
        // 1. Creating the `Counter` class, which contains a `constructor`, `getInstance`, `getCount`, `increment` and `decrement` method.
        // Within the constructor, we check to make sure the class hasn't already been instantiated.
        class Counter {
        constructor() {
            if (instance) {
            throw new Error("You can only create one instance!");
            }
            this.counter = counter;
            instance = this;
        }

        getCount() {
            return this.counter;
        }

        increment() {
            return ++this.counter;
        }

        decrement() {
            return --this.counter;
        }
        }

        // 2. Setting a variable equal to the the frozen newly instantiated object, by using the built-in `Object.freeze` method.
        // This ensures that the newly created instance is not modifiable.
        const singletonCounter = Object.freeze(new Counter());

        // 3. Exporting the variable as the `default` value within the file to make it globally accessible.
        export default singletonCounter;


    #Using Object Methods
        let counter = 0;
        const counterObject = {
            increment : ++counter,
            decrement: --counter,
            getCount: counter
        }

        const singletonCounter = Object.freeze(counterObject);
        export default singletonCounter;


    TRADE OFF :- 
        Restricting the instantiation to just one instance could potentially save a lot of memory space. Instead of having to set up memory for a new instance each time, we only have to set up memory for that one instance, which is referenced throughout the application.

        Unnecessary: ES2015 Modules are singletons by default. We no longer need to explicitly create singletons to achieve this global, non-modifiable behavior.

        Depedency Hiding: When importing another module, it may not always be obvious that that module is importing a Singleton. This could lead to unexpected value modification within the Singleton, which would be reflected throughout the application.

    Example :- 
        DB connection

    
3. Proxy Pattern

    The Proxy Pattern uses a Proxy intercept and control interactions to target objects.
    Let's say that we have a person object. We can access properties with either dot or bracket notation,
    With the Proxy pattern, we don't want to interact with this object directly. Instead, a Proxy object intercepts the request, and (optionally) forwards this to the target object - the person object in this case.


    Implementation :- 
        In JavaScript, we can easily create a new proxy by using the built-in Proxy object.
            -The target object
            -A handler object, which we can use to add functionality to the proxy. This object comes with some built-in functions that we can use, such as get and set.


        const person = {
                name: "Rohan",
                age: 40,
                email: "rohan@gmail.com",
                country: "India"
        }
        
        constt personProxy = new Person(person, {
            get: (target, prop) => {
                return target[prop];
            },
            set: (target, prop, value) => {
                target[prop] = value;
                return true;
            }
        })


        anothter example
            new Proxy((person), {
                get: (target, property) => {
                    return Reflect.get(target, property)
                },
                set: (target, property) => {
                    return Reflect.set(target, property)
                }
            })


    Take Off :- 
    Proxies make it easy to add functionality when interacting with a certain object, such as validation, logging, formatting, notifications, debugging.



4. Observer Pattern

    in this pattern we will have
        1. Observable object, which can be observed by subscribers in order to notify them.
        2. Subscriber, which will be notified by observer

    For example, we can add the logger as a subscriber to the observable.


    Implementation
        we can create a singleton Observer object, which will notify, subscribe and unsubscribe method.


        const observer = [];
        export default Object.freeze({
            notify: (data) => observer.forEach((observer) => observer(data)),
            susbcribe: (func) => observer.push(func),
            unsubscribe: (func) => {
                [...observer].forEach((observer, index) => {
                    if(observer === func){
                        observers.splice(index,1);
                    }
                });
            }
        })


    
    Trade Off :- 
    Separation of Concerns: The observer objects aren't tightly coupled to the observable object, and can be (de)coupled at any time. The observable object is responsible for monitoring the events, while the observers simply handle the received data.

    Decreased performance: Notifying all subscribers might take a significant amount of time if the observer handling becomes too complex, or if there are too many subscibers to notify.


5. Factory Pattern

    in this we can use a special function - factory function - to create many of same object
    A factory function can be a function that return an object

    Implementation :- 

    const createUser = (firstName, lastName) => {
        id: "1",
        createdAt: new Date(),
        firstName,
        lastName,
        fullName: `${firstName} ${lastName}`
    }

    createUser("Rohan","A");
    createUser("Sonia","M");
    createUser("abc", "def");

    trafeOff :- 
    it is usefull where we have to create multiple objects with the same properties, w/o having to repeat the same process again and again.
    A factory func can easily return a custom object depending upon the current environment or user specific configuration.



6. Prototype Pattern

    If you want to share the properties among multiple objects of the same type. we can use prototype pattern.

    Implementation :- 
        #create many dogs with the createDog facttory patttern

        const createDog = (name, age) => ({
            name,
            age,
            bark(){
                console.log(`${name} is barking`);
            },
            wagtail(){
                console.log(`${name} is wagging their tail`);
            }
        });

        const dog1 = new createDog("Max", 4);
        const dog2 = new createDog("abc",5);

        we are unnecessarily adding a new bark annd wagrail methods tto each object.


        class Dog {
            constructor(name, age){
                this.name = name;
                this.age = age;
            }

            bark(){
                console.log(`${this.name} is barking`)
            }

            wagTail() {
                console.log(`${this.name} is wagging their tail`)
            }
        }


        const dog1 = new Dog("A",1);
        const dog1 = new Dog("B",2);
        const dog1 = new Dog("C",3);

        ES6 classes allow us to easily share properties among many instances, bark and wagTail in this case.








    
