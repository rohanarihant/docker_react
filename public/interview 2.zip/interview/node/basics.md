Javascript

    is a sync single threded lang

    thread :- is simplty a process that js program can use to run a task.
              each thread can only do one task at a time.
              js will call the one thread called Main thread

    libuv :- external dependencies in async node.js
             is a cross platform open source lib written in c lang.
             it handles async non-blocking operations in node.js
                using :- event loop
                         thread pool

             Thread Pool :- it has a pool of threads that it can use to run some of these time consuming tasks.
             when the tasks is done then the file contents are retrieved and the associated cb func can be run.

             node uses it to off-load the time consuming tasks and ensure that the main thred will not blocked for long time.


**Every Method in Node.js has the sync suffix always runs on the main thread and is blocking**
            const crypto = require("node:crypto");

            crypto.pbkf2sync for sync method run on main thread
            crypto.pbkf2/fs.readFile for async method runs on thread pool
                they do run sync in their own thread but as far as the main thread is concerned.
                it appears as if methods is running async

            libuv's thread pool is having 4 threads by defaults
            we can change this by using env var like this
                process.env.UV_THREADPOOL_SIZE = 5;

            * imp while increasing the threadpool size beyond the cpu core size then the avg time taken for method execution will also increases.

        Network I/O
            https.request is a net input/output operation not a CPU bound operation.
            it doesn't use the thread pool
            libuv instead delegates the work to OS kernel and whenever possible.
            it will pool the kernel and see if req is completed.

**Libuv and Async Mathods Summary**

        In Node.js asynnc methods are handled by libuv
        they are handled in 2 ways
        1. Native async machanism       2. Thread Pool
        whenever possible, Libuv will use native async machanisms in the OS so as to avoid blocking the main thread.
        Since this is part of the kernel, there is diff machanism for each OS. we have epoll for linux, kqueue for MacOS and IO completion Port Windows.
        Relaying on native async machanisms makes Node scalable as the only Limitaion is OS kernel.
        Example if this type is n/w I/O operation.

        if there is no native async support ad task is I/O or CPU intensive, libuv uses the thread pool to avoid blocking tthe main thread.
        although the thread pool preserves async with respect to Node.js main thread, it can still become a bottleneck if all threads are busy 


**Cluster Module**
    Node is a single threaded
    no matter how many cores your sys have, only uses a single core of CPU.
    this is fine for IO operations but if we have long running and CPU intensive operations, your app might struggle from a performance point of view

    cluster moddules
        the cluster module enables the creation of child processes (also called workers)
        that run simultaneously
        all created workers share the same server port


    How Cluster Modules work in Node.js
        that file is ttreated as cluster master
        master is incharge of spanning new workers.
        which runs an innstance of the node app
            start, sttop, restarting, but doesn't execute the app code itself.

        workers are incharge of handlinng the incoming req, reading files etc.
        each worker gets its own event loop, memory and V8 instance.

        const cluster = require("node:cluster");
        if(cluster.isMaster){ // mster is incharge of creating worker nnodes
            cosole.log(`Master process ${process.pid} is running`)
            cluster.for(); // creating the worker node
            cluster.for(); // creating the worker node
        }else{ // workder is incharge of handelinng the incoming reqs.
            cosole.log(`worker process ${process.pid} is running`)
        }

        ? Why shouldn't we simply create a large number of workers using cluster.fork() ?
        we should only create as many workers as there are CPU cores onn the machine the app is running.

        if you create more workers than there are logical ccores on the computer it can cause an overhead as the sys will have to schedule all the created workers with fewer number of cores.

        const OS  = require("node:os")
        console.log(OS.cpus().length())

        PM2 :- is a module to run a server as a cluster and decide best no of workers to create for machine.
            pm2 start no-cluster.js -i 0
                                        0 // to find how many workers required
                                        2 // will run 2 worker nodes
        
**Worker Thread Module**
    the WT module ennables the use of threads that execute JS in parallel.
    code execution in a workder thread runs in a seperate child process, preventing it from blocking your main app
    the cluster module can be used to run multiple instances of Node.js that can distribute workloads
    WT module allows running multiple apps threads with in single node instance
    when process isolation is not needed, that is, no seperate instance of V8, event loop and memory are needed, you should use WT.

    const {Worker} = require("node:worker_threads");

    const worker = new Worker("./worker-thread.js")
    worker.on("message", (j) => {
        res.writeHead(200, {"Content-Type": "text/plain"})
    })

    // inside worker-thread.js
        import {parentPort} = require("node:worker-threads")

        let j = 0
        for(let i=0;i<600000000;i++){
            j++;
        }
        parentPort.postMessage(j)