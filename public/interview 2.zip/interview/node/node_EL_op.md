<!-- 1 -->
console.log("1")
process.nextTick(() => console.log("This is process.next 1"));
console.log("2")
<!-- 1
2
This is process.next 1 -->

<!-- 2 -->
Promise.resolve().then(() => console.log("this is Promise.resolve 1"))
process.nextTick(() => console.log("this is process.nextTick 2"))

<!-- this is process.nextTick 2
this is Promise.resolve 1 -->

<!-- 3 -->
process.nextTick(() => console.log("this is process.nextTick 1"))
process.nextTick(() => {
    console.log("this is process.nextTick 2")
    process.nextTick(() => {
        console.log("this is the inner next tick inside next tick") 
    })
})
process.nextTick(() => console.log("this is process.nextTick 3"))
Promise.resolve().then(() => console.log("this is Promise.resolve 1"))
Promise.resolve().then(() => {
    console.log("this is Promise.resolve 2")
    process.nextTick(() => 
        console.log("this is the inner tick inside promise then block");
    )
})
Promise.resolve().then(() => console.log("this is Promise.resolve 3"))


<!-- this is process.nextTick 1
this is process.nextTick 2
this is process.nextTick 3
this is the inner next tick inside next tick

this is Promise.resolve 1
this is Promise.resolve 2
this is Promise.resolve 3
this is the inner tick inside promise then block -->

<!-- 4 -->
setTimeout(() => console.log("this is setTimeout 1"),0)
setTimeout(() => {
    console.log("this is setTimeout 2")
    process.nextTick(() => {
        console.log("this is the inner next tick inside setTimeout") 
    })
}, 0)
setTimeout(() => console.log("this is setTimeout 3),0)
process.nextTick(() => console.log("this is process.nextTick 1"))
process.nextTick(() => {
    console.log("this is process.nextTick 2")
    process.nextTick(() => {
        console.log("this is the inner next tick inside next tick") 
    })
})
process.nextTick(() => console.log("this is process.nextTick 3"))
Promise.resolve().then(() => console.log("this is Promise.resolve 1"))
Promise.resolve().then(() => {
    console.log("this is Promise.resolve 2")
    process.nextTick(() => 
        console.log("this is the inner tick inside promise then block");
    )
})
Promise.resolve().then(() => console.log("this is Promise.resolve 3"))

<!-- this is process.nextTick 1
this is process.nextTick 2
this is process.nextTick 3
this is the inner next tick inside next tick

this is Promise.resolve 1
this is Promise.resolve 2
this is Promise.resolve 3
this is the inner tick inside promise then block
this is setTimeout 1
this is setTimeout 2
this is the inner next tick inside setTimeout
this is setTimeout 3
-->


const fs = require("fs")
fs.readFile(__filename, () => {
    console.log("this is a readFile");
})

process.nextTick(() => console.log("this is process.nextTick 1"))
Promise.resolve().then(() => console.log("this is Promise.resolve 1"))

<!-- this is process.nextTick 1
this is Promise.resolve 1
this is a readFile -->




const fs = require("fs");
setTimeout(() => console.log("this is setTimeout 1"),0)
fs.readFile(__filename, () => {
    console.log("this is a readFile");
})

    inconsistency in the logs, sometime timeout will come first soemtime readfile

    * when running setTimeout with delay 0ms and an I/O async method, the order of ecec can never guarenteed.





const fs = require("fs");
fs.readFile(__filename, () => {
    console.log("this is a readFile");
})
process.nextTick(() => console.log("this is process.nextTick 3"))
Promise.resolve().then(() => console.log("this is Promise.resolve 1"))
setTimeout(() => console.log("this is setTimeout 1"),0)

<!-- this is process.nextTick 3
this is Promise.resolve 1
this is setTimeout 1
this is a readFile   -->

    * I/O q cbs are executed adter microtask q cbs and timer cbs


const fs = require("fs");
fs.readFile(__filename, () => {
    console.log("this is a readFile");
})
process.nextTick(() => console.log("this is process.nextTick 3"))
Promise.resolve().then(() => console.log("this is Promise.resolve 1"))
setTimeout(() => console.log("this is setTimeout 1"),0)
setImmediate(() => console.log("this is setImmediate 1"),0)

<!-- this is process.nextTick 3
this is Promise.resolve 1
this is setTimeout 1
this is setImmediate 1
this is a readFile   -->

    * I/O events are polled and db funcs are added to the I/O q only after the I/O is complete.





const fs = require("fs");
fs.readFile(__filename, () => {
    console.log("this is a readFile");
    setImmediate(() => console.log("this is setImmediate 1"),0)
})
process.nextTick(() => console.log("this is process.nextTick 3"))
Promise.resolve().then(() => console.log("this is Promise.resolve 1"))
setTimeout(() => console.log("this is setTimeout 1"),0)

<!-- this is process.nextTick 3
this is Promise.resolve 1
this is setTimeout 1
this is a readFile
this is setImmediate 1  -->




const fs = require("fs");
fs.readFile(__filename, () => {
    console.log("this is a readFile 1");
    setImmediate(() => console.log("this is setImmediate inside the readFIle"),0)
    process.nextTick(() => console.log("this is process.nextTick in the readFile"))
    Promise.resolve().then(() => console.log("this is Promise.resolve in the readFile"))
})
process.nextTick(() => console.log("this is process.nextTick 1"))
Promise.resolve().then(() => console.log("this is Promise.resolve 1"))
setTimeout(() => console.log("this is setTimeout 1"),0)


<!-- this is process.nextTick 1
this is Promise.resolve 1
this is setTimeout 1
this is a readFile 1
this is process.nextTick in the readFile
this is Promise.resolve in the readFile
this is setImmediate inside the readFIle -->
     * microtask q cbs are executed before and after the I/O cbs




setImmediate(() => console.log("this is setImmediate 1"))
setImmediate(() => {
    console.log("this is setImmediate 2")
    process.nextTick(() => console.log("this is process.nextTick 1"))
    Promise.resolve().then(() => console.log("this is Promise.resolve 1"))
})
setImmediate(() => console.log("this is setImmediate 3"))

<!-- this is setImmediate 1
this is setImmediate 2
this is process.nextTick 1
this is Promise.resolve 1
this is setImmediate 3 -->

    * mic task q ccbs are check and executed inbetweenn the check cbs





const fs = require("fs");
const readableStream = fs.createReadStream(__filename);
readableStream.close();

readableStream.on("close",() => {
    console.log("this is from readbleStream close event cbs")
})
setImmediate(() => console.log("this is setImmediate 1"))
setTimeout(() => console.log("this is setTimeout 1"),0)
Promise.resolve().then(() => console.log("this is Promise.resolve 1"))
process.nextTick(() => console.log("this is process.nextTick 1"))



this is process.nextTick 1
this is Promise.resolve 1
this is setTimeout 1
this is setImmediate 1
this is from readbleStream close event cbs