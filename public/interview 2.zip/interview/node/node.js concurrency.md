<!-- diff b/w the process.nextTick() and setImmediate() -->
    both can be used to switch to asynchronous mode of operation by listener functions.

    process.nextTick() :- sets the callback to execute 
    setImmediate :- pushes the cb in the queue to be executed

        so the event loop runs in following manner.


**EVENT LOOP**
    A design patern that orchestrates and co-ordinates the execution of synchronous and asynchronous code in Node.js

    its a loop that alive as  long as your node.js app is up and running


    every iteration we  came across 6 diff queues
    each queue will hold cbs that needs to be execcuted evenntually on call stack

        1. Timer queue
            setTimeout and setInterval

        2. I/O q
            cb realted to fs and http module
        3. check q
            setImmediate cb
        4. close q
            cb associated with the close events
        5. MiroTask Queue at the center
            2 seperate qs
                nextTick q
                    process.nextTick() 
                promise q
                    promise cb
        
        Timer, I/O, Check, Close are part of libuv
        MicroTask Q is not a part of libuv

    Evet Loop :- Execution order
        user written sync task take periority over async code that the runtine would like to execute

        1. MictoTask queue - nextTick cbs then promise cbs
        2. Timer q cbs
        3. MictoTask queue - nextTick cbs then promise cbs
        4. I/O q all cbs 
        5. MictoTask queue - nextTick cbs then promise cbs
        6. Check q cbs
        7. MictoTask queue - nextTick cbs then promise cbs
        8. Close q cbs
        9. MictoTask queue - nextTick cbs then promise cbs

    if the more cbs are to be processed, the loop is kept alive for one more run and same stteps are repeated
        if all cbs done and no more cbs then EL exits

    Whenever an async task is completed in libuv, at what point does Node decide to run the associated cb func on the call stack?
        CB func are executed only when the call stack is empty. The normal flow of execution fill not be interupted to run to a cb.
    
    Whats  about async method setTimeout and setInterval which also delay the execution of cb func?
        setTimeout and setInterval cb are given first priority
    
    If two async tasks such as setTimeout and readFile complete at the same time, how does Node decide which cbs fun to run first on the cb stack?
        Timer cbs are execcuted before I/O callbacks even if both are ready at the same time for execution.

<!-- process.nextTick() -->
    use of process.nextTick is discouraged as it can cause the rest of the EL to strave
    if you endlessly call process.nextTick the control will never make it pass the microtask q

    1. to allow users to handle errors, cleanup any then unneeded resources, or perhaps try the req again before the event loops conttinue
    2. to allow a cb to run after the call stack has unwound but before the event loop continues
 <!-- Time Q  -->
    cb in Microtask q are executed in b/w the execution of cbs in the timer q

    