import React, { useEffect } from 'react'
import {Link, useLocation, useNavigate} from "react-router-dom";
import {useSessionContext} from "../../Context/sessionContext"
import "./NavBar.css"
function Navbar() {
    const location = useLocation();
    const navigate = useNavigate();
    const {isLoggedIn} = useSessionContext();
    const checkActiveClass = (path) => {
      return path === location.pathname ? "active" : "";
    }
    useEffect(() => {
      if(isLoggedIn && ["/login", "/singup"].includes(location.pathname)){
        navigate("/home");
      }
    }, [isLoggedIn]);
  return (
    <section className='navbar-container'>
        <Link to="/home" className={checkActiveClass("/home")}>Home</Link>
        <Link to="/about" className={checkActiveClass("/about")}>About</Link>
        <Link to="/contract" className={checkActiveClass("/contract")}>Contract</Link>
        {!isLoggedIn && <Link to="/login" className={checkActiveClass("/login")}>Login</Link>}
        {!isLoggedIn && <Link to="/signup" className={checkActiveClass("/signup")}>Signup</Link>}
    </section>
  )
}

export default Navbar