import React, {useEffect} from 'react'
import "./Home.css";
import {useSelector, useDispatch} from "react-redux";
import {getAllCustomers} from "../../Redux/Actions/totoActions";
function Home() {
  const dispatch = useDispatch();
  const state = useSelector(state => state.customerReducer);
  useEffect(() => {
    dispatch(getAllCustomers());
  },[])
  return (
    <div className="wrapper">
      <header className="header">
        Hello! {state?.[0]?.email}
      </header>
      <aside className="left-sidebar">
        Left Side
      </aside>
      <article className="main">
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Nam a illo illum quos cumque, hic ad temporibus dignissimos. Delectus officia consectetur ea beatae dolorum eligendi, qui fuga nihil totam voluptatum.</p>
      </article>
      <aside className="right-sidebar">
        Right Side
      </aside>
      <footer className="footer">
        Footer
      </footer>
    </div>
  )
}

export default Home