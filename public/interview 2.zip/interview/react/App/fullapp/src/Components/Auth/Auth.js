import React, { useState } from 'react'
import {useSessionContext} from '../../Context/sessionContext';
import "./Auth.css";


function Auth({path}) {
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");
    const {userList, updateUserList, setIsLoggedIn} = useSessionContext();
    const onSignupClick = () => {
        updateUserList(prev => [...prev, {email, password}]);
        setEmail("");
        setPassword("");
    }
    const onLoginClick = () => {
        const user = userList?.find((user) => user.email === email && user.password === password);
        setIsLoggedIn(user ? true : false);
    }
  return (
    <section className='session-container'>
        <div>
            <label>Email</label>
            <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} />
        </div>
        <div>
            <label>Password</label>
            <input type="password" value={password} onChange={(e) => setPassword(e.target.value)} />
        </div>
        {path === "signup" && <button onClick={() => onSignupClick()}>Signup</button>}
        {path === "login" && <button onClick={() => onLoginClick()}>Login</button>}
    </section>
  )
}

export default Auth