import {ADD_TODO} from "../Actions/todoActionsHelper"
const initialState = [{
    email: "Rohan",
    password: "123123"
}]

const todoReducer = (state=initialState, actions) => {
    switch(actions.type){
        case ADD_TODO:
            return [
                ...state,
                actions.payload
            ]
        default:
            return state;
    }
}

export default todoReducer;