import {createStore, combineReducers, applyMiddleware} from "redux";
import todoReducer from "../Reducer/todoReducer";
import customerReducer from "../Reducer/customerReducer";
import {thunk} from "redux-thunk";
const reducers = combineReducers({todoReducer, customerReducer});
const store = createStore(reducers,applyMiddleware(thunk));

export default store;