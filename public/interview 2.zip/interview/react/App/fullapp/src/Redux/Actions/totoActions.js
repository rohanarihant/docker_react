import {ADD_CUSTOMER, FETCH_CUSTOMERS, SET_CUSTOMERS} from "./todoActionsHelper";

const addCustomer = (payload) => {
    return {
        type: ADD_CUSTOMER,
        payload
    }
}
const fetchCustomers = () => ({type: FETCH_CUSTOMERS})
const setAllCustomers = (data) => {
    return {type: SET_CUSTOMERS, payload: data}
}
const getAllCustomers = () => {
    return async(dispatch, getStore) => {
        dispatch(fetchCustomers());
        const res = await fetch("https://api.github.com/gists/public?per_page=30")
        const response = await res.json();
        dispatch(setAllCustomers(response));
    }
}
export {addCustomer, getAllCustomers}
