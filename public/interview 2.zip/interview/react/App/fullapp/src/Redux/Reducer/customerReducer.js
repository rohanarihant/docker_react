import { ADD_CUSTOMER, SET_CUSTOMERS } from "../Actions/todoActionsHelper";
const initialState = [];

const customerReducer = (state=initialState, actions) => {
        switch(actions.type){
            case ADD_CUSTOMER:
                return[
                    ...state,
                    actions.payload
                ]
            case SET_CUSTOMERS:
                return actions.payload;
            default:
                return state;
        }
}

export default customerReducer;