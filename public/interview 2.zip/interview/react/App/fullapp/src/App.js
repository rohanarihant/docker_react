import logo from './logo.svg';
import './App.css';
import RoutesList from "./Router/Router";
import NavBar from "./Components/Navbar/Navbar";
import { BrowserRouter } from 'react-router-dom'
import {SessionProvider} from './Context/sessionContext';
import {Provider} from "react-redux";
import store from "./Redux/store";
function App() {
  return (
    <div className="App">
      <Provider store={store}>
      <BrowserRouter>
      <SessionProvider>
        <header className="App-header">
          <NavBar />
          <RoutesList />
        </header>
      </SessionProvider>
      </BrowserRouter>
      </Provider>
    </div>
  );
}

export default App;
