import {createContext, useContext, useState} from "react";

const SessionContext = createContext(null);

const SessionProvider = ({children}) => {
    const [isLogin, setIsLogin] = useState(false);
    const [userList, updateUserList] = useState([]);
    const [isLoggedIn, setIsLoggedIn] = useState(false);

    return(
        <SessionContext.Provider value={{isLogin, setIsLogin, userList, updateUserList, isLoggedIn, setIsLoggedIn}}>
            {children}
        </SessionContext.Provider>
    )
}

const useSessionContext = () => {
    return useContext(SessionContext);
}
export {SessionProvider, useSessionContext};