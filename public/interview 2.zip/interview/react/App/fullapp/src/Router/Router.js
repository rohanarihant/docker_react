import React from 'react'
import {BrowserRouter, Routes, Route} from "react-router-dom";
import Auth from '../Components/Auth/Auth';
import Home from "../Components/Home/Home";
import {useSessionContext} from "../Context/sessionContext";
function RoutesList() {
  const {isLogin} = useSessionContext();
  return (
        <Routes>
            <Route path="/home" element={<Home />}></Route>
            <Route path="/login" element={<Auth path="login" />}></Route>
            <Route path="/signup" element={<Auth path="signup" />}></Route>
        </Routes>
  )
}

export default RoutesList