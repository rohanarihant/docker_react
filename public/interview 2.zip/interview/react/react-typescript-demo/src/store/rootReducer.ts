import { combineReducers } from "redux";

import autoReducer from "./auth/reducer";

const rootReducer = combineReducers({
    auth: autoReducer
});

export type AuthSate = ReturnType<typeof rootReducer>;

export default rootReducer;