import React, {FC, useEffect, useState} from "react";
import axios from "axios";
interface Props {
  title: string
}
interface User {
  name: {
    first: string;
    last: string;
  };
  login: {
    uuid:string;
  };
  email: string
}
const App: FC<Props> = ({title}) => {
  const [users, setUsers] = useState<User[]>([]);
  useEffect(() => {
    const getUsers = async() => {
      try{
        const {data} = await axios.get("https://randomuser.me/api/?results=10")
        console.log(data.results);
        setUsers(data.results)
      }catch(err){
        console.log(err,'new error')
      }
    }
    getUsers();
  },[]);
  return(
    <div>
      <h1>{title}</h1>
      <ul>
        {users.map((user: User) => {
          return(
            <li key={user.login.uuid}>
              <div>Name: {user.name.first} {user.name.last}</div>
              <div>Email: {user.email}</div>
              <hr />
              </li>
          )
        })}
      </ul>
    </div>
  )
}

export default App;