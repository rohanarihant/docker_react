import axios from "axios";
import React, {useState, useEffect} from "react";
import './App.css';
import Container from '@mui/material/Container';
import Header from "./components/Header/Header"
import Definitions from "./components/Definitions/Definitions";

function App() {
    const [word, setWord] = useState("");
    const [meanings, setMeanings] = useState([]);
    const [category, setCategory] = useState("en");
    const dictionaryApi = async() => {
        try{
            const data = await axios.get(`https://api.dictionaryapi.dev/api/v2/entries/${category}/${word}`)
            setMeanings(data.data);
        }catch(error){
            console.log(error);
        }
    }
    useEffect(() => {
        dictionaryApi();
    },[word, category]);
    return(
        <div className="App" style={{height: '100vh', backgroundColor: "#282c34", color: "white"}}>
            <Container maxWidth="md" style={{dsplay: "flex", flexDirection: "column", height: "100vh"}}>
                <Header setCategory={setCategory} category={category} word={word} setWord={setWord} />
                {meanings && <Definitions word={word} meanings={meanings} category={category} />}
            </Container>
        </div>
    )
}

export default App;