import React from "react";
import "./Header.css";
import { MenuItem, TextField } from "@mui/material";
import { withTheme } from "@mui/styles";
import { createTheme, ThemeProvider } from "@mui/material/styles";
import categories from "../data/category";

const Header = ({ setCategory, category, word, setWord }) => {
  const theme = createTheme({
    palette: {
      primary: {
        main: "#fff",
      },
      type: "dark"
    },
  });
  const handleChange = (language) => {
    setCategory(language);
    setWord("");
  }
  // const MyComponent = withTheme(({ theme }) => <div>{theme?.direction}</div>);
  return (
    <div className="header">
      <span className="title">{word ? word : "Word Hunt"}</span>
      <div className="inputs">
        <ThemeProvider theme={theme}>
          <TextField
            className="search"
            variant="standard"
            label="Search Word"
            value={word}
            onChange={(e) => setWord(e.target.value)}
          />
          <TextField
            label="Language"
            select
            variant="standard"
            value={category}
            onChange={(e) => handleChange(e.target.value)}
            helperText="Please select your currency"
          >
            {/* key={option.value} value={option.value} */}
            {categories.map(({ value, label }) => (
              <MenuItem key={label} value={label}>
                {value}
              </MenuItem>
            ))}
          </TextField>
        </ThemeProvider>
      </div>
    </div>
  );
};

export default Header;
