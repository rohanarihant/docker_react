import React, { useState } from "react";

const Folder = ({ handleInsertNode, explorer: { isFolder, name, items, id } }) => {
  const [expanded, setExpanded] = useState(false);
  const [textInput, updateTextInput] = useState("");
  const [showInput, setShowInput] = useState({
    isFolder: null,
    visible: false,
  });
  const handleNewFolder = (e, isFolder) => {
    e.stopPropagation();
    setExpanded(true);
    setShowInput({
      visible: true,
      isFolder,
    });
  };
  const addFolder = (e) => {
    if(e.keyCode === 13 && e.target.value){
        handleInsertNode(id, e.target.value, showInput.isFolder);
        setShowInput({...showInput, visible: false});
    }
  }
  return (
    <div style={{ marginTop: 5 }}>
      <div
        className={isFolder ? "folder" : "file"}
        onClick={() => setExpanded(!expanded)}
      >
        <span>{`${isFolder ? "📁" : "📄"} ${name}`}</span>
        {isFolder && <div>
          <button onClick={(e) => handleNewFolder(e, true)}>Folder +</button>
          <button onClick={(e) => handleNewFolder(e, false)}>File +</button>
        </div>}
      </div>
      <div>
        {showInput?.visible && (
          <div>
            <span>{showInput?.isFolder ? "📁" : "📄"}</span>
            <input
              type="text"
              value={textInput}
              onChange={(e) => updateTextInput(e.target.value)}
              autoFocus
              onBlur={() => setShowInput({ ...showInput, visible: false })}
              onKeyDown={addFolder}
            />
          </div>
        )}
        {expanded && (
          <div style={{ paddingLeft: 25 }}>
            {items?.map((item) => (
              <Folder explorer={item} handleInsertNode={handleInsertNode}/>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
export default Folder;
