import {CssBaseline, ThemeProvider } from '@mui/material';
import React from "react";
import ReactDom from "react-dom/client";
import reportWebVitals from "./reportWebVitals";
import theme from "./theme";

const root = ReactDom.createRoot(
    document.getElementById("root")
);

root.render(
    <React.StrictMode>
        <ThemeProvider theme={theme}>
            <CssBaseline />
            <App />
        </ThemeProvider>
    </React.StrictMode>
)

reportWebVitals();