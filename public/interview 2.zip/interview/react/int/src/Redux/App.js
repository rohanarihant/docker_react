import React from "react";
import {Provider} from "react-redux";
import state from './store';
import Counter from "./count";


function App() {
  return (
    <div className="App">
      <Provider store={state}>
        <Counter />
      </Provider>
    </div>
  );
}

export default App;
