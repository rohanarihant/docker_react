import {ADD_COUNT, REMOVE_COUNT} from "./actionTypes";

const addCount = () => {
    return {
        type: ADD_COUNT
    }
}

const  removeCount =  () => {
    return {
        type: REMOVE_COUNT
    }
}

export {
    addCount,
    removeCount
}


// export const fetchData = () => {
//     return async (dispatch) => {
//       dispatch(fetchDataRequest());
//       try {
//         const response = await axios.get('https://api.example.com/data');
//         dispatch(fetchDataSuccess(response.data));
//       } catch (error) {
//         dispatch(fetchDataFailure(error.message));
//       }
//     };
//   };