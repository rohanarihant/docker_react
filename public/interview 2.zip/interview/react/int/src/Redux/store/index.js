import {createStore} from "redux";
import countReducer from "../reducer/countReducer";

const state = createStore(countReducer);

export default state;