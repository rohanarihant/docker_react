import {ADD_COUNT, REMOVE_COUNT} from "../actions/actionTypes";

const initialState = {
    count: 0
}
const countReducer = (state=initialState, action) => {
    switch(action.type){
        case ADD_COUNT:
            return {
                ...state,
                count: state.count+1
            }
        case REMOVE_COUNT:
            return {
                ...state,
                count: state.count-1
            }
        default:
            return state;
    }

}

export default countReducer;