import React from "react";
import {useSelector, useDispatch} from "react-redux";
import {addCount, removeCount} from "./actions/actions";
const Counter = () => {
    const {count} = useSelector(state => state);
    const dispatch = useDispatch();
    console.log(count,'statestate')
    return (
        <section>
            <h3>{count}</h3>
            <button onClick={() => dispatch(addCount())}>Increase</button>
            <button onClick={() => dispatch(removeCount())}>Decrease</button>
        </section>
    )
}

export default Counter;