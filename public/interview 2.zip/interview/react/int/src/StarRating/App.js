import React, {useState} from "react";
import iconSelected from "./icon/icons8-star-selected.png";
import iconUnSelected from "./icon/icons8-star-unselected.png";


function App() {
    const [rating, setRating] = useState(0);
    return (
        <div className="App">
            {Array(5).fill(0).map((obj, i) => {
                const currentIndex = i+1;
                return(<img key={i} onClick={() => setRating(currentIndex)} src={rating >= currentIndex ? iconSelected : iconUnSelected} />)
            })}
        </div>
    );
}

export default App;
