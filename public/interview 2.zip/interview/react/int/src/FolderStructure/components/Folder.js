import { useState } from "react";
import "./styles.css";


function Folder({ explorer, handleInsertNode }) {
  const [expand, setExpand] = useState(false);
  const [inputValue, setInputValue] = useState(null);
  const [showInput, setShowInput] = useState({
      visible: false,
      isFolder: null
  })

  const handleNewFolder  = (e, isFolder) => {
    e.stopPropagation();
    setExpand(true);
    setShowInput({
        visible: true,
        isFolder
    })
  }
  const onAddFolder = (e) => {
      if(e.keyCode === 13 && e.target.value){
          handleInsertNode(explorer.id, inputValue, showInput.isFolder);
          setShowInput({...showInput, visible: false});
    }
    setInputValue(e.target.value);
  }
  if (explorer.isFolder) {
    return (
      <div class="container" style={{ marginTop: 5 }}>
        <div className="folder" onClick={() => setExpand(!expand)}>
          <span>📁 {explorer.name}</span>
          <div>
              <button onClick={(e) => handleNewFolder(e, true)}>Folder +</button>
              <button onClick={(e) => handleNewFolder(e, false)}>File +</button>
          </div>
        </div>
        {expand && (
          <div>
            {
                showInput.visible && (
                    <div className="inputContainer">
                        <span>{showInput.isFolder ? "📁" : "📄"}</span>
                        <input className="inputContainer__input"
                        onKeyDown={(e) => onAddFolder(e, showInput.isFolder)}
                        autoFocus
                        text="text"
                        onBlur={() => setShowInput({...showInput, visible: false})}
                        />
                    </div>
                )
            }  
            {explorer.items.map((exp) => {
              return <Folder explorer={exp} handleInsertNode={handleInsertNode} />
            })}
          </div>
        )}
      </div>
    );
  } else {
    return <span className="file">📄{explorer.name}</span>;
  }
}

export default Folder;
