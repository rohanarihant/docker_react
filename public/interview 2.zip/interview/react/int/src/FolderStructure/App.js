import { useState } from "react";
import Folder from "./components/Folder";
import explorer from "./data/folderData";
import useTraverseTree from "./hooks/useTraverseTree";

function App() {
    const [explorerData, setExplorerData] = useState(explorer)
    const {inserNode} = useTraverseTree();
    const handleInsertNode = (folderId, items, isFolder) => {
      let finalTree = inserNode(explorerData, folderId, items, isFolder);
      setExplorerData(finalTree);
    }
  return (
    <div className="App">
        <Folder explorer={explorerData} handleInsertNode={handleInsertNode} />
    </div>
  );
}

export default App;