import React, { useState, useRef } from "react";

const Counter = () => {
    const [counter, setCounter] = useState(0);
    const timer = useRef(null);
    const startCounter = () => {
        timer.current = setInterval(() => {
            setCounter(preCount => preCount+1);
        },1000)
    }
    const stopInterval = () => {
        clearInterval(timer.current);
    }
    const resetInterval = () => {
        clearInterval(timer.current);
        setCounter(0);
    }

    return(
        <section>
            <div>Counter : {counter}</div>
            <button onClick={() => startCounter()}>Start</button>
            <button onClick={() => stopInterval()}>Stop</button>
            <button onClick={() => resetInterval()}>Reset</button>
        </section>
    )
}

export default Counter;