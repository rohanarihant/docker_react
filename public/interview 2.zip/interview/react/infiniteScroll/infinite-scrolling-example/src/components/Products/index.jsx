import React, { useEffect, useState, useRef } from "react";
import styles from "./style.module.css";
import MessageBox from "../MessageBox"; 
import Spinner from "../Spinner"; 
import ProductCard from "../ProductCard"; 

function Products() {
  const [isLoading, setIsLoading] = useState(false);
  const [isError, setIsError] = useState(false);
  const [data, setData] = useState([]);
  const [isIntersecting, setIsIntersecting] = useState(false);
  const [isSpinnerRefVisible, setIsSpinnerRefVisible] = useState(false);
  const [hasMore, setHasMore] = useState(false);
  const limit = 10;
  const pageRef= useRef(1);
  const fetchProducts = async (page = pageRef.current, isLoadingFirstTime = false) => {
    try {
      isLoadingFirstTime && setIsLoading(true);
      setIsError(false);
      const response = await fetch(
        `https://dummyjson.com/products?limit=${limit}&skip=${(page-1)*10}`
      );
      const res = await response.json();
      if (Array.isArray(res.products) && res.products.length) {
        setData((prev) => {
          const newData = [...prev, ...res.products];
          if(newData.length < res.total){
            setHasMore(true);
          }else{
            setHasMore(false);
          }
          return newData;
      });
    }else{
      setHasMore(false);
    }
    } catch (error) {
      setIsError(true);
      setHasMore(false);
    } finally {
      setIsLoading(false);
    }
  };
  useEffect(() => {
    fetchProducts(1, true);
  }, []);

  // fetching more products
  const spinnerRef = useRef();

  useEffect(() => {
    const ref = spinnerRef.current;
    const observer = new IntersectionObserver(([entry]) => {
      setIsIntersecting(entry.isIntersecting);
    }, {
      root: null,
      rootMargin: "0px",
      threshold:1
    });
    if(ref){
      observer.observe(ref);
    }
    return () => ref && observer.unobserve(ref);
  },[isSpinnerRefVisible]);

  useEffect(() => {
    if(isIntersecting){
      fetchProducts(pageRef.current + 1);
      pageRef.current = pageRef.current+1;
    }

  }, [isIntersecting])
  return (
    <div className={styles.root}>
      {isError ? (
        <MessageBox message="Failed to fetch the products" />
      ) : (isLoading) ? (
        <Spinner text="Loading products ...." />
      ) : (
        <div className={styles.cards_containers}>
          {data.map((product) => (
            <ProductCard
              key={product.id}
              title={product.title}
              price={product.price}
              image={product.images[0]}
            />
          ))}
        </div>
      )}
          {hasMore && <div ref={(el) => {
            spinnerRef.current = el;
            setIsSpinnerRefVisible(prev => !prev);
          }}>
          <Spinner text="Loading more products" />
          </div>}
    </div>
  );
}

export default Products;
