import React from 'react';
import logo from './logo.svg';
import './App.css';
import {useAppDispatch, useAppSelector} from "./redux/hooks/index";
import { increment, decrement} from './redux/slices/counter';
import {RootState} from "./redux/store"
function App() {
  const count = useAppSelector((state:RootState) => state.counter.value);
  const dispatch = useAppDispatch();
  return (
    <div className="App">
      <header className="App-header">
        <h1>Count is {count}</h1>
        <button onClick={() => dispatch(increment())}>Increment</button>
        <button onClick={() => dispatch(decrement())}>Decrement</button>
      </header>
    </div>
  );
}

export default App;
