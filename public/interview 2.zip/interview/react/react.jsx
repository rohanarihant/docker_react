const { useEffect, useState } = require("react");

let obj = {
name: "rohan",
file: 213
}