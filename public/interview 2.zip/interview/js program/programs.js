
// Question 1:

    // function sum(a){
    //     return function(b){
    //         if(b){
    //             return sum(a+b);
    //         }else{
    //         return a;
    //         }
    //     }
    // }

    // sum(1)(2)(3)(4)();

// Question 2:
    // move each element to 2nd left
    // const input = [2,7,11,4,-2];
    // const output = [11,4,-2,2,7];

    // function rotateArray(input){
    //     for(let i=0;i<2;i++){
    //         let temp = input[0];
    //         for(let j=0;j<input.length;j++){
    //             input[j] = input[j+1];
    //         }
    //         input[input.length-1]=temp;
    //     }
    //     console.log(input);
    // }
    // console.log(rotateArray(input));

// Question 3:

    // const input1 = {a:1,b:2, c:3,d:10,e:12};
    // const input2 = {a:2,e:12, f:6,d:10};

    // const output = {d:10,e:12};

    // function func(input1, input2){
    //     let obj = {};

    //     for(let i in input1){
    //         if(input1[i] === input2[i]){
    //             obj[i] = input1[i];
    //         }
    //     }
    //     return obj;
    // }
    // console.log(func(input1,input2));


// Question 4:
// const input1 = [1,4,7,2,4,7];
// const output1 = 4;

// function secondLargest(input){
//     let arr = input.sort((a,b) => a-b);
//     let lastElement = arr[arr.length-1];
//             let result = "";
//     for(let i=arr.length-1;i>0;i--){
//         if(arr[i] !== lastElement){
//             result = arr[i];
//             break;
//         }
//     }
//   return result;
// }
// console.log(secondLargest(input1));


// Question 5:
    // flatten the nested objects
    // const obj = {
    //     A: "12",
    //     B: 23,
    //     C: {
    //         P: 23,
    //         O: {
    //             L: 56
    //         },
    //         Q: [1,2]
    //     }
    // }
    // const solution = (obj, prefix="") => {
    //     let output = {};

    //     for(let key in obj){
    //         let value = obj[key];
    //         const newPrefix = prefix === "" ? key : prefix+"."+key;
    //         if(value !== null && typeof value === "object"){
    //             const newObject = solution(value, newPrefix);
    //             output = {...output, ...newObject};
    //         }else{
    //             output[newPrefix] = value;
    //         }
    //     }
    //     return output;
    // }

    // console.log(solution(obj))

// Question 5:
    // flatten the nested arrays

    // const arr = [1,2,[3,4,[5,[6,7,8]],[9,0]]];

    // function flattenArray(arr){
    //     let result = [];
    //     for(let i=0;i<arr.length;i++){
    //         if(Array.isArray(arr[i])){
    //             // result = result.concat(flattenArray(arr[i]));
    //             result = [...result, ...flattenArray(arr[i])]
    //         }else{
    //             result.push(arr[i]);
    //         }
    //     }
    //     return result;
    // }
    // console.log(flattenArray(arr));

    // function flattenArray(arr, n){
    //     let result = [];
    //     function helper(arr,depth){
    //         for(const val of arr){
    //             if(Array.isArray(val) && depth > 0){
    //                 helper(val, depth-1);
    //             }else{
    //                 result.push(val);
    //             }
    //         }
    //         return result;
    //     }
    //     return helper(arr,n);
    // }

    // console.log(flattenArray(arr,0));


    // Question 6:-

    // const groupBy = (fn, arr) => {
    //     const res = {};

    //     for(let obj of arr){
    //         const key = fn(obj);
    //         if(!res.hasOwnProperty(key)){
    //             res[key] = [];
    //         }
    //         res[key].push(obj);
    //     }
    //     return res;
    // }

    // groupBy(String, [1,2,3])


    // Question 7:-
        // const test = {
        //     past: [{day: 31},{month: 12},{year: 2020}],
        //     present: [{day: 1},{month: 1},{year: 2021}]
        // }

        // const deepClone = (input) => {
        //     let result = Array.isArray(input) ? [] : {};

        //     if(typeof input !== "object"){
        //         return input;
        //     }

        //     for(let key in input){
        //         result[key] = deepClone(input[key]);
        //     }

        //     return result;
        // }

        // const newTest = deepClone(test);
        
        // console.log(newTest,'newTest')
        // console.log(newTest === test);
        // newTest.past[0].day = 1;
        // console.log(newTest,'newTestnewTest')
        // console.log(test,'testtesttesttest')

    // Question 8 :-
    // Memoization

    //     let sum = 0;
    //     const calc= () => {
    //         for(let i=0;i<10;i++){
    //             sum += i;
    //         }
    //         return sum;
    //     }

    // const memoize = (fun) => {
    //     let cache = {};
    //     return function(...args){
    //         let n = args[0];
    //         if(n in cache){
    //             console.log("cache");
    //             return cache[n];
    //         }else{
    //             console.log("calculated first time");
    //             let result = fun(n);
    //             cache[n] = result;
    //             return result;
    //         }
    //     }
    // }

    // console.time();
    // const efficient = memoize(calc);
    // console.log(efficient(5));
    // console.timeEnd();

    // console.time();
    // console.log(efficient(5));
    // console.timeEnd();

    // Question 9 :- 

        // Debouncing

        // let counter = 0;
        // function getData(){
        //     console.log("fetching data"+counter++)
        // }

        // function myDebounce(call,d){
        //     let timer;
        //     return function(...args){
        //         if(timer) clearTimeout(timer);
        //         setTimeout(() => {
        //             call(args)
        //         },d);
        //     }
        // }
        // const newDebounce = myDebounce(getData, 1000)

        // function debounce(func, wait) {
        //     let timeout;
            
        //     return function() {
        //       const context = this;
        //       const args = arguments;
              
        //       clearTimeout(timeout);
        //       timeout = setTimeout(() => {
        //         func.apply(context, args);
        //       }, wait);
        //     };
        //   }

        // function logger(){
        //     console.log("debounce");
        //   }
        //   const printlog = debounce(logger,2000);
        //   printlog();
        //   printlog();
        //   /* Output:-
        //   debounce 
        //   debounce
        //   */

        // ------------------------------------------------------------------------------------------------------------------------------------------------ss


        // function throttle(cb, delay = 250) {
        //     let shouldWait = false
          
        //     return (...args) => {
        //       if (shouldWait) return
          
        //       cb(...args)
        //       shouldWait = true
        //       setTimeout(() => {
        //         shouldWait = false
        //       }, delay)
        //     }
        //   }


        // const optimisedTriggerHandler = throttleFunc(handlerTrigger, 100);
        // const throttleFunc = (func, interval) => {
        //     let shouldFire = true;
        // return function() {
        //         if (shouldFire) {
        //             func();
        //             shouldFire = false;
        //             setTimeOut(() => {
        //             shouldFire = true;
        //             }, interval)
        //         }
        //     }
        // }
// ------------------------------------------------------------------------------------------------------------------------------------------------ss

    // Question 10 :- 
        // const calc = {
        //     total:0,
        //     add: function(a){
        //         this.total += a;
        //         return this;
        //     },
        //     multiply: function(b){
        //         this.total *= b;
        //         return this;
        //     },
        //     substract: function(c){
        //         this.total -= c;
        //         return this;
        //     }
        // }
    
        // const result = calc.add(10).multiply(5).substract(30).add(10);
        // console.log(result.total);

// ------------------------------------------------------------------------------------------------------------------------------------------------ss
    // Question 11 :- 

        // const compose = (...functions) => {
        //     return (...args) => {
        //         functions.reduceRight((arg, fn) => fn(arg), args);
        //     }
        // }
        // function addFive(a){
        //     return a+5;
        // }
        // function substractTwo(b){
        //     return b-2;
        // }
        // function multiplyFour(c){
        //     return c*4;
        // }
        // const evaluate = compose(addFive, substractTwo, multiplyFour);

// ------------------------------------------------------------------------------------------------------------------------------------------------ss
    // Input
    // let test = {
    //     a: {
    //         b: (a, b, c) => a + b + c,
    //         c: (a, b, c) => a + b - c,
    //     },
    //     d: (a, b, c) => a - b - c,
    //     e: 1,
    //     f: true
    // };
    
    // pipe(test)(1,1,1);
    
    
    // function pipe(obj){
    //     return function(...args){
    //         for(let key in obj){
    //             let val = obj[key];
    //             if(typeof val === "function"){
    //                 obj[key] = val(...args);
    //             }else{
    //                 obj[key] = pipe(val)(...args);
    //             }
    //         }
    //         return obj;
    //     }
    // }
    // Output:
    // {
    // "a": {
    //     "b": 3,
    //     "c": 1
    // },
    // "d": -1,
    // "e": 1,
    // "f": true
    // }
// ------------------------------------------------------------------------------------------------------------------------------------------------ss
// #Currying Function

// const sum = (...args) => {
//     const storage = [...args];

//     if(storage.length === 4){
//         return storage.reduce((a,b) => a+b,0);
//     }else{
//         const temp = function(...args2){
//             storage.push(...args2);
//             if(storage.length === 4){
//                 return storage.reduce((a,b) => a+b,0);
//             }else{
//                 return temp;
//             }
//         }
//         return temp;
//     }
// }

// const res = sum(1, 2, 3, 4);
// const res2 = sum(1)(2)(3)(4);
// const res3 = sum(1, 2)(3, 4);
// const res4 = sum(1, 2, 3)(4);
// const res5 = sum(1)(2, 3, 4);

// console.log(res, res2, res3, res4, res5);
// ------------------------------------------------------------------------------------------------------------------------------------------------ss
// Flatten the nested object
// const flatten = (obj, prefix) => {
//     let output = {};
//     for(let key in obj){
//         let val = obj[key];

//         let newPrefix = prefix ? prefix+'.'+key : key;
//         if(typeof val === "object"){
//             if(Array.isArray(val)){
//                 let {...arrayToObj} = val;
//                 const newObj = flatten(arrayToObj, newPrefix);
//                 output = {...output, ...newObj};
//             }else{
//                 let newObj = flatten(val, newPrefix);
//                 output = {...output, ...newObj}
//             }
//         }else{
//             output = {...output, [newPrefix]: val}
//         }
//     }
//     return output;
// }

// const nested = {
//     A: "12",
//     B: 23,
//     C: {
//       P: 23,
//       O: {
//          L: 56
//       },
//       Q: [1, 2]
//      }   
//   };

//   console.log(flatten(nested))
// ------------------------------------------------------------------------------------------------------------------------------------------------ss
// Merge 2 objects
// let merge = (...args) => {
//     let target = {};
//     let deep = false;
//     let i =0;

//     if(typeof args[0] === "boolean"){
//         deep = args[0];
//         i++;
//     }

//     let merger = (obj) => {
//         for(let prop in obj){
//             if(obj.hasOwnProperty(prop)){
//                 if(deep && Object.prototype.toString.call(obj[prop]) === '[Object Object]'){
//                     target[prop] = merge(target[prop], obj[prop]);
//                 }else {
//                     target[prop] = obj[prop];
//                 }
//             }
//         }
//     }

//     for(;i<args.length;i++){
//         merger(args[i]);
//     }
//     return target;
// }

// let obj1 = {
//   name: 'prashant',
//   age: 23,
//   nature: {
//     "helping": true,
//     "shy": false
//   }
// }

// let obj2 = {
//   qualification: 'BSC CS',
//   loves: 'Javascript',
//   nature: {
//     "angry": false,
//     "shy": true
//   }
// }
// console.log(merge(obj1, obj2));
// ------------------------------------------------------------------------------------------------------------------------------------------------ss
function sum(a, b, c, d) {
    return a + b + c + d;
  }
  const curry = (fn) => {
    let helper = (...args) => {
        if(args.length >= fn.length){
           return fn(...args);
        }else{
            let temp = (...args2) => {
               return helper(...args, ...args2);
            }
            return temp;
        }
    }
    return helper;
}

  let curriedSum = curry(sum);
  
  console.log(curriedSum(1,2,3,4,5)); // 10
  console.log(curriedSum(1)(2,3)(4,5)); // 10
  console.log(curriedSum(1)(2)(3)(4)); // 10


// ------------------------------------------------------------------------------------------------------------------------------------------------ss
// ------------------------------------------------------------------------------------------------------------------------------------------------ss
// ------------------------------------------------------------------------------------------------------------------------------------------------ss
// ------------------------------------------------------------------------------------------------------------------------------------------------ss
// ------------------------------------------------------------------------------------------------------------------------------------------------ss
// ------------------------------------------------------------------------------------------------------------------------------------------------ss
