**Conncepts**
**Create Root**
    use createRoot instead of render.
    In your index.js, update ReactDOM.render to ReactDOM.createRoot to create a root, and render your app using root.

    React  17
        const container = document.getElementById('app');
        ReactDOM.render(<App />, container);
    React 18
        const container = document.getElementById('app');
        const root = ReactDOM.createRoot(container);
        //render app to root
        root.render(<App />);

**Concurrency in React 18**
    in React 18 with concurrent rendering, React can interrupt, pause, resume, or abandon a render. This allows React to respond to the user interaction quickly even if it is in the middle of a heavy rendering task.

    Before React 18, rendering was a single, uninterrupted, synchronous transaction and once rendering started, it couldn’t be interrupted.

    Concurrency is a foundational update to React’s rendering mechanism. Concurrency allows React to interrupt rendering.

    React 18 introduces the foundation of concurrent rendering and new features such as suspense, streaming server rendering, and transitions are powered by concurrent rendering.


**Features**
**Automatic Batching**
    In React, batching helps to reduce the number of re-renders that happen when a state changes, when you call setState. Previously, React batched state updates in event handlers, for example:
        const handleClick = () => {
            setCounter();
            setActive();
            setValue();
        }
        //re-rendered once at the end.
    
    However, state updates that happened outside of event handlers were not batched. For example, if you had a promise or were making a network call, the state updates would not be batched. Like this:

        fetch('/network').then( () => {
            setCounter(); //re-rendered 1 times
            setActive();  //re-rendered 2 times
            setValue();   //re-rendered 3 times
        });
        //Total 3 re-renders

    As you can tell, this is not performant. React 18 introduces automatic batching which allows all state updates – even within promises, setTimeouts, and event callbacks – to be batched. This significantly reduces the work that React has to do in the background.
    <!-- React will wait for a micro-task to finish before re-rendering -->

    Automatic batching is available out of the box in React, but if you want to opt-out you can use flushSync.
            flushSync :- Call flushSync to force React to flush any pending work and update the DOM synchronously.
                import { flushSync } from 'react-dom';
                    flushSync(() => {
                    setSomething(123);
                    });

**Transitions**
    Transitions can be used to mark UI updates that do not need urgent resources for updating.
    For example, when typing in a typeahead field, there are two things happening: a blinking cursor that shows visual feedback of your content being typed, and a search functionality in the background that searches for the data that is typed.

    Showing a visual feedback to the user is important and therefore urgent. Searching is not so urgent, and so can be marked as non-urgent.

    These non-urgent updates are called transitions. By marking non-urgent UI updates as "transitions", React will know which updates to prioritize. This makes it easier to optimize rendering and get rid of stale rendering.

    You can mark updates as non-urgent by using startTransition. Here is an example of what a typeahead component would like when marked with transitions:
        
        import { startTransition } from 'react';
            // Urgent: Show what was typed
        setInputValue(input);
            // Mark any non-urgent state updates inside as transitions
        startTransition(() => {
            // Transition: Show the results
        setSearchQuery(input);
        });
    
        How are transitions different from debouncing or setTimeout?
            1. startTransition executes immediately, unlike setTimeout.
            2. setTimeout has a guaranteed delay, whereas startTransition's delay depends on the speed of the device, and other urgent renders.
            3. startTransition updates can be interrupted unlike setTimeout and won't freeze the page.
            4. React can track the pending state for you when marked with startTransition.

**Suspense on the server**
    1. Code splitting on the server with suspense
    2. Streaming rendering on the server

        Client rendering vs server rendering
            In a client-rendered app, you load the HTML of your page from the server along with all the JavaScript that is needed to run the page, and make it interactive.
            If, however, your JavaScript bundle is huge, or you have a slow connection, this process can take a long time and the user will be waiting for the page to become interactive, or to see meaningful content.
        
            For optimizing the user experience and avoiding the user having to sit on a blank screen, we can use server rendering.
            Server rendering is a technique where you render the HTML output of your React components on the server and send HTML from the server. This lets the user view some UI while JS bundles are loading and before the app becomes interactive.

        
        Server rendering further enhances the user experience of loading the page and reducing time to interactive.
        Now what if most of your app is fast except for one part? Maybe this part loads data slowly, or maybe it needs to download a lot of JS before it gets interactive.

        Before React 18, this part was often the bottleneck of the app, and would increase the time it took to render the component.

        One slow component can slow down the entire page. This is because server rendering was all or nothing – you couldn’t tell React to defer loading of a slow component and couldn’t tell React to send HTML for other components.

        React 18 adds support for Suspense on server. With the help of suspense, you can wrap a slow part of your app within the Suspense component, telling React to delay the loading of the slow component. This can also be used to specify a loading state that can be shown while it's loading.

        In React 18, one slow component doesn’t have to slow the render of your entire app. With Suspense, you can tell React to send HTML for other components first along with the HTML for the placeholder, like a loading spinner. Then when the slow component is ready and has fetched its data, the server renderer will pop in its HTML in the same stream.

        This way the user can see the skeleton of the page as early as possible and see it gradually reveal more content as more pieces of HTML Arrive.
        All of this happens before any JS or React loads on the page, which significantly improves the user experience and user-perceived latency.


        React 18 includes some improvements to server-side rendering performance in React, which enables <Suspense> on the server. This means that you can now use <Suspense> and React.lazy on the server. And guess what? That’s not all! <Suspense> in React 18 also enables two major server-side rendering features unlocked by a new API called renderToPipeableStream:

            1. Streaming HTML on the server
            2. Selective Hydration on the client

                SSR in React in Four Steps
                    1. Fetch data for the ENTIRE application on the server.
                    2. Render the ENTIRE application to HTML on the server and then send it to the client.
                    3. Load the JavaScript code for the ENTIRE application on the client.
                    4. Connect the JavaScript code to the HTML for the ENTIRE application on the client—a process known as Hydration.

                        <Layout>
                            <Article />
                            <Suspense fallback={<Spinner />}>
                                <Comments />
                            </Suspense>
                        </Layout>
                        In the snippet above, wrapping the <Comments /> component in <Suspense> tells React not to wait for that component to start streaming the HTML for the rest of the page to the client. While streaming, because we provided the <Spinner /> component as a fallback, the HTML for the <Spinner /> will be sent with the HTML for the rest of the page. Your users will see the spinner while waiting for the comments to load.

**Strict mode**
        Strict mode in React 18 will simulate mounting, unmounting, and re-mounting the component with a previous state. This sets the ground for reusable state in the future where React can immediately mount a previous screen by remounting trees using the same component state before unmounting.

        Strict mode will ensure components are resilient to effects being mounted and unmounted multiple times.


<StrictMode> lets you find common bugs in your components early during development.

Strict Mode enables the following development-only behaviors:

Your components will re-render an extra time to find bugs caused by impure rendering.
Your components will re-run Effects an extra time to find bugs caused by missing Effect cleanup.
Your components will be checked for usage of deprecated APIs.

