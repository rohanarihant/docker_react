# 3 different ways to apply styles to HTML elements in React
    Gobal styling using regular CSS.
        can create a normal css file for each comp or single global css file.
        and apply the styles to html element using class, id and css selector 
    Component level styling using CSS modules.
        It creates a locally scoped CSS in which the class selectors and animation names can be accessed as JavaScript objects within the components.
        CSS modules are created by naming the CSS files as *.modules.css where * can be the name of the file.

        // app.module.css
            .red {
                color: red;
            }

            import Styles from "./app.module.css";
            const App = () => {
            return (
                <>
                <h1 className={Styles.red}>Learnersbucket.com</h1>
                </>
            );
            };

            export default App;
           
            This really keeps the styles isolated to the component itself, but the problem with this is we cannot merge multiple classes (objects) directly.

                We will need one extra package for that called classNames and because it is spelled similarly to the className which used for HTML class, it can be hard to understand it initially to many.
            
                // app.module.css
                .red {
                color: red;
                }

                .large {
                font-size: 3em;
                }

                import Styles from "./app.module.css";
                import ClassNames from "classnames";

                const App = () => {
                return (
                    <>
                    <h1 className={ClassNames(Styles.red, Styles.large)}>
                        Learnersbucket.com
                    </h1>
                    </>
                );
                };

                export default App;

    Creating styled component or Element level styling with styled-components.
        One of the best way to style the components or HTML elements in React is by using the styled-components.
        It allows you to write CSS in JavaScript, which fulfills the purpose of component driven development as the style is isolated to the component itself.

            import Styled from "styled-components";

            const OutlinedButton = Styled.button`
                background: ${(props) => (props.fill ? "gray" : "transparent")};
                border-radius: 3px;
                color: ${(props) => (props.fill ? "white" : "black")};
                border: 1px solid;
                display: inline-block;
                margin: 0.5rem 1rem;
                padding: 0.5rem 0;
                transition: all .25s ease;
                width: 10rem;
                cursor: pointer;

                &:hover{
                color: ${(props) => (props.fill ? "blue" : "red")};;
                }
            `;

            const FilledButton = Styled(OutlinedButton)`
            background: green;
            border-color: yello;
            `;

            const Test = () => {
            return (
                <>
                <OutlinedButton fill>Click me</OutlinedButton>
                <FilledButton fill>I am filled</FilledButton>
                </>
            );
            };

            export default Test;

            The styled-components can aslo be extended. It overrides the styles in the extend components
            Props from the extended component is passed to the base component and all the effects takes place as per the course.

