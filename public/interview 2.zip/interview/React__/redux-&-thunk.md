# Understanding Middleware in Redux
    Middleware provides a way to interact with actions dispatched to the Redux store before they reach the reducer.
    It sits between the action dispatch and the reducer, allowing you to intercept, modify, or delay actions as needed.
    It provides a way to extend Redux's functionality by intercepting and potentially modifying actions before they reach the reducers.


# The Role of Redux-Thunk
    The primary purpose of Redux-Thunk is to handle asynchronous actions in Redux. Asynchronous actions,
    such as fetching data from an API or performing asynchronous computations, are common in web applications.
    Redux-Thunk enables you to dispatch actions asynchronously, making it easier to manage side effects in your Redux applications.

    actiion.js
        export const fetchDataRequest = () => ({
            type: FETCH_DATA_REQUEST
        });


        // Thunk action creator
        export const fetchData = () => {
        return async (dispatch, getState) => {
            dispatch(fetchDataRequest());
            try {
            const response = await axios.get('https://api.example.com/data');
            dispatch(fetchDataSuccess(response.data));
            } catch (error) {
            dispatch(fetchDataFailure(error.message));
            }
        };
        };

        We defined a thunk action creator called fetchData, which returns a function instead of a plain action object.
        This function receives dispatch and getState as arguments, allowing us to dispatch actions and access the current Redux state.


        // SomeComponent.js
            import React, { useEffect } from 'react';
            import { useDispatch, useSelector } from 'react-redux';
            import { fetchData } from './actions';

            const SomeComponent = () => {
            const dispatch = useDispatch();
            const { data, isLoading, error } = useSelector(state => state.someReducer);

            useEffect(() => {
                dispatch(fetchData());
            }, [dispatch]);

        
        // store.js
            import { createStore, applyMiddleware } from 'redux';
            import thunk from 'redux-thunk';
            import rootReducer from './reducers';

            const store = createStore(rootReducer, applyMiddleware(thunk));

            export default store;

        
        Managing Side Effects with Thunks
            Managing side effects, such as asynchronous operations, in Redux applications can be effectively done using thunks.
            Thunks allow you to encapsulate complex logic, including side effects,
            within action creators, providing a centralized and organized way to handle such operations.

                    A. Define Thunk Action Creators
                    B. Dispatch Thunk Actions
                    C. Update Reducer
                    D. Set Up Redux Store with Thunk Middleware



# Principal of Redux
    Single source of truth
        The global state of your application is stored in an object tree within a single store.

    State is read-only
        The only way to change the state is to emit an action, an object describing what happened.
        This ensures that neither the views nor the network callbacks will ever write directly to the state.
        Instead, they express an intent to transform the state.
    Changes are made with pure functions
        To specify how the state tree is transformed by actions, you write pure reducers.
        Reducers are just pure functions that take the previous state and an action, and return the next state.
        Remember to return new state objects, instead of mutating the previous state
