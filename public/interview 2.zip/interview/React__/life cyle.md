# Class Life cycle methods
    A component's lifecycle has three main phases: 
        the Mounting Phase,
        the Updating Phase,
        the Unmounting Phase.

<!-- Component Mounting Phase -->
    The mounting phase refers to the period when a component is being created and inserted into the DOM.

        constructor()
            is called when the component is first created
            You use it to initialize the component's state and bind methods to the component's instance

        render()
            is responsible for generating the component's virtual DOM representation based on its current props and state.
            is called every time the component needs to be re-rendered
        
        getDerivedStateFromProps()
            is called after the constructor and before render()
            This method is called for every render cycle and provides an opportunity to update the component's state based on changes in props before the initial render.
            
            static getDerivedStateFromProps(props, state)
                It takes two parameters:
                    props: The updated props for the component.
                    state: The current state of the component.

            The method should return an object that represents the updated state of the component, or null if no state update is necessary.
            it does not have access to the this keyword and cannot interact with the component's instance methods or properties.
        
        componentDidMount()
            is called once the component has been mounted into the DOM.
            It is typically used to set up any necessary event listeners or timers, perform any necessary API calls or data fetching,
            and perform other initialization tasks that require access to the browser's DOM API.
        
<!-- Component Updating Phase -->
        
        shouldComponentUpdate()
            is called before a component is updated
            It takes two arguments: nextProps and nextState
                returns a boolean value
            If this method returns true, the component will update, and if it returns false, the component will not update
    
        componentWillUpdate()
            is a lifecycle method in React that gets called just before a component's update cycle starts
            we can access the nextProps and nextState arguments to check if there are any changes to the component's state or props
        
        componentDidUpdate()
            is a lifecycle method in React that is called after a component has been updated and re-rendered
            It is useful for performing side effects or additional operations when the component's props or state have changed
        getSnapshotBeforeUpdate()
            is called just before the component's UI is updated.
            It allows the component to capture some information about the current state of the UI,
            such as the scroll position before it changes.
            This method returns a value that is passed as the third parameter to the componentDidUpdate() method

# Unmounting Phase
        componentWillUnmount()
            is called just before the component is removed from the DOM.
            It allows you to perform any necessary cleanup, such as canceling timers, removing event listeners, or clearing any data structures that were set up during the mounting phase
        After componentWillUnmount() is called, the component is removed from the DOM and all of its state and props are destroyed.
