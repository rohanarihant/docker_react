**Key**
    A “key” is a special string attribute you need to include when creating lists of elements
    Keys help React identify which items have changed, are added, or are removed. Keys should be given to the elements inside the array to give the elements a stable identity:


    Keys Must Only Be Unique Among Siblings
        Keys used within arrays should be unique among their siblings. However, they don’t need to be globally unique. We can use the same keys when we produce two different arrays:


        function NumberList(props) {
            const numbers = props.numbers;
            const listItems = numbers.map((number) =>
                <li key={number.toString()}>
                {number}
                </li>
            );
            return (
                <ul>{listItems}</ul>
            );
        }
