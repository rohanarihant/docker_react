Error Boundary for useTransition is currently only available in React’s canary and experimental channels. Learn more about React’s release channels here.
    **Using react-error-boundary**
        Exceptions to Error handling
        Because react-error-boundary uses react error boundary in the background there are a few exceptions to the errors that can be handled.
        These errors are not handled by react-error-boundary
            Event handlers
            Asynchronous code (e.g. setTimeout or requestAnimationFrame callbacks)
            Server side rendering
            Errors thrown in the error boundary itself (rather than its children)

        Examples :- 
            import { useTransition } from "react";
            import { ErrorBoundary } from "react-error-boundary";

            export function AddCommentContainer() {
            return (
                <ErrorBoundary fallback={<p>⚠️Something went wrong</p>}>
                <AddCommentButton />
                </ErrorBoundary>
            );
            }

            function addComment(comment) {
            // For demonstration purposes to show Error Boundary
            if (comment == null) {
                throw new Error("Example Error: An error thrown to trigger error boundary");
            }
            }

            function AddCommentButton() {
            const [pending, startTransition] = useTransition();

            return (
                <button
                disabled={pending}
                onClick={() => {
                    startTransition(() => {
                    // Intentionally not passing a comment
                    // so error gets thrown
                    addComment();
                    });
                }}
                >
                Add comment
                </button>
            );
            }
    

**2nd approach**
    Creating a Functional Error Boundary
            import React, { useState, useEffect } from 'react';

            function ErrorBoundary({ children }) {
            const [hasError, setHasError] = useState(false);

            useEffect(() => {
                if (hasError) {
                // Log the error or send it to an error tracking service
                console.error('Error occurred within the ErrorBoundary');
                }
            }, [hasError]);

            if (hasError) {
                return <FallbackUI />;
            }

            return children;
            }
        
        Implementing Error Boundaries
            function MyComponent() {
            // Simulate an error for demonstration purposes
            if (Math.random() > 0.5) {
                throw new Error('An error occurred in MyComponent');
            }

            // Component logic here
            return <div>This is MyComponent</div>;
            }

            function App() {
            return (
                <ErrorBoundary>
                <MyComponent />
                </ErrorBoundary>
            );
            }