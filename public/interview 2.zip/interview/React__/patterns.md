# Render Props
A render prop is a prop on a component, which value is a function that returns a JSX element.
The component itself does not render anything besides the render prop.
Instead, the component simply calls the render prop, instead of implementing its own rendering logic.

Imagine that we have a Title component.
In this case, the Title component shouldn’t do anything besides rendering the value that we pass.
We can use a render prop for this! Let’s pass the value that we want the Title component to render to the render prop.

<Title render={() => <h1>I am a render prop!</h1>} />
const Title = (props) => props.render();
    To the Component element, we have to pass a prop called render, which is a function that returns a React element.

    Perfect, works smoothly! The cool thing about render props, is that the component that receives the prop is very reusable.
    We can use it multiple times, passing different values to the render prop each time.





# Compound Components
    The Compound Components Pattern is a React design pattern for managing parent components that are made up of child components.

    The principle behind this pattern is to break down the parent component into smaller components
    and then manage the interactions between these smaller components with either props,
    context or other react data management techniques.

    This pattern comes in handy when there is a need to create reusable, versatile components made up of smaller components.
    It enables developers to create sophisticated UI components that can be readily customized and
    extended while maintaining a clear and simple code structure.

    The compound pattern is great when you’re building a component library. You’ll often see this pattern when using UI libraries like Semantic UI.

    e.g 1
        We can also implement the Compound Component pattern by mapping over the children of the component. We can add the open and toggle properties to these elements, by cloning them with the additional props.

            export function FlyOut(props) {
            const [open, toggle] = React.useState(false);

            return (
                <div>
                {React.Children.map(props.children, (child) =>
                    React.cloneElement(child, { open, toggle })
                )}
                </div>
            );
            }


<!--  -->
            import { FlyOut } from "./FlyOut";
            export default function FlyoutMenu() {
            return (
                <FlyOut>
                <FlyOut.Toggle />
                <FlyOut.List>
                    <FlyOut.Item>Edit</FlyOut.Item>
                    <FlyOut.Item>Delete</FlyOut.Item>
                </FlyOut.List>
                </FlyOut>
            );
            }

            Compound components manage their own internal state, which they share among the several child components. When implementing a compound component, we don’t have to worry about managing the state ourselves.
            When importing a compound component, we don’t have to explicitly import the child components that are available on that component.



    e.g 2 

            import React, { createContext, useState } from "react";
            const ToggleContext = createContext();

            function Toggle({ children }) {
            const [on, setOn] = useState(false);
            const toggle = () => setOn(!on);

            return (
                <ToggleContext.Provider value={{ on, toggle }}>
                {children}
                </ToggleContext.Provider>
            );
            }

            Toggle.On = function ToggleOn({ children }) {
            const { on } = useContext(ToggleContext);
            return on ? children : null;
            };

            Toggle.Off = function ToggleOff({ children }) {
            const { on } = useContext(ToggleContext);
            return on ? null : children;
            };

            Toggle.Button = function ToggleButton(props) {
            const { on, toggle } = useContext(ToggleContext);
            return <button onClick={toggle} {...props} />;
            };

            function App() {
            return (
                <Toggle>
                <Toggle.On>The button is on</Toggle.On>
                <Toggle.Off>The button is off</Toggle.Off>
                <Toggle.Button>Toggle</Toggle.Button>
                </Toggle>
            );
            }



<!-- Prop combination -->
        This entails creating a single object out of several related props and passing it as a single prop to the component.

        This pattern allows us to clean up our code and make it simpler to manage the props, making it especially helpful when we want to pass a lot of related properties to a component.

            import React from "react";

            function P(props) {
            const { color, size, children, ...rest } = props;
            return (
                <p style={{ color, fontSize: size }} {...rest}>
                {children}
                </p>
            );
            }

            function App() {
            const paragraphProps = {
                color: "red",
                size: "20px",
                lineHeight: "22px",
            };
            return <P {...paragraphProps}>This is a P</P>;
            }

# Controlled inputs
    The Controlled Input pattern can be used to handle input fields. This pattern involves using an event handler to update the component state if the value of an input field changes, as well as storing the current value of the input field in the component state.

            import React, { useState } from "react";
            function ControlledInput() {
            const [inputValue, setInputValue] = useState("");

            const handleChange = (event) => {
                setInputValue(event.target.value);
            };

            return <input type="text" value={inputValue} onChange={handleChange} />;
            }

# Manage custom components with forwardRefs
    forwardRef lets your component expose a DOM node to parent component with a ref.
    Call forwardRef() to let your component receive a ref and forward it to a child component:

    forwardRef returns a React component that you can render in JSX. Unlike React components defined as plain functions,
    a component returned by forwardRef is also able to receive a ref prop.

    A higher-order component called a ForwardRef takes another component as input and outputs a new component that passes the original component's ref.
    By doing this, the child component's ref, which can be used to retrieve the underlying DOM node or component instance, is made accessible to the parent component.

        import React from "react";
        const CustomInput = React.forwardRef((props, ref) => (
            <input type="text" {...props} ref={ref} />
        ));

        const ParentComponent = () => {
            const inputRef = useRef(null);

            useEffect(() => {
                inputRef.current.focus();
            }, []);

            return <CustomInput ref={inputRef} />;
        };


# HOC
    Within our application, we often want to use the same logic in multiple components. This logic can include applying a certain styling to components, requiring authorization, or adding a global state.

    A Higher Order Component (HOC) is a component that receives another component. The HOC contains certain logic that we want to apply to the component that we pass as a parameter. After applying that logic, the HOC returns the element with the additional logic.

    Say that we always wanted to add a certain styling to multiple components in our application. Instead of creating a style object locally each time, we can simply create a HOC that adds the style objects to the component that we pass to it

    function withStyles(Component) {
        return props => {
            const style = { padding: '0.2rem', margin: '1rem' }
            return <Component style={style} {...props} />
        }
    }

    const Button = () = <button>Click me!</button>
    const Text = () => <p>Hello World!</p>

    const StyledButton = withStyles(Button)
    const StyledText = withStyles(Text)

# Container/Presentational Pattern
    In React, one way to enforce separation of concerns is by using the Container/Presentational pattern. With this pattern, we can separate the view from the application logic.

        Ideally, we want to enforce separation of concerns by separating this process into two parts:
            Presentational Components: Components that care about how data is shown to the user. In this example, that’s the rendering the list of dog images.
            Container Components: Components that care about what data is shown to the user. In this example, that’s fetching the dog images.
