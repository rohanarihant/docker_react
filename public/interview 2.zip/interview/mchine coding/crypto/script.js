console.log("scriptt")
function generateCryptoContent(data){
    return data.map((dt) => {
        return `<div class="crypto-container">
            <img class="crypto-container-img" src=${dt.image}/>
            <div>
                <p>${dt.name}</p>
                <p>${dt.symbol}</p>
            </div>
            <div>
                <p>${dt.current_price}</p>
                <p>${dt.market_cap_change_percentage_24h}</p>
            </div>
        </div>`
    })
}
async function getAllCryptoDetail(){
    let response = await fetch("https://api.coingecko.com/api/v3/coins/markets?vs_currency=inr&order=market_cap_desc&per_page=100&page=1&sparkline=false")
    let cryptoDetails = await response.json();
    document.getElementById("crpto-list").innerHTML = generateCryptoContent(cryptoDetails)
}

getAllCryptoDetail();