let container = document.getElementById("star-container");
let star = document.querySelectorAll(".star");
let filled = 0;

container.addEventListener("click", function(e){
    let currentClicked = e.target.dataset.index;
    for(let i=0;i<star.length;i++){
        star[i].classList.remove("star-rating");
    }
    for(let i=0;i<currentClicked;i++){
        star[i].classList.add("star-rating");
    }
    filled = currentClicked;
    document.getElementById("rating-count").innerHTML = filled;
})