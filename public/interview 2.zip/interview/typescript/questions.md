17 diff between inplicit and explicit types?
17 diff between interface and type?
define optional and required values in types
what are the default value
what is union in typescript
what is void in typescript
what is never in typescript
what is any in typescript
what is unknown in typescript
how to work with dom in typescript
how to work with classes in typescript
how to work with enum in typescript
what is generics in typescript
what is tuples in typescript -> diff b/w array and tupple
optional property in ts
how to cover dynamic keys in obj
what is index signature in ts
what is record type in ts
what is omit and pick in ts
what is readonly in ts
what is partial in ts
what is required in ts

how to use ts with react
ts.config.json
what is type interface in ts?
what is literal type in ts?
what are core component of ts?
*how to transpile ts code to js?
what is .d.ts file in ts?
what is map file in ts?


Advance

what is function overloading in ts
what is extends in ts
what is infer in ts

#1
    write a readonly helper in ts

    interface Todo{
        title: string,
        description: string
    }
    const todo: MyReadonly<Todo> = {
        title: "May",
        description: "abc"
    }

    todo.title = "Hello" // Error: can't reassign a readonly property

#2
    Implement a generic first that takes an Array T and returns it's first element type
        type arr1 = ['a','b','c'];
        type arr2 = [3,2,1];
        type head1 = First<arr1> // expected to be a
        type head2 = First<arr2> // expected to be 3

