The tsconfig.json file specifies the root files and the compiler options required to compile the project
that holds a number of compilation options
tsc --init // to generate the initial config file
it has one major property nname compileOptions  that has multiple sub-properties.
example
    {
  "compilerOptions": {
    "target": "es5",
    "lib": ["dom", "dom.iterable", "esnext"],
    "allowJs": false,
    "skipLibCheck": true,
    "esModuleInterop": true,
    "allowSyntheticDefaultImports": true,
    "strict": true,
    "forceConsistentCasingInFileNames": true,
    "noFallthroughCasesInSwitch": true,
    "module": "esnext",
    "moduleResolution": "node",
    "resolveJsonModule": true,
    "isolatedModules": true,
    "noEmit": true,
    "jsx": "react"
  },
  "include": ["src"]
}


compilerOptions options for compilation
includes the files to start the compilations

    "allowJs": true, // allow you to import js module to ts file

    target :- the language used for the compiled output

    skipLibCheck :- New --skipLibCheck TypeScript 2.0 adds a new --skipLibCheck compiler option that causes type checking of declaration files (files with extension .d.ts) to be skipped. When a program includes large declaration files, the compiler spends a lot of time type checking declarations that are already known to not contain errors, and compile times may be significantly shortened by skipping declaration file type checks.

    module: the module manager used in the compiled output. system is for SystemJS, commonjs for CommonJS.

    moduleResolution: the strategy used to resolve module declaration files (.d.ts files). With the node approach, they are loaded from the node_modules folder like a module (require('module-name'))

    sourceMap: generate or not source map files to debug directly your application TypeScript files in the browser,

    emitDecoratorMetadata: emit or not design-type metadata for decorated declarations in source,

    removeComments: remove comments or not

    experimentalDecorators: enables or not experimental support for ES7 decorators,

    noImplicitAny: allow or not the use of variables / parameters without types (implicit)
          When the noImplicitAny flag is false (by default), the compiler doesn’t infer the variable type based on how it’s used. Instead, the compiler defaults the type to any.


    "compilerOptions": {
    "esModuleInterop": true,
    ...
    },

    which will allow you to import Day.js (and all of its plugins) like this,


