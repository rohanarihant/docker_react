**Into**
    In simple terms, TypeScript is a superset of JavaScript. It includes all of the features of JavaScript and adds a few additional features.
    TypeScript is that it can enforce static typing to catch potential issues earlier in the lifecycle of development.
    It reduces the need for some unit tests and can analyze the code to find runtime errors at design time.

**Why we need TypeScript**
    where TypeScript comes in—by adding additional features and benefits on top of JavaScript,
    it can help developers write maintainable, scalable code more efficiently and address common challenges that arise in large-scale JavaScript development

    JavaScript is an interpreted language, and has benefits but also drawbacks.
    Interpreted languages do not have a compilation step and therefore can’t check that all code written has no minor mistakes in spelling or syntax before it is actually run.
    TypeScript is a strongly typed, object-oriented language that uses a compiler to generate JavaScript.
    The compiler will identify errors within the code base even before it is run in an interpreter.


**Inferred & Duck Typing**
    Inferred typing is a feature of TypeScript that allows the type of a variable or expression to be determined based on the context in which it appears rather than being explicitly specified with a type annotation.

    var inferredString = "this is a string";

    var inferredNumber = 1;

    inferredNumber = inferredString;
    // here we haven't explicitly definned any type but ts will determine this type.
    // called inferred typing, or type inference


    Duck typing checks the compatibility of an object with a particular type based on the presence of certain properties or methods rather than the object’s actual type.
    Duck typing :- In other words, two variables are considered to have the same type if they have the same properties and methods.




