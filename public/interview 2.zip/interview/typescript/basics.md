Diff between typescript and javascript

    JS is executed natively inside the browsers


    Ts can't be executed directly inside the browser
    we need to transpile the ts code to js file
    Ts is js with syntax for types

    bigest problem
    JS we are getting errors on runtime, when js is executed inside browser,  for other app we will get error in compile time.
    TS will return error while writing the code, it will transpile the code and return the error on editor
    because ts will  transpile the code to js and return  the error

    TypeScript is an object-oriented and statically typed language, similar to Java and C#,
    whereas JavaScript is a scripting language closer to Python.
    The object-oriented nature of TypeScript is complete with features such as classes and interfaces,
    and its static typing allows for better tooling with type inference at your disposal.

1. What are the main features of TypeScript?

    Cross-Platform: The TypeScript compiler can be installed on any operating system such as Windows, macOS, and Linux.
    ES6 Features: TypeScript includes most features of planned ECMAScript 2015 (ES6) such as Arrow functions.
    Object-Oriented Language: TypeScript provides all the standard OOP features like classes, interfaces, and modules.
    Static Type-Checking: TypeScript uses static typing and helps type checking at compile time. Thus, you can find compile-time errors while writing the code without running the script.
    Optional Static Typing: TypeScript also allows optional static typing in case you are used to the dynamic typing of JavaScript.
    DOM Manipulation: You can use TypeScript to manipulate the DOM for adding or removing client-side web page elements.

2. What are the benefits of using TypeScript?
    TypeScript is more expressive, meaning it has less syntactical clutter.
    Easy debugging due to advanced debugger that focuses on catching logical errors before compile-time
    Static typing makes TypeScript easier to read and more structured than JavaScript’s dynamic typing.
    Usable across platforms, in both client and server-side projects due to versatile transpiling.

5. What is an interface in TypeScript?
    Interfaces define a contract or structure for objects that use that interface.

    An interface is defined with the keyword interface and it can include properties and method declarations using a function or an arrow function.

    interface IEmployee {
        empCode: number;
        empName: string;
        getSalary: (number) => number; // arrow function
        getManagerName(number): string; 
    }

6. What are modules in TypeScript?
    Modules in TypeScript are a collection of related variables, functions, classes, and interfaces.

    You can think of modules as containers that contain everything needed to execute a task. Modules can be imported to easily share code between projects.

    module module_name{
        class xyz{
            export sum(x, y){
            return x+y;
        }
    }

8. What are Type assertions in TypeScript?
    Type assertion in TypeScript works like typecasting in other languages but without the type checking or restructuring of data possible in languages like C# and Java. Type assertion has no impact on runtime and is used purely by the compiler.

    Type assertion is essentially a soft version of typecasting that suggests the compiler see the variable as a certain type but does not force it into that mold if it’s in a different form.

10. How do you call a base class constructor from a child class in TypeScript?
    You can use the super() function to call the constructor of the base class. 

11. Explain how to use TypeScript Mixins.
13. What are getters/setters in TypeScript? How do you use them?
    Getters and setters are special types of methods that help you delegate different levels of access to private variables based on the needs of the program.

    Getters allow you to reference a value but cannot edit it. Setters allow you to change the value of a variable but not see its current value. These are essential to achieve encapsulation.

    For example, a new employer may be able to get the number of employees in the company but does not have permission to set the number of employees.

16. What is a ‘.map’ file, and why/how can you use it?
    A map file is a source map that shows how the original TypeScript code was interpreted into usable JavaScript code. They help simplify debugging because you can catch any odd compiler behavior.

    Debugging tools can also use these files to allow you to edit the underlying TypeScript rather than the emitted JavaScript file.










