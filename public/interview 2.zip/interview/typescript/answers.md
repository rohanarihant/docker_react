<!-- Types in Ts -->

const foo:string = "Foo";
const isActive:boolean = false;
const age:number = 50;
const user: {id:string; age:number} = {
    id: "abc",
    age: 12
}
const users: {id:string, age:number}[] = [user]

<!-- Diff between implicit and explicit types in Ts -->
here we are assigning the type explicitly
const foo:string = "Foo";

here we are assigning the type implecitly
const foo = "Foo" // here ts implicitly assign the type foo which is a string
let foo = "Foo" // here ts implicitly assign the type string to the var foo
ts will guess it from the value assigned to it


<!-- write a func getFullName which gets name and surname and returns a full name -->

const getFullName = (name, surname) => name+" "+surname
// ts error parameters name implecitly has an any type
// ts error parameters surname implecitly has an any type


sol :- 
const getFullName = (name:string, surname:string):string => name+" "+surname


<!-- interface inside ts -->

in our app we do have lot of entities, we can create interface
interface User {
    id: number,
    name: string
}

const user: User = {
    id: 1,
    name: "a"
}

const getName = (user: User) => {
    return user.name
}

<!-- type inside ts -->

interface User {
    id: number,
    name: string
}

type Numbers = number[];
type Users = User[];

const number: Numbers = [1,2,3];
const users: Users =  [];

<!-- diff  between  type and interface ts -->

interface User {
    id: number,
    name: string
}
const user:User = {id: 1, name:"Foo"}

// here we are using type instead of interface.  it is working fine
in type we are defining the shape of our data, it can be a string, object
its a contract how our object must look

Interface :- 
    1. we always have an object we are defining, we can't define string or array of string 
    2. we can use extend just like we are extending like classes using (extends)
        interface User {
            id: number,
            name: string
        }
        interface Admin extends User {
            permissions: sring[]
        }
Type :- 
    1. we can use types as a replacement of Interface
    2. we can use add new properties to previously defined types by using (intersection)
        type User {
            id: number,
            name: string
        }
        type Admin = User & {permissions: string[]}


interface with implements

interface/type Person {
    name: string,
    greet(): string
}
class Student implements Person {
    name: "Jack",
    greet(): string {
        return "Hello"
    }
}

// we used implements in order to make sure that this class have all necessary variables and functions

<!-- New diff Interface vs Types -->
    1. Objects / Functions
    Both can be used to describe the shape of an object or a function signature. But the syntax differs.

    Interface

        interface Point {
            x: number;
            y: number;
        }

        interface SetPoint {
            (x: number, y: number): void;
        }
    Type alias

        type Point = {
            x: number;
            y: number;
        };
        type SetPoint = (x: number, y: number) => void;
    
    2. Other Types
        Unlike an interface, the type alias can also be used for other types such as primitives, unions, and tuples.

        // primitive
        type Name = string;

        // object
        type PartialPointX = { x: number; };
        type PartialPointY = { y: number; };

        // union
        type PartialPoint = PartialPointX | PartialPointY;

        // tuple
        type Data = [number, string];

    3. Extend
        Both can be extended, but again, the syntax differs. Additionally, note that an interface and type alias are not mutually exclusive. An interface can extend a type alias, and vice versa.

        Interface extends interface
            interface PartialPointX { x: number; }
            interface Point extends PartialPointX { y: number; }
        
        //Type alias extends type alias
            type PartialPointX = { x: number; };
            type Point = PartialPointX & { y: number; };
        
        //Interface extends type alias
            type PartialPointX = { x: number; };
            interface Point extends PartialPointX { y: number; }
        //Type alias extends interface
            interface PartialPointX { x: number; }
            type Point = PartialPointX & { y: number; };
    
    4. Implements
        A class can implement an interface or type alias, both in the same exact way.
        Note however that a class and interface are considered static blueprints. Therefore,
        they can not implement / extend a type alias that names a union type.

        interface Point {
            x: number;
            y: number;
        }

        class SomePoint implements Point {
            x = 1;
            y = 2;
        }

        type Point2 = {
            x: number;
            y: number;
        };

        class SomePoint2 implements Point2 {
            x = 1;
            y = 2;
        }

        type PartialPoint = { x: number; } | { y: number; };

        // FIXME: can not implement a union type
        class SomePartialPoint implements PartialPoint {
            x = 1;
            y = 2;
        }

    5. Declaration merging
        Unlike a type alias, an interface can be defined multiple times,
        and will be treated as a single interface (with members of all declarations being merged).

        // These two declarations become:
        // interface Point { x: number; y: number; }
        interface Point { x: number; }
        interface Point { y: number; }

        const point: Point = { x: 1, y: 2 };

<!-- tuple -->
A tuple is a typed array with a pre-defined length and types for each index.
Tuples are great because they allow each element in the array to be a known type of value.
To define a tuple, specify the type of each element in the array:

// define our tuple
let ourTuple: [number, boolean, string];

// initialize correctly
ourTuple = [5, false, 'Coding God was here'];

<!-- How to Set Default Values in TypeScript -->
        A default value is a value that is automatically assigned to a variable or parameter if no other value is provided.
        In TypeScript, default values can be set for function parameters, function arguments, class properties, and more.

        1. How to Set a Default Value for a Function Parameter in TypeScript?
            function greet(name: string = "World") {
                console.log(`Hello, ${name}!`);
            }
            greet(); // Output: Hello, World!
            greet("John"); // Output: Hello, John!
        
        2. How to Use Default Arguments in TypeScript?
            class Person {
                name: string = "John Doe";
                age: number = 30;
            }
            const person = new Person();
            console.log(person.name); // Output: John Doe
            console.log(person.age); // Output: 30
        
        3. How to Use Default Imports in TypeScript?
            export default function add(a: number, b: number) {
            return a + b;
            }
            // main.ts
            import add from "./mathUtils";
            console.log(add(2, 3)); // Output: 5
        4. How to Use Default Exports in TypeScript?
            export default function add(a: number, b: number) {
                return a + b;
            }
            // main.ts
            import myAddFunction from "./mathUtils";
            console.log(myAddFunction(2, 3)); // Output: 5
        5. What are Default Modules in TypeScript?
            export default {
                add(a: number, b: number) {
                    return a + b;
                },
                subtract(a: number, b: number) {
                    return a - b;
                }
            }
            // main.ts
            import mathUtils from "./mathUtils";
            console.log(mathUtils.add(2, 3)); // Output: 5
            console.log(mathUtils.subtract(5, 3)); // Output: 2
        6. What is a Default Interface in TypeScript?
            interface Person {
                name: string;
                age: number;
            }
            function greet(person: Person = { name: "John Doe", age: 30 }) {
                console.log(`Hello, ${person.name}! You are ${person.age} years old.`);
            }
            greet(); // Output: Hello, John Doe! You are 30 years old.
            greet({ name: "Alice", age: 25 }); // Output: Hello, Alice! You are 25 years old.
        7. How to Define a Default Constructor in TypeScript?
            class Person {
                name: string;
                age: number;
                constructor(name: string = "John Doe", age: number = 30) {
                this.name = name;
                this.age = age;
                }
            }
            const person1 = new Person();
            console.log(person1.name); // Output: John Doe
            console.log(person1.age); // Output: 30
            const person2 = new Person("Alice", 25);
            console.log(person2.name); // Output: Alice
            console.log(person2.age); // Output: 25
<!-- union inside ts -->
    1.
        const getId = (id: string|number ) => { // this pipe is called the union 
            return id.toFixed(); // error we can't return a number because we can send number and string
        }

        // to fixed this
        const getId = (id: string|number ) => {
            if(typeof id === "string"){
                return id;
            }else{
                return id.toFixed();
            }
        }
    
    2.
        type LoadingState = {
            state: "loading"
        }
        type FailedState = {
            state: "failed",
            code: number
        }
        type SuccessState = {
            state: "Success",
            response: {
                title: string
            }
        }

        type NetworkState = LoadingState | FailedState | SuccessState;

<!-- what is type narrowing inside  ts -->

    const foo = (value: string | number) => {
        if(typeof value === "string"){
            return value;
        }
        return value;
    }

<!-- optional properties inside interface or types in ts -->
interface ButtonProps {
    text? : string,
    icon? : string,
    children: JSX.Element
}

const Button = ({text: "submit", icon}:ButtonProps): JSX.Element

<!-- diff b/w ! and ? in ts -->
class Employee {
   firstName: string;
   lastName!: string;
   middleName?: string;
}

If you have strictNullChecks: false in your tsconfig.json
then strictNullChecks will be disabled, it means all fields have null or undefined as valid values

but if strictNullChecks will be true then 
firstName must be string, no null or undefined
but all uninitialized  fields have default value of undefined
it will throw an error

but with this !
value must be string, not null  or undefined
but it will silent the compilation error


About the middleName?: string syntax. This is similar to middleName: string | undefined; Since all values has a default value of undefined, the compiler won't complain that middleName is not assigned.

<!-- what is absttract class in ts -->
Define an abstract class in Typescript using the abstract keyword.
Abstract classes are mainly for inheritance where other classes may drive from them.
We cannot create an instance of an abstract class.

An abstract class typically includes one or more abstract methods or property declarations. The class which extends the abstract class must define all the abstract methods.

The following abstract class declares one abstract method find and also includes a normal method display.


        abstract class Person {
            name: string;
            
            constructor(name: string) {
                this.name = name;
            }

            display(): void{
                console.log(this.name);
            }

            abstract find(string): Person;
        }

        class Employee extends Person { 
            empCode: number;
            
            constructor(name: string, code: number) { 
                super(name); // must call super()
                this.empCode = code;
            }

            find(name:string): Person { 
                // execute AJAX request to find an employee from a db
                return new Employee(name, 1);
            }
        }

        let emp: Person = new Employee("James", 100);
        emp.display(); //James

        let emp2: Person = emp.find('Steve');

<!-- static keyword in ts -->
    The static members of a class are accessed using the class name and dot notation, without creating an object e.g. <ClassName>.<StaticMember>.
    The static members can be defined by using the keyword static.
    Consider the following example of a class with static property.
        class Circle {
            static pi: number = 3.14;
            
            static calculateArea(radius:number) {
                return this.pi * radius * radius;
            }
        }
        
    Circle.pi; // returns 3.14
    Circle.calculateArea(5);
    *static and non-static fields with the same name can exists without any error.
    The static field will be accessed using dot notation and the non-static field can be accessed using an object.
        class Circle {
            static pi = 3.14;
            pi = 3;
        }

        Circle.pi; // returns 3.14

        let circleObj = new Circle();
        circleObj.pi; // returns 3

<!-- omit utility in ts -->
    interface User {
        name: string;
        description: string;
        age: number;
        email: string;
    }

    // removes the `email` property from the User interface
    type UserPreview = Omit<User, "email">;

    const userPreview: UserPreview = {
    name: "Bob",
    description: "Awesome guy",
    age: 20,
    };

<!-- How do “enums” work in TypeScript -->
    enum UserType {
        Guest = "G",
        Verified = "V",
        Admin = "A",
    }

    const userType: UserType = UserType.Verified;

    Enums or enumerated types are a means of defining a set of named constants.
    These data structures have a constant length and contain a set of constant values.
    Enums in TypeScript are commonly used to represent a set number of options for a given value using a set of key/value pairs.

    Enums come in two flavors string and numeric. Lets start with numeric.
    By default, enums will initialize the first value to 0 and add 1 to each additional value:

        enum CardinalDirections {
            North,
            East,
            South,
            West
        }
        let currentDirection = CardinalDirections.North;
        // logs 0
        console.log(currentDirection);
        // throws error as 'North' is not a valid enum
        currentDirection = 'North'; // Error: "North" is not assignable to type 'CardinalDirections'.

        enum StatusCodes {
            NotFound = 404,
            Success = 200,
            Accepted = 202,
            BadRequest = 400
        }
        // logs 404
        console.log(StatusCodes.NotFound);
        // logs 200
        console.log(StatusCodes.Success);

<!-- When do you use a return type of never and how does it differ from void? -->

    Before diving into the differences between never and void, let’s talk about the behavior of a JavaScript function when nothing is returned explicitly.
The type void can be used to indicate a function doesn't return any value.

    printName(name: string): void {
        console.log(name);
    }

    const printer = printName('Will');
    console.log(printer); // logs "undefined"

    In contrast, never is a type that represents a value that never occurs. For example, a function with an infinite loop or a function that throws an error are functions that have a never return type.
    
    const error = (): never => {
        throw new Error("");
    };


<!-- What access modifiers are supported by TypeScript? -->

    The concept of “encapsulation” is used in object-oriented programming to control the visibility of its properties and methods. TypeScript uses access modifiers to set the visibility of a class’s contents. Because TypeScript gets compiled to JavaScript, logic related to access modifiers is applied during compile time, not at run time.

    There are three types of access modifiers in TypeScript: public, private, and protected.

    public: All properties and methods are public by default. Public members of a class are visible and accessible from any location.

    protected: Protected properties are accessible from within the same class and its subclass. For example, a variable or method with the protected keyword will be accessible from anywhere within its class and within a different class that extends the class containing the variable or method.

    private: Private properties are only accessible from within the class the property or method is defined.

<!-- What are generics and how to use them in TypeScript? -->

    To call a generic function, you can either pass in the type explicitly within angle brackets or via type argument inference, letting TypeScript infer the type based on the type of the argument passed in.

        // explicitly specifying the type
        let user = updateUser<string>("Bob");

        // type argument inference
        let user = updateUser("Bob");
    
    Generics allows us to keep track of the type information throughout the function.
    This makes the code flexible and reusable without compromising on its type accuracy.

<!-- When should you use the unknown type? -->
    unknown is a special type that is similar to any. Like any, a common use case of the unknown type is when you don’t know the exact type upfront.

    invokeCallback(callback: any): void {
        callback();
    }
    The unknown equivalent of the above example requires you to add a type check before calling the callback function. The additional type check prevents the run time error above from happening.

    
    invokeCallback(callback: unknown): void {
        if (typeof callback === 'function') {
            callback();
        }
    }

    To summarize, you can assign anything to both an any and an unknown type. However, unknown types require a type check or type assertion to perform any operation on the variable.



<!-- What is the difference between union and intersection types? -->

    Unions and intersection types let you compose and combine existing types instead of creating them from scratch.
    Both union and intersection come with their unique characteristics which make them ideal for different use cases.

    A union type is described as a type that can be one of several types. Union type uses the | (vertical bar) symbol to separate the list of types that will be used in the new type. Let’s take a look at an example:

    interface B {
        name: string,
        email: string
    }

    interface C {
        name: string,
        age: number
    }

    type A = B | C;

    Intersection on the other hand, is described as a type that combines multiple types into one – combining all the properties of each type to create a new type. Intersection uses the & symbol to separate the list of types that will be combined. Let’s look at an example:

    interface B {
        name: string,
        email: string
    }

    interface C {
        name: string,
        age: number
    }

    type A = B & C;

<!-- What is the difference between extends and implements in TypeScript? -->

    Implements and extends have different uses. Let’s go through each individual and take a look at an example to compare the two.

    When a class extends another class, the child class will inherit all the properties and methods of the class it extends. You can override any of the existing properties and methods of its parent and add new ones.

    When a class implements another class or interface, the class has to implement all the methods and properties from the implemented class or interface. The implements keyword acts as a contract that the class has to follow, and TypeScript will make sure that the class is of the same shape as the class or interface it implements.

    class User {
        name: string;
        age: number;
    }

    // John will contain name and age from the User class
    class John extends User {}

    // this will result in an error as Bob doesn't have all the properties that
    // the User class has
    class Bob implements User {}

    // This is valid as Mike satisfies the "contract" specified by the 
    // User class
    class Mike implements User {
        name = 'Mike';
        age = 25
    }

<!-- What are type assertions in TypeScript? -->

    Type assertion allows you to explicitly set the type of a value and tell the compiler not to infer it. This is useful when you know the type of an object more specifically than its current type or current inferred type. In such cases, you can use type assertions to tell TypeScript the current type of the variable

    // using the `as` keyword
    const name: string = person.name as string;

    // using `<>`
    const name: string = <string>person.name;

<!-- What is the difference between type inference and contextual typing? -->

    TypeScript can infer the type of a variable usually based on the variable’s initialization or declaration. This process is known as type inference.

    The snippet below is an example of type inference where TypeScript infers the type of name as “string” based on the value assigned to it.

    let name = 'john'

    Contextual typing is a subset of type inference where TypeScript uses the location or context of a variable to infer its type. You can think about this as type inference in the opposite direction.

    In the snippet below, TpyeScript uses information from the onmousedown function to infer the type of the mouseEvent parameter.

    window.onmousedown = function(mouseEvent) {
        console.log(mouseEvent.button);   // OK
        console.log(mouseEvent.person);   // Error
    };

<!-- How does function overloads work in TypeScript? -->

    Function overload is when the same function name is used multiple times with a different set of arguments – the number of arguments, types, or return types.

    Let’s look at an example of how a print function can accept multiple types as its parameter by using function overloading.

    print(message: string): void;
    print(message: string[]): void;

    print(message: unknown): void {
    if (typeof message === 'string') {
        console.log(message);
    } else if (Array.isArray(message)) {
        message.forEach((individualMessage) => {
        console.log(individualMessage);
        });
    } else {
        throw new Error('unable to print');
    }
    }

    Based on the code snippet above, we can now call print passing in either a single message string or an array of message strings.

    print('Single message');
    // Console Output:
    // Single message

    print(['First message', 'Second message']);
    // Console Output
    // First message
    // Second message