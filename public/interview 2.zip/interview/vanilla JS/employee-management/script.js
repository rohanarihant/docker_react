// const records = require("./records.json");
// var json = require('./records.json');
const records = [
    {
    "firstname": "Rohan",
    "lastName": "Arihant",
    "email": "rohan@gmail.com",
    "phone": 9988776655,
    "imageUrl": ""
    },
    {
    "firstname": "Rohan",
    "lastName": "Arihant",
    "email": "rohan@gmail.com",
    "phone": 9988776655,
    "imageUrl": ""
    },
    {
    "firstname": "Rohan",
    "lastName": "Arihant",
    "email": "rohan@gmail.com",
    "phone": 9988776655,
    "imageUrl": ""
    },
    {
    "firstname": "Rohan",
    "lastName": "Arihant",
    "email": "rohan@gmail.com",
    "contact": 9988776655,
    "imageUrl": "",
    "address": "Bangalore",
    "dateOfBirth": ""
    }
] 
(async function(){
    // const data = await fetch("./records.json");
    // const records = await data.json();
    // console.log(json,'recordsrecords')
    let employees = records;
    let selectedEmployeeId = employees[0].id;
    let selectedEmployee = employees[0];

    const  employeeList = document.querySelector(".employees__names--list");
    const  employeeInfo = document.querySelector(".employees__single--list");

    const renderEmployee = () => {
        employeeList.innerHTML = "";
        employeeInfo.forEach((emp) => {
            const employee = document.createElement("span");
            employee.classList.add("employee__names--item")

            if(parseInt(selectedEmployeeId,10) === emp.id){
                
            }
        })
    }
})();