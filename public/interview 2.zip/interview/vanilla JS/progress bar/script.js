var progress = document.querySelector('.progress');
var progressLabel = document.querySelector('.progressLabel');
var startButton = document.querySelector('.start');


function handleClick(){
    console.log('handleClick')
    let value = 0;
    let interval;
    interval=setInterval(() => {
        if(value === 90){
            clearInterval(interval);
        }
        value += 10;
        console.log(value,'valuevaluevalue')
        progress.style.width=`${value}%`;
        progressLabel.innerText = `${value}%`;
    }, 1000)
}

startButton.addEventListener('click', () => {
    console.log('click')
    handleClick();
})