# Cookie
    A browser should be able to accept at least 300 cookies with a maximum size of 4 kb

    # Writing to document.cookie
        We can write to document.cookie. But it’s not a data property, it’s an accessor (getter/setter).
        An assignment to it is treated specially.
        A write operation to document.cookie updates only the cookie mentioned in it and doesn’t touch other cookies.
            document.cookie = "user=John"; // update only cookie named 'user'
            alert(document.cookie); // show all cookies

<!-- There are a few limitations: -->
        You can only set/update a single cookie at a time using document.cookie.
        The name=value pair, after encodeURIComponent, should not exceed 4KB. So we can’t store anything huge in a cookie.
        The total number of cookies per domain is limited to around 20+, the exact limit depends on the browser.

    Cookies have several attributes, many of which are important and should be set.
    The attributes are listed after key=value, delimited by ;, like this:
        document.cookie = "user=John; path=/; expires=Tue, 19 Jan 2038 03:14:07 GMT"

<!-- domain -->
    domain=site.com

    There’s no way to let a cookie be accessible from another 2nd-level domain, so other.com will never receive a cookie set at site.com.
    Please note, by default, a cookie is not shared with a subdomain, such as forum.site.com.

    For that to happen, when setting a cookie at site.com,
    we should explicitly set the domain attribute to the root domain: domain=site.com.
    Then all subdomains will see such a cookie.

        // at site.com
        // make the cookie accessible on any subdomain *.site.com:
        document.cookie = "user=John; domain=site.com"

        // later

        // at forum.site.com
        alert(document.cookie); // has cookie user=John

    Historically, domain=.site.com (with a dot before site.com) used to work the same way, allowing access to the cookie from subdomains. Leading dots in domain names are now ignored, but some browsers may decline to set the cookie containing such dots.

<!-- path -->
    path=/mypath
    The URL path prefix must be absolute. It makes the cookie accessible for pages under that path. By default, it’s the current path.

    If a cookie is set with path=/admin, it’s visible on pages /admin and /admin/something, but not at /home, /home/admin or /.

    Usually, we should set path to the root: path=/ to make the cookie accessible from all website pages. If this attribute is not set the default is calculated using this method.

<!-- expires, max-age -->
    By default, if a cookie doesn’t have one of these attributes, it disappears when the browser/tab is closed. Such cookies are called “session cookies”

    To let cookies survive a browser close, we can set either the expires or max-age attribute. max-Age has precedence if both are set.

    * expires=Tue, 19 Jan 2038 03:14:07 GMT

    The cookie expiration date defines the time when the browser will automatically delete it (according to the browser’s time zone).

    The date must be exactly in this format, in the GMT timezone. We can use date.toUTCString to get it.
    For instance, we can set the cookie to expire in 1 day:
        // +1 day from now
            let date = new Date(Date.now() + 86400e3);
            date = date.toUTCString();
            document.cookie = "user=John; expires=" + date;

    If we set expires to a date in the past, the cookie is deleted.

    * max-age=3600
        It’s an alternative to expires and specifies the cookie’s expiration in seconds from the current moment.
        If set to zero or a negative value, the cookie is deleted:

            // cookie will die in +1 hour from now
            document.cookie = "user=John; max-age=3600";

            // delete cookie (let it expire right now)
            document.cookie = "user=John; max-age=0";

<!-- secure -->
    The cookie should be transferred only over HTTPS.

    By default, if we set a cookie at http://site.com, then it also appears at https://site.com and vice versa.

    That is, cookies are domain-based, they do not distinguish between the protocols.

    With this attribute, if a cookie is set by https://site.com, then it doesn’t appear when the same site is accessed by HTTP,
    as http://site.com. So if a cookie has sensitive content that should never be sent over unencrypted HTTP,
    the secure flag is the right thing.

        // assuming we're on https:// now
        // set the cookie to be secure (only accessible over HTTPS)
        document.cookie = "user=John; secure";

<!-- samesite -->
    This is another security attribute samesite. It’s designed to protect from so-called XSRF (cross-site request forgery) attacks.

        To understand how it works and when it’s useful, let’s take a look at XSRF attacks.


                # XSRF attack
                    Imagine, you are logged into the site bank.com. That is: you have an authentication cookie from that site. Your browser sends it to bank.com with every request so that it recognizes you and performs all sensitive financial operations.

                    Now, while browsing the web in another window, you accidentally come to another site evil.com. That site has JavaScript code that submits a form <form action="https://bank.com/pay"> to bank.com with fields that initiate a transaction to the hacker’s account.

                    The browser sends cookies every time you visit the site bank.com, even if the form was submitted from evil.com. So the bank recognizes you and performs the payment.


                    This is a so-called “Cross-Site Request Forgery” (in short, XSRF) attack.

                    Real banks are protected from it of course. All forms generated by bank.com have a special field, a so-called “XSRF protection token”, that an evil page can’t generate or extract from a remote page. It can submit a form there, but can’t get the data back. The site bank.com checks for such a token in every form it receives.

                    Such a protection takes time to implement though. We need to ensure that every form has the required token field, and we must also check all requests.

        Use cookie samesite attribute
        The cookie samesite attribute provides another way to protect from such attacks, that (in theory) should not require “xsrf protection tokens”.

        It has two possible values:

<!-- samesite=strict -->
        If authentication cookies have the samesite=strict attribute, then an XSRF attack has no chance of succeeding, because a submission from evil.com comes without cookies. So bank.com will not recognize the user and will not proceed with the payment.






# LocalStorage, sessionStorage
    * Unlike cookies, web storage objects are not sent to server with each request. Because of that, we can store much more. Most modern browsers allow at least 5 megabytes of data (or more) and have settings to configure that.
    * Also unlike cookies, the server can’t manipulate storage objects via HTTP headers. Everything’s done in JavaScript.
    * The storage is bound to the origin (domain/protocol/port triplet). That is, different protocols or subdomains infer different storage objects, they can’t access data from each other.

<!-- The main features of localStorage are: -->

        Shared between all tabs and windows from the same origin.
        The data does not expire. It remains after the browser restart and even OS reboot.
        For instance, if you run this code…

        localStorage.setItem('test', 1);
        …And close/open the browser or just open the same page in a different window, then you can get it like this:

        alert( localStorage.getItem('test') ); // 1
        We only have to be on the same origin (domain/port/protocol), the url path can be different.

        The localStorage is shared between all windows with the same origin, so if we set the data in one window, the change becomes visible in another one.

<!-- Object-like access -->
        We can also use a plain object way of getting/setting keys, like this:

        // set key
        localStorage.test = 2;

        // get key
        alert( localStorage.test ); // 2

        // remove key
        delete localStorage.test;
        That’s allowed for historical reasons, and mostly works, but generally not recommended, because:

        If the key is user-generated, it can be anything, like length or toString, or another built-in method of localStorage. In that case getItem/setItem work fine, while object-like access fails:

        let key = 'length';
        localStorage[key] = 5; // Error, can't assign length
        There’s a storage event, it triggers when we modify the data. That event does not happen for object-like access. We’ll see that later in this chapter.


        Strings only
            Please note that both key and value must be strings.
            If they were any other type, like a number, or an object, they would get converted to a string automatically:       


# sessionStorage
    Properties and methods are the same, but it’s much more limited:

    The sessionStorage exists only within the current browser tab.
    Another tab with the same page will have a different storage.
    But it is shared between iframes in the same tab (assuming they come from the same origin).
    The data survives page refresh, but not closing/opening the tab.