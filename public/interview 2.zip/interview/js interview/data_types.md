In Javascript,
    we have 7 primitive data types (string, number, bigint, boolean, undefined, symbol, and null).
    These all are immutable meaning that once a value is assigned, we cannot modify them,
    what we can do is reassign it to a different value (different memory pointer).
    
    The other data types such as Object and Function, on the other hand, is mutable meaning we can modify the value in the same memory pointer.

    //Q1
    let text = 'abcde'
    text[1] = 'z'
    console.log(text) //ans: abcde


    String is immutable, so once assigned to a value, you cannot change it to a different value.
    What you can do is reassign it. Remember that changing value and reassigning to another value is different

    weekSet 
        // can store only the object
        // we can't iterate 

    weekMap 
        // can store only the object
        // we can't iterate 

    //Q2
        const arr = [1,2,3]
        arr.length = 0
        console.log(arr) //ans: []

        Assigning arr.length as 0 is the same as resetting or clearing the array, so right now, the array will become an empty array

    //Q3
        const arr = [1,2,3,4]
        arr[100] = undefined
        console.log(arr, arr.length) //ans: [ 1, 2, 3, 4, <96 empty items>, undefined ] 101

        Because an array consumes a contiguous memory location, when we assign the index 100 to a value (including undefined)
        JS will reserve the memory from index 0 to index 100. This means the array length now is 101



<!-- Is JavaScript a pass-by-reference or pass-by-value language? -->
    It's always pass by value, but for objects the value of the variable is a reference
            function changeStuff(a, b, c)
            {
                a = a * 10;
                b.item = "changed";
                c = {item: "changed"};
            }

            var num = 10;
            var obj1 = {item: "unchanged"};
            var obj2 = {item: "unchanged"};

            changeStuff(num, obj1, obj2);

            console.log(num);  // 10
            console.log(obj1.item);  // changed
            console.log(obj2.item);  // unchanged



            function changeObject(x) {
                x = { member: "bar" };
                console.log("in changeObject: " + x.member);
            }

            function changeMember(x) {
                x.member = "bar";
                console.log("in changeMember: " + x.member);
            }

            var x = { member: "foo" };

            console.log("before changeObject: " + x.member);                                // before changeObject: foo
            changeObject(x);                                                                // in changeObject: bar
            console.log("after changeObject: " + x.member); /* change did not persist */    // after changeObject: foo

            console.log("before changeMember: " + x.member);                                // before changeMember: foo
            changeMember(x);                                                                // in changeMember: bar
            console.log("after changeMember: " + x.member); /* change persists */           // after changeMember: bar