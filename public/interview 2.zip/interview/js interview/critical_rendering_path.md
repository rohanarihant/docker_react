Critical Rendering Path

    while rendering our code to browser
    first step is to render the html 
    it will generate the DOM tree of HTml element
    
    css will be the render block task
    it will load all of the css files then render it to the browser

    CSSOM
        only those node which has styles in it can be rendered

    Script tag
        it is parser blocking 
        it will download the 1st file and parse it and keep renndering
        then rest of the file keep on downloading and rendering

    Render Tree
        contains only those elements which are going to be displayed
        e.g :- display:none will not been displayed

        dom tree + css tree = render tree

    Layout
        will calculate the layout space, like width height for screen. desktop and mobile

    Paint
        take the nodes from render tree and screen size form layout and display it to screen

    Reflow
        
