1. strict mode
    using "use strict"
     enable the stricly parsing and catch errors and bugs that go unnoticed

    1, Prevent accidental creation of global variables
    2, Catch typing mistakes in variable names (if misspelled the variable name)
    3, Prevent accidental deleting
    4, Prevent duplicating parameter names in a function
        function test(arg1, arg1) {}
    5, Prevent writing to read-only properties

2. Object freeze / seal/ preventExtensions

                        create      read    update   delete
    freeze              no          yes     no          no
    seal                no          yes     yes         no
    preventExtension    no          yes     yes         yes

3. purpose of Async keyword?
    it is used to declare a func as asynchronous, it will return a promise.
    inside that async func an await keyword is used to paused the execution of the func until promise is resolved.
    this allow us to write a async code that look like a sync code.
