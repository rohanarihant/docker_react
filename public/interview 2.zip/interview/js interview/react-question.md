They have asked me to implement the selecting list. where you select parents level or child level, if check or uncheck parent it should affect all the childs under the same parent.
constraints are optimised code and single state.

optimization and performance of web applications.

Create expandable folder tree with React
Basic array questions and string operations
What is a RESTful API?
Can we use React with angular ?
Virtual DOM and Shadow DOM implementation. How does react reconciliation works?
How to scale a website? Read my detailed post on this where i discuss various methods. How to Scale a website? https://javascriptinterviewquestions.com/2020/04/how-to-scale-website-cdn-load-balancers.html

https://dev.to/devabhijeet/all-front-end-interview-questions-asked-during-my-recent-job-hunt-1kge imp

aria-hidden=true