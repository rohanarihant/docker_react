1. The mystery of this

     this is the context of a function invocation (a.k.a. execution).
     The language has 4 function invocation types:
        *   function invocation: alert('Hello World!')
        *   method invocation: console.log('Hello World!')
        *   constructor invocation: new RegExp('\\d')
        *   indirect invocation: alert.call(undefined, 'Hello World!')

            *   Invocation of a function is executing the code that makes the body of a function, or simply calling the function.
                For example parseInt function invocation is parseInt('15').
            *   Context of an invocation is the value of this within function body.
            *   Scope of a function is the set of variables and functions accessible within a function body.

2.1 this in a function invocation
        function sum(a, b) {
            console.log(this === window); // => true
            this.myNumber = 20; // add 'myNumber' property to global object
            return a + b;
        }
        // sum() is invoked as a function
        // this in sum() is a global object (window)
        sum(15, 16);     // => 31
        window.myNumber; // => 20
    At the time sum(15, 16) is called, JavaScript automatically sets this as the global object (window in a browser).

2.2 this in a function invocation, strict mode
    this is undefined in a function invocation in strict mode

        Once enabled, the strict mode affects the execution context, making this to be undefined in a regular function invocation
        function multiply(a, b) {
            'use strict'; // enable the strict mode
            console.log(this === undefined); // => true
            return a * b;
        }
        // multiply() function invocation with strict mode enabled
        // this in multiply() is undefined
        multiply(2, 5); // => 10

2.3. Pitfall: this in an inner function
    


