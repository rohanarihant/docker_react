# Math.round(x) returns the nearest integer:
    console.log(Math.round(4.9)) // 5
    console.log(Math.round(4.4)) // 4
    console.log(Math.round(4.2)) // 4
    console.log(Math.round(-4.2)) // -4

# Math.ceil(x) returns the value of x rounded up to its nearest integer:

    console.log(Math.ceil(4.9)) // 5
    console.log(Math.ceil(4.4)) // 5
    console.log(Math.ceil(4.2)) // 5
    console.log(Math.ceil(-4.2)) // -4
# Math.floor(x) returns the value of x rounded down to its nearest integer:

    console.log(Math.floor(4.9)) // 4
    console.log(Math.floor(4.4)) // 4
    console.log(Math.floor(4.2)) // 4
    console.log(Math.floor(-4.2)) // -5
# Math.trunc(x) returns the integer part of x:
    console.log(Math.trunc(4.9)) // 4
    console.log(Math.trunc(4.4)) // 4
    console.log(Math.trunc(4.2)) // 4
    console.log(Math.trunc(-4.2)) // -4