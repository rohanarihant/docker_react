

* Everything in js happens inside an Execution context
* JS is synchronous single threaded language


**EXECUTION CONTEXT**
    
    (var env)
    Memory         |      Code (thread of execution)

    key:value      |      run code line by line
    a:10           |


EC is created in 2 phases
    1. memory creation phase :- js will allocate memory to all vars and func, it will define undefined to it.
                                in case of func, it will stores the whole code of func in tempemory space.
    2. code execution phase :- run the whole js program line by line. 
            square() will indicate that we need to invoke the func and new EC is created.
        return keyword states that return the control to the place where this func was invoked.
        the whole EC is deleted.

    once the all the js code finished executed the global EC will be deletes, goesoff

* function square(num){ // parameter
    return num*num;
}
const n=4;
square(n) // argument


* Call Stack maintains the order of E of EC.
    call stack is known as 
        call stack
        Execution context stack
        program stack
        control stack
        runtime stack
        machine stack

**Variables/Hoisting** 

1. 
    var x = 7;
    function getName(){
        console.log("Namaste JS");
    }

    getName(); // Namaste JS
    console.log(x); // 7

2.  
    getName(); // Namaste JS
    console.log(x); // undefind

    var x = 7;
    function getName(){
        console.log("Namaste JS");
    }




**Functions**

    whenever EC is created this is also created even for functional and global EC.
    global level this refers to global EC.

    global space : any code written in js. which is not in functions
            whenever we are trying to access anything console.log(a), it will try to access that in the global space.
            this also refer to the window object in js, not in functions


**Undefind and Null**

    undefined :- is like a placeholder for the time being until the var is assigned some other value. till that time it will store this placeholder known as undefind.
        memory is allocated to any var but value is not assigned
        variable is declared but not assigned any value

    not defined :- memory is not allocated to the variable. if we try to access then return Ref not defined error.
                   undefined means a variable has been declared but has not yet been assigned a value :


    null :- means no value. null is an actual value
            null is an assignment value. It can be assigned to a variable as a representation of no value :

**Scope & Scope Chain & Lexical Environment**
    Scope :- where we can access a specific variable or a function.
    Lexical Env :- whenever an EC is created a Lexical Env is also created. LE is the local memory and also the LE of its parent.
    Lexical : means in hierarchy or in a sequence.
            e.g this c func is lexical inside a func.
            where that specific code is present physically.

    function a(){
        var b = 10;
        c();
        function c(){
            console.log(b)
        }
    }

    a();
    console.log(b);

    for function (c) LE points to LE of a, then for (a) LE points to global, for global LE is null.

    Scope Chain :- 
        chain of all the LE and parent references


**Let Var Const & Temporal Dead zone**

    let/const 
        at the time of memory allocation phase they are allocated memory in a diff memory space not on Global.
        you can't access those let and const before putting some value into it
        this is called HOISTING in let/const.


    Temporal Dead zone
        its a time since when let/const is hoisted and till value is iniitialized to it.
        the time between that is the temporal dead zone.

        whenever we try to get any variable from temporal dead zone. it gives us a Ref error.
        const can be declare and initialize at the same time.


**Block scoped and shadowing**

    block -> compond statement
        it is the place where we can group multiple statement where js expect one statement.

        let and const are declared in the block scope.

        let b=100;
        {
            let b = 10;
            console.log(b) // 10
        } // will be in the Block scope under EC
        console.log(b) // 100 // will be in the script scope under EC


        let a = 20;
        {
            var a = 10; //  SyntaxError: Identifier 'a' has already been declared
        }
        // this is called inleggal shadowing

        you can shadow let using let but not using let using var


**Clousers**

    Function along with its LS bundle together a clousers.
    that func will remember the refernce of the variables not value.

    when functions got returned then it will know its lexical scope. where it was defined
    function will be returned along with its lexical scope
    so that it will be called along with the LE declared variables


    function x(){
        var a = 7;
        function y(){
            console.log(a);
        }
        return y;
    }
    var z = x();
    console.log(z);
    z();

    

**Functions**

    # function statement
        function a(){
            console.log("a called");
        }
    
    # function Expression
        var b = function(){
            console.log("b called");
        } 

            major diff between these 2 is hoisting


    # named func expression
        var b = function xyz(){
            console.log("named func exp");
        }
        b();

    # First class function / First class citizen
        ability to used as value.
        the ability to use function as values and can be passed in as an argument to another function, can be returned from tthe functions. this ability is known as FIrst class function

        var b = function xyz(){
            return function(){

            }
        }
        console.log(b());

    # Callback Function
        a function that is passed to another func and called back sometime later is called cb.

            function x(y){

            }

            x(function y(){

            })