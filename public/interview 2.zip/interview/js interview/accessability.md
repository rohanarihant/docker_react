

all buttons should be in the sequence
and good to have outline style

always prefer to use semantic elements

if no sematic element there then can use tabIndex="0" 
    <div tabIndex="0">Button</div>
    The tabindex attribute specifies the tab order of an element (when the "tab" button is used for navigating).
    e.g :-
        <div tabindex="1">W3Schools</div><br>
        <div tabindex="3">Google</div><br>
        <div tabindex="2">Microsoft</div>

aria labels
    to add the aria labels
    which can be listen on voice over