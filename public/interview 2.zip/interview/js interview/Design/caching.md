
**Cache**
    A cache is like short-term memory which has a limited amount of space. It is typically faster than the original data source.

    Caching consists of :- 
        1. precalculating results (e.g. the number of visits from each referring domain for the previous day)
        2. pre-generating expensive indexes (e.g. suggested stories based on a user’s click history)
        3. storing copies of frequently accessed data in a faster backend (e.g. Memcache instead of PostgreSQL.

