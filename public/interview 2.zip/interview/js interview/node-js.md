Timer

setTimeout(()=>console.log("hello"));
setImmediate(()=>console.log("hi"));
process.nextTick(()=>console.log("Rohan"));
