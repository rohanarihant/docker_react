Design :- design tinyurl, spreadsheet
Whiteboard a drone delivery program
design linkedin chat, design linkedin search auto complete....Also they ask about accessibility