Find the right max for every element in an array
Sorting a large data which contains the age of students
Binary Tree TopView
Add Two LL
Check LL is Palindrome
Find an error in BST
Loop in LL
Valid Parenthesis , let, var and const
statefull and stateless components in React
What is context in React?
How did you use Authorization and Authentication in Angular?
Basic Redux questions?
Questions about minification and bundling
Write an algorithm that schedules drone deliveries

Focused on hash tables, trees and graph
Binary search on sorted array.
Kth largest element in an unsorted array.
General discussion.
https://leetcode.com/problems/sort-colors/
https://leetcode.com/discuss/interview-question/3382985/Walmart-Coding-round
https://leetcode.com/discuss/interview-question/1269682/Walmart-string-conversion.
https://leetcode.com/problems/climbing-stairs/
https://leetcode.com/problems/rotting-oranges/
https://leetcode.com/discuss/interview-question/2896001/Walmart-Question

data structures for implementing dictionary and time complexity in each case

1. Find Maximum sum in an array such that no 2 elements are adjacent. In this, 1 more condition was also there that first and last elements should also not be taken together. This question was modification of this.  https://www.geeksforgeeks.org/problems/stickler-theif-1587115621/1

2. In a cartesian plane, there are N tanks and M objects placed. Tanks can fire in 4 directions (N, S, E, W). Position of tanks and objects are given as input and are fixed. We have to find a way to give directions to N tanks such that they will not hit any object and any other tanks. If a tank can fire in 2 directions, then a direction whose ASCII code is lesser will be given preference. Example:- 
Input:- 
N=2 
M=3 

Position of tanks 
(0,0) 
(1,1) 

Position of Objects 
(0,2) 
(0,-2) 
(-2,0) 

Direction of N tanks should be:- 
(0,0) E -> This tank should fire in east direction 
(1,1) E -> This tank can fire in all 4 directions. Since E has least ASCII code in all 4 of them, so E 

k largest elements in an array 

1. Design a data structure which provides the following APIs:- 
a. insert element in O(1) 
b. delete an element in O(1) 
c. find a random element in O(1) 
2. Some questions on Java basics. 
3. Some discussion on projects done in current job. 
4. Got 1 feedback that my knowledge of Java is not so good. So, if we hire you, then what will be your strategy to improve on your Java skills. 


https://leetcode.com/problems/fizz-buzz/
https://leetcode.com/problems/the-skyline-problem/
https://leetcode.com/problems/longest-palindromic-substring/

Find the two numbers from an array whose sum is equal to a given target number.
Find the kth smallest element in a given unsorted array.
Find the single occurring element in an array, in which all other elements are occurring twice.
Find the kth element in a list.
Reverse a string without altering the position of any special characters present in the string.
Reverse a linked list.
Merge two arrays without using extra space.
Make a triangle using HTML and CSS.
Create a memorized function.
Implement merge sort.
Implement a reservation algorithm.
What is the complexity of enqueue and dequeue operation in a queue?


Explain the time complexity of a binary search algorithm?
Describe the difference between a stack and a queue, and when you might use one over the other?
How would you implement a linked list in your preferred programming language?
Explain the difference between merge sort and quicksort, and when you might use one over the other?
How would you go about finding the middle node of a linked list?
Explain the difference between HTML and XHTML?
How would you optimize a website's load time?
Describe the box model in CSS and how it affects layout?
How would you implement a responsive design on a website?
Explain how you would use React to build a dynamic user interface?
