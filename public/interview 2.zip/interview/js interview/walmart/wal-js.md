https://javascriptinterviewquestions.com/2020/04/add123-in-javascript-currying-interview.html
How does closures work in Javacript? Closure based output questions.
Drawing shapes in CSS using box modal? You can approach this by using borders to create shapes like triangle etc.
Inheritance in Javascript and how to implement it in ES5? 
Scope based questions(value of “this” under certain conditions) etc.
