#. REST Api 

    FUndamental concepts 
        Resources :- 
            each resource has a unique identifier called URI that identifies it.
            using methods to access the resource and update delete it
            allows client to filter, pagination and sort it.
            it will return the full data resource
    Principles of Rest API
    1. Client-Server decoupling
        In a REST API design, client and server programs must be independent.
        The client software should only know the URI of the requested resource.
        it should have no additional interaction with the server application. 

    2. Uniform Interface
        All API queries for the same resource should look the same regardless of where they come from.
        The REST API should ensure that similar data, such as a user's name or email address,
        is assigned to just one uniform resource identifier (URI).

    3. Statelessness
        REST APIs are stateless, meaning each request must contain all the information needed to process it.


    * put / post / patch
    put :- update the existing resource, it will replace the entire resource with the new resource.
    post:- create a new resource
    patch:- only alter the data that is specified.

    * payload in context of the REST API
        payload refers to data that is transfered through the REST Api
    * what is REST message
        the concept of messaging refers to the back and fourth comm via req and res by client and server.
        there's a typically a message within every response body assiciated with the provided status code.
        this is most imp part of debugging, testing the rest apis.
        including the confirmation of the req or the exception raised.
    * core component of HTTP req?
        method, URI (used to identify the resource typically using a URL), http version, req header, req body
    * core component of HTTP res ?
        status code, http version, response header, response body
    * what is idempotent and safe HTTP methods?
        idempotent :- can be called multiple time without changing the resources. (GET, HEAD, PUT, DELETE, OPTIONS, and TRACE)
        safe method :-  will not change the resource, it may read but not write (GET method)
    * explain caching in restfull arch
        each rest api contains the metadata related to the request and res
        the header of cache-control and expires specify what responses may be cached by whom and how long

    * how REST api stateless
        REST ARCH REQUIRE CLIENT STATE IS NOT STORED ON THE SERVER.
        statefullness :- an app api or web service is considered statful stores data from the clients on its own servers.
                e.g :- a username and pass from the client to server as a form of authentication and server stores the data then web server is stateful. server is now storing the data from the client.
        statelesness :- each req must contain the necessary info for that perticular HTTP method. so that are stateless.
    * URI
        uniform resource identifier
        it identifies every resource in the rest arch
        can be one of the two types.
            URN :- which identifies a resource through a unique and persistent name like a book ISBN
            URL :- a typical for web address.
    * best practices for URIs
        forward slashes indicate hierarchy
        use plural noun for branches
        use hiephens for multiple words
        use lowercase
        refrain from using file exttensions
    




# GraphQL

    terminology
        Schema :- it is a blueprint that defines all possible data that client can query through the service
        Query :- is a request for data that follow the structure defined in the schema
        Resolver :- is called to retrive the data requested in query. it involve the requesting of data from multiple sources and assembled it into the responses that matches the query sttructure.
        Mutations: job is to modify data on the server. thinking in a CRUD mode. the query that would be equivalent to read in CRUD

# SOAP
    simple object access protocol
        servers as a protocol for exchaging structural info by web apis
        soap standards are strict inn their implementation and statefulness often means that he client and server are closer connected

