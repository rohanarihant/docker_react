# 
console.log(1);

setTimeout(function () {
  console.log(2);
}, 0);

Promise.resolve()
  .then(function () {
    console.log(3);
  })
  .then(function () {
    console.log(4);
  });

// 1
3
4
2

#
console.log("begins");

setTimeout(() => {
  console.log("setTimeout 1");
  Promise.resolve().then(() => {
    console.log("promise 1");
  });
}, 0);

new Promise(function (resolve, reject) {
  console.log("promise 2");
  setTimeout(function () {
    console.log("setTimeout 2");
    resolve("resolve 1");
  }, 0);
}).then((res) => {
  console.log("dot then 1");
  setTimeout(() => {
    console.log(res);
  }, 0);
});

begins
VM76:11 promise 2
VM76:4 setTimeout 1
VM76:6 promise 1
VM76:13 setTimeout 2
VM76:17 dot then 1
VM76:19 resolve 1


#
async function async1() {
  console.log("async1 start");
  await async2();
  console.log("async1 end");
}

async function async2() {
  console.log("async2");
}

console.log("script start");

setTimeout(function () {
  console.log("setTimeout");
}, 0);

async1();

new Promise(function (resolve) {
  console.log("promise1");
  resolve();
}).then(function () {
  console.log("promise2");
});

console.log("script end");


script start
VM80:2 async1 start
VM80:8 async2
VM80:20 promise1
VM80:26 script end
VM80:4 async1 end
VM80:23 promise2
VM80:14 setTimeout

exp :- When the program is executed, it will first print script start, then setTimeout will be put into the macrotask queue, then call the async1 function, print async1 start, and then call await async2 () so async2 will be printed.

await will put things into the microtasks queue, so instead of printing async1 end immediately it will be put into the microtasks queue first.

Then the program continues to execute. When encountering new Promise, it first prints the promise 1 inside, then calls resolve, and puts .then into the microtasks queue. Program execution continues, printing script end.

Now, the execution stack is empty, so it will check the microtasks queue and print async1 end first. Since the microtasks queue will be executed all the way until there is nothing, the event loop will continue to check the microtasks queue. Then it finds that there is a resolve in it , so print promise2. At this time, the queue of microtasks is empty, it goes to the queue of macrotasks. There is a setTimeout in the macrotasks queue, so it is printed out.
