display
position
bootstrap
col-
grid layout
flexbox
center div
canvas/svg
designn Patterns
forward ref
hooks
life cycle methods
performance
redux implementation
currying
promises
async await
// swapping 2 var without temp var
diff async and setTimeout
How do you modularize your CSS files?
//What is the advantage of using constructor functions?
Oops
// How to optimize website assets loading?
In how many ways can we position an HTML element? Or what are the permissible values of the position attribute?
// What are the New tags in Media Elements in HTML5?
// Difference between reset vs normalize CSS?. How do they differ?
//What is a z-index, how does it function?
/Explain a use case for Docker?
// What is the Difference Between “Git Pull” and “Git Fetch”? git pull = git fetch + git merge
// rem, em

// Q1 DOM manipulation test expect data from api call and you need render content using dynamic DOM element creation.
Q2 Nested Promise call or call all Promises and filter the data based on call response.

event bubbling, captturing, examples
vanilla JS DOM APIs
how to schedule events ??



critical  rendering path
compose
clousers questions
var, let const questions
pure functions
this questions
arrow vs normal function

ssg/ssr/spa
virtual dom 
recoincilation
what is fiber?
prottotypical inheritence  questions
promise vs async await o/p questions
coercion

set state is mutable or immutable

weekset weekMap
map vs obj
map and set
promises vs async await
 ChangeEvent, FocusEvent



plan
    spirent JD

typescript


performance
    https://github.com/h5bp/Front-end-Developer-Interview-Questions/blob/main/src/questions/performance-questions.md

DSA
    https://medium.com/@koheiarai94/60-leetcode-questions-to-prepare-for-coding-interview-8abbb6af589e


variable, mixin
sass
positions
grid 
centerly aligned 3 layout
line straigt
section, aside
new apis of html
bookmark in html
line-height



compound indexing

Compound indexes collect and sort data from two or more fields in each document in a collection. Data is grouped by the first field in the index and then by each subsequent field.

For example, the following image shows a compound index where documents are first grouped by userid in ascending order (alphabetically). Then, the scores for each userid are sorted in descending order:

Indexing commonly queried fields increases the likelihood of covered queries. A covered query is a query that can be satisfied entirely using an index and does not have to examine any documents, leading to greatly improved performance.

If your application repeatedly runs a query that contains multiple fields, you can create a compound index to improve performance for that query. For example, a grocery store manager often needs to look up inventory items by name and quantity to determine which items are low stock. You can create a compound index on both the item and quantity fields to improve query performance.

A compound index on commonly queried fields increases the chances of covering those queries. Covered queries are queries that can be satisfied entirely using an index, without examining any documents. This optimizes query performance.

multi key indexing
tsconfig
can we index array keys
abstract class // 
declare keyword
interface in ts
define default values in ts
use js module in ts file
arrow function
how node.js will handle 10k requests
why use node.js over spring boot



function Person() {
    this.name = 'Jack',
    this.age = 25,
    this.sayHello = function () {
      console.log('Hello', this.name);
      function innerFunction() {
        console.log(this.age);
      }
		  innerFunction(); 
	   }
	}
	let x = new Person();
	x.sayHello.call(Person);



// 1 resolve -> p1
// 1 resolve -> p2
// 1 resolve -> p3

// const p1 = new Promise((resolve, reject) => {
//   resolve("p1 promise resolved");
// }); // 2 sec US
// const p2 = new Promise((resolve, reject) => {
//   resolve("p2 promise resolve");
// }); // 4 sec IN
// const p3 = new Promise((resolve, reject) => {
//   resolve("p3 promise resolve");
// }) // 6sec GER

// 2 + 4 + 6 = 12sec
// 6 sec

// Promise.all([p1,p2,p3]).then((data) => console.log(data))

function canYouSpotTheProblem() {
  "use strict";
  for (var counter = 0; counter < 10; counter++) {
    console.log("Happy happy");
  }
}

canYouSpotTheProblem();


// views in mongo
// increase the query operation
// thing to take care while designing schema
// handle the req after req returned from handler
// 
