Prototype

    whenever we create an object. js will automatically push the hidden properties into an object and attaches it to your object

    to access those hidden objects we can use __ptoto__
    here js will put all these methods

    let arr = ["a","b"]
    arr.__proto__.__proto__ = Object.prototype

    arr.__proto__.__proto__.__proto__
        array       object      null
        prototype   prototype


let obj = {
    name: "Rohan",
    city: "Rajpura"
}

let obj2 = {
    name: "sonia"
}
obj2.__proto__ = obj;

obj2.__proto__ // { name: "Rohan", city: "Rajpura" }

obj2.name // sonia
obj2.city // rajpura

this is called shadowing


<!-- Question 1 -->
const x = {};
x.__proto__.h1 = 10;
console.log(x.h1); // 10

Object.prototype.h1 = ++x.h1;

console.log(x.h1) // 11
console.log(x.h1+ Object.keys(x).length) //12