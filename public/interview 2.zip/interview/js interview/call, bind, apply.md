Call Bind Apply 
    are available to all JS functions
    used to set the this keyword independent of how function is called.
    you can use these func to tie a func to obj and call the func as if it belong to that object.


    let car1 = {
        color: "Red",
        company: "Ferrari"
    }

    function purchaseCar(){
        console.log(`I have purchased ${this.color} - ${this.company}`);
    }

    purchaseCar.call(car1);
    purchaseCar.apply(car1);
    purchaseCar.bind(car1);


    Call

        var obj = { name: "Piyush"};
        function sayHello(age){
            return "Hello"+this.name+age;
        }

        console.log(sayHello()); // Hello undefined 
                            // this will point to window obj and name is not there

            here sayHello is pointing the this to obj. but we can use call to call the sayHello method inside the obj

        console.log(sayHello.call(obj, 24)); // Hello Piyush24


    Apply 
        works the same way as Call but it will accept array of args

        var obj = { name: "Piyush"};
        function sayHello(age){
            return "Hello"+this.name+age;
        }

        console.log(sayHello.apply(obj, [23])); // Hello Piyush23   

    Bind
        instead of calling the method strateaway. it will provide the binded function. 
        which we can call later.

        var obj = { name: "Piyush"};
        function sayHello(age){
            return "Hello"+this.name+age;
        }

        const bindFunc = sayHello.bind(obj);

        console.log(bindFunc(24)); // Hello Piyush24



    Questions 4:

        const person = {name: "Piyush"}

        function sayHello(age){
            return `${this.name} is ${age}`;
        }

        console.log(sayHello.call(person, 24)); // Piyush is 24
        console.log(sayHello.bind(person, 24)); // return a function


    Question 5:
        const age = 10;
        var person = {
            name: "Piyush",
            age: 20,
            getAge: function(){
                return this.age;
            }
        };

        var person2 = {age:24};
        person.getAge.call(person2); // 24
                                                                        var age = 10;
                                                                        var person = {
                                                                            name: "Piyush",
                                                                            age: 20,
                                                                            getAge: function(){
                                                                                return this.age;
                                                                            }
                                                                        };
                                                                        console.log(person.getAge(),"person local") // 20
                                                                        var person2 = {age:24};
                                                                        console.log(person.getAge.call(person2),'person2') // 24
                                                                        var Person1 = {
                                                                            name: "Piyush",
                                                                            age: 20,
                                                                            getAge: () => {
                                                                                return this.age;
                                                                            }
                                                                        };
                                                                        
                                                                        console.log(Person1.getAge(),"global"); // 10

    Question 6:
        var status = "happy";

        setTimeout(() => {
            const status = "very happy";

            const data = {
                status: "name",
                getStatus(){
                    return this.status;
                }
            }

            console.log(data.getStatus()) // name
            console.log(data.getStatus.call(this)); //happy
        },0)

    Question 7:
        const animals = [
            {species: "Lion", name:"King"},
            {species: "Whale", name:"Queen"},
        ]

        function printAnimals(i){
            this.print = function(){
                console.log("#"+i+" "+this.species+": "+this.name);
            };
            this.print();
        }
        for(let i=0;i<animals.length;i++){
            printAnimals.call(animals[i],i);
        }

        <!-- #0 Lion: King
        #1 Whale: Queen -->


    Question 8:
        const array = ["a","b"];
        const elements = [0,1,2];

        array.push.apply(array,elements);
        console.log(array); // ['a', 'b', 0, 1, 2]

        <!-- #0 Lion: King
VM697:8 #1 Whale: Queen -->

    Question 9:
        const numbers = [5,6,7,2,3,4];

        console.log(Math.max.apply(null,numbers)) // 7

    Question 10:
        function f(){
            console.log(this);
        }

        let user = {
            g: f.bind(null),
        }

        user.g(); // window

    Question 11:
        function f(){
            console.log(this.name);
        }

        f = f.bind({name: "John"}).bind({name: "Ann"}); // bind chaining doesn't work
        f(); // john

    Question 12:
        function checkPassword(success, failed){
            let password = prompt("Password?", "");
            if(password == "Rohan") success();
            else failed();
        }

        let user = {
            name: "ROhanArihant",
            loginSuccessful(){
                console.log(`${this.name} logged in`);
            },
            loggedFailed(){
                console.log(`${this.name} failed to log in`);
            }
        };

        checkPassword.call(user, user.loginSuccessful.bind(user), user.loggedFailed.bind(user));

    Question 13:

        funtion checkPassword(ok, fail){
            let password = prompt("Password?","");
            if(password === "Rohan") ok();
            else fail();
        }

        let user = {
            name: "Piyush Agarwal",
            login(result){
                console.log(this.name+(result? "login successful"+"login failed"));
            },
        }

    checkPassword();
    // solution   checkPassword(user.login.bind(user, true), user.login.bind(user, false));

    Question 14:
        const age = 10;
        var person = {
            name: "Piyush",
            age: 20,
            getAgeArrow: () => console.log(this.age),
            getAge: function(){
                console.log(this.age);
            }
        }

        var person2 = {age:24};
        person.getAgeArrow.call(person2); // udefined // we can't manupulate the context of the arrow function by call, apply, bind
        person.getAge.call(person2); // 24


**Plyfill**

call :- 

    let car1 = {
        color: "Red",
        company: "Ferrari"
    };

    function purchaseCar(currency, price){
        console.log(`I have purchased ${this.color} - ${this.company} car for ${currency}${price}`);
    }

    Function.prototype.myCall = function(context = {}, ...args){
        if(typeof this !== 'function'){
            throw new Error(this+ "is not callable")
        }
        context.fn = this;
        context.fn(...args);
    }

    purchaseCar.myCall(car1, "Rupee", "10000");

Apply:- 
   Function.prototype.myApply = function(context = {}, args){
        if(typeof this !== "function"){
            throw new Error(this+ "is not callable");
        }
        if(!Array.isArray(args)){
            throw new TypeError("CreateListFromArrayLike called on non-object");
        }
        context.fn = this;
        context.fn(...args);
    }
 purchaseCar.myApply(car1, ["Rupee", "10000"]);

 Bind :- 
    let obj = {
        name: 'Jack',
    };

    let myFunc = function (id, city) {
    console.log(`${this.name}, ${id}, ${city}`);  // id will be undefined
    };

    // Accepting any number of arguments passed to myBind
    Function.prototype.myBind = function (obj, ...args) {
        let func = this;
        // Accepting arguments passed to newFunc
        return function (...newArgs) {
            func.apply(obj, [...args, ...newArgs]);
        };
    };

    let newFunc = myFunc.myBind(obj, 'a_random_id')
    newFunc('New York') // Jack, a_random_id, New York
