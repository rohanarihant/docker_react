<!-- Event Deligation -->
<!-- without adding event listener to each specific list item we can just add it to parent elem and using it to click other list items -->

    document.querySelector("#product").addEventListener("click",(event) => {
        console.log(event);
        if(event.target.tagName === "LI"){
            window.location.href += "#"+event.target.id
        }
    })

    // event.target.tagName
    // event.target.closest("SPAN");


<!-- Event Propagation -->
    the complete process of when and in which direction the event will be executed is called eventPropagation


<!-- Event bubbling -->
    event will be fired from bottom to up.
    there  are some event which don't bubble like focus and blurr


// Question 3 :- 
    event.target vs this.target vs event.currentTarget
    by default event bublling will happen

    const div  = document.querySelector("div");
    const form  = document.querySelector("form");
    const button  = document.querySelector("button");

    div.addEventListener("click",  function(){
        alert("div");
    })
    form.addEventListener("click",  function(){
        alert("form");
    })
    button.addEventListener("click",  function(){
        alert("button");
    })

    // event.currentTarget.tagName // button, form, div
    // event.target.tagName // button, button, button
    // this.tagName // button, form, div

// Question 4 :-  
    what is event capturing / trickling

    event flow will be top to bottom


    div.addEventListener("click",  function(){
        alert("div");
    }, { capture: true })
    form.addEventListener("click",  function(){
        alert("form");
    }, { capture: true })
    button.addEventListener("click",  function(){
        alert("button");
    }, { capture: true })

// Question 5 :-  
    how to stop event bubbling or capturing

    div.addEventListener("click",  function(e){
        e.stopPropagation();
        alert("div");
    })
    form.addEventListener("click",  function(e){
        e.stopPropagation();
        alert("form");
    })
    button.addEventListener("click",  function(e){
        e.stopPropagation();
        alert("button");
    })

<!-- Event.preventDefault() vs. return false -->

    In Jquery
        e.preventDefault() will prevent the default event from occuring
        e.stopPropagation() will prevent the event from bubbling up

        return false will do both
        


1. event.preventDefault()
    Preventing a <form> from reloading the page when clicking a submit button.
    Preventing an <a> link from navigating to a URL.
    Preventing checkbox state toggles or page scrolling.

    Method     Stops Default Browser Actions?     Stops Event Bubbling/Capturing?      Stops Other Handlers on Same Element?
    event.preventDefault()          Yes                     NO                              NO
    event.stopPropagation()         NO                      YES                             NO
    event.stopImmediatePropagation()    NO                  YES                             YES