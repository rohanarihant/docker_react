// 1
    // function fruit(){
    //     name ="namee";
    //     console.log(name); // namee
    //     console.log(price);
    //     var name = "rohan";
    //     let price = 0; // Error ReferenceError: Cannot access 'price' before initialization
    // }
    // fruit();


// 2

    // for(var i=0;i<5;i++){
    //     setTimeout(() => {console.log(i)},0);
    // }
    // for(let i=0;i<5;i++){
    //     setTimeout(() => {console.log(i)},0);
    // }
    // for(var i=0;i<5;i++){
    //     ((new_i) => {
    //         setTimeout(() => {console.log(new_i)},0);
    //     })(i)
    // }

// 3 

    // console.warn(+"true"); //1
    // console.warn(typeof +true); // number

// 4
    // console.warn(!"true"); // false
    // console.warn(typeof("true")); //string

// 5
    // let data = "size";
    // const bird = {
    //     size: "small"
    // }
    // console.warn(bird[data]);  // small
    // console.warn(bird["size"]);  // small
    // console.warn(bird.size);   // small
    // console.warn(bird.data);  // undefined

// 6
    // let c = {name: "peter"};
    // let d;

    // d = c;
    // c.name="anil";
    // console.log(d.name); // anil

// 7 
    // var x;
    // var x = 10;
    // console.log(x) // 10

// 8
    // var x;
    // let x = 10;
    // console.log(x); // SyntaxError: Identifier 'x' has already been declared

// 9
    // const a = {};
    // const b = { key: "b"};
    // const c = { key: "c"};

    // a[b] = 123;  // a["[object object]"] = 123; when we try to convert object to string forcefully it converted to [object object]
    // a[c] = 456;

    // console.log(a[b]); //456

// 10
    // console.log([..."string"]) // spread the each character of the string into the array

// 11
    // const user = {name: "Lydia", age:21}
    // const admin = {admin: true,name: "Rohan", ...user}

    // console.log(admin); {admin: true, name: 'Lydia', age: 21}

// 12
    // const settings = {
    //     username: "rohan",
    //     level: 19,
    //     health: 90
    // }
 
    // const data = JSON.stringify(settings, ["level", "health"]); // will ignore the username property here
    // console.log(data); {"level":19,"health":90}

// 13
    // const shape = {
    //     radius: 10,
    //     diameter(){
    //         return this.radius * 2;
    //     },
    //     parameter: () => 2 * Math.PI * this.radius,
    // };
 
    // console.log(shape.diameter())  // 20
    // console.log(shape.parameter())  // NaN

// 14
    // console.log({a:1} == {a:1}); false
    // console.log({a:1} === {a:1}); false

// 15 
    // let person = {name: "Lydia"};
    // const member = [person]; // saving the reference
    // person = null; // assigned the null to person but member still point to person memory location

    // console.log(member); // [{name: "Lydia"}]
    // member[0]; {name: 'Lydia'}

    
// 16
    // const value = { number: 10};
    // const multiply = (x = {...value}) => {
    //     console.log((x.number *= 2));
    // }

    // multiply(); // 20
    // multiply();// 20
    // multiply(value);// 20
    // multiply(value);// 40

// 17

    // function changeAgeAndReference(person){
    //     person.age = 25;
    //     person = {
    //         name: "John",
    //         age: 50
    //     };

    //     return person;
    // }

    // const personObj1 = {
    //     name: "Alex",
    //     age: 30
    // }

    // const personObj2 = changeAgeAndReference(personObj1); // passing the direct obj and overrideing the age 

    // console.log(personObj1); // {name: 'Alex', age: 25} 
    // console.log(personObj2); // {name: 'John', age: 50}

// 18 
    // shallow copy :- one obj hold the ref to another obj. this is called a shallow copy.
    // Deep copy :- completely cloned a obj to another obj is called deep copy.