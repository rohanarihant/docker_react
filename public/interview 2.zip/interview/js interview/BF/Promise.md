<!-- 1. Promise order -->
    console.log(1) // sync JS

    // promise run constructor function
    // because here resolve is NOT async, then still in sequence to run
    const promise = new Promise((resolve) => {
    console.log(2) 
    resolve() // only mark the promise's internal state to be "Fulfilled"
    console.log(3) // still run to the end of this callback function
    })

    console.log(4) // continue to run sequentially

    // Async: Job Queue for promise
    promise.then(() => {
    console.log(5) 
    }).then(() => {
    console.log(6) 
    })

    // Sync: should be run immediately compared to ASYNC
    console.log(7) 

    // Async: event loop & callback queue for Web API
    setTimeout(() => {
    console.log(8) 
    }, 10)

    // Async: event loop & callback queue for Web API
    setTimeout(() => {
    console.log(9) 
    }, 0) // even though time is 0, still an ASYNC Call

    Output :- 
    1
    2
    3
    4
    7
    5
    6
    9
    8
    
<!-- 2. Promise can settle only once -->

    new Promise((resolve, reject) => {
        resolve(1)
        resolve(2)
        reject('error')
    }).then((value) => {
        console.log(value)
    }, (error) => {
        console.log('error')
    })

    // 1
    // When a promise gets settled (resolved or rejected) additional calls to resolve() or reject() will not have any effect.

<!-- 3. Promise then callbacks -->

    Promise.resolve(1) // 1
    .then(() => 2) // 2 (as 1 isn't used)
    .then(3) // skip
    .then((value) => value * 3) // 2 * 3 == 6
    .then(Promise.resolve(4)) // creates a Pending promise
    .then(console.log) // funnels 6 into console.log

<!-- 4. Promise then callbacks II -->

    Promise.resolve(1)
    .then((val) => {
        console.log(val) // 1
        return val + 1 // chains 2
    })
    .then((val) => {
        console.log(val) // 2
        // chains undefined implicitly
    })
    .then((val) => {
        console.log(val) // undefined
        return Promise.resolve(3)
            .then((val) => {
            console.log(val) // 3
        }) // value undefined is return
    })
    .then((val) => {
        console.log(val) // undefined
        return Promise.reject(4) // 4 is returned
    })
    .catch((val) => {
        console.log(val) // 4
    })
    .finally((val) => { // finally callback doesn't receive any argument, val will always be undefined
        console.log(val) // undefined
        return 10 // since finally is already called, passing 10 makes no difference
    })
    .then((val) => {
        console.log(val) // undefined as finally has already been called
    })

<!-- Comparison of Promises -->

    We know that for object comparisons to be true, the object reference should be same. Here, all the variables p1,p2,p3,p4,p5 store the Promise object, and their comparisons should return false as references are different.

    However, the case of p1 == p3 is true because of how Promise.resolve() works.

    Promise.resolve() returns a Promise object that is resolved with a given value. If the value is a promise, that promise is returned; otherwise, the returned promise will be fulfilled with the value.

    Since we are passing p1 as an argument to p3, the same promise object gets returned and hence the reference is also the same.

    const p1 = Promise.resolve(1)
    const p2 = new Promise((resolve) => resolve(p1))
    const p3 = Promise.resolve(p1)
    const p4 = p2.then(() => new Promise((resolve) => resolve(p3)))
    const p5 = p4.then(() => p4)

    console.log(p1 == p2) // false
    console.log(p1 == p3) // true
    console.log(p3 == p4) // false
    console.log(p4 == p5) // false

<!-- 23. Promise.all() -->
    (async () => {
    await Promise.all([]).then((value) => {
        console.log(value) // []
    }, (error) => {
        console.log(error)
    })
    
    await Promise.all([1,2,Promise.resolve(3), Promise.resolve(4)]).then((value) => {
        console.log(value) // [1,2,3,4]
    }, (error) => {
        console.log(error)
    })
    
    await Promise.all([1,2,Promise.resolve(3), Promise.reject('error')]).then((value) => {
        console.log(value)
    }, (error) => {
        console.log(error) // error
    })
    })()

<!-- Promise.prototype.finally() -->
    Promise.resolve(1)
    .finally((data) => {
        console.log(data) // undefined
        return Promise.reject('error')
    })
    .catch((error) => {
        console.log(error) // error
        throw 'error2'
    })
    .finally((data) => {
        console.log(data) // undefined
        return Promise.resolve(2).then(console.log)
    })
    .then(console.log) // 2
    .catch(console.log) // error2

<!-- 47. Promise Order II -->
console.log(1) // 1️⃣ 

setTimeout(() => {
  console.log(2) // 1️⃣1️⃣
}, 10)

setTimeout(() => {
  console.log(3) // 1️⃣0️⃣
}, 0);

new Promise((_, reject) => {
  console.log(4) // 2️⃣
  reject(5)
  console.log(6) // 3️⃣
})
.then(() => console.log(7))
.catch(() => console.log(8)) // 5️⃣
.then(() => console.log(9)) // 6️⃣
.catch(() => console.log(10))
.then(() => console.log(11)) // 7️⃣
.then(console.log) // 8️⃣
.finally(() => console.log(12)) // 9️⃣

console.log(13) // 4️⃣

<!--  -->
const promise1 = Promise.resolve(1)
const promise2 = Promise.resolve(2)
const promise3 = Promise.resolve(3)
const promise4 = Promise.reject(4)

const promiseAll = async () => {
  const group1 = await Promise.all([promise1, promise2])
  const group2 = await Promise.all([promise3, promise4])
  return [group1, group2]
}

promiseAll().then(console.log).catch(console.log) // 4

<!--  -->
function func() {
  try {
    console.log(1)
    return 
  } catch (e) {
    console.log(2)
  } finally {
    console.log(3)
  }
  console.log(4)
}

func() // 1,3