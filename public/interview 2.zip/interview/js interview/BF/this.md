# This

<!-- 1.  -->
const obj = {
  a: 1,
  b: function() {
    console.log(this.a)
  },
  c() {
    console.log(this.a)
  },
  d: () => {
    console.log(this.a)
  },
  e: (function() {
    return () => {
      console.log(this.a);
    }
  })(),
  f: function() {
    return () => {
      console.log(this.a);
    }
  }
}

console.log(obj.a) // 1
obj.b()  // 1
;(obj.b)() // 1
const b = obj.b
b() // undefined
obj.b.apply({a: 2}) // 2
obj.c() // 1
obj.d() // undefined
;(obj.d)() // undefined
obj.d.apply({a:2}) // undefined
obj.e() // undefined
;(obj.e)() // undefined
obj.e.call({a:2}) // undefined
obj.f()() // 1
;(obj.f())() // 1
obj.f().call({a:2}) // 1


<!-- 2. -->
    // This is a JavaScript Quiz from BFE.dev

    const obj = {
    a: 1,
    b() {
        return this.a
    }
    }
    console.log(obj.b()) // 1
    console.log((true ? obj.b : a)()) // undefined
    console.log((true, obj.b)()) // undefined
    console.log((3, obj['b'])()) // undefined
    console.log((obj.b)()) // 1
    console.log((obj.c = obj.b)()) // undefined

    The case (obj.b)() works because the function b is invoked immediately after being referenced, and it's still invoked as a method of obj. In contrast, in examples 2, 3, 4, and 6, the function b is first evaluated to a value (a standalone function) by the various operators and then invoked, which causes it to lose its context.

<!-- 3. -->
    const obj = {
        a: 1,
        b: this.a + 1,
        c: () => this.a + 1,
        d() {
            return this.a + 1
        },
        e() {
            return (() => this.a + 1)()
        }
    }
    console.log(obj.b) NaN (this will be window)
    console.log(obj.c()) NaN
    console.log(obj.d()) 2
    console.log(obj.e()) 2

<!-- 4. -->
var bar = 1

function foo() {
  return this.bar++
}

const a = {
  bar: 10,
  foo1: foo,
  foo2: function() {
    return foo()
  },
} 


console.log(a.foo1.call()) // call w/o this is global object - 1 
console.log(a.foo1()) //calls foo1 - foo with context of a - 10
console.log(a.foo2.call()) // call w/o this is global object - 2 
console.log(a.foo2()) // calls foo2- foo- this bound to immediate scope i.e. global - 3

<!-- 5. -->

const obj = {
  prefix: 'BFE',
  list: ['1', '2', '3'],
  log() {
    this.list.forEach(function (item) {
      console.log(this.prefix + item);
    });
  },
};

obj.log();

However, inside the forEach callback function, since it's not the obj invoking callback, this will not point to obj. Rather, it will refer to window hence this.prefix will be undefined

<!-- 6. -->
const a = {
  dev: 'BFE.dev',
  update: name => {
    this.dev = name
  }
}
a.update('bigfrontend.dev')
console.log(a.dev) // "BFE.dev"

<!-- 7. -->

class A {
  static dev = 'BFE'
  dev = 'bigfrontend'
}

class B extends A {
  log() {
    console.log(this.dev)
  }

  static log() {
    console.log(this.dev)
  }
}

B.log() // "BFE" <---
new B().log()// "bigfrontend" <---

explanation :- 

    static keyword in JS can be used to define class properties and method. The use of static implies a single shared copy available to all members of class and it's subclasses.

    static properties can be directly accessed by the class.
    class Book {
    static author = 'foo'
    }

    // is same as direct assignment to `Book` class.

    class Book {}

    Book.author = 'foo'
    static method cannot be accessed directly by individual objects (subclasses)
    class Book {
    static info() {}
    }

    Book.info() // correct. just like properties, methods can be accessed directly by class itself

    const bookObj = new Book();
    bookObj.info() // Error (not allowed)
    So applying the above knowledge to our code snippet yield B.log() to print "BFE" (static property) and new B().log() to "bigfrontend" (non static method inheriting non static property)

