# how Ifram events will handled in parent
    window.onMessage / window.postMessage, check browser support
        //in main window
        window.addEventListener('message',function(message){
        if(message.data.type=="preview.compiled"){
            //do something
        }
        });

        //in iframe
        parent.postMessage({
        type:"preview.compiled",
        other:"other data to pass"
        },"url of main window");

    Broadcast Channel API onMessage/postMessage, check browser support
        //Main window
        var bc = new BroadcastChannel('preview:compiled');
        bc.onmessage = function(message){
        console.log(message.data);
        };

        //iframe
        var bc = new BroadcastChannel('preview:compiled');
        bc.postMessage('Some data');



<!-- In React -->
    Iframe.html
        <!DOCTYPE html>
        <html lang="en">
        <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <title>Document</title>
        </head>
        <body>
        <script>
            window.top.postMessage(
            JSON.stringify({
                error: false,
                message: 'Here we go'
            }),
            '*'
            );
        </script>
        </body>
        </html>

            // in parent component
            bindEvents() {
                window.addEventListener("message", this.onMessageReceived, false);
            }

            onMessageReceived(event) {
                var data = JSON.parse(event.data);
                console.log(data);
                this.loading = false;
                this.render()
            }