https://www.youtube.com/watch?v=VFLNxz_W7Gc&t=33s
https://www.youtube.com/watch?v=fq0Ag8rC5GE&t=65s

https://www.youtube.com/watch?v=gF5cR6mn8ag&t=59s
https://www.youtube.com/watch?v=SFVjbdSEFQ4&t=11s
https://www.youtube.com/watch?v=Eb0cLSCjKNU&t=26s