**Docker**
    What is Docker? 
        Docker represents a lightweight alternative to virtualization. Although Docker does not provide as much isolation as a virtualization, it is practically as lightweight as a process.

        Docker host :- is the system on which the Docker containers run
        Docker containers share the kernel of the operating system on the Docker host
