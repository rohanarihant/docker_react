# arrow vs normal func
    1. No arguments object in arrow functions
    2. Arrow functions do not create their own this binding
    3. Arrow functions cannot be used as constructors
    4. Arrow functions cannot be declared
    5  Arrow functions cannot be accessed before initialization
    6  Arrow functions do not bind their own this, instead, they inherit the one from the parent scope, which is called "lexical scoping"

# This keyword

    2 types of object binding in JS
        implicit and explicit

    Implicit :- when you invoke a func in an object using (.) notation.

    var calC = {
        total: 0,
        add(a){
            this.total += a;
            return this;
        },
        substract(a){
            this.total -= a;
            return this;
        },
    };

    const result = calC.add(10);

    explicit :- can be applies using call, bind and apply.



    This :- mean the context in which we are currently in.


    case 1:
        this.a = 5;
        const getParam(){
            console.log(this.a); //5
        }
        getParam();

    case 2:
        this.a = 5;
        const getParam = () => {
            console.log(this.a); //5
        }
        getParam();


    case 3:
        // this inside the object
        
        let user = {
            name: "Piyush",
            age: 24,
            getDetails(){
                console.log(this.name); // "Piyush" this point to user object 
            }
        }

        user.getDetails();
                                                                                                 
                                                                                    let user = {
                                                                                        name: "Piyush",
                                                                                        age: 24,
                                                                                        getDetails: function(){
                                                                                            console.log(this.name); // "Piyush" this point to user object 
                                                                                        }
                                                                                    }

                                                                                    user.getDetails();

        case 3.1:
                let user = {
                    name: "Piyush",
                    age: 24,
                    childObj: {
                        newName: "Roadside Coder",
                        getDetails(){
                            console.log(`${this.newName} ${this.name}); // this point to childObj object
                            // Roadside Coder undefined
                        }
                    }
                }

                user.childObj.getDetails();

    case 4:
        // this inside arrow function
        
        let user = {
            name: "Piyush",
            age: 24,
            getDetails: () => {
                console.log(this.name); // this point to window object
            }
        }
        user.getDetails() // undefined

        case 4.1
                case 4:
                // this inside arrow function
                
                let user = {
                    name: "Piyush",
                    age: 24,
                    getDetails: () => {
                        const nestedArrow = () => console.log(this.name); // window
                        nestedArrow();  // which means the context of getDetails is user
                    }
                }
                user.getDetails(); // undefined
            
                                                            let user1 = {
                                                                name: "Piyush",
                                                                age: 24,
                                                                getDetails:{
                                                                    name: "Rohan",
                                                                    getDetails: function(){
                                                                    const nestedArrow = () => console.log(this); // this points to the conntext of parent
                                                                    nestedArrow();  // which means the context of getDetails is user
                                                                }
                                                            }
                                                            }
                                                            user1.getDetails.getDetails(); // "Piyush"


        

        case 5: 
            // this in Class
            in class this points to the all of its variable inside the contructor
            class User{
                constructor(n){
                    this.name = n;
                }

                getName(){
                    console.log(this.name);
                }
            }

            const user = new User("piyush");
            console.log(user); // {name: "piyush"}



Question 1:
    const user = {
        firstName: "Piyush",
        getName(){
            const firstName = "Piyush! A";
            return this.firstName;
        }
    }

    console.log(user.getName()); // Piyush

Question 2:

    function makeUser(){
        return{
            name: "john",
            ref: this
        };
    }

    let user = makeUser(); // here func is called and the exact parent is window obj, so op will be nothing
    console.log(user.ref.name);


        function makeUser(){
        return{
            name: "john",
            ref(){
               return this;
            }
        };
        }

        let user = makeUser(); // here this is inside the ref method, which is that object only
        console.log(user.ref().name); // john

Question 3:

    const user = {
        name: "piyush a",
        logMessage(){
            console.log(this.name);
        },
    }
    setTimeout(user.logMessage(), 1000);

    here user.logMessage is passed as a callback and this will not have access to the user obj.
    user will be pointed to the window object and op will be nothing


    solution :
        const user = {
            name: "piyush a",
            logMessage(){
                console.log(this.name);
            },
        }
        setTimeout(function(){
            user.logMessage();
        }, 1000); // "piyush a"

Question 4:

    const user = {
        name: "piyush",
        greet(){
            return `Hello, ${this.name}`;
        },
        farewell: () => {
            return `GoodBye ${this.name}!`;
        }
    }

    console.log(user.greet()); // Hello piyush
    console.log(user.farewell()); // GoodBye ! // this will point to window because of arrow func

Question 5:

    let calculator = {
        read(){
            this.a = +prompt("a = ",0);
            this.b = +prompt("b = ",0);
        },
        sum(){
            return this.a + this.b;
        },
        mul(){
            return this.a * this.b;
        },
    }

    calculator.read(); // read the value in a prompt
    console.log(calculator.sum()) // display the sum of both the numbers


Question 6:

    var length = 4;

    function callback(){
        console.log(this.length);
    }

    const object = {
        length: 5,
        method(fn){
            fn(); // this fn will point to window object and op will be 4 here
        },
    };
    object.method(callback);


    6.1
        
    var length = 4;
    function callback(){
        console.log(this.length);
    }

    const object = {
        length: 5,
        method(){
            arguments[0](); // this will point to parent object which iis array and it will return array length
        },
    };
    object.method(callback,2,3); // 3


Question 7:

    const calc = {
        total: 0,
        add(a){
            this.total += a;
            return this;
        },
        multiply(a){
            this.total *= a;
            return this;
        },
        substract(){
            this.total -= a;
            return this;
        },
        add(){
            this.total += a;
            return this;
        }
    }

    const result = calc.add(10).multiply(5).substract(30).add(10);

    console.log(result.total);




// # this in Arrow Functions

this value wouldn't exist under arrow function, they dont have their own this
value for  this  is resolved  by lexically
js will go to the one step up and check value of this in parent scope


#1
const show = () => {
    console.log(this); // window
}
show();

#2
function test(){
    const parentArrow = () => {
        const childArrow = () => {
            console.log(this); // window
        }
        childArrow();
    }
    parentArrow();
}
test();

#3
function test(){
    console.log(this);
    const parentArrow = () => {
        const childArrow = () => {
            console.log(this); // window
        }
        childArrow();      
    }
    parentArrow();
}
test.call({});

#4
var lang = "JS";
setTimeout(() => {
    console.log(this.lang) // will point to window obj
},1000)


#5
const obj = {
    data: [1,2,3],
    processData: function(){
        this.data.forEach((num) => {
            console.log(num * this.multiplier); //2,4,6
        });
    },
    multiplier: 2
}
obj.processData();


#6
function Person() {
    this.name = 'Jack',
    this.age = 25,
    this.sayHello = function () {
      console.log('Hello', this.name); // Hello Jack
      function innerFunction() {
        console.log(this.age); // undefined
      }
		  innerFunction(); 
	   }
	}
	let x = new Person();
	x.sayHello();

solution :- 
    function Person() {
        this.name = 'Jack',
        this.age = 25,
        this.sayHello = function () {
        console.log('Hello', this.name);
        const innerFunction = () => {
            console.log(this.age);
        }
            innerFunction(); 
        }
        }
        let x = new Person();
    x.sayHello()
 
