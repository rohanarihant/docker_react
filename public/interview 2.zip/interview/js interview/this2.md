This :- value of this not refer to the function in which it is used or it’s scope 
        but is determined mostly by the invocation context of function (context.function()) and where it is called.

function foo(){
	var a =2 ;
	this.bar();
}

function bar (){
	console.log(this.a);
}

foo();   //undefined

As you see in above example this in foo function not refer to the lexical scope of the function. But refer to global scope because it’s the invocation context of the function (window.foo()).


4 rules to understand this
   1. Default Binding
        most common case of func call
            var myFunction = function(){
                console.log(this);
            }
            myFunction(); // window
        we call myFunction from window context so this refers to window context

        var myFunction = function() {
            console.log(this.a);
        }

        var a = 5 ;
        myFunction();    //5 
        
        We defined the variable a in the window context so the output of the myFunction() call will be 5
        because this will refer to window context which it’s the default context

    2. Implicit Binding:
        In this case, The object that is standing before the dot is what this keyword will be bound to.
            function foo(){
                console.log(this.a);
            }

            var obj = {
                a:2,
                foo:foo
            };

            obj.foo();  // 2
            As you see above this will refer to the object obj so the value of this.a will equal 2.

        Noted: if you assign the obj.foo to a variable then this variable will reference to the function itself
            var john = {
                name: 'John',
                greet: function(person) {
                    console.log("Hi " + person +", my name is " + this.name);
                }
            }

            john.greet("Mark");  // Hi Mark, my name is John

            var fx = john.greet;
            fx("Mark");   // Hi Mark, my name is
        
            As we see when you call john.greet(“Mark”) this will refer to the john object so this.name will be John
            But after that when assignment var fx = john.greet;
            So fx will be a reference to the greet function itself so the default binding applies and this will refer to Window.
        
    3. Explicit Binding:
        In this case, you can force a function call to use a particular object for this binding,
        without putting a property function reference on the object.
        so we explicitly say to a function what object it should use for this — using functions such as call, apply and bind

        function greet() {
            console.log(this.name);
        }

        var person = {
            name:'Alex'
        }

        greet.call(person, arg1, arg2, arg3, ...); // Alex

        The apply function is similar to call with the difference that the function arguments are passed as an array.

        function greet() {
            console.log(this.name);
        }

        var person = {
            name:'Alex'
        }

        greet.apply(person, [args]); // Alex

        The bind function creates a new function that will act as the original function but with this predefined.

        So You can use bind to returns a function that you can later execute, but Call/apply use it when you need to call the function immediately.

    4. New Binding
        The function that is called with new operator 
            when the code new Foo(…) is executed, the following things happen:
            1- An empty object is created and referenced by this variable, inheriting the prototype of the function.
            2- Properties and methods are added to the object referenced by this.
            3- The newly created object referenced by this is returned at the end implicitly (if no other object was returned explicitly).
            

            function Foo() {        
                    /*
                    1- create a new object using the object literal 
                    var this = {};
                    */

                // 2- add properties and methods 
                    this.name = 'Osama';
                    this.say = function () {
                    return "I am " + this.name; 
                };

                // 3- return this;
            }

            var name = 'Ahmed';
            var result = new Foo();
            console.log(result.name);  //Osama
        
            By calling Foo() with new in front of it, we’ve constructed a new object and set that new object as the this for the call of fo()

    # Priority
        The highest priority has new Binding
        Then explicit binding and implicit binding.
        The lowest priority has default binding.

    # Arrow Function
        Normal functions abide by the 4 rules we just covered.
        But ES6 introduces a special kind of function that does not use these rules:

            You don’t rebind the value of this when you use an arrow function inside of another function:

                const outerThis = this;

                const func = () => {
                    console.log(this === outerThis);
                };

                new func(); // error
                func.call(null);        //true
                func.apply(undefined);  //true
                func.bind({})();       //true

            this will always refer to the lexical scope and not impact by any rule from the 4 rules
            such as I explicit binding in above example also if you try to use new before arrow function will give an error.
            because arrow functions can’t run with new.
    
            So this in arrow function will always take his value from the outside (Lexical scope).

                var group = {
                    title: "Our Group",
                    students: ["John", "Pete", "Alice"],

                    showList() {
                        this.students.forEach(
                            (student) => { 
                                    // this here refer to group object
                                    console.log(this.title + ': ' + student);
                                    }
                        );
                    }
                };

                group.showList();

            Here in forEach, the arrow function is used,
            so this.title in it is exactly the same as in the outer method showList.
            That is: group.title.

    # Conclusion
        1- The value of this is usually determined by a functions execution context.

        2- In the global scope, this refers to the global object (the window object).

        3- The object that is standing before the dot is what the this keyword will be bound to.

        4- We can set the value of this explicitly with call(), bind(), and apply()

        5- When the new keyword is used(a constructor), this is bound to the new object being created.

        6- Arrow Functions don’t bind this — instead, this is bound lexically (i.e. based on the original context)




# This :-  this refers to the objects that is currently calling the function 

    const age = 28;
    function displayAge(){
        console.log(this.age); // 28
        console.log(this); // window
    }

    displayAge(); // this refers to the window object
    window.displayAge(); // this refers to the window object

    <!-- -------------------------------------------------------------------------------------------------------- -->

    var person = {
        age:26,
        displayAge: displayAge
    }
    person.displayAge();
        // person is currently calling the func and this will be the person object itself.

    <!-- -------------------------------------------------------------------------------------------------------- -->

    var person = {
        age:26,
        displayAge: displayAge,
        nestedPerson: {
            age: 40,
            displayArg: displayArg
        }
    }
    person.nestedPerson.displayArg(); // nestedPerson wll be callig func and this will the nestedPerson object

    <!-- -------------------------------------------------------------------------------------------------------- -->

# Scope of function depends where function is defined
# this in ()=> : based on the scope the Arrow Function is defined within

# Variable vs property
    var person = {
        age:28,
        greet1: function(){
            console.log("Greet 1", this.age);
            console.log("Greet 2", this);
            function greet2(){
                console.log("Greet 3", this.age);
                console.log("Greet 4", this);
            }
            greet2();
        }
    }
    person.greet1();

    // Greet 1 28
    // Greet 2 {age: 28, greet1: f}
    // Greet 1 undefined
    // Greet 1 window

    <!-- -------------------------------------------------------------------------------------------------------- -->
# Cat name
    var person = {
        age:28,
        greet1: function(){
            console.log("Greet 1", this.age);
            console.log("Greet 2", this);
            const greet2 = () => {
                console.log("Greet 3", this.age);
                console.log("Greet 4", this);
            }
            greet2();
        }
    }
    person.greet1();

    // Greet 1 28
    // Greet 2 {age: 28, greet1: f}
    // Greet 1 28
    // Greet 1 {age: 28, greet1: f}


    <!-- -------------------------------------------------------------------------------------------------------- -->
        const object = {
            message: 'Hello, World!',

            getMessage() {
                const message = 'Hello, Earth!';
                return this.message;
            }
        };

        console.log(object.getMessage()); // is a method invocation, that's why this inside the method equals object.
    <!-- -------------------------------------------------------------------------------------------------------- -->
# Delayed greeting
        function Pet(name) {
            this.name = name;

            this.getName = () => this.name;
        }

        const cat = new Pet('Fluffy');

        console.log(cat.getName()); // Fluffy

        const { getName } = cat;
        console.log(getName()); // Fluffy

        When a function is invoked as a constructor new Pet('Fluffy'), this inside the constructor function equals the constructed object.
        this.name = name expression inside Pet constructor creates name property on the constructed object.
        this.getName = () => this.name creates a method getName on the constructed object. And since the arrow function is used,
        this inside the arrow function equals to this of the outer scope — the constructor function Pet.

        getName() is an arrow function that resolves this lexically. In other words, it captures the value of this from the outer function where it is defined.

        An arrow function doesn't change its this value no matter how it is invoked, contrary to the regular function.
    <!-- -------------------------------------------------------------------------------------------------------- -->
# Artificial method
        const object = {
            message: 'Hello, World!',

            logMessage() {
                console.log(this.message); // What is logged?
            }
        };

        setTimeout(object.logMessage, 1000);
        setTimeout(() => object.logMessage(), 1000); // 'Hello, World!'

        After a delay of 1 second, undefined is logged to console
        While setTimeout() function uses the object.logMessage as a callback, still, it inovkes object.
        logMessage as a regular function, rather than a method.
        And during a regular function invocation this equals the global object, 
        which is window in the case of the browser environment.
        That's why console.log(this.message) inside logMessage method logs window.message, which is undefined.
    <!-- -------------------------------------------------------------------------------------------------------- -->
# Greeting and farewell
        const object = {
            message: 'Hello, World!'
        };

        function logMessage() {
            console.log(this.message); // "Hello, World!"
        }
        logMessage.call(object,null);

        
        'Hello, World!' and 'Goodbye, undefined!' are logged to console. Open the demo.
        When calling object.greet(), inside the method greet() this value equals object because greet is a regular function.
        Thus object.greet() returns 'Hello, World!'.
        But farewell() is an arrow function, so this value inside of an arrow function always equals this of the outer scope.

        The outer scope of farewell() is the global scope, where this is the global object.
        Thus object.farewell() actually returns 'Goodbye, ${window.who}!', which evaluates to 'Goodbye, undefined!'.
    <!-- -------------------------------------------------------------------------------------------------------- -->
# Tricky length
        var length = 4;
        function callback() {
            console.log(this.length); // What is logged?
        }

        const object = {
            length: 5,
            method(callback) {
                callback(); // 4
            }
        };

        object.method(callback, 1, 2);

        callback() is called using regular function invocation inside method(). Since this value during a regular function invocation equals the global object, this.length is evaluated as window.length inside callback() function.

        The first statement var length = 4, being in the outermost scope, creates a property length on the global object: window.length becomes 4.

        Finally, inside the callback() function this.length evaluates as window.length — 4 being logged to console.
    <!-- -------------------------------------------------------------------------------------------------------- -->
# Calling arguments
        var length = 4;
        function callback() {
            console.log(this.length); // What is logged?
        }

        const object = {
            length: 5,
            method() {
                arguments[0]();
            }
        };

        object.method(callback, 1, 2);

        3 is logged to console. Open the demo.

        obj.method(callback, 1, 2) is invoked with 3 arguments: callback, 1 and 2.
        As result the arguments special variable inside method() is an array-like object of the following structure:
            {
                0: callback,
                1: 1, 
                2: 2, 
                length: 3 
            }
        Because arguments[0]() is a method invocation of callback on arguments object, this inside the callback equals arguments.
        As result this.length inside callback() is same as arguments.length — which is 3.
    <!-- -------------------------------------------------------------------------------------------------------- -->
    <!-- -------------------------------------------------------------------------------------------------------- -->
    <!-- -------------------------------------------------------------------------------------------------------- -->
    <!-- -------------------------------------------------------------------------------------------------------- -->
