// #1


console.log("value is", age); // undefined

var age = 20;

console.log("value is", age); // 20

// hoisting will work here


// #2
age = 100;
console.log("value is", age); // ref error, cann't access age before initialization

let age = 20;

// because let var declaration will keep that var in temporal dead zone until value assignment


// #3
    myFunc(); // second

    var myFunc = function(){
        console.log("first");
    }
    myFunc(); // first

    function myFun(){
        console.log("second");
    }
    myFunc(); //first

    // first myFunc var is declared to  undefined then func defination will override this
    // after 1st func call myFunc is overriden by a func which will return "first" log

// #4
    var variable = 10;

    (() => {
        console.log(variable); // 10
        variable = 20;
        console.log(variable); // 20
    })();

    console.log(variable); // 20
    var variable = 30;

// #5
    var variable = 10;

    (() => {
        console.log(variable); // undefined
        var variable = 20;
        console.log(variable); // 20
    })();

    console.log(variable); // 10
    var variable = 30;

// #6
    foo = 30;
    console.log("FOO", foo); // FOO 30

    var foo = 100;
    console.log("FOO", foo); // FOO 100

// #7
    variable = 10;
    (() => {
        foo =100;
        console.log(variable); // 10
        var foo = 100;
        variable = 20;
        console.log(variable); // 20
    })();

    console.log(foo); // 100
    console.log(variable); // 10
    var variable = 30;

// #8
    for(var i=0;i<10;i++){
        setTimeout(() => console.log(i),0);
    }

    // when the iteration will end i will reach to 10;
    // after all iteration setTimeout start loging the i will be 10

// #9
    var fullName = "Rohan A";
    var obj = {
        fullName: "hacked fullname",
        prop: {
            fullName: "Inside props",
            getFullName: function(){
            return this.fullName;
            }
        },
        getFullName: () => this.fullName,
        getFullNameV2: () => this.fullName,
        getFullNameV3: (function() {
            return this.fullName;
        })(),
    }
    console.log(obj.prop.getFullName()) // "Inside props"
    console.log(obj.getFullName()) // "Rohan A"
    console.log(obj.getFullNameV2()) // "Rohan A"
    console.log(obj.getFullNameV3()) //  TypeError: obj.getFullNameV3 is not a function
    console.log(obj.getFullNameV3) //  "Rohan A"

//  #10
    const piyush = {
        name: "Piyush garg",
        sayName: function(){
            console.log(this.name)
        },
    };

    const john = {
        name: "John Doe",
        sayName: function(){
            console.log(this.name);
        }
    }

    john.sayName.call(piyush); // "Piyush garg"

// # 11
const piyushh = {
    name: "piyush garg",
    sayName: function(){
        console.log(this.name)
    }
}

setTimeout(piyushh.sayName, 3*1000 ) // undefined (this -> window)

// # 12
const obj = {
    height: 30
};

console.log(obj.height); // 30
delete obj.height;
console.log(obj.height); // undefind

// #13
const obj = Object.create({
    height: 30
});
// Object.create will add the properties to  prototype 
// so it will not be able  to delete the properties
console.log(obj.height); // 30
delete obj.height;
console.log(obj.height); // 30

// #  13
console.log("a");
setTimeout(() => console.log("set"),0);
Promise.resolve(() => console.log("Pro").then((res) => res()))
console.log("b");

// a b Pro set

// # 14
let a = ['a','b','c'];
let b = ['a','b','c'];

console.log(a === b)  // false (obj ccomparison)
console.log(JSON.stringify(a) === JSON.stringify(b)); // true (string comparison)

// JSON.stringify will translate the  array to string and then compare it 

// #15
console.log(2 + true); // 3

// #16
console.log([] == ![]); // true

// This is an example of a tricky comparison involving truthy and falsy values.
// The ! operator negates the truthiness of an object. An empty array [] is truthy,so ![] evaluates to false.
// When comparing [] with false, JavaScript performs type coercion, converting false to a numeric value (0).
// Thus, the expression becomes [] == 0, and due to another type coercion, the empty array is converted to an empty string '',
// which is also converted to the numeric value 0. Hence, the expression 0 == 0 evaluates to true.

// #17
console.log(NaN === NaN);

// NaN (Not a Number) is a special numeric value in JavaScript, and interestingly, NaN is not equal to itself. Therefore, the expression NaN === NaN evaluates to false.

// #18
console.log('5' - - '3'); // 8

// The unary - operator can be used to convert a string to a number. In this case, - '3' converts the string '3' to the number -3.
// Then, the expression becomes '5' - (-3), which is equivalent to '5' + 3. JavaScript performs string concatenation since one of the operands is a string, resulting in the string '53'.
// Finally, the result is converted to a number, yielding 8.

// #19
console.log(null == undefined); // true

// In JavaScript, null and undefined are considered equal only when using loose equality (==).
// Therefore, null == undefined evaluates to true.






