js interview questions

#1
let input = "headphone";
let dictionary = new Set(["head","phone","ache", "wire"]);

const matchedWords = getMatchedWords(input, dictionary);


#2
var a = 10;
function check(){
    if(a > 20){
        var a = 20; // var a declaration will be hoisted
    }
    console.log(a) // undefind
}
check()

#3
var c =10;
if(function f(){}){
    c += typeof f; // f will be undefined here
}
console.log(c); // 10undefind

#4
var x = 10;
var output = (function(){
    delete x; // variable can't be deleted, only object keys
    return x;
})();
console.log(output) // 10

#5
var a = 10
b = 20;
let c = 30;
let d = 40;
delete a;
delete b;
delete c;
delete d;
console.log(a); // 10
// console.log(b); // will be deleted because directly assigned to window object
console.log(c); // 30
console.log(d); // 40

#6

let string = "abc";
string[1] = "e";
string[2] = "f";
console.log(string) // abc
// bacause striing is immutable can't be directly assigned or mutate

#7
let bar = null; // null is also a object type
typeof bar === "object" // true (typeof null is "object")
console.log(toString.call(bar)) // [object null]

#8
(function(){
  var a = b = 3; // a is locally assigned but b is globally assigned
})();
console.log(a) // a is not defined (Error sttop execution)
console.log(b) // 3
console.log("a defined? " + (typeof a !== 'undefined')); // false
console.log("b defined? " + (typeof b !== 'undefined')); // true

#9
var myObject = {
    foo: "bar",
    func: function() {
        var self = this;
        console.log("outer func:  this.foo = " + this.foo); // refer thiis to myObject o/p - bar
        console.log("outer func:  self.foo = " + self.foo); // refer thiis to myObject o/p - bar
        (function() {
            console.log("inner func:  this.foo = " + this.foo); // this is no longer refer to myObject
            console.log("inner func:  self.foo = " + self.foo); // self is a local variable sttill in scope and refer to bar value
        }());
    }
};
myObject.func();


<!--  -->
function sayHi(){
    console.log(name);
    console.log(age);
    var name = "rohan"; // undefined
    let age = 10; // Ref error
}

sayHi();

<!--  -->
console.log("9" > "11"); true // in string comparison letter by lettter comparison 9 is greater then 1
console.log("9" > 11); false // string will be converted to number
console.log("" > -1); true // 0 > -1
console.log("Rowdy" > 1); false

<!--  -->
const person1 = {
    name: "Rohan",
    age: 21,
    name: "Sonia"
}
console.log(person1) // {name: 'Sonia', age: 21} override the recent value

<!--  -->
const person1 = {
    name: "Rohan",
    age: 21
}
const person2 = {
    name: "Rohan",
    age: 21
}

console.log(person1 == person2) // false // comparing the memory ref
console.log(person1 === person2) // false

<!--  -->
console.log(3+3+"3"+3+3) // 6333
        // 6+"3"+3+3
        // "63"+3+3
        //  "633"+3 = 6333
console.log(1+2+3+4+5+"6") // 156 -> 15+"6"

<!--  -->
string are compared letter by letter in dictionary order

console.log("good" > "bad"); // true
console.log("Like" > "like"); // true capittal is greatter then lower
console.log("Subscriber" > "Subg"); // true
console.log("SubScribe" > "Subg"); // false

<!--  -->

&& -> return left operand if it can be converted to false, otherwise right operand
|| -> return left operand if it can be converted to true, otherwise right operand

console.log((1 && 2) || (0||3));  // 2
console.log(null && undefined); null
console.log(0 || 1 && 2||3); // 2
console.log(null || 2 && 3 || 4); // 3

<!--  -->
const h1 = {h:"Thor", i:"IM"}
const h2 = {h:"Thor", i:"IM"}
const h3 = h2;
console.log(h1 == h2); // false
console.log(h1 === h2); // false
console.log(h2 === h3); //  true

const array1 = [1,2,3];
const array2 = [1,2,3];
const array3 = array2;
console.log(array1 === array2); // false
console.log(array2 === array3); // true

const User = function(name){
    this.name = name
}

const user1 = new User("Rowdy");
const user2 = new User("Rowdy");
console.log(user1 == user2) //  false


<!--  -->
'111'+1 = 1111
'111'-1 = 110
typeof null -> object
typeof NaN -> number
NaN === NaN // false
0 === [] false
0 == [] true
[] + 1 // 1
[] + '1' // '1'
[] - 1 // -1
{} + [] // 0
{} === [] // false

<!--  -->

const len = 4;
const val = [];
for(var i=0;i < len;i++);{ // for loop will not execute the code in {}, it will end with ;
    val.push(i+1);
}
console.log(val);
// [5]

<!--  -->
data = "please like and subscribe"
searchtext = "a";
data = data.split(searchtext);

console.log(data) //  ['ple', 'se like ', 'nd subscribe']
console.log(data.length-1); // 2

<!--  -->
const obj = {
    name: "conner",
    getName: function(){
        return this.name
    }
}

const getName = obj.getName;
getName(); // conner

<!--  -->
const arr = ["foo","bar"]
arr[10]= "baz";
console.log(arr); // ["foo","bar",<8 empty items>,"baz"]
console.log(arr.length) // 11
arr.length = 1;
console.log(arr) //["foo"]



# HOISTING
<!-- 1. -->
    function test(){
        var x;
        var x;
        console.log("x is"+x); // x isundefined
    }
    test();

<!-- 2. -->
    function test(){
        var x=1;
        {
            var x=2;
            console.log(x); //2
        }
        console.log(x); //2
    }

    function test2(){
        let x=1;
        {
            let x=2;
            console.log(x); //2
        }
        console.log(x); //1
    }

<!-- 3. -->
    function do_something(){
        console.log(bar); // undefined
        var bar = 111;
        console.log(bar); // 111
    }

    do_something();

<!-- 4. -->
var rate = 10;
function getRate(){
    if(rate === undefined){
        var rate = 6;
        return rate;
    }else{
        return 10;
    }
}

console.log("Rate is",getRate()); // Rate is 6

<!-- 5. -->

{
    const func = () => console.log(letVar);
    let letVar = 3;
    func(); // 3
}

<!-- AI Dash old -->
console.log("Start")

setTimeout(() => {
console.log("1")
}, 0)

console.log("2")

new Promise((res, rej) => {
res("3")
}).then((value) => {
console.log(value)
})

Promise.resolve("0").then(console.log)

console.log("4")

// sttart 2 4 3 0 1

<!-- what will be output of following and how should you correct it. -->
class A {
propertyX = "PropertyX"
foo {
console.log(this.propertyX)
}
}

class B {
bar(hoc) {
hoc()
}
}

let a = new A()
let b = new B()

b.bar(a.foo)

the this is undefined in that call  we  assigned  it expectidly
// b.bar(function() { a.foo(); });
// b.bar(a.foo.bind(a))

<!-- what will be output of following : -->

const parent = () => {
let x = 0
return () => {
return ++x;
}
}

const callOne = parent()
const callTwo = parent()

// each instance will have a seperate variable value of x
console.log(callOne())  // 1
console.log(callTwo())  // 1
console.log(callOne())  // 2
console.log(callTwo())  // 2
console.log(callOne())  // 3
console.log(callTwo())  // 3
console.log(callOne())  // 4

<!--  -->
const a = (1,2,3)
console.log(a) // 3

<!--  -->
const entries = [1,2,3,4].entries()
for (const [, item] of entries) {
  console.log(item) // effectively the same as entries.next()
  break;
}
for (const [, item] of entries) {
  console.log(item)
  break;
}

// 1
// 2
        The entries() method returns a new array iterator object that contains the key/value pairs for each index in the array.
        When we run the for...of loop over this iterable, it will repeatedly call the iterator's next() method to produce the sequence of values i.e, 
        in this case, the array elements 1,2,3 and 4 (since we have destructured the array elements as item in the for...of loop itself).

        In the first for...of, it console logs 1 and then encounters a break statement causing the control to go outside the loop,
        but the iterator is not yet completely iterated. So in the second for...of it simply resumes
        from where we last stopped and prints the next array element i.e. 2 because the iterable is the same.


<!--  -->
function func() {
  try {
    console.log(1)  // <-- logs 1
    return      // <-- exit the function AFTER executing finally block
  } catch (e) {
    console.log(2)   // Will gets executed in case of an error in try block
  } finally {
    console.log(3)   // <-- logs 3
  }
  console.log(4)     // <-- logs 3
}

func()

// A finally blocks says "no matter what happens, run this code block after trying to run the code in try block"
// try -->exit from function after executing --> finally

<!--  -->
Here, we created a custom error object stored in error. Updating error.name only updates the name property, it doesn't mean the prototype is also updated. If we recall how instanceOf works, we'll understand why error is instanceOf Error and not SyntaxError

The instanceof operator tests to see if the prototype property of a constructor appears anywhere in the prototype chain of an object.

In the case of clonededError we are making use of the structuredClone() method that creates a deep clone of a given value using the structured clone algorithm. The reason why clonedError is an instance of SyntaxError, is because SyntaxError is a serializable object and is cloned by structuredClone().

In simple words, when we use structuredClone to clone error, it'll actually set the prototype of clonededError to SyntaxError using the error.name property. This results in clonededError instanceof SyntaxError evaluate to true

const error = new Error('😢')
error.name = 'SyntaxError'
console.log(error instanceof Error) // true
console.log(error instanceof SyntaxError) // false

const clonededError = structuredClone(error)
console.log(clonededError instanceof Error) // true
console.log(clonededError instanceof SyntaxError) // true



