<!-- 1 -->
console.log(++[[]][+[]]+[+[]]) // "10"
        var a = ++[[]][+[]];
        var b = [+[]];

        // so a == [] and b == [0]

        ++a;

        // then a == 1 and b is still that array [0]
        // when you sum the var a and an array, it will sum b as a string just like that:

        1 + "0" = "10"

<!--  -->
console.log("0" == 0)   // true
console.log("0" === 0)  // false
console.log({} == {})   // false
console.log({} === {})  // false
console.log(undefined == null)  // true
    In other words, when you do x == y, if x and y are not of the same type, JavaScript will cast one value to another before comparing,
    like if string and number are compared, the string is always cast into a number and then compared
console.log(undefined === undefined)    // ture
console.log(NaN == NaN) false
console.log([] == []) // false


# ==
    If Type(x) is the same as Type(y), then
    If Type(x) is Undefined, return true.
    If Type(x) is Null, return true.
    If Type(x) is Number, then
    If x is NaN, return false.
    If y is NaN, return false.
    If x is the same Number value as y, return true.
    If x is +0 and y is −0, return true.
    If x is −0 and y is +0, return true.
    Return false.


<!--  -->
console.log([] == true) // false 
    The first step of coercion is to convert any non primitive types to primitive types,
    then using a set of rules convert the left, right or both sides to the same type
console.log(![] == true) // false
    The value ![] is false, because [] is an Object (arrays are objects) and all objects, not including null, are truthy.
    So any array, even if it is empty will always be a truthy, and the opposite of a truthy is always false

