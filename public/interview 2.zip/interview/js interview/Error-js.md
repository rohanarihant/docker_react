# Reference error

    console.log(a);

    * trying to access a but its not defined
    show the Refrence error

    console.log(a);
    let a = 10;
    * cannot access 'a' before initialization
         whenever we try to get any variable from temporal dead zone. it gives us a Ref error.

    const a;
    a=100;
    *Missing initializer in the const declaration


# Type error
    getName()
  getName is not a function


# Syntax error
    1.  let a = 100;
        var a=10; //  SyntaxError: Identifier 'a' has already been declared

    2.  let a = 20;
        {
            var a = 10;
        }
        or
        let a =10;
        let a =5;
        console.log(a)
    * indentifier a has already been declared



