Variables

    Number
        The number type represents both integer and floating point numbers.
        
        Infinity represents the mathematical Infinity ∞. It is a special value that’s greater than any number.
        
        NaN represents a computational error. It is a result of an incorrect or an undefined mathematical operation, for instance:

    BigInt
        BigInt type was recently added to the language to represent integers of arbitrary length.
        To be really precise, the “number” type can store larger integers (up to 1.7976931348623157 * 10308), but outside of the safe integer range ±(253-1) there’ll be a precision error, because not all digits fit into the fixed 64-bit storage. So an “approximate” value may be stored.

        // the "n" at the end means it's a BigInt
        const bigInt = 1234567890123456789012345678901234567890n;
    
    String
        A string in JavaScript must be surrounded by quotes.
        let name = "John";

    Boolean (logical type)
        The boolean type has only two values: true and false.

    Null
        The special null value does not belong to any of the types described above.
        It forms a separate type of its own which contains only the null value.

            let age = null;
            It’s just a special value which represents “nothing”, “empty” or “value unknown”.

    Undefined
        The special value undefined also stands apart. It makes a type of its own, just like null.
        The meaning of undefined is “value is not assigned”.
        
        If a variable is declared, but not assigned, then its value is undefined:

        let age;
        alert(age); // shows "undefined"
        undefined is reserved as a default initial value for unassigned things.

    Objects and Symbols
        All other types are called “primitive” because their values can contain only a single thing (be it a string or a number or whatever). In contrast, objects are used to store collections of data and more complex entities.

        Being that important, objects deserve a special treatment. We’ll deal with them later in the chapter Objects, after we learn more about primitives.

        The symbol type is used to create unique identifiers for objects. We have to mention it here for the sake of completeness, but also postpone the details till we know objects.

    *Typeof operand
        The typeof operator returns the type of the operand. It’s useful when we want to process values of different types differently or just want to do a quick check.

        Math is a built-in object that provides mathematical operations. We will learn it in the chapter Numbers. Here, it serves just as an example of an object.

        The result of typeof null is "object". That’s an officially recognized error in typeof, coming from very early days of JavaScript and kept for compatibility. Definitely, null is not an object. It is a special value with a separate type of its own. The behavior of typeof is wrong here.

        The result of typeof alert is "function", because alert is a function. We’ll study functions in the next chapters where we’ll also see that there’s no special “function” type in JavaScript. Functions belong to the object type. But typeof treats them differently, returning "function". That also comes from the early days of JavaScript. Technically, such behavior isn’t correct, but can be convenient in practice.



<!-- Seven primitive data types: -->

    number for numbers of any kind: integer or floating-point, integers are limited by ±(253-1).
    bigint for integer numbers of arbitrary length.
    string for strings. A string may have zero or more characters, there’s no separate single-character type.
    boolean for true/false.
    null for unknown values – a standalone type that has a single value null.
    undefined for unassigned values – a standalone type that has a single value undefined.
    symbol for unique identifiers.

<!-- And one non-primitive data type: -->
    object for more complex data structures.
