# Promise
promise is an object ,which is represent eventual completion or failure of asynchronous operation.

it allow handling asynchronous operation in more readable and manageable way
    Three States of Promises:
        Pending:
            The initial state, representing that the promise is still pending and the asynchronous operation has not completed.

        Fulfilled:
            The state in which the promise has successfully completed, and the associated value is available.

        Rejected:
            The state in which the promise has encountered an error or was unable to complete, and the reason for failure is available.

    Callback Function:
        A callback function is a function passed as an argument to another function, which is then invoked or executed inside the outer function.
         Callbacks are commonly used in asynchronous operations, event handling, and functional programming.

    Why do we need callbacks?
        Callbacks are essential for handling asynchronous operations and ensuring that certain code executes only after the completion of a task.
        They help manage the flow of control in situations where operations take time to complete, such as fetching data from a server or reading a file.
    
    Callback Hell:
        Callback Hell, also known as “Pyramid of Doom”.
        its occurs when multiple nested callbacks are used, and leads to code that is difficult to read and maintain.
        It often happens in asynchronous JavaScript when dealing with multiple asynchronous operations.

        how to avoid callback hell
            Modern JavaScript uses features like Promises and async/await to mitigate callback hell and improve code structure.

