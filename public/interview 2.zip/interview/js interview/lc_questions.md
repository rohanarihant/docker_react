<!-- Flipkart -->
    First round was Machine coding
    We had to make something Gmail
    Second Round was UI tech
    I was asked to make a alert with a backdrop
    Third round Problem solving
        {
            a : {
                b : (a,b,c)=>a+b+c,
                c : (a,b,c) => a+b-c,
                },
                d : (a,b,c) => a-b-c
        }

        Create a function
        Fn(obj)(1,1,1);
        output
        {
            a : {
                b : 3,
                c : 1
                }
                d: -1
        },


        2. Implement LRU Cache in JS 
        3. return the missing number from 2 arrays

<!-- CISCCO -->
        Profile - UI Engineer 1 - Javascript/React/Typescript
        Experience -1 year
        Location - Bangalore

        First Round- Javascript programing assessment

        Question1) https://leetcode.com/discuss/interview-question/490066/efficient-janitor-efficient-vineet-hackerrank-oa
        Question2) sum of double base palindromes with range 1 to given number
        Question3) It was to count the number of words in the given string, two words seperated by - were to be merged, all the other special characters had to be removed
        Question4) https://www.hackerrank.com/contests/projecteuler/challenges/euler072/problem