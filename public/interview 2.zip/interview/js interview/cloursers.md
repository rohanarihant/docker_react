# Clousers

    clousers is a function that references a variable in the outer scope from its inner scope

    <!-- #1  -->
    function makeFunc(){
        var name = "Mozilla";
        function displayName(num){
            console.log(name, num);
        }
        return displayName;
    }

    makeFunc()(5); // Mozilla 5

    <!-- #2  -->
    let count = 0;
    (function printCount(){
        if(count === 0){
            let count = 1;
            console.log(count); // 1
        }
        console.log(count); // 0
    })()

    <!-- #3  -->
    function createBase(a){
        return function(b){
            return a+b;
        }
    }
    var addSix = createBase(6);
    console.log(addSix(10)); // 16
    console.log(addSix(21)); // 27
    
    sol :- we can create a clouser to keep the value passed to a function createBase even function is returned

    <!-- #4  -->
    function find(index){
        let a = [];
        for(let i=0;i< 1000000; i++){
            a[i]= i*i;
        }
        console.log(a[index]);
    }

    console.time("6")
    find(6);
    console.timeEnd("6")
    console.time("12");
    find(12);
    console.timeEnd("12")

    # taking so much of ttime
      to optimize this lets create one clousers which refer to all of the variables and inner function will send the index


    function find(){
        let a = [];
        for(let i=0;i< 1000000; i++){
            a[i]= i*i;
        }
        return function(index){
            console.log(a[index]);
        }
    }
    const clouser = find();
    console.time("6")
    clouser(6);
    console.timeEnd("6")
    console.time("12");
    clouser(12);
    console.timeEnd("12")

    <!-- #5  -->
    function counter(){
        var _counter = 0;
        function add(increment){
            _counter += increment;
        }
        function retrive(){
            return `counter = ${_counter}`;
        }

        return {
            add,
            retrive
        }
    }

    const c = counter();
    c.add(5);
    c.add(10);
    console.log(c.retrive());

    <!-- #6  -->
    // Module  Pattern

    var Module = (function(){
        function privateMethod(){
            console.log("Private")
        }
        return {
            publicMethod: function(){
                console.log("Public")
            }
        }
    })()

    Module.privateMethod(); // typeerror privateMethod is not a func
    Module.publicMethod();  // Public

    <!-- #7  -->
    call this function only once

    let view;
    function likeTheVideo(){
        let counter = 0;
        return function(){
            if(counter > 0){
                console.log("FUnction is called");
            }else {
                view = "Coder";
                console.log("called first time");
                counter++;
            }
        }
    }
    likeTheVideo();
    likeTheVideo();
    likeTheVideo();
    likeTheVideo();
    likeTheVideo();
    likeTheVideo();

    <!-- #8  -->
    once polyfill

    function once(func, context){
        let ran;

        return function(){
            if(func){
                ran = func.apply(context || this, arguments)
                func = null;
            }
            return ran;
        }
    }

    const hello = () => console.log("Hello");
    hello();
    hello();
    hello();
    hello();
    hello();

    <!-- #9  -->
    Diff between clousers and scope

    clousers = create one fun inside another fun, the inner fun is the clouser, it can use the outer func car at a later point

    scope = defines what variable you have access to
    2 types of scopes
    global and local


