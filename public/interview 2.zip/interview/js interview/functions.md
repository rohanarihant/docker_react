<!-- Pure Functions -->

a function which will return the same result with the same argument
we don't mutate anything outside of the function inside it

const addToCart = (cart, item, quantity) => {
    cart.items.push({
        item,
        quantity
    });
    return cart;
}
push always mutates array, its a side effect

const addToCart = (cart, item, quantity) => {
    return {
        ...cart,
        items: [...cart.items, {item, quantity}]
    }
}
here we are not mutating the direct array

Side Effects :- 
working with the API/Fetching the data
working witth local storage
working with DOM Tree
web sockets
can't access any outside variable 
dont have Math.random or new Date because everytime they will return the diff value

<!-- nullish coalescing -->
if left side value is fasly then return right side value otherwise left side value
console.log(null ?? 10) // 10
console.log(undefined ?? 55) // 55
<!-- optional chaining -->
is the conditional && operator
check the left side value and return the right side value
console.log(undefined && 55) // undefined
<!-- Objects -->

class Person{
    constructor(){
        this.name = "hello"
    }
    sayHello(){
        console.log("hello");
    }
}

const p = new Person();
console.log(Object.getPrototypeof(p))
console.log(p insanceOf Person); // true


<!-- diff between class and object -->
class :- a approach to coupling the data the method that modify the data together 
that Person class is having method that use the member of the class
class is like a blueprint of what object needs to look like to construct the instance of it

Object :- can potentially achieve the same thing but,  its a lower level contruct because at the end of the day 
const p = new Person();
this p is an object 