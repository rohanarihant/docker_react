normal file execution

    <script src="" />
        html parsing going on and stopeed                                             then html parsing continues
                                        fetch the script from server
                                                                    execute the scripts
                                                                                       

async 

        html parsing going on and stopeed                  then html parsing continues
 parallely fetched the script from server
                                        execute the scripts
                                                                                

    * it doesn't guarenty the order of execution of script for multiple scripts
    * can't useful for interdependent scripts


defer

        html parsing going will not stop and continuesly going on
        parallely fetched the script from server
                                                execute the scripts

    

     * defer does guarenty the order of execution of script
